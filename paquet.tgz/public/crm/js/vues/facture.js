// =============================================================================
// Fiche d'une facture ou d'un devis : le document tel que le client le reçoit
// (il s'imprime tel quel), les paiements, l'historique, et la suite logique selon
// l'état — émettre, encaisser, faire accepter, transformer un devis en facture.
// =============================================================================
import { h, idUnique, paragraphes } from "../noyau/dom.js";
import { etat, fiche, liees, libelleFiche, nomFiche } from "../noyau/etat.js";
import { lienFiche, naviguer, cheminFiche } from "../noyau/routeur.js";
import { actionFacture, retirerPaiement, supprimerAvecAnnulation, tenter } from "../noyau/ecriture.js";
import { ErreurApi } from "../noyau/api.js";
import { aujourdhui } from "../commun/dates.js";
import { calculerTotaux, montantLigne } from "../commun/calculs.js";
import { ENTITES, MODES_PAIEMENT } from "../commun/schema.js";
import { validerObjet } from "../commun/valider.js";
import { argent, dateCourte, dateLongue, echeanceRelative, nombre, nomComplet, pluriel, tauxTaxe, telephone as fmtTel } from "../commun/format.js";
import { btn, btnIcone, enTete, menuActions, panneau, avis, tampon, pastille } from "../ui/composants.js";
import { creerChamp } from "../ui/formulaire.js";
import { ouvrirDialogue, confirmer } from "../ui/dialogue.js";
import { journal } from "../ui/journal.js";
import { ouvrirCourriel, variablesCourriel } from "../ui/courriel.js";
import { toast } from "../ui/toast.js";
import { etatDocument, soldeDu, libelleOption, dateSansAnneeCourante } from "./aides.js";
import { modifierLaFiche } from "./formulaires.js";
import { creerVueFiche, marquesFiche, panneauClient, piedFiche } from "./fiche.js";

export const depend = ["factures", "entreprises", "contacts", "dossiers", "opportunites", "config"];

// ----- Petites aides -------------------------------------------------------------------------------------------------------------------------------
const estDevis = (f) => f.type === "devis";
const estBrouillon = (f) => f.statut === "brouillon";
const nomDoc = (f) => (estDevis(f) ? "devis" : "facture");
const totauxDoc = (f) => f.totaux || calculerTotaux(f.lignes || [], f.taux || etat.config.taxes, f.paiements || []);
const factureIssueDe = (devis) => liees("factures", "devis_id", devis.id)[0] || null;
const tonTampon = (ton) => (ton === "info" ? "neutre" : ton);
/** États définitifs : le tampon de la page et du document. L'état « en retard » n'est qu'une alerte de la page. */
const TAMPONS_PAGE = new Set(["payee", "annulee", "acceptee", "refusee", "expiree", "en_retard"]);
const TAMPONS_DOCUMENT = new Set(["payee", "annulee", "acceptee", "refusee"]);

/** Le contact auquel écrire : celui de la fiche, sinon un contact de l'entreprise qui a un courriel. */
function contactDe(f) {
  const c = f.contact_id ? fiche("contacts", f.contact_id) : null;
  if (c && !c.supprime) return c;
  return liees("contacts", "entreprise_id", f.entreprise_id).find((x) => !x.archive && x.courriel) || null;
}

const sauts = (lignes) => lignes.filter(Boolean).flatMap((l, i) => (i ? [h("br"), l] : [l]));

// ----- Actions ---------------------------------------------------------------------------------------------------------------------------------------
/** Imprime le document ; le titre de la page devient le nom proposé pour le PDF. */
function imprimer(f) {
  const avant = document.title;
  document.title = [libelleFiche("factures", f), nomFiche("entreprises", f.entreprise_id)].filter(Boolean).join(" — ");
  const retablir = () => {
    document.title = avant;
    removeEventListener("afterprint", retablir);
  };
  addEventListener("afterprint", retablir);
  window.print();
}

async function emettre(f) {
  if (!(f.lignes || []).length) {
    toast("Ajoutez au moins une ligne avant d’émettre ce document.", { ton: "erreur" });
    return;
  }
  const t = totauxDoc(f);
  const ok = await confirmer({
    titre: estDevis(f) ? "Émettre ce devis ?" : "Émettre cette facture ?",
    message: `Un numéro lui sera attribué et ses lignes ne pourront plus être modifiées. ${estDevis(f) ? "Le devis" : "La facture"} pour ${nomFiche("entreprises", f.entreprise_id)} totalise ${argent(t.total)}.`,
    detail: h("p.muet.petit", "Rien n’est envoyé au client automatiquement : vous pourrez l’imprimer ou l’envoyer par courriel ensuite."),
    libelleConfirmer: estDevis(f) ? "Émettre le devis" : "Émettre la facture",
  });
  if (!ok) return;
  const r = await tenter(() => actionFacture(f.id, "emettre"), { entite: "factures" });
  if (!r?.fiche) return;
  const e = r.fiche;
  toast(`${estDevis(e) ? "Devis" : "Facture"} ${e.numero} ${estDevis(e) ? "émis" : "émise"}.`, {
    duree: 9000, action: { libelle: "Imprimer", onclick: () => imprimer(fiche("factures", e.id) || e) },
  });
}

async function statutDevis(f, statut) {
  const r = await tenter(() => actionFacture(f.id, "statut-devis", { statut }), { entite: "factures" });
  if (!r) return;
  const message = { acceptee: "Devis accepté.", refusee: "Devis marqué comme refusé.", envoyee: "Devis remis à « émis »." }[statut];
  toast(message, {
    ton: statut === "refusee" ? "info" : "ok", duree: statut === "envoyee" ? undefined : 9000,
    action: statut === "envoyee" ? null : { libelle: "Annuler", onclick: () => tenter(() => actionFacture(f.id, "statut-devis", { statut: "envoyee" }), { entite: "factures", succes: "Changement annulé." }) },
  });
}

async function creerFactureDepuisDevis(d) {
  const r = await tenter(() => actionFacture(d.id, "vers-facture"), { entite: "factures" });
  if (!r?.fiche) return;
  toast(`Facture créée à partir du devis ${d.numero}. Vérifiez-la, puis émettez-la.`, { duree: 7000 });
  naviguer(cheminFiche("factures", r.fiche.id));
}

async function dupliquer(f) {
  const r = await tenter(() => actionFacture(f.id, "dupliquer"), { entite: "factures" });
  if (!r?.fiche) return;
  toast(`Brouillon créé à partir de ${f.numero || "ce document"}.`);
  naviguer(cheminFiche("factures", r.fiche.id));
}

async function annulerFacture(f) {
  if ((f.paiements || []).length) {
    toast("Cette facture a des paiements. Retirez-les d’abord si vous voulez l’annuler.", { ton: "erreur" });
    return;
  }
  const ok = await confirmer({
    titre: `Annuler la facture ${f.numero} ?`,
    message: "Elle reste dans vos registres, marquée « Annulée », et son numéro n’est pas réutilisé. Elle ne compte plus dans les montants à recevoir. Cette action ne peut pas être défaite.",
    libelleConfirmer: "Annuler la facture", libelleAnnuler: "Garder la facture", danger: true,
  });
  if (!ok) return;
  await tenter(() => actionFacture(f.id, "annuler"), { entite: "factures", succes: `Facture ${f.numero} annulée.` });
}

function ecrireAuClient(f, gabaritId, { titre, aide = "" }) {
  const contact = contactDe(f);
  return ouvrirCourriel({
    titre, gabaritId, aide, destinataire: contact?.courriel || "",
    variables: variablesCourriel({ contact, entreprise: f.entreprise_id ? fiche("entreprises", f.entreprise_id) : null, facture: f }),
    lier: { lieType: "factures", lieId: f.id, lie2: f.entreprise_id ? { type: "entreprises", id: f.entreprise_id } : null },
  });
}
const envoyerDocument = (f) =>
  ecrireAuClient(f, estDevis(f) ? "envoi-devis" : "envoi-facture", {
    titre: estDevis(f) ? "Envoyer le devis" : "Envoyer la facture",
    aide: "Le document n’est pas joint automatiquement : cliquez sur « Imprimer », choisissez « Enregistrer au format PDF », puis joignez le fichier à votre courriel.",
  });
const envoyerRappel = (f) => ecrireAuClient(f, "rappel-facture", { titre: "Rappel de paiement" });

// ----- Paiements -----------------------------------------------------------------------------------------------------------------------------------
function ouvrirPaiement(id) {
  const f0 = fiche("factures", id);
  if (!f0) return null;
  const solde = soldeDu(f0);
  const champs = ENTITES.factures.champs.paiements.item;
  return ouvrirDialogue({
    titre: "Enregistrer un paiement", taille: "petit",
    description: `${libelleFiche("factures", f0)} — ${nomFiche("entreprises", f0.entreprise_id)}. Solde dû : ${argent(solde)}.`,
    contenu: (ctx) => {
      const montant = creerChamp("montant", champs.montant, solde, { aide: "Le solde complet par défaut. Entrez un montant plus petit pour un paiement partiel." });
      const date = creerChamp("date", champs.date, aujourdhui(), {});
      const mode = creerChamp("mode", champs.mode, "virement", {});
      const reference = creerChamp("reference", champs.reference, "", { aide: "Facultatif : numéro de chèque ou de transaction." });
      const tous = { montant, date, mode, reference };
      const alerte = h("p.champ__erreur", { role: "alert", hidden: true });

      const valider = () => {
        const brut = { montant: montant.lire(), date: date.lire(), mode: mode.lire(), reference: reference.lire() };
        const r = validerObjet(champs, brut, { creation: true, config: etat.config });
        const erreurs = { ...r.erreurs };
        if (!erreurs.montant) {
          if (!(r.valeur.montant > 0)) erreurs.montant = "Le montant doit être supérieur à zéro.";
          else if (r.valeur.montant > solde + 0.004) erreurs.montant = `Le solde est de ${argent(solde)}.`;
        }
        for (const [k, c] of Object.entries(tous)) c.erreur(erreurs[k] || null);
        const premier = Object.keys(erreurs).find((k) => tous[k]);
        if (premier) {
          tous[premier].focus();
          return null;
        }
        return r.valeur;
      };

      async function enregistrer() {
        alerte.hidden = true;
        const valeur = valider();
        if (!valeur) return;
        ctx.occupe(true);
        try {
          const rep = await actionFacture(id, "paiements", valeur);
          ctx.fermer(rep);
        } catch (e) {
          if (!(e instanceof ErreurApi)) throw e;
          if (e.champs?.montant) {
            montant.erreur(e.champs.montant);
            montant.focus();
          } else {
            alerte.hidden = false;
            alerte.textContent = e.message;
          }
        } finally {
          ctx.occupe(false);
        }
      }
      ctx.definirPied(btn("Annuler", { onclick: () => ctx.fermer(null) }), btn("Enregistrer le paiement", { ton: "primaire", onclick: enregistrer }));
      return h("form.formulaire", { novalidate: true, onsubmit: (e) => (e.preventDefault(), enregistrer()) }, h("div.grille.grille--1", montant.noeud, date.noeud, mode.noeud, reference.noeud), alerte);
    },
  }).promesse.then((rep) => {
    if (!rep?.paiement) return;
    const f = rep.fiche;
    const payee = f.statut === "payee";
    toast(`Paiement de ${argent(rep.paiement.montant)} enregistré.${payee ? " La facture est payée en totalité." : ""}`, {
      duree: 9000, action: { libelle: "Annuler", onclick: () => tenter(() => retirerPaiement(id, rep.paiement.id), { entite: "factures", succes: "Paiement annulé." }) },
    });
  });
}

async function retirerUnPaiement(f, p) {
  const r = await tenter(() => retirerPaiement(f.id, p.id), { entite: "factures" });
  if (!r) return;
  const corps = { montant: p.montant, date: p.date, ...(p.mode ? { mode: p.mode } : {}), ...(p.reference ? { reference: p.reference } : {}) };
  toast(`Paiement de ${argent(p.montant)} retiré.`, {
    ton: "info", duree: 9000,
    action: { libelle: "Annuler", onclick: () => tenter(() => actionFacture(f.id, "paiements", corps), { entite: "factures", succes: "Paiement rétabli." }) },
  });
}

// ----- En-tête ----------------------------------------------------------------------------------------------------------------------------------------------
/** L'action qui fait avancer le document, selon son état. */
function actionPrincipale(f) {
  const e = etatDocument(f).cle;
  if (estBrouillon(f)) return btn(estDevis(f) ? "Émettre le devis" : "Émettre la facture", { ton: "primaire", icone: "tampon", onclick: () => emettre(fiche("factures", f.id) || f) });
  if (!estDevis(f)) return soldeDu(f) > 0 ? btn("Enregistrer un paiement", { ton: "primaire", icone: "argent", onclick: () => ouvrirPaiement(f.id) }) : null;
  if (e === "envoyee" || e === "expiree") return btn("Marquer comme accepté", { ton: "primaire", icone: "coche", onclick: () => statutDevis(f, "acceptee") });
  if (e === "acceptee") {
    const issue = factureIssueDe(f);
    return issue
      ? btn("Voir la facture", { ton: "primaire", icone: "factures", href: lienFiche("factures", issue.id) })
      : btn("Créer la facture", { ton: "primaire", icone: "factures", onclick: () => creerFactureDepuisDevis(fiche("factures", f.id) || f) });
  }
  return null;
}

function menuPlus(f) {
  const e = etatDocument(f).cle;
  const emis = !estBrouillon(f);
  const facture = !estDevis(f);
  const courante = () => fiche("factures", f.id) || f;
  const usuelles = [
    emis ? { libelle: "Modifier", icone: "modifier", onclick: () => modifierLaFiche("factures", courante()) } : null,
    facture && emis && soldeDu(f) > 0 ? { libelle: "Envoyer un rappel de paiement", icone: "courriel", onclick: () => envoyerRappel(courante()) } : null,
    estDevis(f) && (e === "acceptee" || e === "refusee") ? { libelle: "Remettre le devis à « émis »", icone: "annuler", onclick: () => statutDevis(f, "envoyee") } : null,
    estDevis(f) && (e === "envoyee" || e === "expiree") ? { libelle: "Marquer comme refusé", icone: "non", onclick: () => statutDevis(f, "refusee") } : null,
    { libelle: "Dupliquer", icone: "copier", onclick: () => dupliquer(courante()) },
  ].filter(Boolean);
  const graves = [
    facture && emis && e !== "annulee" ? { libelle: "Annuler la facture", icone: "bloquer", danger: true, onclick: () => annulerFacture(courante()) } : null,
    !emis ? { libelle: "Mettre à la corbeille", icone: "corbeille", danger: true, onclick: () => supprimerAvecAnnulation("factures", f.id, { apres: () => naviguer("/factures") }) } : null,
  ].filter(Boolean);
  return menuActions({
    aria: `Plus d’actions sur ${estDevis(f) ? "ce devis" : "cette facture"}`,
    elements: graves.length ? [...usuelles, "separateur", ...graves] : usuelles,
  });
}

function marqueEtat(f) {
  const e = etatDocument(f);
  return TAMPONS_PAGE.has(e.cle) ? tampon(e.libelle, tonTampon(e.ton)) : pastille(e.libelle, e.ton);
}

function enteteFacture(f) {
  const peutEcrire = etat.droits.ecrire;
  const e = etatDocument(f).cle;
  const ent = f.entreprise_id ? fiche("entreprises", f.entreprise_id) : null;
  const sous = [];
  if (ent && !ent.supprime) sous.push(h("a.lien-fiche", { href: lienFiche("entreprises", ent.id) }, ent.nom));
  if (f.objet) sous.push(sous.length ? " — " : "", f.objet);
  const actions = [];
  if (peutEcrire) {
    const principale = actionPrincipale(f);
    if (principale) actions.push(principale);
    if (estBrouillon(f)) actions.push(btn("Modifier", { icone: "modifier", onclick: () => modifierLaFiche("factures", fiche("factures", f.id) || f) }));
    else if (e !== "annulee" && e !== "refusee" && e !== "payee") actions.push(btn("Envoyer par courriel", { icone: "courriel", onclick: () => envoyerDocument(f) }));
  }
  actions.push(btn("Imprimer", { icone: "imprimer", onclick: () => imprimer(f) }));
  if (peutEcrire) actions.push(menuPlus(f));
  return enTete({
    retour: { href: "#/factures", libelle: "Factures et devis" },
    titre: libelleFiche("factures", f),
    apres: marquesFiche(f, { etats: [marqueEtat(f)] }),
    sous: sous.length ? sous : null,
    actions,
  });
}

// ----- Avis ----------------------------------------------------------------------------------------------------------------------------------------------
function avisFacture(f) {
  const peutEcrire = etat.droits.ecrire;
  const e = etatDocument(f).cle;
  const devis = estDevis(f);
  const pile = [];
  const modifier = () => modifierLaFiche("factures", fiche("factures", f.id) || f);

  if (estBrouillon(f)) {
    if (!(f.lignes || []).length) {
      pile.push(avis({
        ton: "attention", titre: `Ce ${nomDoc(f)} n’a encore aucune ligne`, texte: "Ajoutez au moins une ligne (service, honoraires) pour pouvoir l’émettre.",
        actions: peutEcrire ? btn("Ajouter des lignes", { petit: true, icone: "modifier", onclick: modifier }) : null,
      }));
    } else {
      pile.push(avis({
        ton: "info", titre: `Brouillon : ${devis ? "ce devis" : "cette facture"} n’a pas encore de numéro`,
        texte: `Vérifiez les lignes et le client, puis ${devis ? "émettez-le" : "émettez-la"}. Le numéro est attribué à l’émission, et les lignes ne peuvent plus changer ensuite.`,
      }));
    }
  } else if (e === "en_retard") {
    const solde = soldeDu(f);
    pile.push(avis({
      ton: "erreur", titre: `Facture en retard : échue ${echeanceRelative(f.date_echeance)}`, texte: `Solde dû : ${argent(solde)}. Échéance : ${dateLongue(f.date_echeance)}.`,
      actions: peutEcrire ? [btn("Envoyer un rappel", { petit: true, icone: "courriel", onclick: () => envoyerRappel(f) }), btn("Enregistrer un paiement", { petit: true, icone: "argent", onclick: () => ouvrirPaiement(f.id) })] : null,
    }));
  } else if (e === "annulee") {
    pile.push(avis({ ton: "info", titre: "Facture annulée", texte: "Elle reste dans vos registres pour conserver la numérotation, mais ne compte plus dans les montants à recevoir." }));
  } else if (e === "expiree") {
    pile.push(avis({ ton: "attention", titre: `Devis expiré : sa validité s’est terminée ${echeanceRelative(f.date_echeance)}`, texte: "Si le client confirme tout de même, marquez-le comme accepté ; sinon, « Dupliquer » prépare une nouvelle version." }));
  } else if (e === "refusee") {
    pile.push(avis({ ton: "info", titre: "Devis refusé", texte: "Il est conservé dans vos registres. « Dupliquer » permet d’en préparer une nouvelle version." }));
  }

  // Les numéros de taxes doivent figurer sur une facture (c'est ce qui permet au client de réclamer ses crédits de taxes).
  const v = etat.config.entreprise || {};
  const t = totauxDoc(f);
  if (!devis && e !== "annulee" && (t.tps > 0 || t.tvq > 0) && (!v.no_tps || !v.no_tvq)) {
    const manque = !v.no_tps && !v.no_tvq ? "de TPS et de TVQ" : !v.no_tps ? "de TPS" : "de TVQ";
    pile.push(avis({
      ton: "attention", titre: `Votre numéro ${manque} ne figure pas sur ce document`,
      texte: "Il doit apparaître sur vos factures : c’est lui qui permet à votre client de réclamer ses crédits de taxes.",
      actions: etat.droits.administrer ? btn("Le saisir dans les paramètres", { petit: true, href: "#/parametres/entreprise" }) : null,
    }));
  }
  return pile.length ? h("div.pile-avis", pile) : null;
}

// ----- Chiffres ------------------------------------------------------------------------------------------------------------------------------------------
function blocChiffres(f) {
  if (estBrouillon(f) || f.statut === "annulee") return null;
  const t = totauxDoc(f);
  const e = etatDocument(f).cle;
  const item = (titre, valeur, precision = null, alerte = false) =>
    h("div.fiche-chiffres__item", { class: { "fiche-chiffres__item--alerte": alerte } }, h("dt", titre), h("dd", valeur, precision ? h("small", precision) : null));
  const avantTaxes = `${argent(t.sous_total)} avant taxes`;
  let items;
  if (estDevis(f)) {
    items = [
      item("Total", argent(t.total), avantTaxes),
      item("Valide jusqu’au", f.date_echeance ? dateSansAnneeCourante(f.date_echeance) : "—", f.date_echeance && (e === "envoyee" || e === "expiree") ? echeanceRelative(f.date_echeance) : null, e === "expiree"),
      item("Émis le", f.date_emission ? dateSansAnneeCourante(f.date_emission) : "—"),
    ];
  } else {
    const solde = Math.max(0, t.solde);
    const n = (f.paiements || []).length;
    items = [
      item("Total", argent(t.total), avantTaxes),
      item("Payé", argent(t.paye), n ? pluriel(n, "paiement") : "Aucun paiement"),
      item("Solde dû", argent(solde), solde <= 0 ? "Payée en totalité" : null, e === "en_retard"),
      item("Échéance", f.date_echeance ? dateSansAnneeCourante(f.date_echeance) : "—", f.date_echeance && solde > 0 ? echeanceRelative(f.date_echeance) : null, e === "en_retard"),
    ];
  }
  return h("dl.fiche-chiffres", { css: { "--n": items.length } }, items);
}

// ----- Le document ------------------------------------------------------------------------------------------------------------------------------------
function tableLignes(f) {
  const lignes = f.lignes || [];
  if (!lignes.length) return h("p.doc-papier__vide", "Aucune ligne pour l’instant. Utilisez « Modifier » pour ajouter des services ou des honoraires.");
  return h(
    "table.doc-lignes",
    h("caption.sr-only", "Lignes du document"),
    h("thead", h("tr", h("th", { scope: "col" }, "Description"), h("th.num", { scope: "col" }, "Qté"), h("th.num", { scope: "col" }, "Prix unitaire"), h("th.num", { scope: "col" }, "Montant"))),
    h(
      "tbody",
      lignes.map((l) => {
        const qte = `${nombre(l.quantite)}${l.unite ? ` ${l.unite}` : ""}`;
        return h(
          "tr",
          h("td.doc-lignes__desc", l.description, h("small.doc-lignes__detail", `${qte} × ${argent(l.prix)}`), l.taxable === false ? h("small.doc-lignes__nt", "Non taxable") : null),
          h("td.num.doc-lignes__qte", qte),
          h("td.num.doc-lignes__prix", argent(l.prix)),
          h("td.num.doc-lignes__montant", argent(montantLigne(l)))
        );
      })
    )
  );
}

function totauxDocument(f) {
  const t = totauxDoc(f);
  const taux = f.taux || etat.config.taxes;
  const ligne = (k, v, classe = "") => h("div.totaux__ligne", { class: classe }, h("dt", k), h("dd", v));
  const lignes = [ligne("Sous-total", argent(t.sous_total)), ligne(`TPS (${tauxTaxe(taux.tps)})`, argent(t.tps)), ligne(`TVQ (${tauxTaxe(taux.tvq)})`, argent(t.tvq))];
  const encaisse = !estDevis(f) && !estBrouillon(f) && f.statut !== "annulee" && t.paye > 0;
  lignes.push(ligne("Total", argent(t.total), encaisse ? "totaux__ligne--fort" : "totaux__ligne--total"));
  if (encaisse) {
    lignes.push(ligne("Paiements reçus", argent(-t.paye)));
    lignes.push(ligne("Solde dû", argent(Math.max(0, t.solde)), "totaux__ligne--total"));
  }
  return h("dl.totaux.doc-totaux", lignes);
}

function blocDocument(f) {
  const cfg = etat.config;
  const v = cfg.entreprise || {};
  const devis = estDevis(f);
  const e = etatDocument(f).cle;
  const ent = f.entreprise_id ? fiche("entreprises", f.entreprise_id) : null;
  const con = f.contact_id ? fiche("contacts", f.contact_id) : null;
  const idTitre = idUnique("doc-titre");

  const adresseVendeur = [v.adresse, [v.ville, v.province ? `(${v.province})` : "", v.code_postal].filter(Boolean).join(" ")];
  const numeros = [v.no_tps ? `TPS n° ${v.no_tps}` : "", v.no_tvq ? `TVQ n° ${v.no_tvq}` : "", v.neq ? `NEQ ${v.neq}` : ""].filter(Boolean);
  const adresseClient = ent ? [ent.adresse, [ent.ville, ent.code_postal].filter(Boolean).join(" ")] : [];

  const stampe = estBrouillon(f) ? tampon("Brouillon", "neutre") : TAMPONS_DOCUMENT.has(e) ? tampon(etatDocument(f).libelle, tonTampon(etatDocument(f).ton)) : null;
  const date = (valeur, vide) => (valeur ? dateCourte(valeur) : h("span.doc-papier__prevu", vide));
  const def = (k, val) => h("div", h("dt", k), h("dd", val));

  return h(
    "article.doc-papier",
    { "aria-labelledby": idTitre },
    h(
      "header.doc-papier__tete",
      h(
        "div.doc-papier__vendeur",
        h("p.doc-papier__marque", v.nom || "InnovAffaires"),
        v.nom_legal && v.nom_legal !== v.nom ? h("p.doc-papier__legal", v.nom_legal) : null,
        h("address.doc-papier__adresse", sauts([...adresseVendeur, v.telephone ? fmtTel(v.telephone) : "", v.courriel || ""])),
        numeros.length ? h("p.doc-papier__numeros", sauts(numeros)) : null
      ),
      h(
        "div.doc-papier__identite",
        h("h2.doc-papier__type", { id: idTitre }, devis ? "Devis" : "Facture"),
        h("p.doc-papier__numero", f.numero || h("span.doc-papier__prevu", "Numéro attribué à l’émission")),
        h(
          "dl.doc-papier__dates",
          def("Date d’émission", date(f.date_emission, "à l’émission")),
          def(devis ? "Valide jusqu’au" : "Échéance", date(f.date_echeance, "calculée à l’émission")),
          !devis && (f.conditions || cfg.facturation?.conditions) ? def("Conditions", f.conditions || (estBrouillon(f) ? cfg.facturation.conditions : "")) : null
        ),
        stampe ? h("div.doc-papier__tampon", stampe) : null
      )
    ),
    h(
      "section.doc-papier__parties",
      h(
        "div",
        h("h3.doc-papier__etiquette", devis ? "Préparé pour" : "Facturé à"),
        ent
          ? [
              h("p.doc-papier__client", ent.nom),
              adresseClient.some(Boolean) ? h("address.doc-papier__adresse", sauts(adresseClient)) : null,
              con && !con.supprime ? h("p.doc-papier__attention", `À l’attention de ${nomComplet(con) || con.courriel}`) : null,
            ]
          : h("p.muet", "Client introuvable")
      ),
      f.objet ? h("div", h("h3.doc-papier__etiquette", "Objet"), h("p.doc-papier__objet", f.objet)) : null
    ),
    tableLignes(f),
    h(
      "div.doc-papier__bas",
      h("div.doc-papier__notes", f.notes ? [h("h3.doc-papier__etiquette", "Notes"), paragraphes(f.notes)] : null),
      totauxDocument(f)
    ),
    cfg.facturation?.note_facture ? h("footer.doc-papier__pied", cfg.facturation.note_facture) : null
  );
}

// ----- Paiements (colonne de droite) ---------------------------------------------------------------------------------------------------
function blocPaiements(f) {
  if (estDevis(f) || estBrouillon(f)) return null;
  const paiements = (f.paiements || []).slice().sort((a, b) => String(b.date).localeCompare(String(a.date)));
  if (f.statut === "annulee" && !paiements.length) return null;
  const peutEcrire = etat.droits.ecrire;
  const solde = soldeDu(f);
  const lignes = paiements.map((p) =>
    h(
      "li.paiement",
      h("div.paiement__texte", h("strong", dateCourte(p.date)), h("small", [libelleOption(MODES_PAIEMENT, p.mode) || "Mode non précisé", p.reference ? `réf. ${p.reference}` : ""].filter(Boolean).join(" — "))),
      h("span.paiement__montant", argent(p.montant)),
      peutEcrire ? btnIcone("corbeille", `Retirer le paiement de ${argent(p.montant)} du ${dateCourte(p.date)}`, () => retirerUnPaiement(f, p), { classe: "paiement__retirer" }) : null
    )
  );
  const noeud = panneau(
    { titre: "Paiements", compteur: paiements.length || null, sous: solde > 0 ? `Solde dû : ${argent(solde)}` : paiements.length ? "Payée en totalité" : null, classe: "panneau--liste" },
    lignes.length ? h("ul.paiements", lignes) : h("p.liste-vide", "Aucun paiement reçu pour l’instant.")
  );
  if (peutEcrire && solde > 0) {
    noeud.append(h("div.panneau__pied", btn("Enregistrer un paiement", { icone: "argent", ton: lignes.length ? "secondaire" : "primaire", onclick: () => ouvrirPaiement(f.id) })));
  }
  return noeud;
}

// ----- Client et rattachements ---------------------------------------------------------------------------------------------------------
function blocClient(f) {
  const extra = [];
  const lien = (entite, id, texte) => {
    const x = id ? fiche(entite, id) : null;
    return x && !x.supprime ? h("a.lien-fiche", { href: lienFiche(entite, id) }, texte(x)) : null;
  };
  extra.push(["Dossier", lien("dossiers", f.dossier_id, (x) => x.titre)]);
  extra.push(["Affaire", lien("opportunites", f.opportunite_id, (x) => x.titre)]);
  if (f.devis_id) extra.push(["Devis d’origine", lien("factures", f.devis_id, (x) => libelleFiche("factures", x))]);
  if (estDevis(f)) {
    const issues = liees("factures", "devis_id", f.id);
    if (issues.length) extra.push([issues.length > 1 ? "Factures créées" : "Facture créée", issues.map((x, i) => [i ? ", " : "", h("a.lien-fiche", { href: lienFiche("factures", x.id) }, libelleFiche("factures", x))])]);
  }
  return panneauClient(f, extra);
}

// ----- Historique ------------------------------------------------------------------------------------------------------------------------------------
function blocHistorique(f0) {
  let entreprise = null;
  let version = null;
  let j = null;
  const conteneur = h("div");
  function monter(f) {
    entreprise = f.entreprise_id || null;
    version = f.v;
    j = journal({
      lieType: "factures", lieId: f.id, lie2: entreprise ? { type: "entreprises", id: entreprise } : null,
      aide: "Émission, paiements, courriels envoyés et notes liés à ce document.",
    });
    conteneur.replaceChildren(j.noeud);
  }
  monter(f0);
  return {
    noeud: conteneur,
    miseAJour(_changes, f) {
      if ((f.entreprise_id || null) !== entreprise) monter(f);
      else if (f.v !== version) {
        version = f.v;
        j.recharger();
      }
    },
  };
}

export default creerVueFiche({
  entite: "factures",
  liste: { href: "#/factures", libelle: "Factures et devis" },
  entete: { depend: ["factures", "entreprises", "contacts", "config"], dessiner: enteteFacture },
  blocs: [
    { id: "avis", colonne: "principal", ordre: 0, depend: ["factures", "config"], dessiner: avisFacture },
    { id: "chiffres", colonne: "principal", ordre: 1, depend: ["factures", "config"], dessiner: blocChiffres },
    { id: "document", colonne: "principal", ordre: 3, depend: ["factures", "entreprises", "contacts", "config"], dessiner: blocDocument },
    { id: "historique", colonne: "principal", ordre: 5, creer: blocHistorique },
    { id: "paiements", colonne: "lateral", ordre: 2, depend: ["factures"], dessiner: blocPaiements },
    { id: "client", colonne: "lateral", ordre: 4, depend: ["factures", "entreprises", "contacts", "dossiers", "opportunites"], dessiner: blocClient },
    { id: "pied", colonne: "lateral", ordre: 6, depend: ["factures", "equipe"], dessiner: (f) => piedFiche("factures", f) },
  ],
});
