// =============================================================================
// Calendrier : le mois d'un coup d'œil — rendez-vous, tâches datées, dates limites
// de dépôt, décisions attendues et factures à échéance — et les mêmes éléments en
// liste. Un jour s'ouvre en détail ; un rendez-vous s'ajoute, se modifie et se
// supprime ici. Sur téléphone, le mois devient une grille de points et le jour
// choisi s'affiche juste en dessous.
//
// Adresse : #/calendrier?date=AAAA-MM-JJ&vue=liste&evenement=ID
//
// Quand la personne a relié son compte Google, une cinquième couche montre aussi les événements de son agenda Google
// (lecture seule, lus en direct : rien n'est copié dans le CRM). Les rendez-vous du CRM qui s'y trouvent déjà ne sont pas répétés.
// =============================================================================
import { h, paragraphes } from "../noyau/dom.js";
import { icone } from "../noyau/icones.js";
import { etat, fiche, maintenant, nomUtilisateur } from "../noyau/etat.js";
import { majRequete, naviguer, lireAdresse } from "../noyau/routeur.js";
import { lirePref, ecrirePref } from "../noyau/prefs.js";
import { supprimerAvecAnnulation } from "../noyau/ecriture.js";
import { ErreurApi } from "../noyau/api.js";
import { adresseInvitation, agendaActif, aReconnecter, compteGoogle, evenementsGoogle, fonctionsAttendues, google, resumeSynchro, signalerErreurGoogle, synchroniserAgenda } from "../noyau/google.js";
import { aujourdhui, ajouterJours, ajouterMois, debutMois, finMois, debutSemaine, differenceJours, estDateValide, instantLocal, jourSemaine, joursFeriesQc, partiesLocales } from "../commun/dates.js";
import { dateLongue, jourMois, moisAnnee, jourSemaineCourt, echeanceRelative, ilYa, pluriel, tronquer } from "../commun/format.js";
import { TYPES_EVENEMENT } from "../commun/schema.js";
import { enTete, btn, btnIcone, panneau, etatVide, listeDef, pastille } from "../ui/composants.js";
import { ouvrirDialogue } from "../ui/dialogue.js";
import { toast } from "../ui/toast.js";
import { ligneTache } from "../ui/taches.js";
import { TYPES_REGLE } from "../ui/regle.js";
import { heureTexte, lienLie, lienSite, libelleOption } from "./aides.js";
import { echeancesDossiers, echeancesFactures, rendezVous, tachesDatees } from "./echeances.js";

export const depend = ["evenements", "taches", "dossiers", "factures", "contacts", "entreprises", "opportunites", "config", "google"];

const MAX_PUCES = 3;
const TYPES_ELEMENT = {
  ...TYPES_REGLE,
  tache: { libelle: "Tâche", court: "Tâche", icone: "taches" },
  google: { libelle: "Google Agenda", court: "Google", icone: "calendrier" },
};
const COUCHES = [
  { id: "rdv", libelle: "Rendez-vous", types: ["rdv"], pastille: "rdv" },
  { id: "tache", libelle: "Tâches", types: ["tache"], pastille: "tache" },
  { id: "dossier", libelle: "Dossiers", types: ["depot", "decision"], pastille: "dossier", aide: "Dates limites de dépôt et décisions attendues" },
  { id: "facture", libelle: "Factures", types: ["facture"], pastille: "facture", aide: "Factures dont il reste un solde à encaisser" },
  { id: "google", libelle: "Google Agenda", types: ["google"], pastille: "google", google: true, aide: "Les événements de votre agenda Google, en lecture seule. Les rendez-vous qui viennent du CRM n’y sont pas répétés." },
];
const COUCHES_PAR_DEFAUT = { rdv: true, tache: true, dossier: true, facture: true, google: true };
const FERIES_COURTS = ["Jour de l’An", "Vendredi saint", "Patriotes", "Fête nationale", "Fête du Canada", "Fête du Travail", "Action de grâce", "Noël"];
const FERIES_LONGS = ["Jour de l’An", "Vendredi saint", "Journée nationale des patriotes", "Fête nationale du Québec", "Fête du Canada", "Fête du Travail", "Action de grâce", "Noël"];

const fmtJourLong = new Intl.DateTimeFormat("fr-CA", { timeZone: "UTC", weekday: "long", day: "numeric", month: "long" });
const jourLong = (d) => fmtJourLong.format(new Date(`${d}T00:00:00Z`));
const nomJour = (d) => dateLongue(d).split(" ")[0];
const majuscule = (s) => s.charAt(0).toUpperCase() + s.slice(1);
const auj = () => aujourdhui(maintenant());
/** « 14:00 » → « 14 h » ; « 09:30 » → « 9 h 30 » (pour les petites pastilles du mois). */
const heureCourte = (hhmm) => (hhmm.endsWith(":00") ? `${+hhmm.slice(0, 2)} h` : heureTexte(hhmm));

// ----- Données ------------------------------------------------------------------------------------------------------------------------------------
const RANG_MARQUEUR = { depot: 0, decision: 1, facture: 2 };
function rang(e) {
  if (e.type in RANG_MARQUEUR) return RANG_MARQUEUR[e.type];
  if (e.heure) return 4;
  return e.type === "rdv" || e.type === "google" ? 3 : 5;
}
/** Dans une journée : d'abord les marqueurs (dépôts, décisions, factures), puis les rendez-vous de la journée, ensuite ce qui a une heure, enfin les tâches sans heure. */
function comparer(a, b) {
  const ra = rang(a);
  const rb = rang(b);
  if (ra !== rb) return ra - rb;
  if (ra === 4 && a.heure !== b.heure) return a.heure < b.heure ? -1 : 1;
  return String(a.titre).localeCompare(String(b.titre), "fr-CA");
}

/** Jours fériés du Québec (et ceux que l'organisation a ajoutés) : Map « AAAA-MM-JJ » → { court, long }. */
function feriesEntre(debut, fin) {
  const map = new Map();
  for (let a = +debut.slice(0, 4); a <= +fin.slice(0, 4); a++) joursFeriesQc(a).forEach((d, i) => map.set(d, { court: FERIES_COURTS[i], long: FERIES_LONGS[i] }));
  for (const d of etat.config?.jours_feries_supplementaires || []) if (!map.has(d)) map.set(d, { court: "Jour férié", long: "Jour férié de l’organisation" });
  return map;
}

/**
 * Les événements de l'agenda Google d'une plage, à raison d'un élément par jour : un événement de plusieurs jours figure sur chacun
 * de ses jours. Les rendez-vous qui viennent du CRM sont omis (ils sont déjà dans le calendrier, sous leur propre couleur).
 */
function elementsGoogle(donnees, debut, fin) {
  const sortie = [];
  for (const ev of donnees?.evenements || []) {
    if (ev.crm_id && fiche("evenements", ev.crm_id)) continue;
    let premier;
    let dernier;
    let heureDebut = "";
    let heureFin = "";
    if (ev.journee) {
      // Google donne la fin d'un événement « toute la journée » exclue : du 3 au 4 inclus = 3 → 5.
      premier = ev.debut;
      dernier = ev.fin > ev.debut ? ajouterJours(ev.fin, -1) : ev.debut;
    } else {
      const d = partiesLocales(Date.parse(ev.debut));
      const f = partiesLocales(Date.parse(ev.fin));
      premier = d.date;
      // Un événement qui finit à minuit pile ne déborde pas sur le jour suivant.
      dernier = f.date > d.date ? (f.heure === "00:00" ? ajouterJours(f.date, -1) : f.date) : d.date;
      heureDebut = d.heure;
      heureFin = f.date === d.date && f.heure !== d.heure ? f.heure : "";
    }
    if (dernier < premier) dernier = premier;
    for (let date = premier < debut ? debut : premier; date <= dernier && date <= fin; date = ajouterJours(date, 1)) {
      const suite = date !== premier;
      sortie.push({
        id: `g-${ev.id}-${date}`, type: "google", date, heure: suite ? "" : heureDebut, heureFin: !suite && dernier === premier ? heureFin : "", jusquau: "",
        titre: ev.titre, detail: ev.lieu || "", href: "", entite: "google", ficheId: ev.id, suite, evt: ev,
      });
    }
  }
  return sortie;
}

/** « Du 3 au 5 octobre », « Lundi 5 octobre, toute la journée », « Lundi 5 octobre, de 14 h à 15 h 30 » pour un événement Google. */
function quandGoogle(ev) {
  if (!ev.journee) return null;
  const dernier = ev.fin > ev.debut ? ajouterJours(ev.fin, -1) : ev.debut;
  return dernier > ev.debut ? `Du ${dateLongue(ev.debut)} au ${dateLongue(dernier)}` : `${majuscule(dateLongue(ev.debut))}, toute la journée`;
}

// ----- Vue ----------------------------------------------------------------------------------------------------------------------------------------
export default async function vueCalendrier() {
  const requete = lireAdresse().requete;
  const jourCourant = auj();
  const st = {
    date: estDateValide(requete.get("date")) ? requete.get("date") : jourCourant,
    vue: requete.get("vue") === "liste" || requete.get("vue") === "mois" ? requete.get("vue") : lirePref("calendrier.vue", "mois"),
    couches: { ...COUCHES_PAR_DEFAUT, ...(lirePref("calendrier.couches", {}) || {}) },
    passes: false,
  };
  const peutEcrire = etat.droits.ecrire;
  const evenementDemande = requete.get("evenement");

  // ----- Agenda Google (lecture seule) -----------------------------------------------------------------------------------------------------------
  // donnees : dernière réponse du serveur ; cleEssayee : plage demandée en dernier (réussie ou non : on ne réessaie pas en boucle) ;
  // erreur : pourquoi la dernière lecture a échoué ; synchro : une synchronisation lancée d'ici est en cours.
  const g = { donnees: null, cleEssayee: "", chargement: false, erreur: null, controleur: null, synchro: false, detruite: false };
  const googleVisible = () => agendaActif() && !!st.couches.google;
  function plageGrille() {
    const debut = debutSemaine(debutMois(st.date));
    const nb = Math.ceil((differenceJours(debut, finMois(st.date)) + 1) / 7) * 7;
    return { debut, nb, fin: ajouterJours(debut, nb - 1) };
  }

  // ----- Éléments d'une plage de dates -----------------------------------------------------------------------------------------------------------
  function indexer(debut, fin) {
    const jour = auj();
    const sources = [];
    if (st.couches.dossier) sources.push(echeancesDossiers());
    if (st.couches.facture) sources.push(echeancesFactures());
    if (st.couches.rdv) sources.push(rendezVous());
    if (st.couches.tache) sources.push(tachesDatees());
    if (googleVisible()) sources.push(elementsGoogle(g.donnees, debut, fin));
    const par = new Map();
    for (const liste of sources) {
      for (const e of liste) {
        if (e.date < debut || e.date > fin) continue;
        e.retard = e.date < jour && (e.type === "depot" || e.type === "facture" || e.type === "tache");
        if (!par.has(e.date)) par.set(e.date, []);
        par.get(e.date).push(e);
      }
    }
    for (const liste of par.values()) liste.sort(comparer);
    return par;
  }
  const elementsDuJour = (date) => indexer(date, date).get(date) || [];

  // ----- Ouvertures -----------------------------------------------------------------------------------------------------------------------------------
  function debutParDefaut(date) {
    if (date === auj()) {
      const p = partiesLocales(maintenant() + 3_600_000);
      if (p.date === date) return new Date(instantLocal(date, `${p.heure.slice(0, 2)}:00`)).toISOString();
    }
    return new Date(instantLocal(date, "09:00")).toISOString();
  }
  async function nouveauRdv(date) {
    const m = await import("./formulaires.js");
    m.nouvelleFiche("evenements", { debut: debutParDefaut(date) });
  }
  async function nouvelleTache(date) {
    const m = await import("./formulaires.js");
    m.nouvelleFiche("taches", { echeance: date });
  }
  async function modifierRdv(id) {
    const m = await import("./formulaires.js");
    m.modifierLaFiche("evenements", id);
  }

  function texteQuand(ev) {
    const d = partiesLocales(Date.parse(ev.debut));
    const f = ev.fin && !Number.isNaN(Date.parse(ev.fin)) ? partiesLocales(Date.parse(ev.fin)) : null;
    if (ev.journee_entiere) return f && f.date > d.date ? `Du ${dateLongue(d.date)} au ${dateLongue(f.date)}` : `${majuscule(dateLongue(d.date))}, toute la journée`;
    if (!f) return `${majuscule(dateLongue(d.date))}, ${heureTexte(d.heure)}`;
    if (f.date === d.date) return `${majuscule(dateLongue(d.date))}, de ${heureTexte(d.heure)} à ${heureTexte(f.heure)}`;
    return `Du ${dateLongue(d.date)}, ${heureTexte(d.heure)}, au ${dateLongue(f.date)}, ${heureTexte(f.heure)}`;
  }

  /** Détail d'un rendez-vous. */
  function ouvrirRdv(id) {
    const ev = fiche("evenements", id);
    if (!ev || ev.supprime) {
      toast("Ce rendez-vous n’existe plus.", { ton: "info" });
      return;
    }
    const lieu = ev.lieu ? (/^https?:\/\//i.test(ev.lieu) ? lienSite(ev.lieu) : h("span", ev.lieu)) : null;
    const lie = ev.lie_id ? lienLie(ev.lie_type, ev.lie_id) : null;
    // Lien Google Meet : écrit par le serveur une fois le rendez-vous envoyé à Google Agenda.
    const visio = ev.google_lien
      ? h("a.lien-discret", { href: ev.google_lien, target: "_blank", rel: "noopener noreferrer" }, "Rejoindre avec Google Meet", icone("externe", "ic--p"))
      : ev.google_meet
        ? h("span.muet", "Le lien Google Meet apparaîtra ici quelques instants après l’enregistrement.")
        : null;
    const adresseInvite = ev.google_inviter ? adresseInvitation(ev.lie_type, ev.lie_id) : "";
    const invitation = adresseInvite ? h("span", adresseInvite) : null;
    ouvrirDialogue({
      titre: ev.titre,
      taille: "moyen",
      classe: "dialogue--rdv",
      contenu: (ctx) => {
        const corps = h(
          "div",
          listeDef([
            ["Quand", texteQuand(ev)],
            ["Type", libelleOption(TYPES_EVENEMENT, ev.type)],
            ["Lieu", lieu],
            ["Visioconférence", visio],
            ["Lié à", lie],
            ["Responsable", (etat.equipe || []).length > 1 && ev.responsable_id ? nomUtilisateur(ev.responsable_id) : null],
            ["Invitation Google", invitation],
            ["Notes", ev.notes ? h("div.texte-libre", paragraphes(ev.notes)) : null],
          ])
        );
        corps.addEventListener("click", (e) => {
          if (e.target.closest("a.lien-lie")) ctx.fermer(undefined);
        });
        ctx.definirPied(
          ...(peutEcrire
            ? [
                btn("Supprimer", { ton: "danger", icone: "corbeille", classe: "pousse", onclick: async () => {
                  ctx.fermer(undefined);
                  await supprimerAvecAnnulation("evenements", id);
                } }),
              ]
            : []),
          btn("Fermer", { onclick: () => ctx.fermer(undefined) }),
          ...(peutEcrire ? [btn("Modifier", { ton: "primaire", icone: "modifier", onclick: () => {
            ctx.fermer(undefined);
            modifierRdv(id);
          } })] : [])
        );
        return corps;
      },
    });
  }

  /** Détail d'un événement de l'agenda Google : lecture seule, avec un lien vers Google Agenda pour le modifier. */
  function ouvrirGoogle(e) {
    const ev = e.evt;
    const lieu = ev.lieu ? (/^https?:\/\//i.test(ev.lieu) ? lienSite(ev.lieu) : h("span", ev.lieu)) : null;
    const visio = ev.meet ? h("a.lien-discret", { href: ev.meet, target: "_blank", rel: "noopener noreferrer" }, "Rejoindre avec Google Meet", icone("externe", "ic--p")) : null;
    ouvrirDialogue({
      titre: ev.titre,
      taille: "moyen",
      classe: "dialogue--rdv",
      contenu: (ctx) => {
        ctx.definirPied(
          btn("Fermer", { onclick: () => ctx.fermer(undefined) }),
          ...(ev.lien ? [btn("Ouvrir dans Google Agenda", { ton: "primaire", icone: "externe", href: ev.lien, externe: true })] : [])
        );
        return h(
          "div",
          listeDef([
            ["Quand", quandGoogle(ev) || texteQuand({ debut: ev.debut, fin: ev.fin, journee_entiere: false })],
            ["Lieu", lieu],
            ["Visioconférence", visio],
            ["Disponibilité", ev.occupe ? null : "Libre : cet événement n’occupe pas votre horaire."],
            ["Agenda", `Google Agenda${compteGoogle() ? ` (${compteGoogle()})` : ""}`],
          ]),
          h("p.muet.petit", "Cet événement vient de votre agenda Google : le CRM l’affiche sans le copier. Pour le modifier, ouvrez-le dans Google Agenda.")
        );
      },
    });
  }

  async function ouvrirElement(e) {
    if (e.type === "google") return ouvrirGoogle(e);
    if (e.type === "rdv") return ouvrirRdv(e.ficheId);
    if (e.type === "tache") {
      const m = await import("./formulaires.js");
      return m.modifierLaFiche("taches", e.ficheId);
    }
    if (e.href) naviguer(e.href.replace(/^#/, ""));
    return undefined;
  }

  // ----- Contenu d'un jour (dialogue sur grand écran, panneau sous la grille sur téléphone) --------------------------------------
  function ligneElement(e, { avant = null, large = false } = {}) {
    if (e.type === "tache") {
      const t = fiche("taches", e.ficheId);
      return t ? ligneTache(t, { echeance: false, lienCourt: !large }) : null;
    }
    const t = TYPES_ELEMENT[e.type];
    const titre =
      e.type === "rdv" || e.type === "google"
        ? h("button.cal-ligne__titre", { type: "button", onclick: () => {
            avant?.();
            ouvrirElement(e);
          } }, e.titre)
        : h("a.cal-ligne__titre", { href: e.href }, e.titre);
    const meta = [];
    if (e.type === "rdv") {
      const ev = fiche("evenements", e.ficheId);
      meta.push(h("span.cal-ligne__quand", e.heure ? (e.heureFin ? `${heureTexte(e.heure)} – ${heureTexte(e.heureFin)}` : heureTexte(e.heure)) : "Toute la journée"));
      if (ev?.type) meta.push(h("span", libelleOption(TYPES_EVENEMENT, ev.type)));
      if (e.jusquau) meta.push(h("span", `jusqu’au ${jourMois(e.jusquau)}`));
      if (e.detail) meta.push(h("span.cal-ligne__lieu", icone("lieu", "ic--p"), h("span", tronquer(e.detail, 40))));
      const l = ev?.lie_id ? lienLie(ev.lie_type, ev.lie_id, { court: !large }) : null;
      if (l) meta.push(l);
    } else if (e.type === "google") {
      meta.push(h("span.cal-ligne__quand", e.suite ? "Suite" : e.heure ? (e.heureFin ? `${heureTexte(e.heure)} – ${heureTexte(e.heureFin)}` : heureTexte(e.heure)) : "Toute la journée"));
      meta.push(h("span", t.libelle));
      if (e.detail) meta.push(h("span.cal-ligne__lieu", icone("lieu", "ic--p"), h("span", tronquer(e.detail, 40))));
      if (e.evt.meet) meta.push(h("span.cal-ligne__lieu", icone("video", "ic--p"), h("span", "Google Meet")));
    } else {
      meta.push(h("span", t.libelle));
      if (e.detail) meta.push(h("span", e.detail));
    }
    return h(
      "li.cal-ligne",
      { class: `cal-ligne--${e.type}` },
      h("span.cal-ligne__badge", { class: `cal-type--${e.type}`, "aria-hidden": "true" }, icone(t.icone, "ic--p")),
      h("div.cal-ligne__corps", titre, h("div.cal-ligne__meta", meta)),
      h("div.cal-ligne__fin", e.retard ? pastille("En retard", "erreur", { icone: "alerte" }) : null)
    );
  }

  function contenuJour(date, { avant = null } = {}) {
    const items = elementsDuJour(date);
    const ferie = feriesEntre(date, date).get(date);
    const sous = [echeanceRelative(date, auj()), ferie ? `jour férié : ${ferie.long}` : ""].filter(Boolean).join(" — ");
    const racine = h("div.cal-jour", h("p.cal-jour__sous", majuscule(sous)));
    if (items.length) racine.append(h("ul.cal-liste", items.map((e) => ligneElement(e, { avant }))));
    else racine.append(h("p.cal-jour__vide", "Rien de prévu ce jour-là."));
    if (peutEcrire) {
      racine.append(
        h(
          "div.cal-jour__actions",
          btn("Rendez-vous", { icone: "plus", petit: true, onclick: () => { avant?.(); nouveauRdv(date); } }),
          btn("Tâche", { icone: "plus", petit: true, onclick: () => { avant?.(); nouvelleTache(date); } })
        )
      );
    }
    return racine;
  }

  function ouvrirJour(date) {
    ouvrirDialogue({
      titre: majuscule(dateLongue(date)),
      taille: "moyen",
      classe: "dialogue--jour",
      contenu: (ctx) => {
        const noeud = contenuJour(date, { avant: () => ctx.fermer(undefined) });
        noeud.addEventListener("click", (e) => {
          if (e.target.closest("a[href], button.tache__titre")) ctx.fermer(undefined);
        });
        ctx.definirPied(btn("Fermer", { onclick: () => ctx.fermer(undefined) }));
        return noeud;
      },
    });
  }

  // ----- Le mois ------------------------------------------------------------------------------------------------------------------------------------
  function puce(e) {
    const t = TYPES_ELEMENT[e.type];
    const contenu = [e.heure ? h("span.cal-elt__heure", heureCourte(e.heure)) : null, h("span.cal-elt__titre", e.titre), h("span.sr-only", `, ${t.libelle.toLowerCase()}${e.retard ? ", en retard" : ""}`)];
    const props = { class: ["cal-elt", `cal-type--${e.type}`, { "cal-elt--retard": e.retard }], tabindex: "-1", title: `${t.libelle} — ${e.titre}${e.detail ? ` (${e.detail})` : ""}` };
    if (e.href && e.type !== "rdv") return h("a", { ...props, href: e.href }, contenu);
    return h("button", { ...props, type: "button", onclick: () => ouvrirElement(e) }, contenu);
  }

  function cellule(date, par, feries, mois, jour) {
    const items = par.get(date) || [];
    const dow = jourSemaine(date);
    const ferie = feries.get(date);
    const libelle = `${dateLongue(date)}${ferie ? ` — ${ferie.long}` : ""} — ${items.length ? pluriel(items.length, "élément") : "rien de prévu"}`;
    const visibles = items.length <= MAX_PUCES ? items : items.slice(0, MAX_PUCES - 1);
    const reste = items.length - visibles.length;
    const types = [...new Set(items.map((e) => e.type))];
    return h(
      "td",
      {
        class: ["cal__jour", {
          "cal__jour--autre": date.slice(0, 7) !== mois, "cal__jour--auj": date === jour, "cal__jour--fin-semaine": dow === 0 || dow === 6,
          "cal__jour--ferie": !!ferie, "cal__jour--selection": date === st.date,
        }],
        dataset: { date },
      },
      h(
        "div.cal__jour-tete",
        h("button.cal__num", { type: "button", tabindex: date === st.date ? "0" : "-1", "aria-label": libelle, "aria-current": date === jour ? "date" : null, dataset: { date }, onclick: () => choisirJour(date) }, date.endsWith("-01") ? jourMois(date) : String(+date.slice(8))),
        ferie ? h("span.cal__ferie", { title: ferie.long }, ferie.court) : null
      ),
      items.length
        ? h(
            "ul.cal__elts",
            visibles.map((e) => h("li", puce(e))),
            reste > 0 ? h("li", h("button.cal__plus", { type: "button", tabindex: "-1", onclick: () => choisirJour(date) }, `+ ${reste} autres`)) : null
          )
        : null,
      items.length ? h("div.cal__points", { "aria-hidden": "true" }, types.sort((a, b) => rang({ type: a }) - rang({ type: b })).map((t) => h("span.cal__point", { class: `cal-type--${t}` }))) : null
    );
  }

  function grille() {
    const jour = auj();
    const { debut, nb, fin } = plageGrille();
    const par = indexer(debut, fin);
    const feries = feriesEntre(debut, fin);
    const mois = st.date.slice(0, 7);
    const lignes = [];
    for (let s = 0; s < nb / 7; s++) {
      const tr = h("tr");
      for (let i = 0; i < 7; i++) tr.append(cellule(ajouterJours(debut, s * 7 + i), par, feries, mois, jour));
      lignes.push(tr);
    }
    return h(
      "div.cal__cadre",
      h(
        "table.cal__table",
        h("caption.sr-only", `${majuscule(moisAnnee(st.date))}. Les flèches changent de jour ; Entrée ouvre le jour.`),
        h("thead", h("tr", Array.from({ length: 7 }, (_, i) => { const d = ajouterJours(debut, i); return h("th", { scope: "col" }, h("abbr", { title: nomJour(d) }, jourSemaineCourt(d))); }))),
        h("tbody", lignes)
      )
    );
  }

  // ----- La liste du mois ------------------------------------------------------------------------------------------------------------------------
  function liste() {
    const debut = debutMois(st.date);
    const fin = finMois(st.date);
    const jour = auj();
    const par = indexer(debut, fin);
    const jours = [...par.keys()].sort();
    const courant = jour.slice(0, 7) === st.date.slice(0, 7);
    const passes = courant && !st.passes ? jours.filter((d) => d < jour) : [];
    const visibles = jours.filter((d) => !passes.includes(d));
    const feries = feriesEntre(debut, fin);
    if (!jours.length) {
      return etatVide({
        icone: "calendrier", titre: `Rien de prévu en ${moisAnnee(st.date)}`, texte: "Les rendez-vous, les tâches datées, les dates limites de dépôt et les factures à échéance du mois apparaîtront ici.",
        action: peutEcrire ? btn("Nouveau rendez-vous", { ton: "primaire", icone: "plus", onclick: () => nouveauRdv(courant ? jour : debut) }) : null,
      });
    }
    const sections = visibles.map((d) => {
      const ferie = feries.get(d);
      return h(
        "section.cal-agenda__jour",
        { class: { "cal-agenda__jour--auj": d === jour } },
        h("h3.cal-agenda__titre", h("span", majuscule(jourLong(d))), h("span.cal-agenda__rel", echeanceRelative(d, jour)), ferie ? h("span.cal-agenda__ferie", ferie.long) : null),
        h("ul.cal-liste", par.get(d).map((e) => ligneElement(e, { large: true })))
      );
    });
    return panneau(
      { classe: "panneau--liste cal-agenda" },
      passes.length
        ? h("div.cal-agenda__passes", btn(`Afficher les jours déjà passés (${passes.length})`, { petit: true, icone: "haut", onclick: () => {
            st.passes = true;
            rendre();
          } }))
        : null,
      sections.length ? sections : h("p.cal-agenda__rien", "Plus rien de prévu pour le reste du mois."),
      courant && st.passes && jours.some((d) => d < jour)
        ? h("div.cal-agenda__passes.cal-agenda__passes--bas", btn("Masquer les jours passés", { petit: true, onclick: () => {
            st.passes = false;
            rendre();
          } }))
        : null
    );
  }

  // ----- Barre d'outils -------------------------------------------------------------------------------------------------------------------------------
  const titreMois = h("h2.cal__mois", { "aria-live": "polite" });
  const couchesNoeud = h("div.cal__couches", { role: "group", "aria-label": "Éléments affichés" });
  const commutateur = h("div.commutateur", { role: "group", "aria-label": "Présentation du calendrier" });
  const zoneMois = h("div.cal__zone-mois");
  const panneauJour = h("section.panneau.cal__panneau-jour", { "aria-label": "Détail du jour choisi" });
  const zoneListe = h("div.cal__zone-liste");

  // Les boutons sont créés une fois : le clavier garde sa place quand on les active.
  const boutonsVue = [["mois", "Mois"], ["liste", "Liste"]].map(([id, libelle]) =>
    h("button.commutateur__bouton", { type: "button", dataset: { vue: id }, onclick: () => {
      if (st.vue === id) return;
      st.vue = id;
      ecrirePref("calendrier.vue", id);
      rendre();
      enregistrerUrl();
    } }, libelle)
  );
  commutateur.append(...boutonsVue);
  const boutonsCouches = COUCHES.map((c) =>
    h(
      "button.cal__couche",
      { type: "button", title: c.aide || null, dataset: { couche: c.id }, onclick: () => {
        st.couches[c.id] = !st.couches[c.id];
        ecrirePref("calendrier.couches", st.couches);
        rendre();
      } },
      h("span.cal__pastille", { class: `cal-type--${c.pastille}`, "aria-hidden": "true" }),
      c.libelle
    )
  );
  couchesNoeud.append(...boutonsCouches);

  function majBarre() {
    titreMois.textContent = majuscule(moisAnnee(st.date));
    for (const b of boutonsVue) b.setAttribute("aria-pressed", String(st.vue === b.dataset.vue));
    for (const b of boutonsCouches) {
      b.setAttribute("aria-pressed", String(!!st.couches[b.dataset.couche]));
      // La couche Google n'existe que pour une personne dont l'agenda Google est relié et actif.
      if (COUCHES.find((c) => c.id === b.dataset.couche)?.google) b.hidden = !agendaActif();
    }
  }

  // ----- Lecture de l'agenda Google et bandeau d'état -------------------------------------------------------------------------------
  const bandeau = h("div.cal__google", { hidden: true });
  const horodatage = (iso) => {
    const t = Date.parse(iso || "");
    return Number.isFinite(t) ? t : 0;
  };

  function annulerGoogle() {
    g.controleur?.abort();
    g.controleur = null;
    g.chargement = false;
  }

  async function chargerGoogle({ frais = false } = {}) {
    if (g.detruite) return;
    if (!googleVisible()) {
      annulerGoogle();
      return;
    }
    const { debut, fin } = plageGrille();
    g.controleur?.abort();
    const controleur = new AbortController();
    g.controleur = controleur;
    g.cleEssayee = `${debut}|${fin}`;
    g.chargement = true;
    majBandeau();
    try {
      g.donnees = await evenementsGoogle(debut, fin, { signal: controleur.signal, frais });
      g.erreur = null;
    } catch (e) {
      if (e?.name === "AbortError" || controleur !== g.controleur || g.detruite) return;
      if (!(e instanceof ErreurApi)) console.error("[agenda]", e);
      g.erreur = e instanceof ErreurApi ? e : new ErreurApi("Une erreur est survenue. Réessayez.");
      signalerErreurGoogle(g.erreur);
    }
    if (controleur !== g.controleur || g.detruite) return;
    g.controleur = null;
    g.chargement = false;
    rendre();
  }

  /** Demande les événements Google de la plage affichée, une seule fois par plage (« Réessayer » et « Synchroniser » relisent à la demande). */
  function assurerGoogle() {
    if (!googleVisible()) {
      if (g.controleur) annulerGoogle();
      return;
    }
    const { debut, fin } = plageGrille();
    if (g.cleEssayee !== `${debut}|${fin}`) chargerGoogle();
  }

  async function synchroniserMaintenant() {
    if (g.synchro || !agendaActif()) return;
    g.synchro = true;
    majBandeau();
    try {
      const r = resumeSynchro(await synchroniserAgenda());
      toast(r.texte, { ton: r.ton === "attention" ? "info" : r.ton });
    } finally {
      g.synchro = false;
    }
    // La fin d'une synchronisation relit l'état de Google, ce qui relance déjà la lecture de l'agenda ; sinon on la relance ici.
    if (!g.chargement) {
      g.cleEssayee = "";
      await chargerGoogle({ frais: true });
    }
    majBandeau();
  }

  /** Une ligne discrète sous la barre : état de la connexion à Google, dernière synchronisation, erreurs et bouton « Synchroniser ». */
  function majBandeau() {
    const gg = google();
    const moi = gg.moi || {};
    const noeuds = [];
    let ton = "";
    if (agendaActif()) {
      const derniere = horodatage(moi.derniere_synchro);
      const echec = moi.derniere_erreur;
      let texte;
      if (g.erreur) {
        ton = "alerte";
        texte = `Impossible de lire votre agenda Google : ${g.erreur.message}`;
      } else if (echec) {
        ton = "alerte";
        texte = `La dernière synchronisation de votre agenda Google a échoué : ${echec.message}`;
      } else {
        texte = `Google Agenda${compteGoogle() ? ` (${compteGoogle()})` : ""} : ${g.chargement ? "lecture en cours…" : derniere ? `synchronisé ${ilYa(derniere)}` : "pas encore synchronisé"}`;
        if (g.donnees?.tronque && !g.chargement) texte += ". Seuls les premiers événements du mois sont affichés.";
      }
      noeuds.push(
        icone(ton ? "alerte" : "calendrier", "ic--p"),
        h("span.cal__google-texte", texte),
        peutEcrire
          ? btn(g.synchro ? "Synchronisation…" : ton ? "Réessayer" : "Synchroniser", {
              petit: true, ton: "discret", icone: "rafraichir", desactive: g.synchro,
              onclick: () => (g.erreur ? (g.cleEssayee = "", chargerGoogle({ frais: true })) : synchroniserMaintenant()),
            })
          : null
      );
    } else if (aReconnecter() && fonctionsAttendues().agenda) {
      ton = "alerte";
      noeuds.push(
        icone("alerte", "ic--p"),
        h("span.cal__google-texte", "Votre connexion à Google a expiré : vos événements Google Agenda sont en pause."),
        btn("Reconnecter", { petit: true, ton: "discret", onclick: () => naviguer("/parametres/google") })
      );
    } else if (peutEcrire && gg.configure && gg.fonctions?.agenda && !moi.connecte) {
      noeuds.push(
        icone("calendrier", "ic--p"),
        h("span.cal__google-texte", "Voyez aussi vos événements Google Agenda ici, et envoyez-y vos rendez-vous."),
        h("a.lien-discret", { href: "#/parametres/google" }, "Relier mon compte Google")
      );
    }
    bandeau.hidden = !noeuds.length;
    bandeau.classList.toggle("cal__google--alerte", ton === "alerte");
    bandeau.replaceChildren(...noeuds.filter(Boolean));
  }

  function enregistrerUrl() {
    majRequete({ date: st.date === auj() ? "" : st.date, vue: st.vue === "liste" ? "liste" : "" });
  }

  const enLigne = () => panneauJour.getClientRects().length > 0;

  function majPanneauJour() {
    panneauJour.replaceChildren(
      h("header.panneau__tete", h("div.panneau__titres", h("h2", majuscule(dateLongue(st.date))))),
      h("div.panneau__corps", contenuJour(st.date))
    );
  }

  function rendre({ focus = null } = {}) {
    const actif = document.activeElement;
    const dansGrille = actif instanceof HTMLElement && zoneMois.contains(actif) ? actif.dataset.date || actif.closest("td")?.dataset.date : null;
    majBarre();
    const mois = st.vue === "mois";
    zoneMois.hidden = !mois;
    panneauJour.hidden = !mois;
    zoneListe.hidden = mois;
    if (mois) {
      zoneMois.replaceChildren(grille());
      majPanneauJour();
    } else zoneListe.replaceChildren(liste());
    const cible = focus || dansGrille;
    if (cible && mois) zoneMois.querySelector(`.cal__num[data-date="${cible}"]`)?.focus({ preventScroll: true });
    majBandeau();
    assurerGoogle();
  }

  /** Clic sur un jour : sur téléphone le jour s'affiche sous la grille ; sinon une fenêtre s'ouvre. */
  function choisirJour(date) {
    st.date = date;
    enregistrerUrl();
    rendre({ focus: date });
    if (!enLigne()) ouvrirJour(date);
  }

  /** Déplacement au clavier : change le jour choisi sans ouvrir de fenêtre. */
  function deplacer(date) {
    const autreMois = date.slice(0, 7) !== st.date.slice(0, 7);
    const ancien = st.date;
    st.date = date;
    enregistrerUrl();
    if (autreMois) {
      rendre({ focus: date });
      return;
    }
    for (const [d, actif] of [[ancien, false], [date, true]]) {
      const td = zoneMois.querySelector(`td[data-date="${d}"]`);
      td?.classList.toggle("cal__jour--selection", actif);
      td?.querySelector(".cal__num")?.setAttribute("tabindex", actif ? "0" : "-1");
    }
    zoneMois.querySelector(`.cal__num[data-date="${date}"]`)?.focus({ preventScroll: true });
    majPanneauJour();
  }

  function memeJourDuMois(date, n) {
    const premier = ajouterMois(debutMois(date), n);
    const dernier = +finMois(premier).slice(8);
    return ajouterJours(premier, Math.min(+date.slice(8), dernier) - 1);
  }

  zoneMois.addEventListener("keydown", (ev) => {
    const b = ev.target instanceof HTMLElement ? ev.target.closest(".cal__num") : null;
    if (!b || ev.altKey || ev.ctrlKey || ev.metaKey) return;
    const d = b.dataset.date;
    const cible = {
      ArrowLeft: () => ajouterJours(d, -1), ArrowRight: () => ajouterJours(d, 1), ArrowUp: () => ajouterJours(d, -7), ArrowDown: () => ajouterJours(d, 7),
      Home: () => debutSemaine(d), End: () => ajouterJours(debutSemaine(d), 6), PageUp: () => memeJourDuMois(d, -1), PageDown: () => memeJourDuMois(d, 1),
    }[ev.key]?.();
    if (!cible) return;
    ev.preventDefault();
    deplacer(cible);
  });

  function allerAuMois(n) {
    const cible = memeJourDuMois(st.date, n);
    st.date = cible.slice(0, 7) === auj().slice(0, 7) ? auj() : debutMois(cible);
    st.passes = false;
    enregistrerUrl();
    rendre();
  }

  const barre = h(
    "div.cal__barre",
    h(
      "div.cal__nav",
      btnIcone("gauche", "Mois précédent", () => allerAuMois(-1)),
      btnIcone("droite", "Mois suivant", () => allerAuMois(1)),
      btn("Aujourd’hui", { petit: true, onclick: () => {
        st.date = auj();
        st.passes = false;
        enregistrerUrl();
        rendre();
      } }),
      titreMois
    ),
    couchesNoeud
  );

  const actions = [commutateur];
  if (peutEcrire) actions.push(btn("Nouveau rendez-vous", { ton: "primaire", icone: "plus", onclick: () => nouveauRdv(st.date) }));

  const racine = h(
    "div.cal",
    enTete({ titre: "Calendrier", sous: "Rendez-vous, tâches datées, dates limites de dépôt, décisions attendues et factures à échéance.", actions }),
    barre,
    bandeau,
    zoneMois,
    panneauJour,
    zoneListe
  );
  rendre();

  // Un lien « #/calendrier?evenement=… » (depuis l'Accueil) ouvre directement le rendez-vous.
  if (evenementDemande) {
    setTimeout(() => {
      const ev = fiche("evenements", evenementDemande);
      if (ev && !ev.supprime) ouvrirRdv(evenementDemande);
      enregistrerUrl();
    }, 0);
  }

  return {
    titre: "Calendrier",
    noeud: racine,
    miseAJour(changes) {
      // Le compte Google a été relié, renouvelé ou retiré, ou une synchronisation vient de finir : on relit l'agenda.
      if (changes?.has("google")) {
        g.cleEssayee = "";
        if (!googleVisible()) {
          annulerGoogle();
          g.donnees = null;
          g.erreur = null;
        }
      }
      rendre();
      return true;
    },
    detruire() {
      g.detruite = true;
      annulerGoogle();
    },
  };
}
