// =============================================================================
// Changer une affaire d'étape ou un dossier de statut : motif obligatoire quand
// l'affaire est perdue, décision demandée quand le dossier est accepté ou refusé,
// message avec annulation, annonce pour les lecteurs d'écran. Sert au tableau des
// affaires (glisser-déposer, menu « Déplacer vers… ») et aux fiches.
// =============================================================================
import { h, annoncer, idUnique } from "../noyau/dom.js";
import { icone } from "../noyau/icones.js";
import { fiche as ficheDe, etapeDe, statutDossierDe } from "../noyau/etat.js";
import { modifierFiche, tenter } from "../noyau/ecriture.js";
import { RAISONS_PERTE, ENTITES } from "../commun/schema.js";
import { aujourdhui } from "../commun/dates.js";
import { tronquer } from "../commun/format.js";
import { btn } from "../ui/composants.js";
import { creerChamp } from "../ui/formulaire.js";
import { ouvrirDialogue } from "../ui/dialogue.js";
import { toast } from "../ui/toast.js";

/** Demande pourquoi l'affaire est perdue. Retourne l'identifiant de la raison, ou null si la personne renonce. */
export function choisirRaisonPerte(o) {
  return ouvrirDialogue({
    titre: "Pourquoi cette affaire est-elle perdue ?",
    taille: "petit",
    description: `« ${tronquer(o.titre, 70)} » sera classée parmi les affaires perdues. Cette raison alimente vos rapports.`,
    contenu: (ctx) => {
      const id = idUnique("raison");
      const sel = h("select.saisie", { id, "data-focus-id": "raison-perte" }, h("option", { value: "" }, "Choisir une raison…"), RAISONS_PERTE.map((r) => h("option", { value: r.id }, r.libelle)));
      if (o.raison_perte) sel.value = o.raison_perte;
      const erreur = h("p.champ__erreur", { hidden: true, role: "alert" }, "Choisissez une raison pour continuer.");
      const valider = () => {
        if (!sel.value) {
          erreur.hidden = false;
          sel.focus();
          return;
        }
        ctx.fermer(sel.value);
      };
      sel.addEventListener("change", () => (erreur.hidden = true));
      sel.addEventListener("keydown", (e) => e.key === "Enter" && (e.preventDefault(), valider()));
      ctx.definirPied(btn("Annuler", { onclick: () => ctx.fermer(null) }), btn("Classer comme perdue", { ton: "primaire", onclick: valider }));
      return h("div.champ", h("label.champ__etiquette", { for: id }, "Raison de la perte"), h("div.saisie-select", sel, icone("bas", "ic--p")), erreur);
    },
  }).promesse.then((v) => v || null);
}

/**
 * Déplace l'affaire vers une étape. Retourne true si elle a bougé.
 *   options.annulable : proposer « Annuler » dans le message (défaut : oui)
 */
export async function deplacerAffaire(id, etapeId, { annulable = true } = {}) {
  const o = ficheDe("opportunites", id);
  const cible = etapeDe(etapeId);
  if (!o || !cible || o.etape === etapeId) return false;
  const avant = { etape: o.etape, raison_perte: o.raison_perte ?? null, probabilite: o.probabilite };
  const patch = { etape: etapeId };
  if (cible.type === "perdue") {
    const raison = await choisirRaisonPerte(o);
    if (!raison) return false;
    patch.raison_perte = raison;
  } else if (o.raison_perte) patch.raison_perte = null;

  const r = await tenter(() => modifierFiche("opportunites", ficheDe("opportunites", id) || o, patch), { entite: "opportunites" });
  if (!r) return false;
  annoncer(`Affaire déplacée vers l’étape « ${cible.nom} ».`);
  toast(`« ${tronquer(o.titre, 44)} » est maintenant à l’étape « ${cible.nom} ».`, {
    ton: cible.type === "perdue" ? "info" : "ok",
    action: annulable
      ? {
          libelle: "Annuler",
          onclick: () => {
            const courante = ficheDe("opportunites", id);
            if (!courante) return;
            const retour = { etape: avant.etape, raison_perte: avant.raison_perte };
            if (avant.probabilite !== undefined && avant.probabilite !== null) retour.probabilite = avant.probabilite;
            tenter(() => modifierFiche("opportunites", courante, retour), { succes: "Déplacement annulé.", entite: "opportunites" });
          },
        }
      : null,
  });
  return true;
}

// ----- Dossiers de financement -----------------------------------------------------------------------------------------------------------------------
/** Un montant saisi (« 48 000,00 ») en nombre ; null s'il est vide, NaN s'il est invalide. */
function lireMontant(texte) {
  const s = String(texte ?? "").replace(/[\s\u00a0\u202f]/g, "");
  if (s === "") return null;
  return /^\d+([.,]\d{1,2})?$/.test(s) ? Math.round(parseFloat(s.replace(",", ".")) * 100) / 100 : Number.NaN;
}

/**
 * Demande les renseignements de la décision de l'organisme : le montant accordé pour un dossier accepté,
 * les motifs pour un dossier refusé, et la date. Tout est facultatif. Retourne le correctif à appliquer
 * au dossier, ou null si la personne renonce.
 */
function demanderDecision(d, cible) {
  const accepte = cible.type === "accepte";
  const champs = ENTITES.dossiers.champs;
  return ouvrirDialogue({
    titre: accepte ? "Dossier accepté" : "Dossier refusé",
    taille: "petit",
    description: accepte
      ? `La réponse de l’organisme pour « ${tronquer(d.titre, 60)} ». Ces renseignements alimentent la fiche et vos rapports ; tout est facultatif.`
      : `La réponse de l’organisme pour « ${tronquer(d.titre, 60)} ». Garder les motifs aide à préparer une nouvelle demande ; tout est facultatif.`,
    contenu: (ctx) => {
      const date = creerChamp("date_decision", champs.date_decision, d.date_decision || aujourdhui(), {});
      const montant = accepte ? creerChamp("montant_obtenu", champs.montant_obtenu, d.montant_obtenu ?? d.montant_demande ?? "", {}) : null;
      const motifs = accepte ? null : creerChamp("raison_refus", champs.raison_refus, d.raison_refus || "", { rows: 4 });
      const valider = () => {
        const patch = { date_decision: date.lire() || null };
        if (montant) {
          const n = lireMontant(montant.lire());
          if (Number.isNaN(n)) {
            montant.erreur("Entrez un montant en dollars, par exemple 48 000,00.");
            montant.focus();
            return;
          }
          patch.montant_obtenu = n;
          patch.raison_refus = null;
        } else {
          patch.raison_refus = motifs.lire().trim() || null;
          patch.montant_obtenu = null;
        }
        ctx.fermer(patch);
      };
      ctx.definirPied(btn("Annuler", { onclick: () => ctx.fermer(null) }), btn("Enregistrer", { ton: "primaire", onclick: valider }));
      const form = h("form.formulaire", { novalidate: true, onsubmit: (e) => (e.preventDefault(), valider()) }, h("div.grille.grille--1", montant ? montant.noeud : motifs.noeud, date.noeud));
      return form;
    },
  }).promesse.then((v) => v || null);
}

/**
 * Change le statut d'un dossier. Retourne true s'il a bougé.
 * Le serveur date le changement et ajoute les tâches prévues pour le nouveau statut.
 * Une décision (accepté ou refusé) est demandée à part ; un retour en arrière efface la décision.
 */
export async function changerStatutDossier(id, statutId, { annulable = true } = {}) {
  const d = ficheDe("dossiers", id);
  const cible = statutDossierDe(statutId);
  if (!d || !cible || d.statut === statutId) return false;
  const ancien = statutDossierDe(d.statut);
  const suivis = ["date_depot", "date_decision", "montant_obtenu", "raison_refus"];
  const avant = Object.fromEntries(suivis.map((k) => [k, d[k] ?? null]));
  const patch = { statut: statutId };
  if (cible.type === "accepte" || cible.type === "refuse") {
    const decision = await demanderDecision(d, cible);
    if (!decision) return false;
    Object.assign(patch, decision);
  } else if (cible.type === "en-cours" && ancien && ancien.type !== "en-cours") {
    // Le dossier repart en traitement : la décision précédente ne tient plus.
    for (const k of ["date_decision", "montant_obtenu", "raison_refus"]) if (avant[k] !== null) patch[k] = null;
  }

  const r = await tenter(() => modifierFiche("dossiers", ficheDe("dossiers", id) || d, patch), { entite: "dossiers" });
  if (!r) return false;
  annoncer(`Dossier passé au statut « ${cible.nom} ».`);
  const n = r.effets?.taches || 0;
  const suite = n ? ` ${n} tâche${n > 1 ? "s ont été ajoutées" : " a été ajoutée"} à votre liste.` : "";
  toast(`« ${tronquer(d.titre, 44)} » est maintenant « ${cible.nom} ».${suite}`, {
    ton: cible.type === "refuse" ? "info" : "ok", duree: n ? 9000 : undefined,
    action: annulable
      ? {
          libelle: "Annuler",
          onclick: () => {
            const courant = ficheDe("dossiers", id);
            if (!courant) return;
            const retour = { statut: d.statut };
            for (const k of suivis) if ((courant[k] ?? null) !== avant[k]) retour[k] = avant[k];
            tenter(() => modifierFiche("dossiers", courant, retour), { succes: n ? "Statut rétabli. Les tâches ajoutées restent dans votre liste." : "Changement de statut annulé.", entite: "dossiers" });
          },
        }
      : null,
  });
  return true;
}
