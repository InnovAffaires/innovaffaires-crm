// =============================================================================
// Fenêtres de création et de modification des fiches, pour toutes les entités,
// avec les éditeurs particuliers : lignes de facture, documents d'un dossier,
// lien vers une autre fiche.
// =============================================================================
import { h, idUnique } from "../noyau/dom.js";
import { icone } from "../noyau/icones.js";
import { TYPES_LIEN } from "../commun/schema.js";
import { valeursParDefaut } from "../commun/valider.js";
import { calculerTotaux, montantLigne } from "../commun/calculs.js";
import { argent, tauxTaxe } from "../commun/format.js";
import { aujourdhui, partiesLocales, instantLocal } from "../commun/dates.js";
import { nouvelId } from "../commun/ids.js";
import { etat, fiche as ficheLocale, mettreAJourFiche } from "../noyau/etat.js";
import { creerFiche, modifierFiche, tenter } from "../noyau/ecriture.js";
import { naviguer, cheminFiche } from "../noyau/routeur.js";
import { ErreurApi } from "../noyau/api.js";
import { creerFormulaire, optionsRef } from "../ui/formulaire.js";
import { combobox } from "../ui/combobox.js";
import { ouvrirDialogue } from "../ui/dialogue.js";
import { btn, btnIcone, menuActions } from "../ui/composants.js";
import { toast } from "../ui/toast.js";

const ENTITES_AVEC_PAGE = new Set(["contacts", "entreprises", "opportunites", "dossiers", "factures"]);
const NOMS_LIEN = { contacts: "Contact", entreprises: "Entreprise", opportunites: "Affaire", dossiers: "Dossier", factures: "Facture ou devis", demandes: "Demande du site" };
const sansEspaces = (s) => String(s ?? "").replace(/[\s  $]/g, "");
const nombreDe = (s) => {
  const n = parseFloat(sansEspaces(s).replace(",", "."));
  return Number.isFinite(n) ? n : 0;
};
const texteNombre = (n, dec = null) => (n === undefined || n === null || n === "" ? "" : dec === null ? String(n).replace(".", ",") : Number(n).toFixed(dec).replace(".", ","));

// ===== Éditeur : lignes d'une facture ou d'un devis =========================================================
function editeurLignes({ valeur = [], desactive = false, taux }) {
  const corps = h("div.lignes__corps");
  const totaux = h("dl.totaux");
  const err = h("p.champ__erreur", { hidden: true, role: "alert" });
  const lignes = [];
  let initial = null;

  function lireLigne(l) {
    return { description: l.desc.value, quantite: sansEspaces(l.qte.value), unite: l.unite.value, prix: sansEspaces(l.prix.value), taxable: l.taxable.checked };
  }
  function apercu() {
    const items = lignes.map((l) => ({ quantite: nombreDe(l.qte.value), prix: nombreDe(l.prix.value), taxable: l.taxable.checked }));
    const t = calculerTotaux(items, taux);
    lignes.forEach((l, i) => (l.montant.textContent = argent(montantLigne(items[i]))));
    totaux.replaceChildren(
      ...[
        ["Sous-total", argent(t.sous_total)],
        [`TPS (${tauxTaxe(taux.tps)})`, argent(t.tps)],
        [`TVQ (${tauxTaxe(taux.tvq)})`, argent(t.tvq)],
      ].map(([k, v]) => h("div.totaux__ligne", h("dt", k), h("dd", v))),
      h("div.totaux__ligne.totaux__ligne--total", h("dt", "Total"), h("dd", argent(t.total)))
    );
    renumeroter();
  }
  function renumeroter() {
    lignes.forEach((l, i) => l.noeud.setAttribute("aria-label", `Ligne ${i + 1}`));
  }

  function ajouter(v = {}, { focus = false } = {}) {
    const champ = (nom, controle, classe = "") => h("label.lg-champ", { class: classe }, h("span.lg-champ__nom", nom), controle);
    const desc = h("input.saisie", { type: "text", maxlength: 300, placeholder: "Description", disabled: desactive, autocomplete: "off" });
    const qte = h("input.saisie.saisie--nombre", { type: "text", inputmode: "decimal", disabled: desactive, autocomplete: "off" });
    const unite = h("input.saisie", { type: "text", maxlength: 20, placeholder: "ex. h", disabled: desactive, autocomplete: "off" });
    const prix = h("input.saisie.saisie--nombre", { type: "text", inputmode: "decimal", placeholder: "0,00", disabled: desactive, autocomplete: "off" });
    const idCase = idUnique("lg-tx");
    const taxable = h("input", { id: idCase, type: "checkbox", disabled: desactive });
    desc.value = v.description ?? "";
    qte.value = v.quantite === undefined ? "1" : texteNombre(v.quantite);
    unite.value = v.unite ?? "";
    prix.value = v.prix === undefined || v.prix === "" ? "" : texteNombre(v.prix, 2);
    taxable.checked = v.taxable !== false;
    const montant = h("output.lg-montant", { "aria-label": "Montant de la ligne" });
    const retirer = btnIcone("fermer", "Retirer cette ligne", () => {
      const i = lignes.indexOf(l);
      lignes.splice(i, 1);
      noeud.remove();
      apercu();
      if (!lignes.length) corps.append(vide());
      (lignes[Math.min(i, lignes.length - 1)]?.desc || ajoutBtn).focus();
    }, { desactive });
    const noeud = h(
      "div.lg",
      { role: "group", class: { "lg--verrou": desactive } },
      champ("Description", desc, "lg-champ--desc"),
      champ("Quantité", qte, "lg-champ--qte"),
      champ("Unité", unite, "lg-champ--unite"),
      champ("Prix unitaire", prix, "lg-champ--prix"),
      h("div.lg-champ.lg-champ--tx", h("label.case", { for: idCase }, taxable, h("span.case__boite", { "aria-hidden": "true" }, icone("coche", "ic--p")), h("span", "Taxable"))),
      h("div.lg-champ.lg-champ--montant", h("span.lg-champ__nom", "Montant"), montant),
      h("div.lg-champ.lg-champ--x", retirer)
    );
    const l = { noeud, desc, qte, unite, prix, taxable, montant };
    for (const el of [desc, qte, unite, prix, taxable]) el.addEventListener(el === taxable ? "change" : "input", apercu);
    for (const el of [qte, prix]) {
      el.addEventListener("blur", () => {
        const s = sansEspaces(el.value);
        if (s && /^-?\d+([.,]\d+)?$/.test(s)) el.value = texteNombre(nombreDe(s), el === prix ? 2 : null);
        apercu();
      });
    }
    corps.querySelector(".lignes__vide")?.remove();
    lignes.push(l);
    corps.append(noeud);
    apercu();
    if (focus) desc.focus();
    return l;
  }
  const vide = () => h("p.lignes__vide", "Aucune ligne pour l’instant. Ajoutez une ligne ou un service d’honoraires.");

  const hon = etat.config?.honoraires || {};
  const ajoutBtn = btn("Ajouter une ligne", { icone: "plus", petit: true, desactive, onclick: () => ajouter({}, { focus: true }) });
  const presets = menuActions({
    libelle: "Honoraires", icone: "argent", ton: "secondaire", aria: "Ajouter des honoraires courants",
    elements: () => [
      { libelle: `Diagnostic de financement — ${argent(hon.diagnostic || 0)}`, onclick: () => ajouter({ description: "Diagnostic de financement", quantite: 1, prix: hon.diagnostic || 0 }, { focus: false }) },
      { libelle: `Préparation d’un dossier — ${argent(hon.dossier || 0)}`, onclick: () => ajouter({ description: "Préparation d’un dossier de demande de financement", quantite: 1, prix: hon.dossier || 0 }, { focus: false }) },
      { libelle: `Heures de consultation — ${argent(hon.taux_horaire || 0)} l’heure`, onclick: () => ajouter({ description: "Consultation", quantite: 1, unite: "h", prix: hon.taux_horaire || 0 }, { focus: true }) },
    ],
    classeBouton: "btn btn--secondaire btn--petit",
  });
  const noeud = h(
    "div.champ.lignes",
    h("div.lignes__tete", h("span.champ__etiquette", "Lignes"), desactive ? h("span.petit.muet", "Verrouillées : le document a été émis.") : h("div.rangee", presets, ajoutBtn)),
    h("div.lignes__entete", { "aria-hidden": "true" }, h("span", "Description"), h("span.num", "Qté"), h("span", "Unité"), h("span.num", "Prix unitaire"), h("span", "Taxable"), h("span.num", "Montant"), h("span")),
    corps,
    h("div.lignes__pied", totaux),
    err
  );
  for (const v of valeur) ajouter(v);
  if (!lignes.length && !desactive) ajouter({});
  if (!lignes.length) corps.append(vide());
  const lire = () => lignes.map(lireLigne);
  initial = JSON.stringify(lire());
  return {
    noeud, lire, modifie: () => JSON.stringify(lire()) !== initial, focus: () => (lignes[0]?.desc || ajoutBtn).focus(),
    erreurs(map) {
      const globales = [];
      for (const l of lignes) for (const el of [l.desc, l.qte, l.unite, l.prix]) el.removeAttribute("aria-invalid");
      for (const [k, m] of Object.entries(map)) {
        const [, i, champ] = /^lignes\.(\d+)\.(\w+)$/.exec(k) || [];
        const l = lignes[Number(i)];
        const el = l && { description: l.desc, quantite: l.qte, unite: l.unite, prix: l.prix }[champ];
        if (el) {
          el.setAttribute("aria-invalid", "true");
          el.title = m;
          globales.push(`Ligne ${Number(i) + 1} : ${m}`);
        } else globales.push(m);
      }
      err.hidden = !globales.length;
      err.textContent = globales.join(" ");
    },
    desactiver() {},
  };
}

// ===== Éditeur : documents à obtenir d'un dossier ============================================================
export const DOCUMENTS_HABITUELS = [
  "Preuve de constitution (statuts) et NEQ",
  "États financiers du dernier exercice",
  "États financiers de l’exercice précédent",
  "Description du projet et résultats attendus",
  "Calendrier de réalisation",
  "Soumissions ou devis des fournisseurs",
  "Montage financier et mise de fonds",
  "Liste des autres aides reçues ou demandées",
  "Autorisation de représentation signée",
  "Résolution autorisant la demande",
];

function editeurDocuments({ valeur = [] }) {
  const liste = h("ul.docs__liste");
  const lignes = [];
  const saisie = h("input.saisie", { type: "text", maxlength: 200, placeholder: "Ajouter un document (Entrée pour valider)", autocomplete: "off", "aria-label": "Nouveau document à obtenir" });
  const noeud = h("div.champ.docs", h("span.champ__etiquette", "Documents à obtenir"), liste, h("div.docs__ajout", saisie, btn("Ajouter", { petit: true, onclick: () => ajouterSaisie() }), btn("Ajouter la liste habituelle", { petit: true, onclick: ajouterHabituels })));
  const err = h("p.champ__erreur", { hidden: true, role: "alert" });
  noeud.append(err);

  function ajouter(v = {}) {
    const idCase = idUnique("doc");
    const recu = h("input", { id: idCase, type: "checkbox" });
    recu.checked = !!v.recu;
    const nom = h("input.saisie", { type: "text", maxlength: 200, "aria-label": "Nom du document", autocomplete: "off" });
    nom.value = v.nom ?? "";
    const note = h("input.saisie", { type: "text", maxlength: 300, placeholder: "Note", "aria-label": "Note sur le document", autocomplete: "off" });
    note.value = v.note ?? "";
    const l = { id: v.id || nouvelId(), date_recu: v.date_recu || "", recu, nom, note };
    const dateTxt = h("span.docs__date.petit.muet");
    const majDate = () => (dateTxt.textContent = recu.checked && l.date_recu ? `reçu le ${l.date_recu}` : "");
    recu.addEventListener("change", () => {
      l.date_recu = recu.checked ? l.date_recu || aujourdhui() : "";
      majDate();
    });
    majDate();
    const noeudLigne = h(
      "li.docs__ligne",
      h("label.case", { for: idCase }, recu, h("span.case__boite", { "aria-hidden": "true" }, icone("coche", "ic--p")), h("span.sr-only", "Reçu")),
      h("div.docs__champs", nom, note),
      dateTxt,
      btnIcone("fermer", "Retirer ce document", () => {
        lignes.splice(lignes.indexOf(l), 1);
        noeudLigne.remove();
        saisie.focus();
      })
    );
    l.noeud = noeudLigne;
    lignes.push(l);
    liste.append(noeudLigne);
    return l;
  }
  function ajouterSaisie() {
    const t = saisie.value.trim();
    if (!t) return;
    ajouter({ nom: t });
    saisie.value = "";
    saisie.focus();
  }
  function ajouterHabituels() {
    const connus = new Set(lignes.map((l) => l.nom.value.trim().toLowerCase()));
    for (const nom of DOCUMENTS_HABITUELS) if (!connus.has(nom.toLowerCase())) ajouter({ nom });
  }
  saisie.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      ajouterSaisie();
    }
  });
  for (const d of valeur) ajouter(d);
  const lire = () => {
    const sortie = lignes.map((l) => {
      const o = { id: l.id, nom: l.nom.value, recu: l.recu.checked };
      if (l.recu.checked && l.date_recu) o.date_recu = l.date_recu;
      if (l.note.value.trim()) o.note = l.note.value;
      return o;
    });
    const reste = saisie.value.trim();
    if (reste) sortie.push({ id: nouvelId(), nom: reste, recu: false });
    return sortie;
  };
  const initial = JSON.stringify(lire());
  return {
    noeud, lire, modifie: () => JSON.stringify(lire()) !== initial, focus: () => saisie.focus(),
    erreurs(map) {
      err.hidden = !Object.keys(map).length;
      err.textContent = Object.values(map).join(" ");
    },
  };
}

// ===== Éditeur : lien vers une autre fiche (tâches et rendez-vous) ==========================================
function editeurLien({ type = "", id = "", desactive = false }) {
  const idType = idUnique("lie-t");
  const sel = h("select.saisie", { id: idType, disabled: desactive }, h("option", { value: "" }, "Aucune"), TYPES_LIEN.map((t) => h("option", { value: t }, NOMS_LIEN[t])));
  sel.value = type || "";
  let cb = null;
  const zone = h("div.lie__choix");
  const err = h("p.champ__erreur", { hidden: true });
  const noeud = h("div.champ.lie", h("label.champ__etiquette", { for: idType }, "Liée à"), h("div.lie__rang", h("div.saisie-select", sel, icone("bas", "ic--p")), zone), err);
  function monter() {
    zone.replaceChildren();
    cb = null;
    if (!sel.value) return;
    cb = combobox({ options: () => optionsRef(sel.value), valeur: sel.value === type ? id : null, placeholder: `Choisir ${NOMS_LIEN[sel.value].toLowerCase()}…`, etiquette: "Fiche liée", aucun: "Choisir…", desactive });
    zone.append(cb.noeud);
  }
  sel.addEventListener("change", () => {
    monter();
    noeud.dispatchEvent(new CustomEvent("change", { bubbles: true }));
  });
  monter();
  const lireId = () => (cb ? cb.lire() || "" : "");
  const lireType = () => (lireId() ? sel.value : "");
  const initial = JSON.stringify([lireType(), lireId()]);
  return {
    noeud, lireType, lireId, focus: () => sel.focus(),
    modifie: () => JSON.stringify([lireType(), lireId()]) !== initial,
    erreurs(map) {
      const m = Object.values(map)[0];
      err.hidden = !m;
      err.textContent = m || "";
    },
  };
}

// ===== Dispositions ================================================================================================
const A = (cle, o = {}) => ({ cle, ...o });
const E = (cle, o = {}) => ({ cle, etendu: true, ...o });

function disposition(entite, { creation, verrou }) {
  switch (entite) {
    case "contacts":
      return [
        { titre: "Identité", champs: ["prenom", "nom", "courriel", "telephone", "mobile", "titre", "entreprise_id", "ville", "langue"] },
        {
          titre: "Suivi",
          champs: [
            "source", "responsable_id", E("etiquettes", { placeholder: "Ajouter une étiquette (Entrée)" }),
            E("consentement", { aide: "Détermine si vous pouvez écrire à cette personne à des fins promotionnelles. Une réponse à sa propre demande suffit pour y répondre." }),
            E("ne_pas_appeler", { aide: "À cocher si cette personne a demandé de ne plus être appelée. Elle sort de la file d’appels et ne peut plus y être ajoutée. Décochez pour la retirer de la liste." }),
            E("notes", { rows: 4 }), ...(creation ? [] : [E("archive")]),
          ],
        },
      ];
    case "entreprises":
      return [
        { titre: "Entreprise", champs: [E("nom"), "neq", "secteur", "forme", "employes", "annee_fondation", "chiffre_affaires", "site_web", "telephone"] },
        { titre: "Adresse", champs: [E("adresse"), "ville", "code_postal", "region"] },
        { titre: "Suivi", champs: ["source", "responsable_id", E("etiquettes", { placeholder: "Ajouter une étiquette (Entrée)" }), E("ne_pas_appeler", { aide: "À cocher si cette entreprise a demandé de ne plus être appelée. Elle sort de la file d’appels et ne peut plus y être ajoutée. Décochez pour la retirer de la liste." }), E("notes", { rows: 4 }), ...(creation ? [] : [E("archive")])] },
      ];
    case "opportunites":
      return [
        {
          champs: [
            E("titre"), "entreprise_id", "contact_id", "etape", "service", "valeur", "probabilite", "date_fermeture_prevue", "source", "responsable_id",
            E("raison_perte"), E("notes", { rows: 4 }),
          ],
        },
      ];
    case "dossiers":
      return [
        { titre: "Dossier", champs: [E("titre"), "entreprise_id", "contact_id", E("programme"), "organisme", "palier", "type_aide", "statut", "opportunite_id", "responsable_id"] },
        { titre: "Montants", colonnes: 3, champs: ["montant_demande", "cout_projet", "montant_obtenu"] },
        { titre: "Dates", champs: ["date_limite", "date_depot", "date_decision_prevue", "date_decision"] },
        { titre: "Organisme", champs: ["numero_dossier", E("lien_portail"), E("raison_refus", { rows: 3 })] },
        { titre: "Documents", champs: ["documents"] },
        { titre: "Notes", colonnes: 1, champs: [E("notes", { rows: 5 })] },
      ];
    case "taches":
      return [{ champs: [E("titre"), "type", "priorite", "echeance", "heure", "responsable_id", ...(creation ? [] : ["statut"]), E("lie_type"), A("lie_id"), E("description", { rows: 4 })] }];
    case "evenements":
      return [{ champs: [E("titre"), "type", E("journee_entiere"), "debut", "fin", E("lieu"), E("lie_type"), A("lie_id"), "responsable_id", E("notes", { rows: 3 })] }];
    case "factures":
      return [
        {
          titre: "Document",
          champs: [A("type", { desactive: verrou }), A("entreprise_id", { desactive: verrou }), "contact_id", E("objet"), A("date_emission", { desactive: verrou, aide: "Laissée vide : la date du jour à l’émission." }), A("date_echeance", { aide: "Laissée vide : calculée selon vos conditions de paiement à l’émission." }), "conditions", "dossier_id", "opportunite_id"],
        },
        { titre: "Lignes", colonnes: 1, champs: ["lignes"] },
        { titre: "Notes", colonnes: 1, champs: [E("notes", { rows: 3, aide: "Affichées sur le document imprimé." })] },
      ];
    case "demandes":
      return [{ champs: ["statut", "reponse_le", E("ne_pas_appeler", { aide: "À cocher si cette personne a demandé de ne plus être appelée. Elle sort de la file d’appels et ne peut plus y être ajoutée. Décochez pour la retirer de la liste." }), E("notes", { rows: 4 })] }];
    default:
      throw new Error(`Aucun formulaire pour ${entite}`);
  }
}

function defautsCreation(entite) {
  const c = etat.config;
  const moi = etat.utilisateur?.id;
  const sortie = {};
  if (["contacts", "entreprises", "opportunites", "dossiers", "taches", "evenements"].includes(entite) && moi) sortie.responsable_id = moi;
  if (entite === "opportunites" && c?.etapes?.[0]) {
    sortie.etape = c.etapes[0].id;
    sortie.probabilite = c.etapes[0].probabilite;
  }
  if (entite === "dossiers" && c?.statuts_dossier?.[0]) sortie.statut = c.statuts_dossier[0].id;
  if (entite === "factures") sortie.conditions = c?.facturation?.conditions || "";
  if (entite === "evenements") {
    const p = partiesLocales(Date.now() + 3_600_000);
    sortie.debut = new Date(instantLocal(p.date, `${p.heure.slice(0, 2)}:00`)).toISOString();
  }
  return sortie;
}

const TITRES = {
  contacts: ["Nouveau contact", "Modifier le contact"],
  entreprises: ["Nouvelle entreprise", "Modifier l’entreprise"],
  opportunites: ["Nouvelle affaire", "Modifier l’affaire"],
  dossiers: ["Nouveau dossier de financement", "Modifier le dossier"],
  taches: ["Nouvelle tâche", "Modifier la tâche"],
  evenements: ["Nouveau rendez-vous", "Modifier le rendez-vous"],
  factures: ["Nouvelle facture", "Modifier la facture"],
  demandes: ["Nouvelle demande", "Modifier la demande"],
};

const SUCCES = {
  contacts: ["Contact créé.", "Contact enregistré."],
  entreprises: ["Entreprise créée.", "Entreprise enregistrée."],
  opportunites: ["Affaire créée.", "Affaire enregistrée."],
  dossiers: ["Dossier créé.", "Dossier enregistré."],
  taches: ["Tâche ajoutée.", "Tâche enregistrée."],
  evenements: ["Rendez-vous ajouté.", "Rendez-vous enregistré."],
  factures: ["Document créé.", "Document enregistré."],
  demandes: ["", "Demande enregistrée."],
};

// ===== Création rapide d'un lien (depuis une liste déroulante) ===============================================
function separerNom(texte) {
  const mots = String(texte).trim().split(/\s+/).filter(Boolean);
  if (mots.length <= 1) return { nom: mots[0] || "" };
  return { prenom: mots[0], nom: mots.slice(1).join(" ") };
}
const creationsRapides = {
  entreprises: {
    libelle: "Créer l’entreprise",
    action: async (nom) => {
      const r = await tenter(() => creerFiche("entreprises", { nom, responsable_id: etat.utilisateur?.id }), { succes: `Entreprise « ${nom} » créée.` });
      return r?.fiche.id || null;
    },
  },
  contacts: {
    libelle: "Créer le contact",
    action: async (texte) => {
      const r = await tenter(() => creerFiche("contacts", { ...separerNom(texte), responsable_id: etat.utilisateur?.id }), { succes: `Contact « ${texte} » créé.` });
      return r?.fiche.id || null;
    },
  },
};

// ===== Fenêtre ===========================================================================================
function ouvrir({ entite, fiche = null, valeurs = {}, options = {} }) {
  const creation = !fiche;
  const config = etat.config;
  const typeDoc = (fiche?.type || valeurs.type) === "devis" ? "devis" : "facture";
  const verrou = entite === "factures" && !creation && fiche.statut !== "brouillon";
  const init = creation ? { ...valeursParDefaut(entite), ...defautsCreation(entite), ...valeurs } : { ...fiche };
  const editeurs = {};
  if (entite === "factures") editeurs.lignes = editeurLignes({ valeur: init.lignes || [], desactive: verrou, taux: init.taux || config.taxes });
  if (entite === "dossiers") editeurs.documents = editeurDocuments({ valeur: init.documents || [] });
  if (entite === "taches" || entite === "evenements") {
    const lien = editeurLien({ type: init.lie_type, id: init.lie_id });
    editeurs.lie_type = { noeud: lien.noeud, lire: lien.lireType, modifie: lien.modifie, focus: lien.focus };
    editeurs.lie_id = { noeud: null, lire: lien.lireId, modifie: lien.modifie, erreurs: lien.erreurs };
  }

  let courante = fiche;
  const titreBase = TITRES[entite][creation ? 0 : 1];
  const titre = entite === "factures" ? (typeDoc === "devis" ? (creation ? "Nouveau devis" : "Modifier le devis") : titreBase) : titreBase;

  return ouvrirDialogue({
    titre, taille: entite === "dossiers" || entite === "factures" ? "grand" : "moyen",
    contenu: (ctx) => {
      const form = creerFormulaire({
        entite, valeurs: init, disposition: disposition(entite, { creation, verrou }), editeurs, creationsRapides, existant: fiche,
        surChangement: () => {
          ctx.modifie(form.modifie());
          conditions();
        },
        surSoumission: () => enregistrer(),
      });
      const champ = (k) => form.champs.get(k);
      const montrer = (k, visible) => {
        const c = champ(k);
        if (c?.noeud) c.noeud.hidden = !visible;
      };
      let derniereEtape = init.etape;
      function conditions() {
        if (entite === "opportunites") {
          const id = champ("etape").lire();
          const e = config.etapes.find((x) => x.id === id);
          montrer("raison_perte", e?.type === "perdue");
          if (id !== derniereEtape) {
            derniereEtape = id;
            if (e && !champ("probabilite").modifie()) champ("probabilite").definir?.(e.probabilite);
          }
        } else if (entite === "dossiers") {
          const s = config.statuts_dossier.find((x) => x.id === champ("statut").lire());
          montrer("raison_refus", s?.type === "refuse");
        } else if (entite === "evenements") {
          const jour = champ("journee_entiere").lire();
          for (const k of ["debut", "fin"]) for (const t of champ(k).noeud.querySelectorAll(".saisie--heure")) t.hidden = !!jour;
        }
      }
      conditions();

      const cible = h("div");
      cible.append(form.noeud);
      const annuler = btn("Annuler", { onclick: () => ctx.fermer(undefined) });
      const ok = btn(creation ? "Créer" : "Enregistrer", { ton: "primaire", onclick: () => enregistrer() });
      ctx.definirPied(annuler, ok);

      async function enregistrer() {
        const r = form.valider({ creation });
        if (!r.ok) return;
        if (!creation && !Object.keys(r.charge).length) {
          ctx.fermer(courante);
          return;
        }
        ctx.occupe(true);
        try {
          const rep = creation ? await creerFiche(entite, { ...(options.cachees || {}), ...r.charge }) : await modifierFiche(entite, courante, r.charge);
          ctx.modifie(false);
          ctx.fermer(rep.fiche);
          const suite = SUCCES[entite][creation ? 0 : 1];
          const nbTaches = rep.effets?.taches || 0;
          const msg = nbTaches ? `${suite} ${nbTaches} tâche${nbTaches > 1 ? "s ont été ajoutées" : " a été ajoutée"} à votre liste.` : suite;
          const naviguerApres = options.naviguer ?? (creation && ENTITES_AVEC_PAGE.has(entite));
          if (naviguerApres) {
            toast(msg);
            naviguer(cheminFiche(entite, rep.fiche.id));
          } else if (creation && ENTITES_AVEC_PAGE.has(entite)) {
            toast(msg, { action: { libelle: "Ouvrir", onclick: () => naviguer(cheminFiche(entite, rep.fiche.id)) } });
          } else toast(msg);
          options.surEnregistre?.(rep.fiche, rep);
        } catch (e) {
          if (!(e instanceof ErreurApi)) throw e;
          if (e.estConflit && e.actuelle) {
            courante = e.actuelle;
            form.definirExistant(e.actuelle);
            mettreAJourFiche(entite, e.actuelle);
            form.afficherErreurs({ _global: "Cette fiche a été modifiée ailleurs pendant votre saisie. Vos changements n’ont pas encore été enregistrés. Vérifiez-les, puis enregistrez de nouveau : seuls les champs que vous avez changés seront remplacés." });
          } else if (e.champs && Object.keys(e.champs).length) {
            form.afficherErreurs(e.champs);
          } else {
            form.afficherErreurs({ _global: e.message });
          }
        } finally {
          ctx.occupe(false);
        }
      }
      return cible;
    },
  });
}

/**
 * Ouvre la fenêtre de création. Retourne la promesse de la fenêtre (valeur : la fiche créée).
 *   options.cachees : valeurs envoyées avec la création sans figurer dans le formulaire (ex. { dossier_id } d'une facture)
 *   options.naviguer : ouvrir (true) ou non (false) la fiche créée ; par défaut, on l'ouvre quand elle a sa propre page
 *   options.surEnregistre(fiche, reponse) : appelé après l'enregistrement
 */
export function nouvelleFiche(entite, valeurs = {}, options = {}) {
  return ouvrir({ entite, valeurs, options }).promesse;
}

/** Ouvre la fenêtre de modification d'une fiche existante. */
export function modifierLaFiche(entite, fiche, options = {}) {
  const courante = typeof fiche === "string" ? ficheLocale(entite, fiche) : fiche;
  return ouvrir({ entite, fiche: courante, options }).promesse;
}

