// =============================================================================
// Affaires : le tableau des étapes (colonnes, glisser-déposer) ou la liste.
// Une affaire est une occasion de mandat : de la demande à la livraison, ou à la perte.
// =============================================================================
import { h } from "../noyau/dom.js";
import { icone } from "../noyau/icones.js";
import { etat, actives, nomFiche, nomUtilisateur, etapeDe, texteRecherche, fiche as ficheDe, maintenant } from "../noyau/etat.js";
import { lienFiche, naviguer } from "../noyau/routeur.js";
import { lirePref, ecrirePref } from "../noyau/prefs.js";
import { SERVICES } from "../commun/schema.js";
import { argentEntier, argent, normaliser, pluriel } from "../commun/format.js";
import { aujourdhui, differenceJours } from "../commun/dates.js";
import { btn, btnIcone, enTete, avatar, menuActions, etatVide } from "../ui/composants.js";
import { barreFiltres } from "../ui/filtres.js";
import { creerVueListe } from "./liste.js";
import { nouvelleFiche } from "./formulaires.js";
import { deplacerAffaire } from "./etapes.js";
import { pastilleEtape, libelleOption, noeudEcheance, dateSansAnneeCourante, tonEcheance } from "./aides.js";

export const depend = ["opportunites", "entreprises", "contacts", "equipe", "config"];

const CLE_VUE = "affaires.vue";
const CLE_REPLIEES = "affaires.colonnes-repliees";
const STAGNATION_JOURS = 14; // une affaire ouverte qui n'a pas bougé depuis ce nombre de jours est signalée

// ----- Choix de la présentation ---------------------------------------------------------------------------------------------------
function vueChoisie(ctx) {
  const url = ctx.requete.get("vue");
  if (url === "liste" || url === "colonnes") return url;
  const pref = lirePref(CLE_VUE, null);
  if (pref === "liste" || pref === "colonnes") return pref;
  return matchMedia("(max-width: 44rem)").matches ? "liste" : "colonnes";
}

function commutateurVue(actuelle) {
  const bouton = (id, libelle, ic) =>
    h(
      "button.commutateur__bouton",
      { type: "button", "aria-pressed": String(actuelle === id), onclick: () => {
        if (id === actuelle) return;
        ecrirePref(CLE_VUE, id);
        naviguer(`/affaires?vue=${id}`);
      } },
      icone(ic, "ic--p"),
      h("span", libelle)
    );
  return h("div.commutateur", { role: "group", "aria-label": "Présentation des affaires" }, bouton("colonnes", "Colonnes", "affaires"), bouton("liste", "Liste", "liste"));
}

// ----- Chiffres ----------------------------------------------------------------------------------------------------------------------------------
const probabiliteDe = (o) => {
  if (o.probabilite !== undefined && o.probabilite !== null) return +o.probabilite;
  return +(etapeDe(o.etape)?.probabilite ?? 0);
};

function phraseSynthese() {
  const ouvertes = actives("opportunites").filter((o) => etapeDe(o.etape)?.type === "ouverte");
  if (!ouvertes.length) return "Aucune affaire ouverte pour l’instant.";
  const valeur = ouvertes.reduce((n, o) => n + (+o.valeur || 0), 0);
  const pondere = ouvertes.reduce((n, o) => n + ((+o.valeur || 0) * probabiliteDe(o)) / 100, 0);
  return `${pluriel(ouvertes.length, "affaire ouverte", "affaires ouvertes")} : ${argentEntier(valeur)} d’honoraires en vue, dont ${argentEntier(pondere)} pondérés selon la probabilité de chaque étape.`;
}

const clientDe = (o) => nomFiche("entreprises", o.entreprise_id) || (o.contact_id ? nomFiche("contacts", o.contact_id) : "");
const joursALEtape = (o) => (o.etape_depuis ? Math.max(0, differenceJours(o.etape_depuis, aujourdhui(maintenant()))) : null);

// ----- Le tableau --------------------------------------------------------------------------------------------------------------------------------
function etapesReplieesParDefaut(etapes) {
  const premiereGagnee = etapes.findIndex((e) => e.type === "gagnee");
  return new Set(etapes.filter((e, i) => e.type === "perdue" || (e.type === "gagnee" && i !== premiereGagnee)).map((e) => e.id));
}
function lireReplies(etapes) {
  const brut = lirePref(CLE_REPLIEES, null);
  return Array.isArray(brut) ? new Set(brut) : etapesReplieesParDefaut(etapes);
}

const ordreOuvertes = (a, b) =>
  (a.date_fermeture_prevue || "9999-12-31").localeCompare(b.date_fermeture_prevue || "9999-12-31") || (+b.valeur || 0) - (+a.valeur || 0) || String(a.titre).localeCompare(String(b.titre), "fr");
const ordreFermees = (a, b) => String(b.fermee_le || b.maj || "").localeCompare(String(a.fermee_le || a.maj || ""));

async function vuePlateau(ctx) {
  const memo = ctx.memoire;
  const st = memo.get("plateau") || { q: "", responsable: "", service: "" };
  memo.set("plateau", st);
  const peutEcrire = etat.droits.ecrire;
  let replies = lireReplies(etat.config.etapes);
  let glisse = null; // identifiant de l'affaire en cours de glissement
  let rendreApres = false;

  const plateau = h("div.plateau", { role: "group", "aria-label": "Affaires par étape" });
  const sous = h("span", phraseSynthese());

  const equipe = () => etat.equipe.map((u) => ({ id: u.id, libelle: u.nom }));
  const filtres = [];
  if (etat.equipe.length > 1) filtres.push({ id: "responsable", libelle: "Responsable", tout: "Tous responsables", options: equipe, valeur: st.responsable, surChangement: (v) => { st.responsable = v; dessiner(); } });
  filtres.push({ id: "service", libelle: "Service", tout: "Tous les services", options: () => SERVICES, valeur: st.service, surChangement: (v) => { st.service = v; dessiner(); } });
  const barre = barreFiltres({
    placeholder: "Rechercher une affaire, un client…", q: st.q, aria: "Rechercher parmi les affaires",
    surRecherche: (q) => { st.q = q; dessiner(); },
    surReinitialiser: () => { st.q = ""; st.responsable = ""; st.service = ""; dessiner(); },
    filtres,
  });

  const filtrees = () => {
    const jetons = normaliser(st.q).split(/\s+/).filter(Boolean);
    return actives("opportunites").filter((o) => {
      if (jetons.length) {
        const t = `${texteRecherche("opportunites", o)} ${normaliser(nomFiche("contacts", o.contact_id))}`;
        if (!jetons.every((x) => t.includes(x))) return false;
      }
      return (!st.responsable || o.responsable_id === st.responsable) && (!st.service || o.service === st.service);
    });
  };

  // ----- Carte ---------------------------------------------------------------------------------------------------------------------------------
  function carte(o, etapes) {
    const etape = etapeDe(o.etape);
    const ouverte = etape?.type === "ouverte";
    const client = nomFiche("entreprises", o.entreprise_id);
    const contact = nomFiche("contacts", o.contact_id);
    const ligneClient = [client, contact].filter(Boolean);
    const depuis = joursALEtape(o);
    const tonDate = ouverte && o.date_fermeture_prevue ? tonEcheance(o.date_fermeture_prevue) : "neutre";

    const menu = menuActions({
      aria: `Actions pour l’affaire ${o.titre}`, classeBouton: "btn-icone", contenu: icone("options"), fixe: true,
      elements: [
        { libelle: "Ouvrir la fiche", icone: "voir", onclick: () => naviguer(`/affaires/${encodeURIComponent(o.id)}`) },
        ...(peutEcrire ? ["separateur", ...etapes.filter((e) => e.id !== o.etape).map((e) => ({ libelle: `Déplacer vers « ${e.nom} »`, icone: "droite", onclick: () => deplacerAffaire(o.id, e.id) }))] : []),
      ],
    });

    const li = h(
      "li.carte",
      { dataset: { id: o.id }, draggable: peutEcrire ? "true" : null },
      h(
        "div.carte__tete",
        h("a.carte__titre", { href: lienFiche("opportunites", o.id), draggable: "false", "data-focus-id": `carte-${o.id}` }, o.titre),
        menu
      ),
      ligneClient.length ? h("p.carte__client", ligneClient.join(" — ")) : null,
      h(
        "div.carte__pied",
        h(
          "span.carte__meta",
          etat.equipe.length > 1 && o.responsable_id ? h("span.carte__resp", { title: `Responsable : ${nomUtilisateur(o.responsable_id)}` }, avatar(nomUtilisateur(o.responsable_id), { taille: "s" })) : null,
          o.date_fermeture_prevue && ouverte
            ? h("span.carte__date", { class: tonDate !== "neutre" ? `echeance--${tonDate}` : "" }, `Fermeture ${dateSansAnneeCourante(o.date_fermeture_prevue)}`)
            : o.fermee_le && !ouverte
              ? h("span.carte__date", `Fermée le ${dateSansAnneeCourante(o.fermee_le)}`)
              : null
        ),
        o.valeur ? h("span.carte__valeur", argentEntier(o.valeur)) : h("span.carte__valeur.muet", "—")
      ),
      ouverte && depuis !== null && depuis >= STAGNATION_JOURS
        ? h("p.carte__stagne", icone("sablier", "ic--p"), `À cette étape depuis ${depuis} jours`)
        : null
    );
    if (peutEcrire) {
      li.addEventListener("dragstart", (e) => {
        glisse = o.id;
        e.dataTransfer.effectAllowed = "move";
        e.dataTransfer.setData("text/plain", o.id);
        setTimeout(() => li.classList.add("carte--glissee"), 0);
        plateau.classList.add("plateau--glisse");
      });
      li.addEventListener("dragend", () => {
        glisse = null;
        li.classList.remove("carte--glissee");
        plateau.classList.remove("plateau--glisse");
        for (const c of plateau.querySelectorAll(".colonne--cible")) c.classList.remove("colonne--cible");
        if (rendreApres) dessiner();
      });
    }
    return li;
  }

  // ----- Colonne ------------------------------------------------------------------------------------------------------------------------------
  function basculer(id) {
    if (replies.has(id)) replies.delete(id);
    else replies.add(id);
    ecrirePref(CLE_REPLIEES, [...replies]);
    dessiner();
    plateau.querySelector(`[data-etape="${CSS.escape(id)}"] .colonne__bascule`)?.focus({ preventScroll: true });
  }

  function brancherDepot(section, etapeId) {
    const accepte = () => !!glisse && ficheDe("opportunites", glisse)?.etape !== etapeId;
    section.addEventListener("dragenter", (e) => glisse && e.preventDefault());
    section.addEventListener("dragover", (e) => {
      if (!glisse) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = accepte() ? "move" : "none";
      section.classList.toggle("colonne--cible", accepte());
    });
    section.addEventListener("dragleave", (e) => {
      if (!section.contains(e.relatedTarget)) section.classList.remove("colonne--cible");
    });
    section.addEventListener("drop", (e) => {
      e.preventDefault();
      section.classList.remove("colonne--cible");
      const id = glisse || e.dataTransfer.getData("text/plain");
      glisse = null;
      plateau.classList.remove("plateau--glisse");
      if (id) deplacerAffaire(id, etapeId);
    });
  }

  function colonne(e, cartes, etapes) {
    const n = cartes.length;
    const total = cartes.reduce((s, o) => s + (+o.valeur || 0), 0);
    const replie = replies.has(e.id);
    const idTitre = `col-${e.id}`;
    const section = h("section.colonne", { class: [`colonne--${e.type}`, replie ? "colonne--repliee" : ""], dataset: { etape: e.id }, "aria-labelledby": idTitre });
    if (replie) {
      section.append(
        h(
          "button.colonne__bascule.colonne__bascule--ouvrir",
          { type: "button", "aria-expanded": "false", onclick: () => basculer(e.id), title: "Déplier cette étape" },
          h("span.colonne__compteur", String(n)),
          h("span.colonne__nom-vertical", { id: idTitre }, e.nom),
          icone("droite", "ic--p")
        )
      );
    } else {
      cartes.sort(e.type === "ouverte" ? ordreOuvertes : ordreFermees);
      section.append(
        h(
          "header.colonne__tete",
          h(
            "div.colonne__titres",
            h("h2.colonne__nom", { id: idTitre }, e.nom),
            h("p.colonne__chiffres", pluriel(n, "affaire"), total ? ` — ${argentEntier(total)}` : "")
          ),
          h(
            "div.colonne__actions",
            peutEcrire && e.type !== "perdue" ? btnIcone("plus", `Ajouter une affaire à l’étape « ${e.nom} »`, () => nouvelleFiche("opportunites", { etape: e.id })) : null,
            h("button.btn-icone.colonne__bascule", { type: "button", "aria-expanded": "true", "aria-label": `Replier l’étape « ${e.nom} »`, title: "Replier cette étape", onclick: () => basculer(e.id) }, icone("gauche", "ic--p"))
          )
        ),
        n
          ? h("ul.colonne__cartes", cartes.map((o) => carte(o, etapes)))
          : h("div.colonne__vide", peutEcrire ? "Aucune affaire. Glissez-en une ici." : "Aucune affaire.")
      );
    }
    brancherDepot(section, e.id);
    return section;
  }

  // ----- Rendu ------------------------------------------------------------------------------------------------------------------------------------
  function dessiner() {
    if (glisse) {
      rendreApres = true; // on ne remplace pas le tableau pendant qu'une carte est tenue
      return;
    }
    rendreApres = false;
    const etapes = etat.config.etapes;
    const lignes = filtrees();
    const parEtape = new Map(etapes.map((e) => [e.id, []]));
    const orphelines = [];
    for (const o of lignes) (parEtape.get(o.etape) || orphelines).push(o);

    const defilementX = plateau.scrollLeft;
    const focus = document.activeElement?.dataset?.focusId && plateau.contains(document.activeElement) ? document.activeElement.dataset.focusId : null;
    const colonnes = etapes.map((e) => colonne(e, parEtape.get(e.id), etapes));
    if (orphelines.length) colonnes.push(colonne({ id: "_autres", nom: "Étape inconnue", type: "ouverte" }, orphelines, etapes));
    plateau.replaceChildren(...colonnes);
    plateau.scrollLeft = defilementX;
    if (focus) plateau.querySelector(`[data-focus-id="${CSS.escape(focus)}"]`)?.focus({ preventScroll: true });

    const n = lignes.length;
    const total = actives("opportunites").length;
    barre.definirCompte(n === total ? pluriel(n, "affaire") : `${n} sur ${pluriel(total, "affaire")}`);
    sous.textContent = phraseSynthese();
  }

  const actions = [commutateurVue("colonnes")];
  if (peutEcrire) actions.push(btn("Nouvelle affaire", { ton: "primaire", icone: "plus", onclick: () => nouvelleFiche("opportunites") }));

  const vide = actives("opportunites").length
    ? null
    : etatVide({
        icone: "affaires", titre: "Aucune affaire pour l’instant",
        texte: "Une affaire suit une occasion de mandat, de la première demande jusqu’à la livraison. Elles se créent aussi toutes seules quand vous convertissez une demande du site.",
        action: peutEcrire ? btn("Nouvelle affaire", { ton: "primaire", icone: "plus", onclick: () => nouvelleFiche("opportunites") }) : null,
      });

  const noeud = h(
    "div.affaires-page",
    enTete({ titre: "Affaires", sous, actions }),
    vide ? vide : h("div.pile.pile--s", barre.noeud, plateau)
  );
  if (!vide) dessiner();

  return {
    titre: "Affaires",
    noeud,
    miseAJour() {
      if (vide) return false; // la première affaire change l'écran : on redessine tout
      dessiner();
      return true;
    },
  };
}

// ----- La liste -----------------------------------------------------------------------------------------------------------------------------------------
const PHASES = [
  { id: "ouverte", libelle: "Ouvertes" },
  { id: "gagnee", libelle: "Gagnées (mandat en cours ou livré)" },
  { id: "perdue", libelle: "Perdues" },
];
const indexEtape = (o) => etat.config.etapes.findIndex((e) => e.id === o.etape);

const vueListe = creerVueListe({
  entite: "opportunites",
  titre: "Affaires",
  sous: phraseSynthese,
  nouveau: { libelle: "Nouvelle affaire" },
  actionsAvant: () => [commutateurVue("liste")],
  placeholder: "Rechercher une affaire, un client…",
  triDefaut: { col: "etape", dir: "asc" },
  href: (o) => lienFiche("opportunites", o.id),
  vide: { icone: "affaires", titre: "Aucune affaire pour l’instant", texte: "Une affaire suit une occasion de mandat, de la première demande jusqu’à la livraison." },
  filtres: [
    { id: "phase", libelle: "Situation", tout: "Toutes les situations", options: () => PHASES, test: (o, v) => etapeDe(o.etape)?.type === v },
    { id: "etape", libelle: "Étape", tout: "Toutes les étapes", options: () => etat.config.etapes.map((e) => ({ id: e.id, libelle: e.nom })), test: (o, v) => o.etape === v },
    { id: "service", libelle: "Service", tout: "Tous les services", options: () => SERVICES, test: (o, v) => o.service === v },
    { id: "responsable", libelle: "Responsable", tout: "Tous responsables", options: () => etat.equipe.map((u) => ({ id: u.id, libelle: u.nom })), test: (o, v) => o.responsable_id === v },
  ],
  // Une fonction plutôt qu'une liste : la colonne « Responsable » n'apparaît que si l'équipe compte plus d'une personne.
  get colonnes() {
    const cols = [
      {
        id: "titre", titre: "Affaire", classe: "cellule-titre", valeur: (o) => o.titre,
        rendu: (o) => h("div.identite__texte", h("a", { href: lienFiche("opportunites", o.id) }, o.titre), h("small.muet", [clientDe(o), libelleOption(SERVICES, o.service)].filter(Boolean).join(" — ") || "—")),
      },
      { id: "etape", titre: "Étape", valeur: indexEtape, rendu: (o) => pastilleEtape(o.etape) },
      { id: "valeur", titre: "Honoraires", classe: "num", valeur: (o) => +o.valeur || 0, rendu: (o) => (o.valeur ? argent(o.valeur) : h("span.muet", "—")) },
      {
        id: "fermeture", titre: "Fermeture prévue", valeur: (o) => o.date_fermeture_prevue || "",
        rendu: (o) => (etapeDe(o.etape)?.type === "ouverte" ? noeudEcheance(o.date_fermeture_prevue) : o.fermee_le ? h("span.muet", `Fermée le ${dateSansAnneeCourante(o.fermee_le)}`) : h("span.muet", "—")),
      },
      {
        id: "depuis", titre: "À cette étape", classe: "num", valeur: (o) => joursALEtape(o) ?? -1,
        rendu: (o) => (joursALEtape(o) === null ? h("span.muet", "—") : `${joursALEtape(o)} j`), mobile: "cache",
      },
    ];
    if (etat.equipe.length > 1) cols.push({ id: "resp", titre: "Responsable", valeur: (o) => nomUtilisateur(o.responsable_id), rendu: (o) => nomUtilisateur(o.responsable_id) || h("span.muet", "—"), mobile: "cache" });
    return cols;
  },
  exporter: {
    nom: "affaires-innovaffaires",
    colonnes: [
      { titre: "Affaire", valeur: (o) => o.titre }, { titre: "Client", valeur: clientDe }, { titre: "Contact", valeur: (o) => nomFiche("contacts", o.contact_id) },
      { titre: "Étape", valeur: (o) => etapeDe(o.etape)?.nom || o.etape }, { titre: "Service", valeur: (o) => libelleOption(SERVICES, o.service) },
      { titre: "Honoraires estimés", valeur: (o) => o.valeur }, { titre: "Probabilité (%)", valeur: probabiliteDe }, { titre: "Fermeture prévue", valeur: (o) => o.date_fermeture_prevue },
      { titre: "Fermée le", valeur: (o) => o.fermee_le }, { titre: "Raison de la perte", valeur: (o) => o.raison_perte }, { titre: "Responsable", valeur: (o) => nomUtilisateur(o.responsable_id) },
    ],
  },
});

export default async function vueAffaires(ctx) {
  return vueChoisie(ctx) === "liste" ? vueListe(ctx) : vuePlateau(ctx);
}
