// =============================================================================
// Corbeille : une fiche supprimée y reste 30 jours, puis elle est effacée pour
// de bon. D'ici là, on peut la rétablir ; un administrateur peut aussi l'effacer
// tout de suite.
// =============================================================================
import { h } from "../noyau/dom.js";
import { etat, supprimees, libelleFiche, nomUtilisateur, maintenant } from "../noyau/etat.js";
import { ENTITES } from "../commun/schema.js";
import { dateCourte, normaliser, pluriel } from "../commun/format.js";
import { partiesLocales } from "../commun/dates.js";
import { enTete, btn, etatVide, pastille } from "../ui/composants.js";
import { tableau } from "../ui/tableau.js";
import { barreFiltres } from "../ui/filtres.js";
import { ouvrirDialogue, confirmer } from "../ui/dialogue.js";
import { toast } from "../ui/toast.js";
import { tenter, restaurerFiche, supprimerDefinitivement } from "../noyau/ecriture.js";
import { cheminFiche, naviguer } from "../noyau/routeur.js";
import { ErreurApi } from "../noyau/api.js";

export const depend = ["contacts", "entreprises", "opportunites", "dossiers", "taches", "evenements", "factures", "demandes", "equipe"];

const JOURS_CONSERVATION = 30;
const JOUR_MS = 86_400_000;
const ORDRE = ["contacts", "entreprises", "opportunites", "dossiers", "taches", "evenements", "factures", "demandes"];
/** Entités qui ont une page de détail où ouvrir la fiche rétablie. */
const AVEC_PAGE = new Set(["contacts", "entreprises", "opportunites", "dossiers", "factures", "demandes"]);

const majuscule = (s) => s.charAt(0).toUpperCase() + s.slice(1);
/** Nom et genre de la fiche : un devis n'est pas une « facture ». */
const typeDe = (l) => (l.entite === "factures" && l.f.type === "devis" ? { libelle: "Devis", genre: "m" } : { libelle: ENTITES[l.entite].libelle, genre: ENTITES[l.entite].genre });
const accord = (l, base) => `${base}${typeDe(l).genre === "f" ? "e" : ""}`;

function lignesCorbeille() {
  const out = [];
  for (const entite of ORDRE) {
    for (const f of supprimees(entite)) out.push({ entite, f, ms: Date.parse(f.supprime) || 0, nom: libelleFiche(entite, f) });
  }
  return out;
}

const joursRestants = (l) => Math.ceil((l.ms + JOURS_CONSERVATION * JOUR_MS - maintenant()) / JOUR_MS);

function noeudReste(l) {
  const n = joursRestants(l);
  if (n <= 0) return pastille("Effacement imminent", "attention");
  if (n <= 3) return pastille(`${n} jour${n > 1 ? "s" : ""}`, "attention");
  return h("span", `${n} jours`);
}

async function retablir(l) {
  const r = await tenter(() => restaurerFiche(l.entite, l.f.id), { entite: l.entite });
  if (!r) return;
  toast(`${typeDe(l).libelle} « ${l.nom} » ${accord(l, "rétabli")}.`, {
    action: AVEC_PAGE.has(l.entite) ? { libelle: "Ouvrir", onclick: () => naviguer(cheminFiche(l.entite, l.f.id)) } : null,
  });
}

async function effacer(l) {
  const ok = await confirmer({
    titre: "Effacer définitivement ?",
    message: `« ${l.nom} » sera ${accord(l, "effacé")} pour toujours. Cette action ne peut pas être annulée.`,
    libelleConfirmer: "Effacer définitivement", danger: true,
  });
  if (!ok) return;
  const fait = await tenter(async () => (await supprimerDefinitivement(l.entite, l.f.id), true), { entite: l.entite });
  if (fait) toast(`${typeDe(l).libelle} ${accord(l, "effacé")} définitivement.`, { ton: "info" });
}

/** Efface toute la corbeille, une fiche à la fois, avec un compteur d'avancement. */
async function viderCorbeille(lignes) {
  const ok = await confirmer({
    titre: "Vider la corbeille ?",
    message: `${pluriel(lignes.length, "fiche sera effacée", "fiches seront effacées")} définitivement. Cette action ne peut pas être annulée.`,
    libelleConfirmer: "Tout effacer", danger: true,
  });
  if (!ok) return;
  const progres = h("p", { role: "status", "aria-live": "polite" }, `0 sur ${lignes.length}…`);
  const d = ouvrirDialogue({ titre: "Effacement en cours", taille: "petit", fermable: false, contenu: () => h("div", progres) });
  let faits = 0;
  let echecs = 0;
  let message = "";
  for (const l of lignes) {
    try {
      await supprimerDefinitivement(l.entite, l.f.id);
      faits++;
    } catch (e) {
      if (!(e instanceof ErreurApi)) throw e;
      echecs++;
      message = e.message;
      if (e.estReseau) break;
    }
    progres.textContent = `${faits + echecs} sur ${lignes.length}…`;
  }
  d.fermer();
  if (echecs) toast(`${pluriel(faits, "fiche effacée", "fiches effacées")}. ${pluriel(echecs, "n’a pas pu être effacée", "n’ont pas pu être effacées")} : ${message}`, { ton: "erreur", duree: 12000 });
  else toast(`Corbeille vidée : ${pluriel(faits, "fiche effacée", "fiches effacées")}.`, { ton: "info" });
}

export default async function vueCorbeille(ctx) {
  const st = ctx.memoire.get("etat") || { q: "", type: "" };
  ctx.memoire.set("etat", st);

  const toutes = lignesCorbeille();
  const admin = etat.droits.administrer;
  const peutEcrire = etat.droits.ecrire;

  function filtrees() {
    const jetons = normaliser(st.q).split(/\s+/).filter(Boolean);
    return toutes.filter((l) => {
      if (st.type && l.entite !== st.type) return false;
      if (!jetons.length) return true;
      const texte = normaliser(`${l.nom} ${typeDe(l).libelle}`);
      return jetons.every((j) => texte.includes(j));
    });
  }

  const colonnes = [
    {
      id: "fiche", titre: "Fiche", classe: "cellule-titre", valeur: (l) => l.nom,
      rendu: (l) => h("div.identite__texte", h("strong", l.nom), h("small.muet", typeDe(l).libelle, l.f.anonymise ? " · anonymisé" : "")),
    },
    {
      id: "supprimee", titre: "Supprimée", valeur: (l) => l.ms,
      rendu: (l) => {
        const par = nomUtilisateur(l.f.maj_par);
        return h("div.identite__texte", l.ms ? dateCourte(partiesLocales(l.ms).date) : "—", par ? h("small.muet", `par ${par}`) : null);
      },
    },
    { id: "reste", titre: "Effacement dans", valeur: (l) => joursRestants(l), rendu: (l) => noeudReste(l) },
  ];
  if (peutEcrire) {
    colonnes.push({
      id: "actions", titre: "Actions", classe: "actions", triable: false,
      rendu: (l) =>
        h(
          "div.rangee.rangee--fin",
          btn("Rétablir", {
            petit: true, icone: "annuler", desactive: !!l.f.anonymise, onclick: () => retablir(l),
            titre: l.f.anonymise ? "Un contact anonymisé ne peut pas être rétabli." : null, aria: `Rétablir ${l.nom}`,
          }),
          admin ? btn("Effacer", { petit: true, ton: "danger", icone: "corbeille", onclick: () => effacer(l), aria: `Effacer définitivement ${l.nom}` }) : null
        ),
    });
  }

  const typesPresents = ORDRE.filter((e) => toutes.some((l) => l.entite === e));
  if (st.type && !typesPresents.includes(st.type)) st.type = "";

  const tableauUi = tableau({
    colonnes, lignes: [], tri: { col: "supprimee", dir: "desc" }, libelle: "Fiches dans la corbeille",
    vide: () =>
      toutes.length
        ? etatVide({ icone: "recherche", titre: "Aucun résultat", texte: "Aucune fiche de la corbeille ne correspond à cette recherche." })
        : etatVide({ icone: "corbeille", titre: "La corbeille est vide", texte: "Les fiches que vous supprimez arrivent ici et y restent 30 jours : vous pouvez les rétablir d’ici là." }),
  });

  const barre = barreFiltres({
    placeholder: "Rechercher dans la corbeille…", q: st.q, aria: "Rechercher dans la corbeille",
    surRecherche: (q) => {
      st.q = q;
      maj();
    },
    surReinitialiser: () => {
      st.q = "";
      st.type = "";
      maj();
    },
    filtres: [
      {
        id: "type", libelle: "Type de fiche", tout: "Tous les types", valeur: st.type,
        options: () => typesPresents.map((e) => ({ id: e, libelle: majuscule(ENTITES[e].pluriel) })),
        surChangement: (v) => {
          st.type = v;
          maj();
        },
      },
    ],
  });

  function maj() {
    const lignes = filtrees();
    tableauUi.majLignes(lignes);
    barre.definirCompte(lignes.length === toutes.length ? pluriel(lignes.length, "fiche", "fiches") : `${lignes.length} sur ${pluriel(toutes.length, "fiche", "fiches")}`);
  }
  maj();

  const actions = admin && toutes.length ? [btn("Vider la corbeille", { ton: "danger", icone: "corbeille", onclick: () => viderCorbeille(toutes) })] : [];
  const sous = `Une fiche supprimée reste ici ${JOURS_CONSERVATION} jours, puis elle est effacée définitivement.`;
  return {
    titre: "Corbeille",
    noeud: h("div", enTete({ titre: "Corbeille", sous, actions }), toutes.length ? h("div.pile.pile--s", barre.noeud, tableauUi.noeud) : tableauUi.noeud),
  };
}
