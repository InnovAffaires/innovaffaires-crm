// =============================================================================
// Rapports : ce que la pratique a produit sur une période (demandes, affaires
// gagnées, financement obtenu, facturation), puis la situation du moment
// (affaires ouvertes, dossiers en cours, factures à recevoir).
// Les calculs sont dans commun/rapports.js ; ici on choisit la période et on
// dessine. Rien n'est saisi dans cet écran : tout vient des fiches.
// =============================================================================
import { h, remplir, idUnique } from "../noyau/dom.js";
import { icone } from "../noyau/icones.js";
import { etat, actives, maintenant } from "../noyau/etat.js";
import { majRequete } from "../noyau/routeur.js";
import { aujourdhui } from "../commun/dates.js";
import { argent, argentCompact, argentEntier, dateComplete, moisAnnee, moisCourt, nombre, pluriel, pourcent } from "../commun/format.js";
import { PERIODES, PERIODE_DEFAUT, calculerRapports } from "../commun/rapports.js";
import { avis, btn, enTete, etatVide, listeDef } from "../ui/composants.js";
import { barresH, cadre, colonnes, legende, tableauDonnees, tuile } from "../ui/graphiques.js";

export const depend = ["demandes", "opportunites", "dossiers", "factures", "config"];

const ENTITES_RAPPORTS = ["demandes", "opportunites", "dossiers", "factures"];
const NBSP = " ";
const MOINS = "−";
const COURT = { "6m": "6 mois", "12m": "12 mois", annee: "Depuis janvier", derniere: "Année dernière" };

// ----- Mise en forme ---------------------------------------------------------------------------------------------------------------------
const majuscule = (s) => s.charAt(0).toUpperCase() + s.slice(1);
const date = (iso) => dateComplete(iso).replaceAll(" ", NBSP);
const pct = (part) => pourcent(part * 100).replace(" ", NBSP);
const decimal = new Intl.NumberFormat("fr-CA", { maximumFractionDigits: 1 });

/** Étiquette d'axe pour des dollars : « 800 $ », « 2,5 k$ », « 1,2 M$ ». */
function axeArgent(v) {
  if (v >= 1e6) return `${decimal.format(v / 1e6)}${NBSP}M$`;
  if (v >= 1e3) return `${decimal.format(v / 1e3)}${NBSP}k$`;
  return `${nombre(v)}${NBSP}$`;
}

/** Comment nommer la période de comparaison, selon la période choisie. */
function comparaison(periode) {
  const an = +periode.fin.slice(0, 4) - 1;
  switch (periode.id) {
    case "6m":
      return { avec: "aux 6 mois précédents", sur: "sur les 6 mois précédents" };
    case "12m":
      return { avec: "aux 12 mois précédents", sur: "sur les 12 mois précédents" };
    case "annee":
      return { avec: `à la même période en ${an}`, sur: `à la même date en ${an}` };
    default:
      return { avec: `à ${an}`, sur: `en ${an}` };
  }
}

/** Écart avec la période de comparaison : le signe, la valeur d'avant et la période nommée. */
function variation(actuel, avant, format, cmp) {
  if (!actuel && !avant) return null;
  const ecart = Math.round(actuel) - Math.round(avant);
  const reference = `(${format(avant)} ${cmp.sur})`;
  if (ecart === 0) return { sens: "stable", signe: "Inchangé", texte: reference };
  return { sens: ecart > 0 ? "hausse" : "baisse", signe: `${ecart > 0 ? "+" : MOINS}${format(Math.abs(ecart))}`, texte: reference };
}

const categoriesMois = (cles) =>
  cles.map((cle, i) => ({ court: moisCourt(cle), long: majuscule(moisAnnee(cle)), annee: i === 0 || cle.endsWith("-01") ? cle.slice(0, 4) : null }));

/** Étape n sur N → l'un des cinq crans du dégradé (du plus pâle au plus foncé). */
const classeOrdinale = (i, n) => `g-o${n <= 1 ? 3 : Math.round((i * 4) / (n - 1)) + 1}`;

// ----- Tuiles -----------------------------------------------------------------------------------------------------------------------------------
function tuiles(r) {
  const { demandes, affaires, financement, facturation } = r.tuiles;
  const cmp = comparaison(r.periode);
  return h("div.tuiles", [
    tuile({
      libelle: "Demandes reçues",
      valeur: nombre(demandes.valeur),
      delta: variation(demandes.valeur, demandes.precedente, nombre, cmp),
      sous: demandes.valeur ? `Dont ${pluriel(demandes.converties, "convertie", "converties")} en contact` : "Aucune demande du site sur la période.",
    }),
    tuile({
      libelle: "Affaires gagnées",
      valeur: nombre(affaires.gagnees),
      delta: variation(affaires.gagnees, affaires.precedente.gagnees, nombre, cmp),
      sous: [
        affaires.gagnees ? `${argentEntier(affaires.valeur)} d’honoraires` : null,
        affaires.tauxReussite === null ? "Aucune affaire fermée sur la période." : `Taux de réussite : ${pct(affaires.tauxReussite)}`,
      ].filter(Boolean),
    }),
    tuile({
      libelle: "Financement obtenu",
      valeur: argentEntier(financement.obtenu),
      titre: argent(financement.obtenu),
      delta: variation(financement.obtenu, financement.precedent.obtenu, argentEntier, cmp),
      sous: [
        financement.acceptes ? pluriel(financement.acceptes, "dossier accepté", "dossiers acceptés") : null,
        financement.tauxAcceptation === null ? "Aucune décision reçue sur la période." : `Taux d’acceptation : ${pct(financement.tauxAcceptation)}`,
      ].filter(Boolean),
    }),
    tuile({
      libelle: "Facturé",
      valeur: argentEntier(facturation.facture),
      titre: argent(facturation.facture),
      delta: variation(facturation.facture, facturation.precedente.facture, argentEntier, cmp),
      sous: [`Encaissé : ${argentEntier(facturation.encaisse)}`, "Taxes comprises"],
    }),
  ]);
}

// ----- Graphiques de la période ----------------------------------------------------------------------------------------------
function cadreDemandes(r, memo) {
  const mois = r.mois.demandes;
  const total = mois.reduce((n, m) => n + m.total, 0);
  const converties = mois.reduce((n, m) => n + m.converties, 0);
  const base = { titre: "Demandes reçues par mois", sous: "Demandes du site, pourriels exclus.", ...memo("demandes") };
  if (!total) {
    return cadre({ ...base, vide: etatVide({ icone: "demandes", titre: "Aucune demande sur cette période", texte: "Les messages envoyés par le formulaire de votre site apparaîtront ici, mois par mois." }) });
  }
  const categories = categoriesMois(mois.map((m) => m.cle));
  const nom = "Demandes reçues et converties, par mois";
  return cadre({
    ...base,
    legende: legende([{ classe: "g-s1", libelle: "Reçues" }, { classe: "g-s2", libelle: "Converties en contact" }]),
    graphique: colonnes({
      categories, entier: true, formatAxe: nombre, formatValeur: nombre, libelle: nom,
      series: [
        { id: "recues", libelle: "Reçues", classe: "g-s1", valeurs: mois.map((m) => m.total) },
        { id: "converties", libelle: "Converties", classe: "g-s2", valeurs: mois.map((m) => m.converties) },
      ],
    }),
    tableau: tableauDonnees({ libelle: nom, colonnes: ["Mois", "Reçues", "Converties"], lignes: mois.map((m, i) => [categories[i].long, nombre(m.total), nombre(m.converties)]), pied: ["Total", nombre(total), nombre(converties)] }),
  });
}

function cadreFacturation(r, memo) {
  const mois = r.mois.facturation;
  const facture = mois.reduce((n, m) => n + m.facture, 0);
  const encaisse = mois.reduce((n, m) => n + m.encaisse, 0);
  const base = { titre: "Facturé et encaissé par mois", sous: "Taxes comprises.", ...memo("facturation") };
  if (!facture && !encaisse) {
    return cadre({ ...base, vide: etatVide({ icone: "factures", titre: "Rien de facturé ni d’encaissé sur cette période", texte: "Les montants apparaissent dès qu’une facture est émise ou qu’un paiement est enregistré." }) });
  }
  const categories = categoriesMois(mois.map((m) => m.cle));
  const nom = "Montants facturés et encaissés, par mois";
  return cadre({
    ...base,
    legende: legende([{ classe: "g-s1", libelle: "Facturé" }, { classe: "g-s2", libelle: "Encaissé" }]),
    graphique: colonnes({
      categories, formatAxe: axeArgent, formatValeur: argentEntier, libelle: nom,
      series: [
        { id: "facture", libelle: "Facturé", classe: "g-s1", valeurs: mois.map((m) => m.facture) },
        { id: "encaisse", libelle: "Encaissé", classe: "g-s2", valeurs: mois.map((m) => m.encaisse) },
      ],
    }),
    tableau: tableauDonnees({ libelle: nom, colonnes: ["Mois", "Facturé", "Encaissé"], lignes: mois.map((m, i) => [categories[i].long, argent(m.facture), argent(m.encaisse)]), pied: ["Total", argent(facture), argent(encaisse)] }),
  });
}

function cadreProvenance(r, memo) {
  const lignes = r.provenance;
  const base = { titre: "D’où viennent vos affaires", sous: "Affaires créées pendant la période.", ...memo("provenance") };
  if (!lignes.length) {
    return cadre({ ...base, vide: etatVide({ icone: "affaires", titre: "Aucune affaire créée sur cette période", texte: "Indiquez la provenance du client sur la fiche d’une affaire pour voir ici ce qui vous apporte des mandats." }) });
  }
  const nom = "Affaires créées pendant la période, par provenance";
  return cadre({
    ...base,
    legende: legende([{ classe: "g-s1", libelle: "Gagnées" }, { classe: "g-autre", libelle: "Autres (ouvertes ou perdues)" }]),
    graphique: {
      noeud: barresH({
        libelle: nom, formatValeur: nombre,
        lignes: lignes.map((p) => ({
          libelle: p.libelle,
          detail: [p.gagnees ? pluriel(p.gagnees, "gagnée", "gagnées") : null, p.regroupe ? `${p.regroupe} provenances regroupées` : null].filter(Boolean).join(" — ") || null,
          valeur: p.total,
          segments: [{ valeur: p.gagnees, classe: "g-s1" }, { valeur: p.total - p.gagnees, classe: "g-autre" }],
        })),
      }),
    },
    tableau: tableauDonnees({
      libelle: nom, colonnes: ["Provenance", "Affaires", "Gagnées"],
      lignes: lignes.map((p) => [p.libelle, nombre(p.total), nombre(p.gagnees)]),
      pied: ["Total", nombre(lignes.reduce((n, p) => n + p.total, 0)), nombre(lignes.reduce((n, p) => n + p.gagnees, 0))],
    }),
  });
}

function cadreRaisons(r, memo) {
  const lignes = r.raisonsPerte;
  const base = { titre: "Pourquoi des affaires sont perdues", sous: "Affaires perdues pendant la période.", ...memo("raisons") };
  if (!lignes.length) {
    return cadre({ ...base, vide: etatVide({ icone: "ok", titre: "Aucune affaire perdue sur cette période", texte: "Quand vous classez une affaire comme perdue, la raison choisie s’affiche ici." }) });
  }
  const nom = "Affaires perdues pendant la période, par raison";
  return cadre({
    ...base,
    graphique: { noeud: barresH({ libelle: nom, formatValeur: nombre, lignes: lignes.map((x) => ({ libelle: x.libelle, valeur: x.total, classe: "g-s1" })) }) },
    tableau: tableauDonnees({ libelle: nom, colonnes: ["Raison", "Affaires perdues"], lignes: lignes.map((x) => [x.libelle, nombre(x.total)]), pied: ["Total", nombre(lignes.reduce((n, x) => n + x.total, 0))] }),
  });
}

// ----- La situation du moment ---------------------------------------------------------------------------------------------------
const totaux = (paires) => h("dl.pipeline__totaux", paires.map(([k, v]) => h("div", h("dt", k), h("dd", v))));

function cadrePipeline(r, memo) {
  const p = r.actuel.pipeline;
  const base = { titre: "Affaires ouvertes", sous: "Honoraires estimés, par étape.", ...memo("pipeline") };
  if (!p.nombre) {
    return cadre({ ...base, vide: etatVide({ icone: "affaires", titre: "Aucune affaire ouverte", texte: "Une affaire suit un mandat potentiel, de la première demande jusqu’à la signature." }) });
  }
  const nom = "Honoraires estimés des affaires ouvertes, par étape";
  const n = p.etapes.length;
  return cadre({
    ...base,
    graphique: {
      noeud: h(
        "div",
        barresH({
          libelle: nom, formatValeur: argentCompact,
          lignes: p.etapes.map((e, i) => ({ libelle: e.nom, detail: pluriel(e.nombre, "affaire", "affaires"), valeur: e.valeur, classe: classeOrdinale(i, n), texteValeur: e.nombre ? argentCompact(e.valeur) : "—" })),
        }),
        totaux([["Honoraires estimés", argentEntier(p.valeur)], ["Pondérés par la probabilité", argentEntier(p.ponderee)]])
      ),
    },
    tableau: tableauDonnees({
      libelle: nom, colonnes: ["Étape", "Affaires", "Honoraires estimés", "Pondérés"],
      lignes: p.etapes.map((e) => [e.nom, nombre(e.nombre), argent(e.valeur), argent(e.ponderee)]),
      pied: ["Total", nombre(p.nombre), argent(p.valeur), argent(p.ponderee)],
    }),
  });
}

function cadreDossiers(r, memo) {
  const d = r.actuel.dossiers;
  const base = { titre: "Dossiers en cours", sous: "Nombre de dossiers, par statut.", ...memo("dossiers") };
  if (!d.nombre) {
    return cadre({ ...base, vide: etatVide({ icone: "dossiers", titre: "Aucun dossier en cours", texte: "Les dossiers de financement que vous préparez ou suivez apparaîtront ici, par statut." }) });
  }
  const nom = "Dossiers de financement en cours, par statut";
  return cadre({
    ...base,
    graphique: {
      noeud: h(
        "div",
        barresH({
          libelle: nom, formatValeur: nombre,
          lignes: d.statuts.map((s) => ({ libelle: s.nom, detail: s.montant ? `${argentCompact(s.montant)} demandés` : null, valeur: s.nombre, classe: "g-s1", texteValeur: s.nombre ? nombre(s.nombre) : "—" })),
        }),
        totaux([["Dossiers en cours", nombre(d.nombre)], ["Montant demandé", argentEntier(d.montantDemande)]])
      ),
    },
    tableau: tableauDonnees({
      libelle: nom, colonnes: ["Statut", "Dossiers", "Montant demandé"],
      lignes: d.statuts.map((s) => [s.nom, nombre(s.nombre), argent(s.montant)]),
      pied: ["Total", nombre(d.nombre), argent(d.montantDemande)],
    }),
  });
}

function cadreRecevoir(r) {
  const f = r.actuel.recevoir;
  const contenu = f.nombre
    ? h(
        "dl.registre-chiffres",
        h("div.registre-chiffres__ligne.registre-chiffres__ligne--principale", h("dt", `À encaisser (${pluriel(f.nombre, "facture", "factures")})`), h("dd", argent(f.total))),
        f.nombreEnRetard ? h("div.registre-chiffres__ligne.registre-chiffres__ligne--alerte", h("dt", `dont en retard (${f.nombreEnRetard})`), h("dd", argent(f.enRetard))) : null
      )
    : etatVide({ icone: "ok", titre: "Rien à recevoir", texte: "Toutes les factures émises sont payées." });
  return cadre({
    titre: "À recevoir", sous: "Factures émises, pas encore payées.", classe: "g-carte--recevoir",
    graphique: { noeud: h("div", contenu, f.nombre ? h("p.g-lien", h("a", { href: "#/factures" }, "Voir les factures")) : null) },
  });
}

// ----- Définitions ----------------------------------------------------------------------------------------------------------------------
function definitions() {
  return h(
    "details.replie.rapports__defs",
    h("summary.replie__titre", icone("droite", "ic--p replie__fleche"), h("span.replie__nom", "Comment ces chiffres sont calculés")),
    h(
      "div.replie__corps",
      listeDef([
        ["Demande reçue", "Un message du formulaire du site, daté de la période. Les pourriels ne comptent pas."],
        ["Demande convertie", "Une demande que vous avez convertie en contact."],
        ["Affaire gagnée ou perdue", "Une affaire qui se trouve à une étape « gagnée » ou « perdue » et dont la fermeture est datée de la période. Le taux de réussite est le nombre d’affaires gagnées divisé par celui des affaires gagnées et perdues."],
        ["Honoraires", "La valeur inscrite sur chaque affaire gagnée."],
        ["Dossier accepté", "Un dossier de financement accepté (ou terminé avec un montant obtenu) dont la décision est datée de la période. Le taux d’acceptation compare les dossiers acceptés aux dossiers refusés."],
        ["Financement obtenu", "La somme des montants obtenus inscrits sur les dossiers acceptés."],
        ["Facturé", "Les factures émises (ni brouillons, ni annulées, ni devis), à leur date d’émission, taxes comprises."],
        ["Encaissé", "Les paiements enregistrés pendant la période sur les factures émises, taxes comprises."],
        ["Provenance", "L’origine du client, choisie sur la fiche de l’affaire. Les affaires sans provenance sont regroupées sous « Non précisée »."],
        ["Comparaison", "Avec « 6 mois » ou « 12 mois » : la période de même durée juste avant. Avec « Depuis janvier » : la même portion de l’année précédente. Avec « Année dernière » : l’année d’avant."],
        ["Situation actuelle", "Une photo du jour, qui ne dépend pas de la période choisie. Les honoraires pondérés multiplient la valeur de chaque affaire par la probabilité de son étape, ou par celle que vous avez inscrite sur l’affaire."],
      ])
    )
  );
}

// ----- Écran -------------------------------------------------------------------------------------------------------------------------------
export default async function rapports(ctx) {
  const st = ctx.memoire.get("etat") || { periode: PERIODE_DEFAUT, tableaux: new Set() };
  ctx.memoire.set("etat", st);
  const demandee = ctx.requete.get("periode");
  if (PERIODES.some((p) => p.id === demandee)) st.periode = demandee;
  else if (st.periode !== PERIODE_DEFAUT) majRequete({ periode: st.periode });

  let graphes = [];
  const memo = (id) => ({
    tableauOuvert: st.tableaux.has(id),
    surBascule: (ouvert) => (ouvert ? st.tableaux.add(id) : st.tableaux.delete(id)),
  });

  const idPeriode = idUnique("rap");
  const idActuel = idUnique("rap");

  const boutons = PERIODES.map((p) =>
    h("button.commutateur__bouton", { type: "button", dataset: { periode: p.id }, "aria-pressed": String(p.id === st.periode), onclick: () => choisir(p.id) }, COURT[p.id])
  );
  const phrase = h("p.rapports__periode", { "aria-live": "polite" });
  const zoneAvis = h("div.rapports__avis");
  const zonePeriode = h("div.rapports__contenu");
  const zoneActuel = h("div.rapports__contenu");

  const corps = h(
    "div.rapports__corps",
    h(
      "section.rapports__bloc",
      { "aria-labelledby": idPeriode },
      h("header.rapports__tete", h("h2", { id: idPeriode }, "Sur la période"), h("div.commutateur.commutateur--periodes", { role: "group", "aria-label": "Période des rapports" }, boutons)),
      phrase,
      zonePeriode
    ),
    h(
      "section.rapports__bloc",
      { "aria-labelledby": idActuel },
      h("header.rapports__tete", h("div", h("h2", { id: idActuel }, "Situation actuelle"), h("p.rapports__periode", "Une photo du jour : ces chiffres ne dépendent pas de la période choisie."))),
      zoneActuel
    ),
    definitions()
  );
  const zoneVide = h("div", { hidden: true }, etatVide({ icone: "rapports", titre: "Pas encore de chiffres à présenter", texte: "Les rapports se remplissent à mesure que vous recevez des demandes, ouvrez des affaires, suivez des dossiers de financement et émettez des factures." }));

  function choisir(id) {
    if (id === st.periode) return;
    st.periode = id;
    majRequete({ periode: id === PERIODE_DEFAUT ? "" : id });
    for (const b of boutons) b.setAttribute("aria-pressed", String(b.dataset.periode === id));
    dessiner();
  }

  function dessiner() {
    for (const g of graphes) g.detruire();
    graphes = [];

    const vide = ENTITES_RAPPORTS.every((n) => !actives(n).length);
    zoneVide.hidden = !vide;
    corps.hidden = vide;
    remplir(
      zoneAvis,
      ENTITES_RAPPORTS.some((n) => etat.collections[n].some((f) => f.exemple && !f.supprime))
        ? avis({
            ton: "info", titre: "Ces chiffres incluent des données d’exemple",
            texte: "Les fiches fictives comptent dans les rapports. Retirez-les depuis l’Accueil avant de vous fier aux chiffres.",
            actions: btn("Aller à l’Accueil", { petit: true, href: "#/accueil" }),
          })
        : null
    );
    if (vide) return;

    const r = calculerRapports(
      { demandes: actives("demandes"), affaires: actives("opportunites"), dossiers: actives("dossiers"), factures: actives("factures") },
      etat.config, st.periode, aujourdhui(maintenant())
    );
    const p = r.periode;
    const cmp = comparaison(p);
    phrase.textContent = `${p.libelle} : du ${date(p.debut)} au ${date(p.fin)}. Les écarts comparent cette période ${cmp.avec} (du ${date(p.precedente.debut)} au ${date(p.precedente.fin)}).`;

    const cadres = {
      demandes: cadreDemandes(r, memo), facturation: cadreFacturation(r, memo), provenance: cadreProvenance(r, memo), raisons: cadreRaisons(r, memo),
      pipeline: cadrePipeline(r, memo), dossiers: cadreDossiers(r, memo), recevoir: cadreRecevoir(r),
    };
    graphes = Object.values(cadres);
    remplir(
      zonePeriode,
      tuiles(r),
      h("div.rapports__grille.rapports__grille--large", cadres.demandes.noeud, cadres.facturation.noeud),
      h("div.rapports__grille.rapports__grille--large", cadres.provenance.noeud, cadres.raisons.noeud)
    );
    remplir(zoneActuel, h("div.rapports__grille.rapports__grille--etroite", cadres.pipeline.noeud, cadres.dossiers.noeud, cadres.recevoir.noeud));
  }

  dessiner();

  const noeud = h(
    "div.rapports",
    enTete({
      titre: "Rapports",
      sous: "Ce que votre pratique a produit, calculé à partir de vos fiches. Rien à saisir ici.",
      actions: btn("Imprimer", { icone: "imprimer", onclick: () => window.print() }),
    }),
    zoneAvis,
    zoneVide,
    corps
  );

  return {
    titre: "Rapports",
    noeud,
    miseAJour() {
      dessiner();
      return true;
    },
    detruire() {
      for (const g of graphes) g.detruire();
      graphes = [];
    },
  };
}
