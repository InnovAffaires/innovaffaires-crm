// Liste des contacts.
import { h } from "../noyau/dom.js";
import { etat } from "../noyau/etat.js";
import { nomComplet } from "../commun/format.js";
import { CONSENTEMENTS } from "../commun/schema.js";
import { lienFiche } from "../noyau/routeur.js";
import { avatar, lienVers } from "../ui/composants.js";
import { etiquettesConnues } from "../ui/formulaire.js";
import { nomFiche, nomUtilisateur, libelleFiche } from "../noyau/etat.js";
import { creerVueListe } from "./liste.js";
import { lienCourriel, lienTelephone, puces, libelleOption } from "./aides.js";

export const depend = ["contacts", "entreprises", "equipe", "config"];

const cleTri = (c) => `${c.nom || ""} ${c.prenom || ""}`.trim() || c.courriel || "";

export default creerVueListe({
  entite: "contacts",
  titre: "Contacts",
  sous: () => "Les personnes avec qui vous travaillez ou qui vous ont écrit.",
  nouveau: { libelle: "Nouveau contact" },
  archive: (c) => !!c.archive || !!c.anonymise,
  libelleArchives: "Afficher les contacts archivés",
  placeholder: "Rechercher un nom, un courriel, une entreprise, une étiquette…",
  triDefaut: { col: "nom", dir: "asc" },
  href: (c) => lienFiche("contacts", c.id),
  vide: { icone: "contacts", titre: "Aucun contact pour l’instant", texte: "Les personnes qui vous écrivent par le formulaire du site apparaissent dans les demandes ; vous pouvez aussi ajouter un contact vous-même ou importer une liste (Paramètres → Importer)." },
  filtres: [
    { id: "etiquette", libelle: "Étiquette", tout: "Toutes les étiquettes", options: () => etiquettesConnues().map((e) => ({ id: e, libelle: e })), test: (c, v) => (c.etiquettes || []).includes(v) },
    { id: "source", libelle: "Provenance", tout: "Toutes provenances", options: () => (etat.config?.sources || []).map((s) => ({ id: s.id, libelle: s.libelle })), test: (c, v) => c.source === v },
    { id: "consentement", libelle: "Consentement", tout: "Tous consentements", options: () => CONSENTEMENTS, test: (c, v) => (c.consentement || "aucun") === v },
    { id: "responsable", libelle: "Responsable", tout: "Tous responsables", options: () => etat.equipe.map((u) => ({ id: u.id, libelle: u.nom })), test: (c, v) => c.responsable_id === v },
  ],
  colonnes: [
    {
      id: "nom", titre: "Nom", classe: "cellule-titre", valeur: cleTri,
      rendu: (c) =>
        h("div.identite", avatar(nomComplet(c) || c.courriel || "?", { taille: "s" }), h("div.identite__texte", h("a", { href: lienFiche("contacts", c.id) }, libelleFiche("contacts", c)), c.titre ? h("small.muet", c.titre) : null)),
    },
    { id: "entreprise", titre: "Entreprise", valeur: (c) => nomFiche("entreprises", c.entreprise_id), rendu: (c) => (c.entreprise_id ? lienVers("entreprises", c.entreprise_id) : h("span.muet", "—")) },
    { id: "courriel", titre: "Courriel", valeur: (c) => c.courriel, rendu: (c) => lienCourriel(c.courriel) },
    { id: "telephone", titre: "Téléphone", valeur: (c) => c.telephone || c.mobile, rendu: (c) => lienTelephone(c.telephone || c.mobile), mobile: "cache" },
    { id: "ville", titre: "Ville", valeur: (c) => c.ville, rendu: (c) => c.ville || h("span.muet", "—"), mobile: "cache" },
    { id: "etiquettes", titre: "Étiquettes", rendu: (c) => puces(c.etiquettes), mobile: "cache", triable: false },
  ],
  exporter: {
    nom: "contacts-innovaffaires",
    colonnes: [
      { titre: "Prénom", valeur: (c) => c.prenom }, { titre: "Nom", valeur: (c) => c.nom }, { titre: "Fonction", valeur: (c) => c.titre },
      { titre: "Entreprise", valeur: (c) => nomFiche("entreprises", c.entreprise_id) }, { titre: "Courriel", valeur: (c) => c.courriel },
      { titre: "Téléphone", valeur: (c) => c.telephone }, { titre: "Cellulaire", valeur: (c) => c.mobile }, { titre: "Ville", valeur: (c) => c.ville },
      { titre: "Provenance", valeur: (c) => (etat.config?.sources || []).find((s) => s.id === c.source)?.libelle || "" },
      { titre: "Consentement", valeur: (c) => libelleOption(CONSENTEMENTS, c.consentement) },
      { titre: "Étiquettes", valeur: (c) => (c.etiquettes || []).join(", ") }, { titre: "Responsable", valeur: (c) => nomUtilisateur(c.responsable_id) },
    ],
  },
});
