// Liste des entreprises.
import { h } from "../noyau/dom.js";
import { etat, liees, nomUtilisateur } from "../noyau/etat.js";
import { SECTEURS, REGIONS, FORMES_JURIDIQUES } from "../commun/schema.js";
import { argent } from "../commun/format.js";
import { lienFiche } from "../noyau/routeur.js";
import { etiquettesConnues } from "../ui/formulaire.js";
import { creerVueListe } from "./liste.js";
import { lienSite, libelleOption } from "./aides.js";

export const depend = ["entreprises", "contacts", "dossiers", "opportunites", "equipe", "config"];

const dossiersActifs = (e) =>
  liees("dossiers", "entreprise_id", e.id).filter((d) => {
    const s = etat.config?.statuts_dossier.find((x) => x.id === d.statut);
    return !s || s.type === "en-cours" || s.type === "accepte";
  });
const affairesOuvertes = (e) =>
  liees("opportunites", "entreprise_id", e.id).filter((o) => etat.config?.etapes.find((x) => x.id === o.etape)?.type === "ouverte");

export default creerVueListe({
  entite: "entreprises",
  titre: "Entreprises",
  sous: () => "Vos clients, prospects et organismes.",
  nouveau: { libelle: "Nouvelle entreprise" },
  archive: (e) => !!e.archive,
  libelleArchives: "Afficher les entreprises archivées",
  placeholder: "Rechercher un nom, une ville, un NEQ, une étiquette…",
  triDefaut: { col: "nom", dir: "asc" },
  href: (e) => lienFiche("entreprises", e.id),
  vide: { icone: "entreprises", titre: "Aucune entreprise pour l’instant", texte: "Ajoutez vos clients et prospects pour y rattacher leurs contacts, leurs dossiers de financement et leurs factures." },
  filtres: [
    { id: "secteur", libelle: "Secteur", tout: "Tous les secteurs", options: () => SECTEURS, test: (e, v) => e.secteur === v },
    { id: "region", libelle: "Région", tout: "Toutes les régions", options: () => REGIONS, test: (e, v) => e.region === v },
    { id: "etiquette", libelle: "Étiquette", tout: "Toutes les étiquettes", options: () => etiquettesConnues().map((x) => ({ id: x, libelle: x })), test: (e, v) => (e.etiquettes || []).includes(v) },
    { id: "source", libelle: "Provenance", tout: "Toutes provenances", options: () => (etat.config?.sources || []).map((s) => ({ id: s.id, libelle: s.libelle })), test: (e, v) => e.source === v },
  ],
  colonnes: [
    { id: "nom", titre: "Entreprise", classe: "cellule-titre", valeur: (e) => e.nom, rendu: (e) => h("div.identite__texte", h("a", { href: lienFiche("entreprises", e.id) }, e.nom || "Sans nom"), e.forme ? h("small.muet", libelleOption(FORMES_JURIDIQUES, e.forme)) : null) },
    { id: "secteur", titre: "Secteur", valeur: (e) => libelleOption(SECTEURS, e.secteur), rendu: (e) => libelleOption(SECTEURS, e.secteur) || h("span.muet", "—") },
    { id: "ville", titre: "Ville", valeur: (e) => e.ville, rendu: (e) => e.ville || h("span.muet", "—") },
    { id: "contacts", titre: "Contacts", classe: "num", valeur: (e) => liees("contacts", "entreprise_id", e.id).length, rendu: (e) => String(liees("contacts", "entreprise_id", e.id).length), etiquette: "Contacts" },
    { id: "dossiers", titre: "Dossiers actifs", classe: "num", valeur: (e) => dossiersActifs(e).length, rendu: (e) => String(dossiersActifs(e).length), etiquette: "Dossiers actifs" },
    { id: "affaires", titre: "Honoraires en vue", classe: "num", valeur: (e) => affairesOuvertes(e).reduce((n, o) => n + (+o.valeur || 0), 0), rendu: (e) => { const n = affairesOuvertes(e).reduce((s, o) => s + (+o.valeur || 0), 0); return n ? argent(n) : h("span.muet", "—"); }, mobile: "cache" },
    { id: "site", titre: "Site Web", rendu: (e) => lienSite(e.site_web), mobile: "cache", triable: false },
  ],
  exporter: {
    nom: "entreprises-innovaffaires",
    colonnes: [
      { titre: "Nom", valeur: (e) => e.nom }, { titre: "NEQ", valeur: (e) => e.neq }, { titre: "Secteur", valeur: (e) => libelleOption(SECTEURS, e.secteur) },
      { titre: "Forme juridique", valeur: (e) => libelleOption(FORMES_JURIDIQUES, e.forme) }, { titre: "Employés", valeur: (e) => e.employes },
      { titre: "Adresse", valeur: (e) => e.adresse }, { titre: "Ville", valeur: (e) => e.ville }, { titre: "Code postal", valeur: (e) => e.code_postal },
      { titre: "Région", valeur: (e) => libelleOption(REGIONS, e.region) }, { titre: "Téléphone", valeur: (e) => e.telephone }, { titre: "Site Web", valeur: (e) => e.site_web },
      { titre: "Étiquettes", valeur: (e) => (e.etiquettes || []).join(", ") }, { titre: "Responsable", valeur: (e) => nomUtilisateur(e.responsable_id) },
    ],
  },
});
