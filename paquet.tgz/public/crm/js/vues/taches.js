// =============================================================================
// Écran des tâches : tout ce qu'il reste à faire, du plus urgent au plus lointain,
// avec recherche et filtres, puis les tâches terminées. Une tâche se coche, se
// modifie d'un clic et mène à la fiche à laquelle elle est liée.
// =============================================================================
import { h } from "../noyau/dom.js";
import { etat, actives, fiche, libelleFiche } from "../noyau/etat.js";
import { majRequete, lireAdresse } from "../noyau/routeur.js";
import { aujourdhui } from "../commun/dates.js";
import { normaliser, pluriel } from "../commun/format.js";
import { TYPES_TACHE, PRIORITES } from "../commun/schema.js";
import { enTete, btn, panneau, etatVide } from "../ui/composants.js";
import { barreFiltres } from "../ui/filtres.js";
import { ajoutRapide, listeTaches, regrouperTaches, GROUPES_TACHES } from "../ui/taches.js";

export const depend = ["taches", "equipe", "config", "contacts", "entreprises", "opportunites", "dossiers", "factures", "demandes"];

const MAX_PAR_GROUPE = 25;
const PAGE_TERMINEES = 50;
const LIENS = [
  { id: "contacts", libelle: "Contact" }, { id: "entreprises", libelle: "Entreprise" }, { id: "opportunites", libelle: "Affaire" },
  { id: "dossiers", libelle: "Dossier de financement" }, { id: "factures", libelle: "Facture ou devis" }, { id: "demandes", libelle: "Demande du site" },
  { id: "aucune", libelle: "Sans lien" },
];

const equipeMultiple = () => (etat.equipe || []).length > 1;

export default async function vueTaches(ctx) {
  const memo = ctx.memoire;
  const st = memo.get("etat") || { vue: "afaire", q: "", filtres: {}, deplies: new Set(), nbTerminees: PAGE_TERMINEES };
  memo.set("etat", st);
  // Premier passage : si l'équipe compte plusieurs personnes, on commence par « mes tâches ».
  if (st.filtres.resp === undefined) st.filtres.resp = equipeMultiple() ? "moi" : "";
  const p = ctx.requete;
  if (p.get("vue") === "terminees" || p.get("vue") === "afaire") st.vue = p.get("vue");
  for (const cle of ["type", "priorite", "lie"]) if (p.has(cle)) st.filtres[cle] = p.get(cle);
  if (p.has("resp")) st.filtres.resp = p.get("resp") === "tous" ? "" : p.get("resp");
  if (p.has("q")) st.q = p.get("q");

  const peutEcrire = etat.droits.ecrire;
  const moi = () => etat.utilisateur?.id;

  // ----- Sélection ---------------------------------------------------------------------------------------------------------------------------------
  const jetons = () => normaliser(st.q).split(/\s+/).filter(Boolean);
  const texteDe = (t) => normaliser([t.titre, t.description, t.lie_id && fiche(t.lie_type, t.lie_id) ? libelleFiche(t.lie_type, fiche(t.lie_type, t.lie_id)) : ""].filter(Boolean).join(" "));

  function filtrer(taches) {
    const j = jetons();
    const f = st.filtres;
    return taches.filter((t) => {
      if (f.resp === "moi") {
        if (t.responsable_id && t.responsable_id !== moi()) return false;
      } else if (f.resp === "aucun") {
        if (t.responsable_id) return false;
      } else if (f.resp && t.responsable_id !== f.resp) return false;
      if (f.type && (t.type || "tache") !== f.type) return false;
      if (f.priorite && (t.priorite || "normale") !== f.priorite) return false;
      if (f.lie === "aucune" ? t.lie_id : f.lie && t.lie_type !== f.lie) return false;
      if (j.length) {
        const texte = texteDe(t);
        if (!j.every((x) => texte.includes(x))) return false;
      }
      return true;
    });
  }
  const toutes = () => actives("taches");
  const aFaire = () => toutes().filter((t) => t.statut !== "fait");
  const terminees = () => toutes().filter((t) => t.statut === "fait").sort((a, b) => String(b.terminee_le || "").localeCompare(String(a.terminee_le || "")));
  const actif = () => !!st.q.trim() || Object.entries(st.filtres).some(([k, v]) => (k === "resp" ? v !== (equipeMultiple() ? "moi" : "") : !!v));

  function enregistrerUrl() {
    majRequete(
      {
        vue: st.vue === "terminees" ? "terminees" : "", q: st.q, type: st.filtres.type, priorite: st.filtres.priorite, lie: st.filtres.lie,
        resp: equipeMultiple() ? (st.filtres.resp === "" ? "tous" : st.filtres.resp === "moi" ? "" : st.filtres.resp) : "",
      },
      { chemin: lireAdresse().chemin }
    );
  }

  // ----- Barre d'outils ----------------------------------------------------------------------------------------------------------------------
  const options = {
    resp: () => [{ id: "moi", libelle: "Mes tâches" }, { id: "aucun", libelle: "Sans responsable" }, ...(etat.equipe || []).filter((u) => u.id !== moi()).map((u) => ({ id: u.id, libelle: u.nom }))],
    type: () => TYPES_TACHE,
    priorite: () => PRIORITES,
    lie: () => LIENS,
  };
  const defFiltre = (id, libelle, tout) => ({
    id, libelle, tout, options: options[id], valeur: st.filtres[id] || "",
    surChangement: (v) => {
      st.filtres[id] = v;
      st.nbTerminees = PAGE_TERMINEES;
      rendre();
      enregistrerUrl();
    },
  });
  const filtresUi = [
    ...(equipeMultiple() ? [defFiltre("resp", "Responsable", "Toute l’équipe")] : []),
    defFiltre("type", "Type", "Tous les types"),
    defFiltre("priorite", "Priorité", "Toutes les priorités"),
    defFiltre("lie", "Liée à", "Toutes les fiches"),
  ];
  if (equipeMultiple()) filtresUi[0].valeur = st.filtres.resp;

  const barre = barreFiltres({
    placeholder: "Rechercher une tâche", q: st.q, aria: "Rechercher parmi les tâches", focusId: "taches-q",
    surRecherche: (q) => {
      st.q = q;
      st.nbTerminees = PAGE_TERMINEES;
      rendre();
      enregistrerUrl();
    },
    surReinitialiser: () => {
      st.q = "";
      st.filtres = { resp: equipeMultiple() ? "moi" : "" };
      for (const f of filtresUi) f.valeur = f.id === "resp" ? st.filtres.resp : "";
      barre.entree.value = "";
      barre.maj();
      rendre();
      enregistrerUrl();
    },
    filtres: filtresUi,
  });

  const zone = h("div.pile.pile--s");
  let panneauAjout = null;
  const commutateur = h("div.commutateur", { role: "group", "aria-label": "Tâches à faire ou terminées" });
  const sousTitre = h("p.page-tete__sous");
  function majCommutateur() {
    sousTitre.textContent = st.vue === "terminees" ? "Les tâches terminées, de la plus récente à la plus ancienne." : "Ce qu’il reste à faire, des tâches les plus urgentes aux plus lointaines.";
    if (panneauAjout) panneauAjout.hidden = st.vue === "terminees";
    const bouton = (id, libelle, n) =>
      h(
        "button.commutateur__bouton",
        { type: "button", "aria-pressed": String(st.vue === id), onclick: () => {
          if (st.vue === id) return;
          st.vue = id;
          st.nbTerminees = PAGE_TERMINEES;
          rendre();
          enregistrerUrl();
        } },
        h("span", libelle),
        h("span.commutateur__nombre", String(n))
      );
    commutateur.replaceChildren(bouton("afaire", "À faire", aFaire().length), bouton("terminees", "Terminées", terminees().length));
  }

  // ----- Rendu -------------------------------------------------------------------------------------------------------------------------------------
  function nouvelle() {
    return import("./formulaires.js").then((m) => m.nouvelleFiche("taches", { responsable_id: moi() }));
  }
  function reinitialiser() {
    st.q = "";
    st.filtres = { resp: equipeMultiple() ? "moi" : "" };
    for (const f of filtresUi) f.valeur = f.id === "resp" ? st.filtres.resp : "";
    barre.entree.value = "";
    barre.maj();
    rendre();
    enregistrerUrl();
  }
  const videFiltre = () => etatVide({ icone: "recherche", titre: "Aucune tâche ne correspond", texte: "Essayez d’autres mots ou retirez un filtre.", action: btn("Tout réinitialiser", { onclick: reinitialiser }) });

  function groupe(def, liste) {
    const visibles = st.deplies.has(def.id) ? liste : liste.slice(0, MAX_PAR_GROUPE);
    const reste = liste.length - visibles.length;
    return h(
      "section.groupe-taches",
      h("h3.groupe-taches__titre", { class: `groupe-taches__titre--${def.ton}` }, def.titre, h("span.panneau__compteur", String(liste.length))),
      listeTaches(visibles, { lienCourt: false }),
      reste > 0
        ? h("button.btn.btn--discret.btn--petit.groupe-taches__suite", { type: "button", onclick: () => {
            st.deplies.add(def.id);
            rendre();
          } }, `Afficher les ${reste} autres`)
        : null
    );
  }

  function contenuAFaire() {
    const tout = aFaire();
    if (!tout.length) {
      return etatVide({
        icone: "ok", titre: "Rien à faire pour l’instant", texte: "Ajoutez ce qu’il reste à faire, avec ou sans échéance : une tâche liée à un client, un dossier ou une affaire se retrouve aussi sur sa fiche.",
        action: peutEcrire ? btn("Nouvelle tâche", { ton: "primaire", icone: "plus", onclick: nouvelle }) : null,
      });
    }
    const liste = filtrer(tout);
    barre.definirCompte(!actif() ? pluriel(liste.length, "tâche à faire", "tâches à faire") : `${liste.length} sur ${pluriel(tout.length, "tâche à faire", "tâches à faire")}`);
    if (!liste.length) return videFiltre();
    const g = regrouperTaches(liste, aujourdhui());
    return panneau({ classe: "panneau--liste" }, GROUPES_TACHES.filter((d) => g[d.id].length).map((d) => groupe(d, g[d.id])));
  }

  function contenuTerminees() {
    const tout = terminees();
    if (!tout.length) return etatVide({ icone: "liste-verif", titre: "Aucune tâche terminée", texte: "Les tâches que vous cochez apparaissent ici, de la plus récente à la plus ancienne." });
    const liste = filtrer(tout);
    barre.definirCompte(!actif() ? pluriel(liste.length, "tâche terminée", "tâches terminées") : `${liste.length} sur ${pluriel(tout.length, "tâche terminée", "tâches terminées")}`);
    if (!liste.length) return videFiltre();
    const visibles = liste.slice(0, st.nbTerminees);
    const reste = liste.length - visibles.length;
    return panneau(
      { classe: "panneau--liste" },
      listeTaches(visibles, { quandTerminee: true, lienCourt: false }),
      reste > 0
        ? h("div.panneau__pied.panneau__pied--centre", btn(`Afficher les ${Math.min(PAGE_TERMINEES, reste)} suivantes (${reste} au total)`, { petit: true, onclick: () => {
            st.nbTerminees += PAGE_TERMINEES;
            rendre();
          } }))
        : null
    );
  }

  /** Redessine la liste. Si la case cochée vient de disparaître (tâche terminée), le focus passe à la tâche suivante. */
  function rendre() {
    const cases = (racine) => [...racine.querySelectorAll(".tache input[type=checkbox]")];
    const actifEl = document.activeElement;
    const rang = zone.contains(actifEl) && actifEl.matches?.(".tache input[type=checkbox]") ? cases(zone).indexOf(actifEl) : -1;
    majCommutateur();
    zone.replaceChildren(st.vue === "terminees" ? contenuTerminees() : contenuAFaire());
    if (rang >= 0 && !document.contains(actifEl)) {
      const apres = cases(zone);
      (apres[Math.min(rang, apres.length - 1)] || zone.querySelector("button, a"))?.focus({ preventScroll: true });
    }
  }

  const ajout = ajoutRapide({ placeholder: "Ajouter une tâche… (Entrée pour valider)", focusId: "taches-ajout" });
  panneauAjout = ajout ? h("div.panneau.panneau--saisie", h("div.panneau__corps", ajout)) : null;
  const actions = [commutateur];
  if (peutEcrire) actions.push(btn("Nouvelle tâche", { ton: "primaire", icone: "plus", onclick: nouvelle }));

  const noeud = h(
    "div",
    enTete({ titre: "Tâches", actions }),
    h("div.pile.pile--s", panneauAjout, barre.noeud, zone)
  );
  noeud.querySelector(".page-tete__titres").append(sousTitre);
  rendre();

  return {
    titre: "Tâches",
    noeud,
    miseAJour() {
      rendre();
      return true;
    },
  };
}
