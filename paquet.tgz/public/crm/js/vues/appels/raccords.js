// =============================================================================
// Raccords du poste d'appel avec le reste du CRM : les boutons des fiches
// (contact, entreprise, demande du site) et la mention « Ne pas appeler ».
// Les fiches n'ont qu'à appeler ces fonctions : elles savent qui peut écrire,
// qui est sur la liste interne et ce qu'on peut composer.
// =============================================================================
import { etat } from "../../noyau/etat.js";
import { dateCourte } from "../../commun/format.js";
import { adresseTel } from "../../commun/appels.js";
import { btn, tampon } from "../../ui/composants.js";
import { appelerDepuisFiche } from "./session.js";
import { ouvrirAjoutRapide } from "./ajouter.js";

/**
 * Bouton « Appeler » d'une fiche. Pour qui peut modifier le CRM, il ouvre l'écran d'appel (numéro, script, chronomètre,
 * résultat consigné sur la fiche); pour les autres, c'est un simple lien tel:. Rien si la personne est sur la liste
 * « ne pas appeler » ou si aucun numéro n'est utilisable.
 */
export function boutonAppeler(entite, f, telephone, opts = {}) {
  if (f.ne_pas_appeler) return null;
  const lien = adresseTel(telephone);
  if (!lien) return null;
  if (!etat.droits.ecrire) return btn("Appeler", { icone: "appel", href: lien, ...opts });
  return btn("Appeler", {
    icone: "appel", titre: "Ouvre l’écran d’appel : numéro, script, chronomètre et enregistrement du résultat",
    onclick: () => appelerDepuisFiche(entite, f.id), ...opts,
  });
}

/** Bouton « À la file d'appels » (demande du site) : choisit quand appeler, puis ajoute une tâche d'appel. */
export function boutonFileAppels(entite, f, opts = {}) {
  if (!etat.droits.ecrire || f.ne_pas_appeler) return null;
  return btn("À la file d’appels", { icone: "ajout-liste", ton: "discret", onclick: () => ouvrirAjoutRapide([{ entite, id: f.id }]), ...opts });
}

/** Entrée de menu « À la file d'appels » (menu « Ajouter » des fiches). */
export function entreeFileAppels(entite, f) {
  return { libelle: "À la file d’appels", icone: "ajout-liste", onclick: () => ouvrirAjoutRapide([{ entite, id: f.id }]) };
}

/** Tampon d'en-tête : la personne ou l'entreprise est sur la liste interne « ne pas appeler ». */
export const marqueNePasAppeler = (f) => (f.ne_pas_appeler ? tampon("Ne pas appeler", "erreur") : null);

/** Valeur de la ligne « Ne pas appeler » d'un panneau (null quand elle n'a rien à dire). */
export function texteNePasAppeler(f) {
  if (!f.ne_pas_appeler) return null;
  return f.ne_pas_appeler_le ? `Inscrit à la liste interne le ${dateCourte(f.ne_pas_appeler_le)}` : "Inscrit à la liste interne";
}
