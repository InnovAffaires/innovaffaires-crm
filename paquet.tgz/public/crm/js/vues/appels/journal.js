// =============================================================================
// Onglet « Journal » : les appels consignés, du plus récent au plus ancien, avec
// leur résultat, leur durée et les notes prises. La liste vient du serveur (une
// période à la fois); la recherche et les filtres s'appliquent ensuite sur place.
// =============================================================================
import { h, remplir } from "../../noyau/dom.js";
import { etat, maintenant, nomUtilisateur, nomFiche } from "../../noyau/etat.js";
import { lire, ErreurApi } from "../../noyau/api.js";
import { lienFiche } from "../../noyau/routeur.js";
import { aujourdhui } from "../../commun/dates.js";
import { dateCourte, heure, normaliser, pluriel, tronquer } from "../../commun/format.js";
import { RESULTATS, resultatDe, dureeTexte } from "../../commun/appels.js";
import { avis, btn, chargement, etatVide, pastille } from "../../ui/composants.js";
import { barreFiltres } from "../../ui/filtres.js";
import { tableau } from "../../ui/tableau.js";
import { surChangement, envoisEnAttente } from "./session.js";
import { bornesPeriode, commutateurPeriodes, libellePeriode } from "./periode.js";

const LIMITE = 500;

/** Les notes d'un appel, sans les lignes que le CRM ajoute lui-même (numéro composé, rendez-vous). */
function notesDe(a) {
  return String(a.texte || "")
    .split(/\n{2,}/)
    .map((x) => x.trim())
    .filter((x) => x && !/^Numéro composé :/.test(x) && !/^Rendez-vous fixé :/.test(x))
    .join(" · ")
    .replace(/\s*\n+\s*/g, " ");
}

export function monterJournal(ctx) {
  const st = ctx.memoire.get("journal") || { periode: "7j", q: "", resultat: "", par: "" };
  ctx.memoire.set("journal", st);

  const zone = h("div.pile");
  const zoneListe = h("div.histo-appels__liste");
  const phrase = h("p.muet.histo-appels__periode", { "aria-live": "polite" });
  let appels = [];
  let total = 0;
  let jeton = 0;
  let table = null;
  let chargeEnCours = false;

  // ----- Filtres ---------------------------------------------------------------------------------------------------------
  const periodes = commutateurPeriodes({
    actif: st.periode, aria: "Période du journal",
    surChoix: (id) => {
      if (id === st.periode) return;
      st.periode = id;
      periodes.choisir(id);
      charger();
    },
  });
  const equipe = (etat.equipe || []).filter((u) => u.actif !== false);
  const filtres = [
    { id: "resultat", libelle: "Résultat", tout: "Tous les résultats", options: RESULTATS.map((r) => ({ id: r.id, libelle: r.libelle })), valeur: st.resultat, surChangement: (v) => ((st.resultat = v), appliquer()) },
  ];
  if (equipe.length > 1) {
    filtres.push({ id: "par", libelle: "Appelant", tout: "Toute l’équipe", options: equipe.map((u) => ({ id: u.id, libelle: u.nom })), valeur: st.par, surChangement: (v) => ((st.par = v), appliquer()) });
  }
  const barre = barreFiltres({
    placeholder: "Nom, note ou résultat…", q: st.q, aria: "Rechercher dans le journal des appels", focusId: "journal-q", filtres,
    surRecherche: (v) => ((st.q = v), appliquer()),
    surReinitialiser: () => ((st.q = ""), (st.resultat = ""), (st.par = ""), appliquer()),
  });

  // ----- Liste ---------------------------------------------------------------------------------------------------------------
  const colonnes = [
    {
      id: "personne", titre: "Personne", classe: "cellule-titre", valeur: (a) => nomPersonne(a),
      rendu: (a) => {
        const nom = nomPersonne(a);
        return nom ? h("a", { href: lienFiche(a.lie_type, a.lie_id) }, nom) : h("span.muet", "Fiche supprimée");
      },
    },
    {
      id: "resultat", titre: "Résultat", valeur: (a) => resultatDe(a.resultat)?.court || "",
      rendu: (a) => {
        const r = resultatDe(a.resultat);
        return r ? pastille(r.court, r.ton, { icone: r.icone }) : "—";
      },
    },
    {
      id: "date", titre: "Date", valeur: (a) => a.date,
      rendu: (a) => {
        const ms = Date.parse(a.date);
        return h("span", dateCourte(aujourdhui(ms)), h("small.muet.histo-appels__heure", ` ${heure(ms)}`));
      },
    },
    { id: "duree", titre: "Durée", classe: "num", valeur: (a) => a.duree_s ?? null, rendu: (a) => (a.duree_s ? dureeTexte(a.duree_s) : "—") },
    // Avec une seule personne dans l'équipe, « Appelant » n'apprend rien et prend de la place.
    ...(equipe.length > 1 ? [{ id: "par", titre: "Appelant", mobile: "cache", valeur: (a) => nomUtilisateur(a.par), rendu: (a) => nomUtilisateur(a.par) || "—" }] : []),
    {
      // Sur téléphone, les notes sont ce qu'on veut relire : elles passent sur leur propre ligne (et disparaissent quand il n'y en a pas).
      id: "notes", titre: "Notes", classe: "histo-appels__cellule-notes", triable: false,
      rendu: (a) => {
        const n = notesDe(a);
        return n ? h("span.histo-appels__notes", { title: n }, tronquer(n, 140)) : h("span.muet.histo-appels__vide", "—");
      },
    },
  ];

  function nomPersonne(a) {
    return nomFiche(a.lie_type, a.lie_id) || "";
  }

  function filtrer() {
    const mots = normaliser(st.q || "").split(/\s+/).filter(Boolean);
    return appels.filter((a) => {
      if (st.resultat && a.resultat !== st.resultat) return false;
      if (st.par && a.par !== st.par) return false;
      if (!mots.length) return true;
      const texte = normaliser(`${nomPersonne(a)} ${notesDe(a)} ${resultatDe(a.resultat)?.libelle || ""}`);
      return mots.every((m) => texte.includes(m));
    });
  }

  function appliquer() {
    const lignes = filtrer();
    const filtre = !!(st.q || st.resultat || st.par);
    barre.definirCompte(
      filtre ? `${pluriel(lignes.length, "appel", "appels")} sur ${total}.` : `${pluriel(total, "appel", "appels")}.`
    );
    if (table) table.majLignes(lignes);
  }

  function vide() {
    const filtre = !!(st.q || st.resultat || st.par);
    return etatVide({
      icone: "appel",
      titre: filtre ? "Aucun appel ne correspond" : "Aucun appel consigné sur cette période",
      texte: filtre ? "Essayez d’autres mots, ou retirez un filtre." : "Chaque appel terminé avec un résultat apparaît ici, avec sa durée et vos notes.",
      action: filtre ? null : btn("Aller à la file d’attente", { ton: "primaire", href: "#/appels" }),
    });
  }

  function afficher() {
    table = tableau({
      colonnes, lignes: filtrer(), libelle: "Journal des appels", tri: { col: "date", dir: "desc" }, vide,
      href: (a) => (nomPersonne(a) ? lienFiche(a.lie_type, a.lie_id) : null),
      texteLimite: (n, t) => `${n} appels affichés sur ${t}.`,
    });
    remplir(zoneListe, table.noeud, total > appels.length ? h("p.muet.petit", `Seuls les ${appels.length} appels les plus récents de la période sont affichés (sur ${total}). Choisissez une période plus courte pour voir les autres.`) : null);
    appliquer();
  }

  // ----- Chargement ---------------------------------------------------------------------------------------------------------
  async function charger() {
    const mon = ++jeton;
    chargeEnCours = true;
    table = null;
    const b = bornesPeriode(st.periode, aujourdhui(maintenant()));
    phrase.textContent = `${libellePeriode(st.periode)} — du ${dateCourte(b.du)} au ${dateCourte(b.au)}.`;
    remplir(zoneListe, chargement("Chargement du journal…"));
    try {
      const rep = await lire(`/appels/journal?du=${b.du}&au=${b.au}&limite=${LIMITE}`);
      if (mon !== jeton) return;
      appels = rep.appels || [];
      total = rep.total ?? appels.length;
      chargeEnCours = false;
      afficher();
    } catch (e) {
      if (mon !== jeton) return;
      chargeEnCours = false;
      if (!(e instanceof ErreurApi)) throw e;
      remplir(zoneListe, avis({ ton: "erreur", titre: "Le journal n’a pas pu être chargé", texte: e.message, actions: btn("Réessayer", { petit: true, onclick: charger }) }));
    }
  }

  // Quand les derniers appels de la séance viennent d'être enregistrés, la liste se met à jour toute seule.
  let enAttente = envoisEnAttente().length;
  const off = surChangement(() => {
    const n = envoisEnAttente().length;
    const termine = enAttente > 0 && n === 0;
    enAttente = n;
    if (termine && !chargeEnCours) charger();
  });

  charger();

  remplir(
    zone,
    h("div.histo-appels__outils", periodes.noeud, phrase),
    barre.noeud,
    zoneListe
  );
  return {
    noeud: zone,
    miseAJour: () => true,
    detruire: () => {
      jeton++;
      off();
    },
  };
}
