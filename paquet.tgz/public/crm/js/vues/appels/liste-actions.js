// =============================================================================
// Listes d'appels : les gestes communs à l'écran des listes et à celui d'une liste — puiser des appels dans la liste, la renommer,
// la mettre en pause ou l'archiver, retirer ses appels de la file, la supprimer.
// =============================================================================
import { h, idUnique } from "../../noyau/dom.js";
import { icone } from "../../noyau/icones.js";
import { etat } from "../../noyau/etat.js";
import { ErreurApi } from "../../noyau/api.js";
import { naviguer } from "../../noyau/routeur.js";
import { pluriel } from "../../commun/format.js";
import { MAX_NOM_LISTE, MAX_DESCRIPTION_LISTE } from "../../commun/listes-appels.js";
import { btn } from "../../ui/composants.js";
import { ouvrirDialogue, confirmer } from "../../ui/dialogue.js";
import { toast } from "../../ui/toast.js";
import { modifierListe, supprimerListe, verserCibles, prochainesCibles, retirerDeLaFile, appelsOuvertsDeListe } from "../../noyau/listes-appels.js";
import { blocOptions, bilanAjout } from "./ajouter.js";

/** Nombre d'appels proposé par défaut quand on puise dans une liste : l'objectif du jour, sinon 25. */
export const nombreParDefaut = () => etat.config?.appels?.objectif_jour || 25;

// ----- Puiser des appels dans la liste -----------------------------------------------------------------------------------------
/**
 * Ajoute à la file d'appels les prochaines personnes « à appeler » de la liste (ou, avec `cibles`, des personnes précises de la liste).
 * Retourne une promesse : le nombre d'appels ajoutés (0 si la fenêtre est fermée sans rien faire).
 */
export function ouvrirPuiser(liste, { cibles = null } = {}) {
  const restantes = liste.compteurs?.a_appeler ?? 0;
  const precises = Array.isArray(cibles) ? cibles : null;
  return ouvrirDialogue({
    titre: precises ? "Ajouter à la file d’appels" : `Puiser dans « ${liste.nom} »`, taille: "moyen",
    contenu: (ctx) => {
      const options = blocOptions();
      const zoneErreur = h("div.formulaire__alerte", { role: "alert", hidden: true });
      const idN = idUnique("pui-n");
      const entree = h("input.saisie.saisie--nombre", { id: idN, type: "number", min: "1", max: String(Math.max(1, restantes)), step: "1", inputmode: "numeric", autocomplete: "off" });
      entree.value = String(Math.max(1, Math.min(restantes, nombreParDefaut())));
      const erreurN = h("p.champ__erreur", { role: "alert", hidden: true });

      async function ajouter() {
        zoneErreur.hidden = true;
        erreurN.hidden = true;
        let n = precises ? precises.length : Number.parseInt(entree.value, 10);
        if (!precises && !(Number.isInteger(n) && n >= 1 && n <= restantes)) {
          erreurN.hidden = false;
          erreurN.textContent = restantes ? `Indiquez un nombre entre 1 et ${restantes}.` : "Il ne reste personne à appeler dans cette liste.";
          entree.focus();
          return;
        }
        const o = options.lire();
        if (!o) return;
        ctx.occupe(true);
        try {
          const lesCibles = precises || (await prochainesCibles(liste.id, n));
          if (!lesCibles.length) {
            ctx.occupe(false);
            toast("Il ne reste personne à appeler dans cette liste.", { ton: "info" });
            ctx.fermer(0);
            return;
          }
          const r = await verserCibles(liste.id, lesCibles, o);
          ctx.occupe(false);
          toast(bilanAjout(r), { ton: r.creees ? "ok" : "info" });
          ctx.fermer(r.creees);
        } catch (e) {
          ctx.occupe(false);
          if (!(e instanceof ErreurApi)) throw e;
          zoneErreur.hidden = false;
          zoneErreur.textContent = e.message;
        }
      }

      ctx.definirPied(btn("Annuler", { onclick: () => ctx.fermer(0) }), btn("Ajouter à la file", { ton: "primaire", icone: "ajout-liste", onclick: ajouter }));
      return h(
        "form.formulaire",
        { novalidate: true, onsubmit: (e) => (e.preventDefault(), ajouter()) },
        zoneErreur,
        precises
          ? h("p", h("strong", pluriel(precises.length, "personne", "personnes")), " de la liste « ", liste.nom, " ».")
          : [
              h("p", "Il reste ", h("strong", pluriel(restantes, "personne", "personnes")), " à appeler dans cette liste. Les prochaines, dans l’ordre du fichier, reçoivent une tâche « Appeler » et se retrouvent dans la file d’appels."),
              h("div.champ", h("label.champ__etiquette", { for: idN }, "Combien de personnes ajouter à la file ?"), entree, erreurN, h("p.champ__aide", "Vous pourrez en ajouter d’autres plus tard : la liste garde la trace de qui a déjà été appelé.")),
            ],
        options.noeud
      );
    },
  }).promesse.then((n) => n || 0);
}

// ----- Renommer, décrire, choisir le script --------------------------------------------------------------------------------------
/** Retourne une promesse : l'en-tête de liste à jour, ou null si la fenêtre est fermée sans enregistrer. */
export function ouvrirModifier(liste) {
  return ouvrirDialogue({
    titre: "Modifier la liste", taille: "moyen",
    contenu: (ctx) => {
      const zoneErreur = h("div.formulaire__alerte", { role: "alert", hidden: true });
      const idNom = idUnique("lm-n");
      const idDesc = idUnique("lm-d");
      const idScript = idUnique("lm-s");
      const nom = h("input.saisie", { id: idNom, type: "text", maxlength: MAX_NOM_LISTE, autocomplete: "off", spellcheck: "true", "aria-required": "true" });
      nom.value = liste.nom;
      const erreurNom = h("p.champ__erreur", { role: "alert", hidden: true });
      const desc = h("textarea.saisie.saisie--long", { id: idDesc, rows: 3, maxlength: MAX_DESCRIPTION_LISTE, spellcheck: "true" });
      desc.value = liste.description || "";
      const scripts = etat.config.appels.scripts || [];
      const script = h("select.saisie", { id: idScript }, h("option", { value: "" }, "Selon la personne (script habituel)"), scripts.map((s) => h("option", { value: s.id }, s.nom)));
      script.value = scripts.some((s) => s.id === liste.script_id) ? liste.script_id : "";

      async function enregistrer() {
        zoneErreur.hidden = true;
        erreurNom.hidden = true;
        const valeur = nom.value.trim();
        if (!valeur) {
          erreurNom.hidden = false;
          erreurNom.textContent = "Donnez un nom à la liste.";
          nom.focus();
          return;
        }
        const patch = {};
        if (valeur !== liste.nom) patch.nom = valeur;
        if (desc.value.trim() !== (liste.description || "")) patch.description = desc.value.trim();
        if (script.value !== (liste.script_id || "")) patch.script_id = script.value;
        if (!Object.keys(patch).length) return ctx.fermer(null);
        ctx.occupe(true);
        try {
          const maj = await modifierListe(liste.id, patch, { version: liste.v });
          ctx.occupe(false);
          toast("La liste a été modifiée.", { ton: "ok" });
          ctx.fermer(maj);
        } catch (e) {
          ctx.occupe(false);
          if (!(e instanceof ErreurApi)) throw e;
          if (e.code === "nom_pris") {
            erreurNom.hidden = false;
            erreurNom.textContent = e.champs?.nom || e.message;
            nom.focus();
          } else {
            zoneErreur.hidden = false;
            zoneErreur.textContent = e.message;
          }
        }
      }

      ctx.definirPied(btn("Annuler", { onclick: () => ctx.fermer(null) }), btn("Enregistrer", { ton: "primaire", icone: "coche", onclick: enregistrer }));
      return h(
        "form.formulaire",
        { novalidate: true, onsubmit: (e) => (e.preventDefault(), enregistrer()) },
        zoneErreur,
        h("div.champ", h("label.champ__etiquette", { for: idNom }, "Nom de la liste"), nom, erreurNom, h("p.champ__aide", "Il sert aussi d’étiquette sur les fiches créées par l’importation. Renommer la liste ne change pas ces étiquettes.")),
        h("div.champ", h("label.champ__etiquette", { for: idDesc }, "Description (facultatif)"), desc),
        h("div.champ", h("label.champ__etiquette", { for: idScript }, "Script d’appel de cette liste"), h("div.saisie-select", script, icone("bas", "ic--p")), h("p.champ__aide", "Pendant les appels de cette liste, ce script s’affiche en premier. Vous pouvez toujours en choisir un autre sur la fiche d’appel."))
      );
    },
  }).promesse.then((m) => m || null);
}

// ----- Statut, file, suppression ---------------------------------------------------------------------------------------------------
const MESSAGES_STATUT = {
  active: "La liste est de nouveau en service : on peut y puiser des appels.",
  pausee: "La liste est en pause : on ne peut plus y puiser d’appels pour l’instant.",
  archivee: "La liste est archivée.",
};

/** Change le statut (active, pausee, archivee). Retourne l'en-tête à jour, ou null si la personne annule ou si l'envoi échoue. */
export async function changerStatut(liste, statut) {
  const nFile = liste.compteurs?.file ?? 0;
  if (statut === "archivee" && nFile > 0) {
    const ok = await confirmer({
      titre: "Archiver cette liste ?", message: `${pluriel(nFile, "personne de cette liste est encore dans la file", "personnes de cette liste sont encore dans la file")} d’appels. ${nFile > 1 ? "Elles y restent" : "Elle y reste"} : utilisez « Retirer de la file » pour ${nFile > 1 ? "les " : "l’"}enlever.`,
      libelleConfirmer: "Archiver",
    });
    if (!ok) return null;
  }
  try {
    const maj = await modifierListe(liste.id, { statut }, { version: liste.v });
    toast(MESSAGES_STATUT[statut], { ton: "ok" });
    return maj;
  } catch (e) {
    if (!(e instanceof ErreurApi)) throw e;
    toast(e.message, { ton: "erreur" });
    return null;
  }
}

/** Ferme les appels de la liste que personne n'a encore faits. Retourne le nombre d'appels retirés (0 si annulé). */
export async function retirerLesAppels(liste) {
  const n = appelsOuvertsDeListe(liste.id);
  if (!n) {
    toast("Aucun appel de cette liste n’attend dans la file.", { ton: "info" });
    return 0;
  }
  const ok = await confirmer({
    titre: "Retirer de la file ?",
    message: `${pluriel(n, "appel de la liste « ", "appels de la liste « ")}${liste.nom} » que personne n’a encore ${n > 1 ? "faits" : "fait"} ${n > 1 ? "seront retirés" : "sera retiré"} de la file, sans consigner d’appel. Les relances et les rappels déjà programmés restent.`,
    libelleConfirmer: "Retirer de la file",
  });
  if (!ok) return 0;
  try {
    const r = await retirerDeLaFile(liste.id);
    toast(r.retirees ? `${pluriel(r.retirees, "appel retiré", "appels retirés")} de la file.` : "Rien à retirer : ces appels viennent d’être faits.", { ton: "info" });
    return r.retirees;
  } catch (e) {
    if (!(e instanceof ErreurApi)) throw e;
    toast(e.message, { ton: "erreur" });
    return 0;
  }
}

/** Supprime la liste après confirmation. Retourne true si elle l'est. */
export async function supprimerAvecConfirmation(liste) {
  const ok = await confirmer({
    titre: "Supprimer cette liste ?", danger: true, libelleConfirmer: "Supprimer la liste",
    message: `La liste « ${liste.nom} » disparaît. Les fiches créées par l’importation, leurs étiquettes et l’historique des appels restent dans le CRM, tout comme les appels de cette liste qui sont déjà dans la file.`,
  });
  if (!ok) return false;
  try {
    await supprimerListe(liste.id);
    toast(`La liste « ${liste.nom} » a été supprimée.`, { ton: "info" });
    naviguer("/appels/listes");
    return true;
  } catch (e) {
    if (!(e instanceof ErreurApi)) throw e;
    toast(e.message, { ton: "erreur" });
    return false;
  }
}
