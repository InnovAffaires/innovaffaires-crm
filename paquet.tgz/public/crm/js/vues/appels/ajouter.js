// =============================================================================
// Ajouter des personnes à la file d'appels : une fenêtre pour choisir (contacts,
// entreprises, demandes du site) et une version rapide pour les boutons des fiches.
// Chaque personne reçoit une tâche « Appeler… » ; le serveur ignore celles qui n'ont
// pas de numéro, qui sont sur la liste « ne pas appeler » ou déjà dans la file.
// =============================================================================
import { h, remplir, idUnique, annoncer } from "../../noyau/dom.js";
import { icone } from "../../noyau/icones.js";
import { actives, maintenant, mettreAJourFiche, libelleFiche, texteRecherche, nomFiche } from "../../noyau/etat.js";
import { envoyer, ErreurApi } from "../../noyau/api.js";
import { aujourdhui, ajouterJours } from "../../commun/dates.js";
import { normaliser, pluriel } from "../../commun/format.js";
import { PRIORITES, STATUTS_DEMANDE } from "../../commun/schema.js";
import { btn, pastille, etatVide } from "../../ui/composants.js";
import { ouvrirDialogue, informer } from "../../ui/dialogue.js";
import { toast } from "../../ui/toast.js";
import { etiquettesConnues } from "../../ui/formulaire.js";
import { personneDe, fileDAppels } from "../../noyau/acces-appels.js";
import { nouvelleCle } from "./session.js";

const LOT = 200;
const PAGE = 80;

const RAISONS = {
  sans_numero: "sans numéro de téléphone",
  ne_pas_appeler: "sur la liste « ne pas appeler »",
  deja_dans_la_file: "déjà dans la file",
  introuvable: "fiche introuvable",
};

// ----- Envoi ----------------------------------------------------------------------------------------------------
/** Crée les tâches d'appel (par lots de 200). Retourne { creees, ignores }. */
export async function ajouterALaFile(cibles, { echeance, heure, priorite }) {
  let creees = 0;
  const ignores = [];
  for (let i = 0; i < cibles.length; i += LOT) {
    const rep = await envoyer("/appels/file", { cle: nouvelleCle(), cibles: cibles.slice(i, i + LOT), echeance, heure: heure || undefined, priorite });
    for (const t of rep.taches || []) mettreAJourFiche("taches", t);
    creees += (rep.taches || []).length;
    ignores.push(...(rep.ignores || []));
  }
  return { creees, ignores };
}

/** Phrase de bilan : « 12 personnes ajoutées à la file d'appels (2 sans numéro, 1 déjà dans la file). » */
export function bilanAjout({ creees, ignores }) {
  const parRaison = new Map();
  for (const i of ignores) parRaison.set(i.raison, (parRaison.get(i.raison) || 0) + 1);
  const details = [...parRaison].map(([r, n]) => `${n} ${RAISONS[r] || r}`).join(", ");
  if (!creees) return ignores.length ? `Personne n’a été ajouté${ignores.length > 1 ? "e" : ""} : ${details}.` : "Rien à ajouter.";
  return `${pluriel(creees, "personne ajoutée", "personnes ajoutées")} à la file d’appels${details ? ` (ignorées : ${details})` : ""}.`;
}

// ----- Options : pour quand, à quelle heure, quelle priorité -------------------------------------------------
const QUAND = [
  { id: "aujourdhui", libelle: "Aujourd’hui", jours: 0 },
  { id: "demain", libelle: "Demain", jours: 1 },
  { id: "semaine", libelle: "Dans 7 jours", jours: 7 },
  { id: "date", libelle: "Choisir une date…" },
];

function blocOptions() {
  const auj = aujourdhui(maintenant());
  const idQuand = idUnique("aj-q");
  const idDate = idUnique("aj-d");
  const idHeure = idUnique("aj-h");
  const idPrio = idUnique("aj-p");
  const quand = h("select.saisie", { id: idQuand }, QUAND.map((o) => h("option", { value: o.id }, o.libelle)));
  const date = h("input.saisie.saisie--date", { id: idDate, type: "date", min: auj, max: "2199-12-31", hidden: true, "aria-label": "Date choisie" });
  const heure = h("input.saisie.saisie--heure", { id: idHeure, type: "time" });
  const prio = h("select.saisie", { id: idPrio }, PRIORITES.map((o) => h("option", { value: o.id }, o.libelle)));
  prio.value = "normale";
  const erreur = h("p.champ__erreur", { role: "alert", hidden: true });
  quand.addEventListener("change", () => {
    date.hidden = quand.value !== "date";
    erreur.hidden = true;
    if (!date.hidden) date.focus();
  });
  const noeud = h(
    "div.groupe",
    h("h3.groupe__titre", "Quand les appeler ?"),
    h(
      "div.grille.grille--3",
      h("div.champ", h("label.champ__etiquette", { for: idQuand }, "Pour le"), h("div.saisie-select", quand, icone("bas", "ic--p")), date),
      h("div.champ", h("label.champ__etiquette", { for: idHeure }, "À partir de (facultatif)"), heure),
      h("div.champ", h("label.champ__etiquette", { for: idPrio }, "Priorité"), h("div.saisie-select", prio, icone("bas", "ic--p")))
    ),
    erreur
  );
  return {
    noeud,
    lire() {
      let echeance = auj;
      const choix = QUAND.find((o) => o.id === quand.value);
      if (choix?.jours !== undefined) echeance = ajouterJours(auj, choix.jours);
      else {
        if (!date.value || date.value < auj) {
          erreur.hidden = false;
          erreur.textContent = date.value ? "Choisissez aujourd’hui ou une date à venir." : "Choisissez la date.";
          date.focus();
          return null;
        }
        echeance = date.value;
      }
      return { echeance, heure: heure.value || undefined, priorite: prio.value };
    },
  };
}

// ----- Version rapide (boutons des fiches, sélection dans une liste) --------------------------------------------
/**
 * ouvrirAjoutRapide([{ entite, id }], { titre }) — les personnes sont déjà choisies; on précise seulement quand les appeler.
 * Retourne une promesse : le nombre de personnes ajoutées (0 si la fenêtre est fermée).
 */
export function ouvrirAjoutRapide(cibles, { titre = "Ajouter à la file d’appels" } = {}) {
  const clesDansLaFile = new Set([...fileDAppels({ portee: "tout" }).items, ...fileDAppels({ portee: "tout" }).exclus].map((x) => x.cle));
  const examens = cibles.map((c) => {
    const p = personneDe(c.entite, c.id);
    const cle = p.cible ? `${p.cible.entite}:${p.cible.id}` : null;
    const raison = !p.cible ? "introuvable" : p.nePasAppeler ? "ne_pas_appeler" : !p.numeros.length ? "sans_numero" : cle && clesDansLaFile.has(cle) ? "deja_dans_la_file" : null;
    return { ...c, nom: p.nom || nomFiche(c.entite, c.id) || "Sans nom", raison };
  });
  const bonnes = examens.filter((x) => !x.raison);
  if (!bonnes.length) {
    const un = examens[0];
    const texte =
      examens.length === 1
        ? `${un.nom} est ${RAISONS[un.raison]}.`
        : `Aucune de ces personnes ne peut être ajoutée : ${[...new Set(examens.map((x) => RAISONS[x.raison]))].join(", ")}.`;
    return informer({ titre: "Impossible d’ajouter à la file", message: texte, detail: un.raison === "sans_numero" ? h("p.muet", "Ajoutez un numéro de téléphone sur la fiche, puis recommencez.") : null }).then(() => 0);
  }

  return ouvrirDialogue({
    titre, taille: "moyen",
    contenu: (ctx) => {
      const options = blocOptions();
      const zoneErreur = h("div.formulaire__alerte", { role: "alert", hidden: true });
      const ignorees = examens.filter((x) => x.raison);
      const noms = bonnes.slice(0, 4).map((x) => x.nom).join(", ");
      const autres = bonnes.length - 4;
      async function ajouter() {
        const o = options.lire();
        if (!o) return;
        zoneErreur.hidden = true;
        ctx.occupe(true);
        try {
          const r = await ajouterALaFile(bonnes.map((x) => ({ entite: x.entite, id: x.id })), o);
          ctx.occupe(false);
          toast(bilanAjout({ creees: r.creees, ignores: [...r.ignores, ...ignorees.map((x) => ({ raison: x.raison }))] }), { ton: r.creees ? "ok" : "info" });
          ctx.fermer(r.creees);
        } catch (e) {
          ctx.occupe(false);
          if (!(e instanceof ErreurApi)) throw e;
          zoneErreur.hidden = false;
          zoneErreur.textContent = e.message;
        }
      }
      ctx.definirPied(btn("Annuler", { onclick: () => ctx.fermer(0) }), btn("Ajouter à la file", { ton: "primaire", icone: "ajout-liste", onclick: ajouter }));
      return h(
        "form.formulaire",
        { novalidate: true, onsubmit: (e) => (e.preventDefault(), ajouter()) },
        zoneErreur,
        h("p", h("strong", pluriel(bonnes.length, "personne", "personnes")), " : ", noms, autres > 0 ? ` et ${pluriel(autres, "autre")}` : "", "."),
        ignorees.length ? h("p.muet.petit", `Non ajouté${ignorees.length > 1 ? "es" : "e"} : ${ignorees.map((x) => `${x.nom} (${RAISONS[x.raison]})`).join(" ; ")}.`) : null,
        options.noeud
      );
    },
  }).promesse.then((n) => n || 0);
}

// ----- Choisir dans les fiches ----------------------------------------------------------------------------------------
const SOURCES = [
  { id: "contacts", libelle: "Contacts" },
  { id: "entreprises", libelle: "Entreprises" },
  { id: "demandes", libelle: "Demandes du site" },
];

function fichesDe(source, { q, etiquette, statut }) {
  const jetons = normaliser(q).split(/\s+/).filter(Boolean);
  let fiches;
  if (source === "contacts") {
    fiches = actives("contacts").filter((c) => !c.archive && !c.anonymise && (!etiquette || (c.etiquettes || []).includes(etiquette)));
  } else if (source === "entreprises") {
    fiches = actives("entreprises").filter((e) => !e.archive);
  } else {
    fiches = actives("demandes").filter((d) => !d.contact_id && (statut === "tous" ? true : statut === "actives" ? d.statut === "nouveau" || d.statut === "en-cours" : d.statut === statut));
  }
  if (jetons.length) fiches = fiches.filter((f) => jetons.every((j) => texteRecherche(source, f).includes(j)));
  const collateur = new Intl.Collator("fr-CA", { sensitivity: "base", numeric: true });
  if (source === "demandes") fiches = fiches.slice().sort((a, b) => String(b.recu || "").localeCompare(String(a.recu || "")));
  else fiches = fiches.slice().sort((a, b) => collateur.compare(libelleFiche(source, a), libelleFiche(source, b)));
  return fiches;
}

/** La fenêtre complète : choisir parmi les contacts, les entreprises et les demandes du site. */
export function ouvrirAjoutFile({ source = "contacts" } = {}) {
  return ouvrirDialogue({
    titre: "Ajouter des personnes à la file d’appels", taille: "grand",
    contenu: (ctx) => {
      const st = { source, q: "", etiquette: "", statut: "actives", limite: PAGE };
      const choisis = new Map(); // "entite:id" → { entite, id, nom }
      const options = blocOptions();
      const zoneErreur = h("div.formulaire__alerte", { role: "alert", hidden: true });
      const liste = h("ul.registre-liste.ajout__liste");
      const pied = h("div.ajout__pied");
      const compteur = h("p.ajout__compteur.muet", { role: "status", "aria-live": "polite" });
      const filtres = h("div.ajout__filtres");
      const idQ = idUnique("aj-rech");
      const recherche = h("input.saisie", { id: idQ, type: "search", placeholder: "Nom, entreprise, courriel ou numéro", autocomplete: "off", spellcheck: "false", "aria-label": "Rechercher une personne" });
      const boutonAjout = btn("Ajouter à la file", { ton: "primaire", icone: "ajout-liste", desactive: true, onclick: () => ajouter() });
      const commutateur = h("div.commutateur", { role: "group", "aria-label": "D’où choisir les personnes" });

      let clesDansLaFile = new Set();
      const cle = (r) => `${r.entite}:${r.id}`;

      function majBouton() {
        const n = choisis.size;
        boutonAjout.disabled = n === 0;
        boutonAjout.querySelector("span").textContent = n ? `Ajouter ${pluriel(n, "personne", "personnes")}` : "Ajouter à la file";
        compteur.textContent = n ? `${pluriel(n, "personne choisie", "personnes choisies")}.` : "Cochez les personnes à appeler.";
      }

      function ligne(f) {
        const p = personneDe(st.source, f.id);
        const cleCible = p.cible ? `${p.cible.entite}:${p.cible.id}` : null;
        const raison = !p.cible ? "introuvable" : p.nePasAppeler ? "ne_pas_appeler" : !p.numeros.length ? "sans_numero" : cleCible && clesDansLaFile.has(cleCible) ? "deja_dans_la_file" : null;
        const r = { entite: st.source, id: f.id, nom: p.nom || libelleFiche(st.source, f) };
        const coche = h("input", { type: "checkbox", disabled: !!raison, checked: choisis.has(cle(r)), "aria-label": `Choisir ${r.nom}` });
        coche.addEventListener("change", () => {
          if (coche.checked) choisis.set(cle(r), r);
          else choisis.delete(cle(r));
          majBouton();
        });
        const sous = st.source === "contacts" ? [p.fonction, p.entreprise?.nom].filter(Boolean).join(" · ") : st.source === "entreprises" ? [f.ville, f.secteur].filter(Boolean).join(" · ") : [f.organisation, f.courriel].filter(Boolean).join(" · ");
        return h(
          "li",
          h(
            "label.ligne.ajout__ligne",
            { class: { "ajout__ligne--bloquee": !!raison } },
            coche,
            h("span.case__boite", { "aria-hidden": "true" }, icone("coche", "ic--p")),
            h("span.ligne__texte", h("span.ligne__titre", r.nom), sous ? h("span.ligne__sous", sous) : null),
            h("span.ligne__fin", raison ? pastille(raison === "deja_dans_la_file" ? "Déjà dans la file" : raison === "ne_pas_appeler" ? "Ne pas appeler" : "Sans numéro", "attention") : p.numeros[0].affiche)
          )
        );
      }

      function dessiner() {
        clesDansLaFile = new Set([...fileDAppels({ portee: "tout" }).items, ...fileDAppels({ portee: "tout" }).exclus].map((x) => x.cle));
        const toutes = fichesDe(st.source, st);
        const visibles = toutes.slice(0, st.limite);
        liste.replaceChildren(...visibles.map(ligne));
        pied.replaceChildren();
        if (!toutes.length) {
          liste.replaceChildren(h("li", etatVide({ icone: "recherche", titre: "Aucune fiche ne correspond", texte: st.source === "demandes" ? "Seules les demandes qui n’ont pas encore été converties en contact sont proposées ici." : "Essayez d’autres mots.", })));
          return;
        }
        const eligibles = visibles.filter((f) => {
          const p = personneDe(st.source, f.id);
          return p.cible && !p.nePasAppeler && p.numeros.length && !clesDansLaFile.has(`${p.cible.entite}:${p.cible.id}`);
        });
        remplir(
          pied,
          h("span.muet.petit", `${toutes.length > visibles.length ? `${visibles.length} fiches affichées sur ${toutes.length}` : pluriel(toutes.length, "fiche", "fiches")}.`),
          eligibles.length
            ? btn(eligibles.length === 1 ? "Cocher la personne affichée qui peut être appelée" : `Cocher les ${eligibles.length} personnes affichées qui peuvent être appelées`, {
                petit: true,
                onclick: () => {
                  for (const f of eligibles) choisis.set(`${st.source}:${f.id}`, { entite: st.source, id: f.id, nom: libelleFiche(st.source, f) });
                  dessiner();
                  majBouton();
                  annoncer(`${pluriel(eligibles.length, "personne cochée", "personnes cochées")}.`);
                },
              })
            : null,
          toutes.length > visibles.length
            ? btn("Afficher plus de fiches", { petit: true, onclick: () => (st.limite += PAGE, dessiner()) })
            : null
        );
      }

      function dessinerFiltres() {
        filtres.replaceChildren();
        if (st.source === "contacts") {
          const etiquettes = etiquettesConnues();
          if (etiquettes.length) {
            const sel = h("select.saisie.saisie--filtre", { "aria-label": "Étiquette" }, h("option", { value: "" }, "Toutes les étiquettes"), etiquettes.map((e) => h("option", { value: e }, e)));
            sel.value = st.etiquette;
            sel.addEventListener("change", () => ((st.etiquette = sel.value), (st.limite = PAGE), dessiner()));
            filtres.append(h("div.saisie-select", sel, icone("bas", "ic--p")));
          }
        } else if (st.source === "demandes") {
          const sel = h(
            "select.saisie.saisie--filtre", { "aria-label": "Statut de la demande" },
            h("option", { value: "actives" }, "Nouvelles et en traitement"), h("option", { value: "tous" }, "Toutes les demandes non converties"),
            STATUTS_DEMANDE.filter((s) => s.id !== "converti").map((s) => h("option", { value: s.id }, s.libelle))
          );
          sel.value = st.statut;
          sel.addEventListener("change", () => ((st.statut = sel.value), (st.limite = PAGE), dessiner()));
          filtres.append(h("div.saisie-select", sel, icone("bas", "ic--p")));
        }
      }

      function dessinerSources() {
        commutateur.replaceChildren(
          ...SOURCES.map((s) =>
            h("button.commutateur__bouton", {
              type: "button", "aria-pressed": String(st.source === s.id),
              onclick: () => {
                if (st.source === s.id) return;
                st.source = s.id;
                st.limite = PAGE;
                dessinerSources();
                dessinerFiltres();
                dessiner();
              },
            }, h("span", s.libelle))
          )
        );
      }

      recherche.addEventListener("input", () => {
        st.q = recherche.value;
        st.limite = PAGE;
        dessiner();
      });

      async function ajouter() {
        const o = options.lire();
        if (!o) return;
        zoneErreur.hidden = true;
        ctx.occupe(true);
        try {
          const r = await ajouterALaFile([...choisis.values()].map(({ entite, id }) => ({ entite, id })), o);
          ctx.occupe(false);
          toast(bilanAjout(r), { ton: r.creees ? "ok" : "info" });
          ctx.fermer(r.creees);
        } catch (e) {
          ctx.occupe(false);
          if (!(e instanceof ErreurApi)) throw e;
          zoneErreur.hidden = false;
          zoneErreur.textContent = e.message;
        }
      }

      ctx.definirPied(h("div.ajout__etat", compteur), btn("Annuler", { onclick: () => ctx.fermer(0) }), boutonAjout);
      dessinerSources();
      dessinerFiltres();
      dessiner();
      majBouton();
      return h(
        "div.pile",
        zoneErreur,
        h("div.ajout__outils", commutateur, h("div.ajout__recherche", h("label.sr-only", { for: idQ }, "Rechercher une personne"), recherche), filtres),
        h("div.registre-conteneur.ajout__cadre", liste),
        pied,
        options.noeud
      );
    },
  }).promesse.then((n) => n || 0);
}
