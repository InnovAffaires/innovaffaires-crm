// =============================================================================
// Poste d'appel : l'état d'une séance d'appels, conservé en dehors des écrans
// (qui se redessinent à chaque synchronisation) — notes en cours, minuterie,
// personnes passées ou terminées — et l'envoi des résultats au serveur.
//
// Un résultat est confié à une file d'envoi : l'écran passe aussitôt à la personne
// suivante, l'envoi se fait en arrière-plan, et reprend de lui-même (avec la même
// clé d'opération, donc sans doublon) si la connexion est coupée.
// =============================================================================
import { etat, maintenant, mettreAJourFiche, notifier } from "../../noyau/etat.js";
import { envoyer, lire, ErreurApi } from "../../noyau/api.js";
import { naviguer } from "../../noyau/routeur.js";
import { toast } from "../../ui/toast.js";
import { aujourdhui, ajouterJours } from "../../commun/dates.js";
import { dateCourte } from "../../commun/format.js";
import { resultatDe, heureCourte } from "../../commun/appels.js";
import { fileDAppels } from "../../noyau/acces-appels.js";

const ETAT = {
  uid: null,
  passes: new Set(), // personnes passées pendant la séance (reviennent en fin de file)
  fait: new Map(), // personne → tâches qu'elle avait quand on l'a appelée (cachée de la file tant que ce sont les mêmes)
  faits: [], // [{ cle, nom, resultat, abouti, ms, duree, direct }] (direct : appel lancé depuis une fiche, hors de la file)
  cartes: new Map(), // cle de personne → état de la carte d'appel
  courante: null, // personne affichée
  direct: null, // { lieType, lieId, retour } : appel lancé depuis une fiche
  envois: [], // résultats à envoyer
  enCours: false,
  reprise: null,
  ecouteurs: new Set(),
  statsJour: null, // { total, joints, rdv, secondes } du serveur
  statsPour: "",
};

function reinitialiser(uid) {
  clearTimeout(ETAT.reprise);
  ETAT.uid = uid;
  ETAT.passes = new Set();
  ETAT.fait = new Map();
  ETAT.faits = [];
  ETAT.cartes = new Map();
  ETAT.courante = null;
  ETAT.direct = null;
  ETAT.envois = [];
  ETAT.enCours = false;
  ETAT.reprise = null;
  ETAT.statsJour = null;
  ETAT.statsPour = "";
}

/** L'état de la séance. Une autre personne qui se connecte dans le même navigateur repart d'un état vierge. */
export function session() {
  const uid = etat.utilisateur?.id;
  if (uid && ETAT.uid !== uid) reinitialiser(uid);
  return ETAT;
}

/** S'abonne aux changements d'état (envois, compteurs). Retourne la fonction qui désabonne. */
export function surChangement(fn) {
  ETAT.ecouteurs.add(fn);
  return () => ETAT.ecouteurs.delete(fn);
}
function signaler() {
  for (const f of [...ETAT.ecouteurs]) {
    try {
      f();
    } catch (e) {
      console.error("[appels]", e);
    }
  }
}

// ----- Cartes d'appel ----------------------------------------------------------------------------------------
export function nouvelleCle() {
  const octets = crypto.getRandomValues(new Uint8Array(12));
  return [...octets].map((o) => o.toString(16).padStart(2, "0")).join("");
}

/** L'état de saisie d'une carte : conservé quand on change de personne ou d'onglet. */
export function carte(cle) {
  const s = session();
  if (!s.cartes.has(cle)) {
    s.cartes.set(cle, {
      cleOperation: nouvelleCle(),
      notes: "", numeroCle: null, numeroAppele: "", scriptId: null,
      chronoDebut: null, chronoFin: null, appeleLe: null,
      suiteTitre: "", suiteType: "tache", suiteQuand: "demain",
      panneau: null, rappelDate: "", rappelHeure: "", rdvDate: "", rdvHeure: "", rdvType: "appel-decouverte",
    });
  }
  return s.cartes.get(cle);
}

// Minuterie
export function secondesEcoulees(c, ms = Date.now()) {
  if (!c.chronoDebut) return 0;
  return Math.max(0, Math.floor(((c.chronoFin ?? ms) - c.chronoDebut) / 1000));
}
export const chronoEnMarche = (c) => !!c.chronoDebut && !c.chronoFin;
export function demarrerChrono(c) {
  if (c.chronoDebut && c.chronoFin) {
    c.chronoDebut = Date.now() - (c.chronoFin - c.chronoDebut);
    c.chronoFin = null;
  } else if (!c.chronoDebut) {
    c.chronoDebut = Date.now();
    c.appeleLe = maintenant();
  }
}
export function arreterChrono(c) {
  if (c.chronoDebut && !c.chronoFin) c.chronoFin = Date.now();
}

// ----- File de la séance -----------------------------------------------------------------------------------------
/**
 * Retire d'une liste de la file les personnes déjà appelées pendant la séance. Elles restent cachées tant que leurs
 * tâches sont celles d'avant l'appel (le serveur n'a pas encore répondu); dès qu'une nouvelle tâche apparaît
 * (un rappel prévu à 15 h, par exemple), elles reviennent à leur place.
 */
export function sansTraitees(items) {
  const fait = session().fait;
  if (!fait.size) return items;
  return items.filter((it) => {
    const vues = fait.get(it.cle);
    return !(vues && it.taches.every((t) => vues.has(t.id)));
  });
}

/**
 * La file d'aujourd'hui pour la séance.
 *   disponibles : toutes les personnes de la file qu'on peut encore appeler (même un rappel prévu plus tard)
 *   restants    : celles à appeler maintenant (en retard, d'aujourd'hui ou dont le rappel est arrivé), dans l'ordre
 */
export function fileDeSeance() {
  const f = fileDAppels({ portee: "jour" });
  const disponibles = sansTraitees(f.items);
  return { ...f, disponibles, restants: disponibles.filter((it) => it.groupe <= 1) };
}

/** La prochaine personne à appeler : la première de la file qui n'a pas été passée, sinon la première passée. */
export function suivante(file = fileDeSeance(), { sauf = null } = {}) {
  const s = session();
  const dispo = file.restants.filter((it) => it.cle !== sauf);
  return dispo.find((it) => !s.passes.has(it.cle)) || dispo[0] || null;
}

export function passer(cle) {
  const s = session();
  s.passes.add(cle);
  if (s.courante === cle) s.courante = null;
  signaler();
}

export function choisir(cle) {
  const s = session();
  s.passes.delete(cle);
  s.courante = cle;
  s.direct = null;
}

/** Ouvre la séance sur une personne de la file (ou sur la première). */
export function commencer(cle = null) {
  const s = session();
  s.direct = null;
  s.courante = cle;
  if (cle) s.passes.delete(cle);
  naviguer("/appels/session");
}

/** Appel direct depuis une fiche : le résultat revient ensuite à la fiche. */
export function appelerDepuisFiche(lieType, lieId) {
  const s = session();
  s.direct = { lieType, lieId, retour: location.hash.replace(/^#/, "") || "/accueil" };
  naviguer("/appels/session");
}

export function terminerSeance() {
  const s = session();
  s.passes = new Set();
  s.fait = new Map();
  s.faits = [];
  s.courante = null;
  s.direct = null;
  signaler();
}

/** Bilan de la séance. `dansLaFile` : appels faits depuis la file (un appel lancé depuis une fiche compte dans le bilan, pas dans « Personne N sur M »). */
export function compteursSeance() {
  const f = session().faits;
  return {
    appels: f.length, joints: f.filter((x) => x.abouti).length, rdv: f.filter((x) => x.resultat === "rdv").length, secondes: f.reduce((n, x) => n + (x.duree || 0), 0),
    dansLaFile: f.filter((x) => !x.direct).length,
  };
}

// ----- Statistiques du jour (objectif) -----------------------------------------------------------------------
export async function chargerStatsJour() {
  const auj = aujourdhui(maintenant());
  try {
    const rep = await lire(`/appels/stats?du=${auj}&au=${auj}`);
    const st = rep.stats || {};
    ETAT.statsJour = { total: st.total || 0, joints: st.joints || 0, rdv: st.rdv || 0, secondes: st.secondes || 0 };
    ETAT.statsPour = auj;
    signaler();
  } catch (e) {
    if (!(e instanceof ErreurApi)) throw e;
    // Les compteurs du jour sont un confort : leur absence ne gêne pas les appels.
  }
}

// ----- Enregistrement d'un résultat ---------------------------------------------------------------------------
export const QUAND_SUITE = [
  { id: "aucune", libelle: "Sans échéance" },
  { id: "aujourdhui", libelle: "Aujourd’hui" },
  { id: "demain", libelle: "Demain" },
  { id: "semaine", libelle: "Dans 7 jours" },
];
const JOURS_SUITE = { aujourdhui: 0, demain: 1, semaine: 7 };

function suiteDe(c) {
  const titre = c.suiteTitre.trim();
  if (!titre) return undefined;
  const suite = { titre, type: c.suiteType || "tache" };
  const jours = JOURS_SUITE[c.suiteQuand];
  if (jours !== undefined) suite.date = ajouterJours(aujourdhui(maintenant()), jours);
  return suite;
}

/**
 * Consigne un appel : la carte est vidée, la personne passe dans les « traitées » et le résultat part
 * en arrière-plan. `plus` : { rappel: { date, heure }, rdv: { date, heure, type } }.
 */
export function consigner({ item, resultat, plus = {} }) {
  const s = session();
  const r = resultatDe(resultat);
  const cible = item.personne.cible;
  if (!r || !cible) return false;
  const c = carte(item.cle);
  const corps = { cle: c.cleOperation, cible_type: cible.entite, cible_id: cible.id, resultat };
  if (item.tache) corps.tache_id = item.tache.id;
  const duree = secondesEcoulees(c);
  if (c.chronoDebut) {
    corps.duree_s = duree;
    if (c.appeleLe) corps.debut = new Date(c.appeleLe).toISOString();
  }
  if (c.numeroAppele) corps.numero = c.numeroAppele;
  const notes = c.notes.trim();
  if (notes) corps.notes = notes;
  if (plus.rappel) corps.rappel = plus.rappel;
  if (plus.rdv?.date) corps.rdv = plus.rdv;
  const suite = suiteDe(c);
  if (suite) corps.suite = suite;

  s.envois.push({ id: corps.cle, corps, etat: "attente", tentatives: 0, erreur: "", nom: item.personne.nom, resultat, uid: s.uid, notes });
  s.faits.push({ cle: item.cle, nom: item.personne.nom, resultat, abouti: r.abouti, ms: Date.now(), duree, direct: !!item.direct });
  s.fait.set(item.cle, new Set(item.taches.map((t) => t.id)));
  s.passes.delete(item.cle);
  s.cartes.delete(item.cle);
  if (s.courante === item.cle) s.courante = null;
  signaler();
  traiterEnvois();
  return true;
}

// ----- Envoi en arrière-plan ---------------------------------------------------------------------------------------
const delaiReprise = (tentatives) => Math.min(30_000, 2000 * 2 ** Math.max(0, tentatives - 1));
const retentable = (err) => err.estReseau || err.statut >= 500 || err.statut === 429 || err.statut === 0;

function annoncerSuites(rep, e) {
  const nom = e.nom;
  if (e.resultat === "ne_pas_appeler") toast(`${nom} est inscrit(e) à la liste « ne pas appeler » : on ne l’appellera plus.`, { ton: "info", duree: 6000 });
  else if (rep.evenement) toast(`Rendez-vous ajouté au calendrier : ${nom}.`, { ton: "ok", duree: 5000 });
  else if (rep.rappel) {
    const quand = `${dateCourte(rep.rappel.echeance)}${rep.rappel.heure ? `, ${heureCourte(rep.rappel.heure)}` : ""}`;
    toast(`Rappel programmé : ${nom}, le ${quand}.`, { ton: "ok", duree: 5000 });
  } else if (rep.relance) toast(`${nom} : nouvel essai prévu le ${dateCourte(rep.relance.tache.echeance)} (essai ${rep.relance.essai} sur ${rep.relance.max}).`, { ton: "info", duree: 5000 });
  else if (rep.limite_atteinte) toast(`${nom} : tous les essais sont faits, aucune relance n’est programmée.`, { ton: "info", duree: 6000 });
}

function appliquerReponse(rep, e) {
  for (const t of rep.taches || []) mettreAJourFiche("taches", t);
  if (rep.evenement) mettreAJourFiche("evenements", rep.evenement);
  if (rep.fiche && rep.entite_fiche) mettreAJourFiche(rep.entite_fiche, rep.fiche);
  // L'appel est maintenant consigné sur la fiche : un historique déjà ouvert (retour à la fiche pendant l'envoi) se recharge.
  notifier("activites");
  annoncerSuites(rep, e);
}

/** Envoie un à un les résultats en attente. Reprend plus tard si la connexion est coupée. */
export async function traiterEnvois() {
  if (ETAT.enCours) return;
  ETAT.enCours = true;
  clearTimeout(ETAT.reprise);
  try {
    for (;;) {
      if (!etat.utilisateur || etat.utilisateur.id !== ETAT.uid) break;
      const e = ETAT.envois.find((x) => x.etat === "attente");
      if (!e) break;
      e.etat = "envoi";
      signaler();
      try {
        const rep = await envoyer("/appels/resultat", e.corps);
        ETAT.envois = ETAT.envois.filter((x) => x !== e);
        appliquerReponse(rep, e);
      } catch (err) {
        if (!(err instanceof ErreurApi)) {
          e.etat = "echec";
          e.erreur = "Erreur inattendue dans l’application.";
          console.error("[appels] envoi", err);
          signaler();
          continue;
        }
        e.tentatives += 1;
        e.erreur = err.message;
        if (retentable(err)) {
          e.etat = "attente";
          signaler();
          ETAT.reprise = setTimeout(() => traiterEnvois(), delaiReprise(e.tentatives));
          break;
        }
        e.etat = "echec";
        // Session expirée : l'écran de connexion s'affiche déjà ; l'appel reste à envoyer une fois reconnecté.
        if (err.statut !== 401) toast(`L’appel de ${e.nom} n’a pas pu être enregistré : ${err.message}`, { ton: "erreur", duree: 12000 });
      }
      signaler();
    }
  } finally {
    ETAT.enCours = false;
    signaler();
  }
  if (!ETAT.envois.some((x) => x.etat === "attente" || x.etat === "envoi") && ETAT.envois.length === 0) chargerStatsJour();
}

export const envoisEnAttente = () => ETAT.envois.filter((e) => e.etat === "attente" || e.etat === "envoi");
export const envoisEnEchec = () => ETAT.envois.filter((e) => e.etat === "echec");

export function reessayerEnvois() {
  for (const e of ETAT.envois) if (e.etat === "echec") e.etat = "attente";
  signaler();
  traiterEnvois();
}
export function abandonnerEnvoi(id) {
  ETAT.envois = ETAT.envois.filter((e) => e.id !== id);
  signaler();
}

// Un appel non encore enregistré ne doit pas disparaître parce qu'on ferme l'onglet.
addEventListener("beforeunload", (e) => {
  if (ETAT.envois.length) {
    e.preventDefault();
    e.returnValue = "";
  }
});
addEventListener("online", () => {
  if (ETAT.envois.length) traiterEnvois();
});
