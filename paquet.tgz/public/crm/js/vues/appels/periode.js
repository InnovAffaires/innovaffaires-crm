// =============================================================================
// Périodes proposées pour le journal et les statistiques des appels.
// =============================================================================
import { h } from "../../noyau/dom.js";
import { ajouterJours } from "../../commun/dates.js";

export const PERIODES_APPELS = [
  { id: "jour", court: "Aujourd’hui", libelle: "Aujourd’hui" },
  { id: "7j", court: "7 jours", libelle: "Les 7 derniers jours" },
  { id: "30j", court: "30 jours", libelle: "Les 30 derniers jours" },
  { id: "mois", court: "Ce mois-ci", libelle: "Ce mois-ci" },
  { id: "mois_passe", court: "Mois dernier", libelle: "Le mois dernier" },
];

/** Dates (AAAA-MM-JJ, incluses) d'une période, à partir de la date du jour. */
export function bornesPeriode(id, auj) {
  const premier = `${auj.slice(0, 7)}-01`;
  switch (id) {
    case "jour":
      return { du: auj, au: auj };
    case "30j":
      return { du: ajouterJours(auj, -29), au: auj };
    case "mois":
      return { du: premier, au: auj };
    case "mois_passe": {
      const fin = ajouterJours(premier, -1);
      return { du: `${fin.slice(0, 7)}-01`, au: fin };
    }
    default:
      return { du: ajouterJours(auj, -6), au: auj };
  }
}

export const libellePeriode = (id) => PERIODES_APPELS.find((p) => p.id === id)?.libelle || "";

/** Boutons de choix de la période. Retourne { noeud, choisir(id) } ; choisir() ne fait que marquer le bouton actif. */
export function commutateurPeriodes({ actif, surChoix, aria = "Période" }) {
  const boutons = PERIODES_APPELS.map((p) =>
    h("button.commutateur__bouton", { type: "button", dataset: { periode: p.id }, "aria-pressed": String(p.id === actif), onclick: () => surChoix(p.id) }, p.court)
  );
  return {
    noeud: h("div.commutateur.commutateur--periodes", { role: "group", "aria-label": aria }, boutons),
    choisir(id) {
      for (const b of boutons) b.setAttribute("aria-pressed", String(b.dataset.periode === id));
    },
  };
}
