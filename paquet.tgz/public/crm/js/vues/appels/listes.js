// =============================================================================
// Onglet « Listes » : les listes d'appels de prospection importées (Excel, CSV, copier-coller), où elles en sont, et le bouton qui
// en importe une nouvelle. Une liste garde l'ordre du fichier; on y puise des appels à son rythme, et le CRM suit qui a été appelé.
// =============================================================================
import { h, remplir } from "../../noyau/dom.js";
import { etat } from "../../noyau/etat.js";
import { dateCourte, pluriel } from "../../commun/format.js";
import { aujourdhui } from "../../commun/dates.js";
import { statutListe } from "../../commun/listes-appels.js";
import { btn, panneau, pastille, etatVide, avis, chargement, menuActions } from "../../ui/composants.js";
import { chargerListes, listesEnMemoire } from "../../noyau/listes-appels.js";
import { ouvrirPuiser, ouvrirModifier, changerStatut, retirerLesAppels, supprimerAvecConfirmation } from "./liste-actions.js";

/** Pastille du statut d'une liste, ou rien quand elle est active. */
export function pastilleStatut(liste) {
  if (liste.statut === "active") return null;
  return pastille(statutListe(liste.statut).libelle, liste.statut === "pausee" ? "attention" : "neutre");
}

/** Barre de progression d'une liste : part des personnes déjà appelées. */
export function barreProgres(compteurs, { etiquette = "Avancement de la liste" } = {}) {
  const total = compteurs.total || 0;
  const part = total ? Math.min(1, (compteurs.appeles || 0) / total) : 0;
  return h("div.progres", { role: "progressbar", "aria-label": etiquette, "aria-valuemin": "0", "aria-valuemax": String(total), "aria-valuenow": String(compteurs.appeles || 0) }, h("span.progres__barre", { css: { "--p": part.toFixed(3) } }));
}

/** « Importée le 20 oct. 2026 » */
export const dateDeCreation = (liste) => dateCourte(aujourdhui(Date.parse(liste.cree) || Date.now()));

/** Les chiffres d'une liste, en une ligne : « 120 à appeler · 25 dans la file · 40 appelées · 5 exclues ». */
export function chiffresListe(c) {
  const morceaux = [
    h("li", h("strong.tnum", String(c.a_appeler)), " à appeler"),
    h("li", h("strong.tnum", String(c.file)), " dans la file"),
    h("li", h("strong.tnum", String(c.appeles)), c.appeles > 1 ? " appelées" : " appelée"),
    c.exclu ? h("li", h("strong.tnum", String(c.exclu)), c.exclu > 1 ? " exclues" : " exclue") : null,
  ];
  return h("ul.liste-chiffres", morceaux);
}

export function monterListes(ctx) {
  const memo = ctx.memoire;
  const st = memo.get("listes") || { archivees: false };
  memo.set("listes", st);
  const peutEcrire = etat.droits.ecrire;
  const zone = h("div.pile");
  let echec = null;
  let dernierChargement = 0;
  let detruit = false;

  function recharger({ force = true } = {}) {
    dernierChargement = Date.now();
    return chargerListes({ force })
      .then(() => {
        echec = null;
      })
      .catch((e) => {
        echec = e;
        throw e;
      })
      .finally(() => {
        if (!detruit) rendre();
      });
  }

  function menuDe(liste) {
    const apres = () => recharger().catch(() => {});
    const el = [
      { libelle: "Modifier le nom, la description ou le script", icone: "modifier", onclick: () => ouvrirModifier(liste).then((m) => m && apres()) },
      liste.statut === "active"
        ? { libelle: "Mettre en pause", icone: "sablier", onclick: () => changerStatut(liste, "pausee").then(apres) }
        : { libelle: liste.statut === "pausee" ? "Reprendre la liste" : "Remettre en service", icone: "lecture", onclick: () => changerStatut(liste, "active").then(apres) },
      liste.statut !== "archivee" ? { libelle: "Archiver", icone: "archiver", onclick: () => changerStatut(liste, "archivee").then(apres) } : null,
      liste.compteurs.file > 0 ? { libelle: "Retirer ses appels de la file", icone: "fermer", onclick: () => retirerLesAppels(liste).then(apres) } : null,
      "separateur",
      { libelle: "Supprimer la liste", icone: "corbeille", danger: true, onclick: () => supprimerAvecConfirmation(liste).then(apres) },
    ];
    return menuActions({ aria: `Plus d’actions pour la liste ${liste.nom}`, fixe: true, elements: el });
  }

  function carte(liste) {
    const c = liste.compteurs;
    const peutPuiser = peutEcrire && liste.statut === "active" && c.a_appeler > 0;
    const suite = [
      c.joints ? pluriel(c.joints, "personne jointe", "personnes jointes") : null,
      c.rdv ? pluriel(c.rdv, "rendez-vous", "rendez-vous") : null,
    ].filter(Boolean);
    return h(
      "li.liste-carte",
      { class: { "liste-carte--inactive": liste.statut !== "active" } },
      h(
        "div.liste-carte__tete",
        h("a.liste-carte__nom", { href: `#/appels/listes/${encodeURIComponent(liste.id)}` }, liste.nom),
        pastilleStatut(liste),
        peutEcrire ? h("div.liste-carte__menu", menuDe(liste)) : null
      ),
      liste.description ? h("p.liste-carte__description", liste.description) : null,
      h("div.liste-carte__avancement", barreProgres(c), h("p.liste-carte__avancement-texte.muet", `${c.appeles} sur ${pluriel(c.total, "personne", "personnes")} déjà appelée${c.total > 1 ? "s" : ""}`)),
      chiffresListe(c),
      suite.length ? h("p.liste-carte__suite", suite.join(" · ")) : null,
      h("p.liste-carte__meta.muet", [`Importée le ${dateDeCreation(liste)}`, liste.fichier || null].filter(Boolean).join(" · ")),
      h(
        "div.liste-carte__actions",
        peutPuiser ? btn("Ajouter à la file", { ton: "primaire", petit: true, icone: "ajout-liste", onclick: () => ouvrirPuiser(liste).then((n) => n && recharger().catch(() => {})) }) : null,
        btn("Ouvrir la liste", { petit: true, href: `#/appels/listes/${encodeURIComponent(liste.id)}` })
      )
    );
  }

  function rendre() {
    if (detruit) return;
    const toutes = listesEnMemoire();
    if (!toutes) {
      remplir(
        zone,
        echec
          ? avis({ ton: "erreur", titre: "Les listes n’ont pas pu être lues", texte: echec.message, actions: btn("Réessayer", { petit: true, onclick: () => ((echec = null), rendre(), recharger().catch(() => {})) }) })
          : chargement("Chargement des listes…")
      );
      return;
    }
    const enCours = toutes.filter((l) => l.statut !== "archivee");
    const archivees = toutes.filter((l) => l.statut === "archivee");
    // La dernière liste archivée vient d'être remise en service (ou supprimée) : on revient aux listes en cours, sinon l'écran resterait vide.
    if (!archivees.length) st.archivees = false;
    const visibles = st.archivees ? archivees : enCours;
    const outils = h(
      "div.file__outils",
      peutEcrire ? btn("Importer une liste", { ton: "primaire", icone: "televerser", href: "#/appels/listes/importer" }) : null,
      archivees.length
        ? h(
            "div.commutateur",
            { role: "group", "aria-label": "Listes à montrer" },
            h("button.commutateur__bouton", { type: "button", "aria-pressed": String(!st.archivees), onclick: () => ((st.archivees = false), rendre()) }, h("span", "En cours"), h("span.commutateur__nombre", String(enCours.length))),
            h("button.commutateur__bouton", { type: "button", "aria-pressed": String(st.archivees), onclick: () => ((st.archivees = true), rendre()) }, h("span", "Archivées"), h("span.commutateur__nombre", String(archivees.length)))
          )
        : null
    );
    let contenu;
    if (!toutes.length) {
      contenu = panneau(
        {},
        etatVide({
          icone: "liste", titre: "Aucune liste d’appels",
          texte: peutEcrire
            ? "Importez une liste de prospection (un fichier Excel ou CSV, ou des lignes copiées depuis un tableur). Le CRM crée les fiches, écarte les doublons et les personnes à ne pas appeler, puis vous y puisez des appels au rythme que vous voulez : 25 par jour, par exemple."
            : "Aucune liste d’appels de prospection n’a été importée pour l’instant.",
          action: peutEcrire ? btn("Importer une liste", { ton: "primaire", icone: "televerser", href: "#/appels/listes/importer" }) : null,
        })
      );
    } else if (!visibles.length) {
      contenu = panneau({}, etatVide({ icone: "archiver", titre: st.archivees ? "Aucune liste archivée" : "Toutes vos listes sont archivées", texte: st.archivees ? "" : "Importez une nouvelle liste, ou consultez les listes archivées." }));
    } else {
      contenu = h("ul.listes", visibles.map(carte));
    }
    remplir(zone, toutes.length ? outils : null, contenu, toutes.length && !peutEcrire ? avis({ ton: "info", titre: "Accès en lecture seule", texte: "Vous pouvez consulter les listes, mais pas en importer ni en modifier." }) : null);
  }

  rendre();
  recharger().catch(() => {});

  return {
    noeud: zone,
    miseAJour(changes) {
      rendre();
      // Les appels faits, les tâches fermées ou ajoutées changent les chiffres : on relit, au plus toutes les 5 secondes.
      if (changes.has("taches") && Date.now() - dernierChargement > 5000) recharger().catch(() => {});
      return true;
    },
    detruire() {
      detruit = true;
    },
  };
}
