// =============================================================================
// Onglet « Statistiques » : combien d'appels, combien de personnes jointes, de
// rendez-vous pris, à quelle heure on joint le mieux. Les calculs sont faits par le
// serveur (commun/appels.js, calculerStats); ici on choisit la période et on dessine.
// =============================================================================
import { h, remplir } from "../../noyau/dom.js";
import { maintenant, nomUtilisateur } from "../../noyau/etat.js";
import { lire, ErreurApi } from "../../noyau/api.js";
import { aujourdhui } from "../../commun/dates.js";
import { dateCourte, dateLongue, moisCourt, nombre, pluriel, pourcent } from "../../commun/format.js";
import { RESULTATS, dureeTexte } from "../../commun/appels.js";
import { avis, btn, chargement, etatVide, listeDef } from "../../ui/composants.js";
import { barresH, cadre, colonnes, legende, tableauDonnees, tuile } from "../../ui/graphiques.js";
import { icone } from "../../noyau/icones.js";
import { surChangement, envoisEnAttente } from "./session.js";
import { bornesPeriode, commutateurPeriodes, libellePeriode } from "./periode.js";

const NBSP = " ";
/** Part de n dans d, en pourcentage entier (« 42 % »); « — » quand il n'y a rien à comparer. */
const part = (n, d) => (d > 0 ? pourcent(Math.round((n / d) * 100)).replace(" ", NBSP) : "—");

const LEGENDE_REPONSE = [{ classe: "g-s1", libelle: "La personne a répondu" }, { classe: "g-autre", libelle: "Pas de conversation" }];

// ----- Tuiles --------------------------------------------------------------------------------------------------------------------
function tuiles(st) {
  const moyenne = st.joints ? Math.round(st.secondesJoints / st.joints) : 0;
  return h("div.tuiles", [
    tuile({
      libelle: "Appels faits", valeur: nombre(st.total),
      sous: st.total ? [`Sans réponse : ${nombre(st.parResultat.pas_de_reponse)}`, `Messages laissés : ${nombre(st.parResultat.message)}`] : "Aucun appel sur la période.",
    }),
    tuile({ libelle: "Personnes jointes", valeur: nombre(st.joints), sous: st.total ? `Taux de contact : ${part(st.joints, st.total)}` : "—" }),
    tuile({ libelle: "Rendez-vous pris", valeur: nombre(st.rdv), sous: st.rdv ? `Un rendez-vous pour ${pluriel(Math.round(st.total / st.rdv), "appel", "appels")}` : st.total ? "Aucun rendez-vous pris pendant ces appels." : "—" }),
    tuile({
      libelle: "Temps au téléphone", valeur: st.secondes ? dureeTexte(st.secondes) : "—",
      sous: st.joints && moyenne ? `Durée moyenne d’une conversation : ${dureeTexte(moyenne)}` : "Calculé à partir du chronomètre de chaque appel.",
    }),
  ]);
}

// ----- Graphiques ---------------------------------------------------------------------------------------------------------------
function cadreJours(st, memo) {
  const jours = st.parJour;
  if (jours.length < 2) return null; // une seule journée : le graphique par heure suffit
  const base = { titre: "Appels par jour", sous: "Appels faits et personnes jointes, jour après jour.", ...memo("jours") };
  const nom = "Appels faits et personnes jointes, par jour";
  const categories = jours.map((j, i) => ({ court: String(+j.date.slice(8)), long: dateLongue(j.date), annee: i === 0 || j.date.endsWith("-01") ? moisCourt(j.date) : null }));
  return cadre({
    ...base,
    legende: legende([{ classe: "g-s1", libelle: "Appels" }, { classe: "g-s2", libelle: "Personnes jointes" }]),
    graphique: colonnes({
      categories, entier: true, formatAxe: nombre, formatValeur: nombre, libelle: nom,
      series: [
        { id: "appels", libelle: "Appels", classe: "g-s1", valeurs: jours.map((j) => j.total) },
        { id: "joints", libelle: "Personnes jointes", classe: "g-s2", valeurs: jours.map((j) => j.joints) },
      ],
    }),
    tableau: tableauDonnees({
      libelle: nom, colonnes: ["Jour", "Appels", "Jointes", "Rendez-vous"],
      lignes: jours.map((j, i) => [categories[i].long, nombre(j.total), nombre(j.joints), nombre(j.rdv)]),
      pied: ["Total", nombre(st.total), nombre(st.joints), nombre(st.rdv)],
    }),
  });
}

function cadreResultats(st, memo) {
  const base = { titre: "Comment se terminent les appels", sous: "Nombre d’appels, par résultat.", ...memo("resultats") };
  const nom = "Appels de la période, par résultat";
  return cadre({
    ...base,
    legende: legende(LEGENDE_REPONSE),
    graphique: {
      noeud: barresH({
        libelle: nom, formatValeur: nombre,
        lignes: RESULTATS.map((r) => ({ libelle: r.libelle, detail: st.parResultat[r.id] ? part(st.parResultat[r.id], st.total) : null, valeur: st.parResultat[r.id] || 0, classe: r.abouti ? "g-s1" : "g-autre", texteValeur: st.parResultat[r.id] ? nombre(st.parResultat[r.id]) : "—" })),
      }),
    },
    tableau: tableauDonnees({
      libelle: nom, colonnes: ["Résultat", "Appels", "Part"],
      lignes: RESULTATS.map((r) => [r.libelle, nombre(st.parResultat[r.id] || 0), part(st.parResultat[r.id] || 0, st.total)]),
      pied: ["Total", nombre(st.total), st.total ? part(st.total, st.total) : "—"],
    }),
  });
}

function cadreHeures(st, memo) {
  const base = { titre: "À quelle heure on joint le mieux", sous: "Appels faits et personnes jointes, selon l’heure de l’appel.", ...memo("heures") };
  const avec = st.parHeure.filter((x) => x.total > 0).map((x) => x.heure);
  if (!avec.length) return null;
  const nom = "Appels faits et personnes jointes, par heure du jour";
  const debut = Math.min(8, ...avec);
  const fin = Math.max(20, ...avec);
  const plage = st.parHeure.slice(debut, fin + 1);
  const categories = plage.map((x) => ({ court: String(x.heure), long: `${x.heure} h à ${x.heure + 1} h` }));
  return cadre({
    ...base,
    legende: legende([{ classe: "g-s1", libelle: "Appels" }, { classe: "g-s2", libelle: "Personnes jointes" }]),
    graphique: colonnes({
      categories, entier: true, formatAxe: nombre, formatValeur: nombre, libelle: nom,
      series: [
        { id: "appels", libelle: "Appels", classe: "g-s1", valeurs: plage.map((x) => x.total) },
        { id: "joints", libelle: "Personnes jointes", classe: "g-s2", valeurs: plage.map((x) => x.joints) },
      ],
    }),
    tableau: tableauDonnees({
      libelle: nom, colonnes: ["Heure", "Appels", "Jointes", "Taux de contact"],
      lignes: plage.filter((x) => x.total > 0).map((x) => [`${x.heure} h à ${x.heure + 1} h`, nombre(x.total), nombre(x.joints), part(x.joints, x.total)]),
    }),
  });
}

function cadreEquipe(st, memo) {
  const gens = st.parUtilisateur;
  if (gens.length < 2) return null;
  const base = { titre: "Par personne de l’équipe", sous: "Appels faits, avec la part des conversations tenues.", ...memo("equipe") };
  const nom = "Appels de la période, par personne de l’équipe";
  const libelle = (u) => nomUtilisateur(u.uid) || "Autre";
  return cadre({
    ...base,
    legende: legende(LEGENDE_REPONSE),
    graphique: {
      noeud: barresH({
        libelle: nom, formatValeur: nombre,
        lignes: gens.map((u) => ({
          libelle: libelle(u), detail: [u.rdv ? pluriel(u.rdv, "rendez-vous", "rendez-vous") : null, u.secondes ? dureeTexte(u.secondes) : null].filter(Boolean).join(" · ") || null,
          valeur: u.total, segments: [{ valeur: u.joints, classe: "g-s1" }, { valeur: u.total - u.joints, classe: "g-autre" }],
        })),
      }),
    },
    tableau: tableauDonnees({
      libelle: nom, colonnes: ["Personne", "Appels", "Jointes", "Rendez-vous", "Temps"],
      lignes: gens.map((u) => [libelle(u), nombre(u.total), nombre(u.joints), nombre(u.rdv), u.secondes ? dureeTexte(u.secondes) : "—"]),
    }),
  });
}

// ----- Définitions ------------------------------------------------------------------------------------------------------------
function definitions() {
  return h(
    "details.replie.rapports__defs",
    h("summary.replie__titre", icone("droite", "ic--p replie__fleche"), h("span.replie__nom", "Comment ces chiffres sont calculés")),
    h(
      "div.replie__corps",
      listeDef([
        ["Appel", "Un appel terminé avec un résultat dans le poste d’appel (Joint, Rendez-vous, Sans réponse…). Une note d’appel ajoutée à la main sur une fiche, sans résultat, n’est pas comptée."],
        ["Personne jointe", "Quelqu’un a répondu : conversation tenue, rendez-vous pris, à rappeler, pas intéressé ou « ne plus appeler ». « Sans réponse », « Message laissé » et « Mauvais numéro » ne comptent pas."],
        ["Taux de contact", "Les personnes jointes divisées par les appels faits."],
        ["Temps au téléphone", "La somme des durées chronométrées pendant les appels. Un appel fait sans chronomètre compte pour zéro."],
        ["Heures", "L’heure de Montréal du début de l’appel (ou de son enregistrement, si le chronomètre n’a pas servi)."],
      ])
    )
  );
}

// ----- Écran ------------------------------------------------------------------------------------------------------------------------
export function monterStats(ctx) {
  const st = ctx.memoire.get("stats") || { periode: "7j", tableaux: new Set() };
  ctx.memoire.set("stats", st);

  const zone = h("div.pile");
  const phrase = h("p.muet.histo-appels__periode", { "aria-live": "polite" });
  const contenu = h("div.rapports__contenu");
  let graphes = [];
  let jeton = 0;
  let chargeEnCours = false;

  const memo = (id) => ({ tableauOuvert: st.tableaux.has(id), surBascule: (ouvert) => (ouvert ? st.tableaux.add(id) : st.tableaux.delete(id)) });
  const periodes = commutateurPeriodes({
    actif: st.periode, aria: "Période des statistiques",
    surChoix: (id) => {
      if (id === st.periode) return;
      st.periode = id;
      periodes.choisir(id);
      charger();
    },
  });

  function liberer() {
    for (const g of graphes) g.detruire?.();
    graphes = [];
  }

  function afficher(stats) {
    liberer();
    if (!stats.total) {
      remplir(contenu, etatVide({
        icone: "appel", titre: "Aucun appel consigné sur cette période",
        texte: "Les statistiques se remplissent à mesure que vous terminez des appels avec un résultat (Joint, Rendez-vous, Sans réponse…).",
        action: btn("Aller à la file d’attente", { ton: "primaire", href: "#/appels" }),
      }));
      return;
    }
    // Les graphiques disponibles, deux par rangée.
    const cadres = [cadreJours(stats, memo), cadreHeures(stats, memo), cadreResultats(stats, memo), cadreEquipe(stats, memo)].filter(Boolean);
    graphes = cadres;
    const rangees = [];
    for (let i = 0; i < cadres.length; i += 2) rangees.push(h("div.rapports__grille.rapports__grille--large", cadres.slice(i, i + 2).map((c) => c.noeud)));
    remplir(contenu, tuiles(stats), rangees, definitions());
  }

  async function charger() {
    const mon = ++jeton;
    chargeEnCours = true;
    liberer();
    const b = bornesPeriode(st.periode, aujourdhui(maintenant()));
    phrase.textContent = `${libellePeriode(st.periode)} — du ${dateCourte(b.du)} au ${dateCourte(b.au)}.`;
    remplir(contenu, chargement("Chargement des statistiques…"));
    try {
      const rep = await lire(`/appels/stats?du=${b.du}&au=${b.au}`);
      if (mon !== jeton) return;
      chargeEnCours = false;
      afficher(rep.stats);
    } catch (e) {
      if (mon !== jeton) return;
      chargeEnCours = false;
      if (!(e instanceof ErreurApi)) throw e;
      remplir(contenu, avis({ ton: "erreur", titre: "Les statistiques n’ont pas pu être chargées", texte: e.message, actions: btn("Réessayer", { petit: true, onclick: charger }) }));
    }
  }

  let enAttente = envoisEnAttente().length;
  const off = surChangement(() => {
    const n = envoisEnAttente().length;
    const termine = enAttente > 0 && n === 0;
    enAttente = n;
    if (termine && !chargeEnCours) charger();
  });

  charger();
  remplir(zone, h("div.histo-appels__outils", periodes.noeud, phrase), contenu);
  return {
    noeud: zone,
    miseAJour: () => true,
    detruire: () => {
      jeton++;
      off();
      liberer();
    },
  };
}
