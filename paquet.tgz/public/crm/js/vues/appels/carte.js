// =============================================================================
// La carte d'appel : une personne à la fois, avec ses numéros, le script, la
// minuterie, les notes et les boutons de résultat. Choisir un résultat consigne
// l'appel et affiche aussitôt la personne suivante.
//
// L'écran se redessine souvent (synchronisation toutes les 45 s) : tout ce que la
// personne saisit vit dans session.js (carte(cle)), jamais seulement dans le DOM.
// =============================================================================
import { h, remplir, idUnique, annoncer, copierTexte, paragraphes } from "../../noyau/dom.js";
import { icone } from "../../noyau/icones.js";
import { etat, maintenant, libelleFiche } from "../../noyau/etat.js";
import { lienFiche, naviguer } from "../../noyau/routeur.js";
import { lireActivites } from "../../noyau/ecriture.js";
import { aujourdhui } from "../../commun/dates.js";
import { ilYa, pluriel } from "../../commun/format.js";
import {
  RESULTATS, resultatDe, adresseTel, plageHoraire, heureCourte, rappelParDefaut, analyserScript, segmenterChamps, CHAMPS_SCRIPT,
  valeursScript, scriptPourPersonne, chronoTexte, TYPES_SUITE, libelleEssai, dureeTexte,
} from "../../commun/appels.js";
import { avatar, btn, btnIcone, pastille, tampon, etatVide, avis, panneau } from "../../ui/composants.js";
import { toast } from "../../ui/toast.js";
import { appelDirect } from "../../noyau/acces-appels.js";
import { listeEnMemoire, chargerListes } from "../../noyau/listes-appels.js";
import {
  session, carte, fileDeSeance, suivante, passer, choisir, consigner, terminerSeance, compteursSeance, surChangement,
  secondesEcoulees, chronoEnMarche, demarrerChrono, arreterChrono, QUAND_SUITE,
} from "./session.js";
import { ouvrirAjoutFile } from "./ajouter.js";

const LIBELLE_CHAMP = Object.fromEntries(CHAMPS_SCRIPT.map((x) => [x.id, x.libelle.toLowerCase()]));
const TYPES_RDV = [
  { id: "appel-decouverte", libelle: "Appel découverte (30 min)" },
  { id: "rencontre", libelle: "Rencontre (1 h)" },
  { id: "visio", libelle: "Rencontre virtuelle (1 h)" },
];
const ICONE_ACT = { note: "note", appel: "appel", courriel: "courriel", rencontre: "rendez-vous", document: "document", systeme: "historique" };
const MAX_SUIVANTS = 8;

// Historique récent d'une personne : lu une fois, gardé une minute.
const historiques = new Map();

export function monterCarte() {
  const s = session();
  const racine = h("div.appel-page");
  let item = null;
  let signature = "";
  let minuteur = null;
  let ticks = 0;
  let offSession = null;
  const refs = { chrono: null, majChrono: null, horaire: null, bandeau: null, suivants: null, notes: null, resultats: null };

  // ----- Quelle personne afficher ? ------------------------------------------------------------------------------------
  // `disponibles` : toute la file d'aujourd'hui (même un rappel prévu plus tard, si on l'a choisi à la main);
  // `restants` : ce qui est à faire maintenant, dans l'ordre.
  function trouver() {
    if (s.direct) return { it: appelDirect(s.direct.lieType, s.direct.lieId), file: null };
    const file = fileDeSeance();
    let it = s.courante ? file.disponibles.find((x) => x.cle === s.courante) || null : null;
    if (!it) {
      it = suivante(file);
      s.courante = it ? it.cle : null;
    }
    return { it, file };
  }

  /** La liste d'appels de prospection d'où vient cet appel, si elle est connue (les listes se lisent à part des fiches). */
  const listeDe = (it) => (it?.tache?.liste_id ? listeEnMemoire(it.tache.liste_id) : null);

  const signatureDe = (it) => {
    const p = it.personne;
    const liste = listeDe(it);
    return JSON.stringify([p.nom, p.fonction, p.entreprise?.nom, p.nePasAppeler, p.numeros.map((n) => n.brut), p.demande?.projet, it.tache?.id, it.essai, etat.config.v, it.tache?.liste_id, liste?.nom, liste?.script_id]);
  };

  // ----- Bandeau du haut ---------------------------------------------------------------------------------------------------
  function bandeau(file) {
    const cpt = compteursSeance();
    // La personne affichée compte même si elle a été choisie à la main parmi les rappels prévus plus tard.
    const restants = file ? file.restants.length + (item && !file.restants.some((x) => x.cle === item.cle) ? 1 : 0) : 0;
    return h(
      "div.appel__bandeau",
      s.direct
        ? h("a.retour", { href: `#${s.direct.retour}` }, icone("retour", "ic--p"), "Retour à la fiche")
        : h("a.retour", { href: "#/appels" }, icone("retour", "ic--p"), "File d’attente"),
      !s.direct && item ? h("p.appel__position", `Personne ${cpt.dansLaFile + 1} sur ${cpt.dansLaFile + restants}`) : null,
      cpt.appels
        ? h("p.appel__compteurs", h("strong", pluriel(cpt.appels, "appel", "appels")), ` · ${cpt.joints} joint${cpt.joints > 1 ? "s" : ""}`, cpt.rdv ? ` · ${pluriel(cpt.rdv, "rendez-vous", "rendez-vous")}` : "", cpt.secondes ? ` · ${dureeTexte(cpt.secondes)}` : "")
        : null
    );
  }
  function majBandeau(file) {
    if (!refs.bandeau) return;
    const n = bandeau(file);
    refs.bandeau.replaceWith(n);
    refs.bandeau = n;
  }

  // ----- Tête : qui est-ce ? --------------------------------------------------------------------------------------------------
  function zoneTete(it) {
    const p = it.personne;
    const t = it.tache;
    const cible = p.cible;
    const max = etat.config.appels.essais_max;
    const marques = [];
    if (p.nePasAppeler) marques.push(tampon("Ne pas appeler", "erreur"));
    if (it.essai > 1) marques.push(pastille(libelleEssai(it.essai, max), "info"));
    if (p.demande) marques.push(pastille(`Demande du site${p.demande.recu ? ` · ${ilYa(Date.parse(p.demande.recu), maintenant())}` : ""}`, "neutre"));
    if (t?.priorite === "haute") marques.push(h("span.file__priorite", icone("drapeau", "ic--p"), h("span", "Prioritaire")));
    if (t?.heure) marques.push(pastille(`Prévu à ${heureCourte(t.heure)}`, "neutre"));
    if (it.direct) marques.push(pastille("Appel direct", "neutre"));
    const liste = listeDe(it);
    if (liste) marques.push(h("span.pastille.pastille--neutre.pastille--liste", { title: `Liste d’appels : ${liste.nom}` }, icone("liste", "ic--p"), h("span.pastille__texte", liste.nom)));
    const sous = [p.fonction, p.entreprise && cible.entite !== "entreprises" ? p.entreprise.nom : null].filter(Boolean).join(" · ");
    const ctx = p.contexte && p.contexte.entite !== "demandes" ? p.contexte : null;
    return h(
      "header.appel__tete",
      avatar(p.nom, { taille: "l" }),
      h(
        "div.appel__ident",
        h("h2.appel__nom", { tabindex: "-1" }, p.nom),
        sous ? h("p.appel__sous", sous) : null,
        marques.length ? h("div.appel__marques", marques) : null,
        t && !/^(rappeler|appeler)\s/i.test(t.titre || "") ? h("p.appel__motif", icone("liste-verif", "ic--p"), h("span", t.titre)) : null,
        ctx ? h("p.appel__motif", icone("dossiers", "ic--p"), h("span", "Concerne : "), h("a.lien-fiche", { href: lienFiche(ctx.entite, ctx.id), target: "_blank", rel: "noopener" }, libelleFiche(ctx.entite, ctx.fiche))) : null
      ),
      h("a.btn.btn--discret.btn--petit.appel__fiche", { href: lienFiche(cible.entite, cible.id), target: "_blank", rel: "noopener", title: "Ouvrir la fiche dans un nouvel onglet" }, icone("externe"), h("span", "Fiche"))
    );
  }

  // ----- Avertissement sur les heures d'appel -----------------------------------------------------------------------------
  function contenuHoraire() {
    const a = etat.config.appels;
    if (!a.avertir_heures) return null;
    const plage = plageHoraire(etat.config, maintenant());
    if (plage.dansPlage) return null;
    return avis({
      ton: "attention",
      titre: `Il est ${heureCourte(plage.heure)} : en dehors des heures d’appel habituelles`,
      texte: `Les appels de vente sont permis ${plage.finDeSemaine ? "la fin de semaine" : "en semaine"} de ${heureCourte(plage.debut)} à ${heureCourte(plage.fin)}. Si cet appel répond à une demande de la personne ou concerne un client, vous pouvez continuer.`,
    });
  }
  function majHoraire() {
    if (!refs.horaire) return;
    remplir(refs.horaire, contenuHoraire());
  }

  // ----- Numéros, bouton Appeler, minuterie ---------------------------------------------------------------------------
  function ligneChrono(c) {
    const temps = h("span.chrono__temps", { role: "timer", "aria-label": "Durée de l’appel" }, chronoTexte(secondesEcoulees(c)));
    const libelle = h("span", "Démarrer le chrono");
    const bouton = h("button.btn.btn--discret.btn--petit", { type: "button" }, icone("chrono"), libelle);
    const majBouton = () => {
      const marche = chronoEnMarche(c);
      libelle.textContent = marche ? "Arrêter le chrono" : c.chronoDebut ? "Reprendre" : "Démarrer le chrono";
      temps.textContent = chronoTexte(secondesEcoulees(c));
      temps.classList.toggle("chrono__temps--marche", marche);
    };
    bouton.addEventListener("click", () => {
      if (chronoEnMarche(c)) arreterChrono(c);
      else demarrerChrono(c);
      majBouton();
    });
    refs.chrono = temps;
    refs.majChrono = majBouton;
    majBouton();
    return h("div.chrono", icone("horloge", "ic--p"), temps, bouton);
  }

  function zoneNumeros(it, c) {
    const p = it.personne;
    if (p.nePasAppeler) {
      return avis({ ton: "erreur", titre: "Cette personne est sur la liste « ne pas appeler »", texte: "Ne l’appelez pas. Si elle vous a redemandé de la joindre, retirez d’abord la mention sur sa fiche." });
    }
    if (!p.numeros.length) {
      return avis({
        ton: "attention", titre: "Aucun numéro de téléphone", texte: "Ajoutez un numéro sur la fiche pour pouvoir l’appeler d’ici.",
        actions: btn("Ouvrir la fiche", { petit: true, href: lienFiche(p.cible.entite, p.cible.id) }),
      });
    }
    const dernier = c.numeroCle;
    return h(
      "section.appel__numeros",
      { "aria-label": "Numéros de téléphone" },
      h(
        "ul.numeros",
        p.numeros.map((n, i) => {
          const href = adresseTel(n.brut);
          const appeler = h(
            "a.btn.btn--primaire.numero__appeler",
            {
              href, class: { "btn--large": i === 0 }, "aria-label": `Appeler ${p.nom} au ${n.affiche}`, "aria-keyshortcuts": i === 0 ? "A" : null,
              onclick: () => {
                c.numeroCle = n.cle;
                c.numeroAppele = n.brut;
                demarrerChrono(c);
                refs.majChrono?.();
                racine.querySelectorAll(".numero").forEach((li, k) => li.classList.toggle("numero--choisi", k === i));
              },
            },
            icone("telephone"),
            h("span", "Appeler"),
            i === 0 ? h("kbd", "A") : null
          );
          return h(
            "li.numero",
            { class: { "numero--choisi": dernier === n.cle } },
            h(
              "div.numero__texte",
              h("strong.numero__tel", n.affiche, n.poste ? h("small", ` poste ${n.poste}`) : null),
              h("small.muet", [n.etiquette, n.de].filter(Boolean).join(" · "), dernier === n.cle ? " · composé" : "")
            ),
            h(
              "div.numero__actions",
              appeler,
              btnIcone("copier", `Copier le numéro ${n.affiche}`, async () => {
                const ok = await copierTexte(n.affiche.replace(/ /g, " "));
                toast(ok ? "Numéro copié." : "La copie a échoué : sélectionnez le numéro à la main.", { ton: ok ? "info" : "erreur", duree: 2500 });
              })
            )
          );
        })
      ),
      p.numeros.some((n) => n.poste) ? h("p.muet.petit", "Si un poste est indiqué, composez-le à la main une fois la ligne connectée.") : null,
      ligneChrono(c),
      h("p.muet.petit.numeros__aide", "Pas d’application d’appel sur cet ordinateur ? Copiez le numéro et composez-le sur votre téléphone : le chronomètre peut se lancer à la main.")
    );
  }
  // ----- Contexte : ce que la personne a écrit, derniers échanges ---------------------------------------------
  function zoneContexte(it) {
    const p = it.personne;
    const blocs = [];
    if (p.demande?.projet) {
      blocs.push(
        h(
          "section.appel__contexte",
          h("h3", "Ce que la personne a écrit"),
          h("div.appel__citation", paragraphes(p.demande.projet)),
          h("p.muet.petit", [p.demande.organisation, p.demande.courriel].filter(Boolean).join(" · "))
        )
      );
    }
    const hist = h("section.appel__historique", { hidden: true }, h("h3", "Derniers échanges"));
    blocs.push(hist);
    chargerHistorique(it, hist);
    return h("div.pile.pile--s.appel__zone-contexte", blocs);
  }

  function rendreHistorique(noeud, activites) {
    const liste = (activites || []).filter((a) => a.type !== "systeme").slice(0, 3);
    if (!liste.length) {
      noeud.hidden = true;
      return;
    }
    noeud.hidden = false;
    noeud.replaceChildren(
      h("h3", "Derniers échanges"),
      h(
        "ul.appel__echanges",
        liste.map((a) =>
          h(
            "li",
            icone(ICONE_ACT[a.type] || "note", "ic--p"),
            h("span.appel__echange", h("strong", a.titre || a.type), " ", h("span.muet", ilYa(Date.parse(a.date), maintenant())), a.texte ? h("small.appel__extrait", String(a.texte).replace(/\s+/g, " ").slice(0, 160)) : null)
          )
        )
      )
    );
  }

  async function chargerHistorique(it, noeud) {
    const cible = it.personne.cible;
    if (!cible) return;
    const memo = historiques.get(it.cle);
    if (memo && Date.now() - memo.ms < 60_000) {
      rendreHistorique(noeud, memo.activites);
      return;
    }
    try {
      const activites = await lireActivites(cible.entite, cible.id, 4);
      historiques.set(it.cle, { ms: Date.now(), activites });
      if (noeud.isConnected) rendreHistorique(noeud, activites);
    } catch {
      /* l'historique est un plus : sans lui, l'appel reste possible */
    }
  }

  // ----- Script ---------------------------------------------------------------------------------------------------------------------------
  function morceaux(texte, valeurs) {
    return segmenterChamps(texte).map((m) => {
      if (typeof m === "string") return m;
      const v = valeurs[m.champ];
      if (v) return h("span.script__valeur", v);
      return h("span.script__vide", { title: "Information absente de la fiche" }, `[${LIBELLE_CHAMP[m.champ] || m.champ}]`);
    });
  }

  function zoneScript(it, c) {
    const scripts = etat.config.appels.scripts || [];
    if (!scripts.length) {
      return etat.droits.administrer
        ? panneau({ titre: "Script d’appel", niveau: 3 }, h("p.muet", "Aucun script n’est enregistré. Rédigez-en un dans "), btn("Paramètres → Appels", { petit: true, href: "#/parametres/appels" }))
        : null;
    }
    const defaut = scriptPourPersonne(it.personne, etat.config, { prefereId: listeDe(it)?.script_id || "" });
    const courant = scripts.find((x) => x.id === c.scriptId) || defaut;
    const valeurs = valeursScript({ personne: it.personne, utilisateur: etat.utilisateur, config: etat.config });
    const corps = h("div.script__corps");
    const rendre = (sc) => {
      corps.replaceChildren(
        ...analyserScript(sc.texte).map((sec) =>
          h(
            "section.script__section",
            sec.titre ? h("h4.script__titre", sec.titre) : null,
            sec.blocs.map((b) => (b.type === "puces" ? h("ul", b.lignes.map((l) => h("li", morceaux(l, valeurs)))) : h("p", morceaux(b.texte, valeurs))))
          )
        )
      );
    };
    rendre(courant);
    const idSel = idUnique("sc");
    const choix =
      scripts.length > 1
        ? h(
            "div.script__choix",
            h("label.sr-only", { for: idSel }, "Script à suivre"),
            h("div.saisie-select", h("select.saisie.saisie--filtre", { id: idSel, onchange: (e) => {
              c.scriptId = e.target.value;
              rendre(scripts.find((x) => x.id === c.scriptId) || courant);
            } }, scripts.map((x) => h("option", { value: x.id, selected: x.id === courant.id }, x.nom))), icone("bas", "ic--p"))
          )
        : null;
    return h(
      "section.script",
      { "aria-label": "Script d’appel" },
      h("header.script__tete", h("h3", "Script"), choix),
      corps,
      h("p.muet.petit.script__note", "Les mots entre crochets manquent sur la fiche : dites-les de vive voix ou complétez la fiche après l’appel.")
    );
  }

  // ----- Notes et tâche de suite ---------------------------------------------------------------------------------------
  function zoneNotes(c) {
    const id = idUnique("notes");
    const ta = h("textarea.saisie.saisie--long.appel__notes", {
      id, rows: 6, maxlength: 4000, spellcheck: "true", "data-focus-id": "appel-notes", "aria-keyshortcuts": "N", placeholder: "Ce qui a été dit, ce qu’il faut retenir…",
    });
    ta.value = c.notes;
    ta.addEventListener("input", () => (c.notes = ta.value));
    refs.notes = ta;
    return h("div.champ.appel__zone-notes", h("label.champ__etiquette", { for: id }, "Notes d’appel ", h("kbd", "N")), ta, h("p.champ__aide", "Elles s’ajoutent à l’historique de la fiche."));
  }

  function zoneSuite(c) {
    const idT = idUnique("st-t");
    const idQ = idUnique("st-q");
    const idY = idUnique("st-y");
    const titre = h("input.saisie", { id: idT, type: "text", maxlength: 300, autocomplete: "off", placeholder: "Ex. : envoyer la liste des programmes", "data-focus-id": "appel-suite" });
    titre.value = c.suiteTitre;
    titre.addEventListener("input", () => (c.suiteTitre = titre.value));
    const type = h("select.saisie", { id: idY }, TYPES_SUITE.map((t) => h("option", { value: t.id }, t.libelle)));
    type.value = c.suiteType;
    type.addEventListener("change", () => (c.suiteType = type.value));
    const quand = h("select.saisie", { id: idQ }, QUAND_SUITE.map((o) => h("option", { value: o.id }, o.libelle)));
    quand.value = c.suiteQuand;
    quand.addEventListener("change", () => (c.suiteQuand = quand.value));
    return h(
      "details.replie.appel__suite",
      { open: !!c.suiteTitre },
      h("summary.replie__titre", icone("liste-verif", "ic--p"), h("span", "Ajouter une tâche de suite"), h("span.replie__compte.muet", "facultatif"), icone("droite", "replie__fleche")),
      h(
        "div.replie__corps",
        h("div.champ", h("label.champ__etiquette", { for: idT }, "À faire"), titre),
        h(
          "div.grille.grille--2",
          h("div.champ", h("label.champ__etiquette", { for: idY }, "Type"), h("div.saisie-select", type, icone("bas", "ic--p"))),
          h("div.champ", h("label.champ__etiquette", { for: idQ }, "Pour le"), h("div.saisie-select", quand, icone("bas", "ic--p")))
        )
      )
    );
  }

  // ----- Résultats --------------------------------------------------------------------------------------------------------------
  function champ(libelle, controle, id, erreur) {
    return h("div.champ", h("label.champ__etiquette", { for: id }, libelle), controle, erreur);
  }

  function terminer(id, plus = {}) {
    const nom = item.personne.nom;
    const r = resultatDe(id);
    const retour = s.direct ? s.direct.retour : null;
    if (!consigner({ item, resultat: id, plus })) return;
    if (retour) {
      // Appel lancé depuis une fiche : on y revient une fois le résultat consigné.
      s.direct = null;
      toast(`Appel consigné : ${r.court.toLowerCase()}.`, { ton: "ok", duree: 3500 });
      naviguer(retour);
      return;
    }
    annoncer(`${nom} : ${r.court}.`);
    dessiner();
    focusAppeler();
  }

  function panneauRappel(c) {
    const auj = aujourdhui(maintenant());
    const defaut = rappelParDefaut({ config: etat.config, auj });
    if (!c.rappelDate) c.rappelDate = defaut.date;
    if (!c.rappelHeure) c.rappelHeure = defaut.heure;
    const idD = idUnique("rp-d");
    const idH = idUnique("rp-h");
    const date = h("input.saisie.saisie--date", { id: idD, type: "date", min: auj, max: "2199-12-31" });
    date.value = c.rappelDate;
    const heure = h("input.saisie.saisie--heure", { id: idH, type: "time" });
    heure.value = c.rappelHeure;
    const erreur = h("p.champ__erreur", { role: "alert", hidden: true });
    const valider = () => {
      if (!date.value || date.value < auj) {
        erreur.hidden = false;
        erreur.textContent = date.value ? "Choisissez aujourd’hui ou une date à venir." : "Choisissez la date du rappel.";
        date.focus();
        return;
      }
      c.rappelDate = date.value;
      c.rappelHeure = heure.value;
      terminer("rappeler", { rappel: { date: date.value, heure: heure.value || undefined } });
    };
    return h(
      "form.resultat-panneau",
      { novalidate: true, onsubmit: (e) => (e.preventDefault(), valider()) },
      h("h3", icone("horloge", "ic--p"), "Quand rappeler ?"),
      h("div.grille.grille--2", champ("Date", date, idD, erreur), champ("Heure", heure, idH, null)),
      h("p.muet.petit", "Un rappel prioritaire est ajouté à la file à cette date."),
      h("div.actions-ligne", btn("Enregistrer et passer au suivant", { ton: "primaire", type: "submit", icone: "coche" }), btn("Annuler", { onclick: () => fermerPanneau(c) }))
    );
  }

  function panneauRdv(c) {
    const auj = aujourdhui(maintenant());
    const idD = idUnique("rv-d");
    const idH = idUnique("rv-h");
    const idT = idUnique("rv-t");
    const date = h("input.saisie.saisie--date", { id: idD, type: "date", min: auj, max: "2199-12-31" });
    date.value = c.rdvDate;
    const heure = h("input.saisie.saisie--heure", { id: idH, type: "time" });
    heure.value = c.rdvHeure;
    const type = h("select.saisie", { id: idT }, TYPES_RDV.map((t) => h("option", { value: t.id }, t.libelle)));
    type.value = c.rdvType;
    const erreurDate = h("p.champ__erreur", { role: "alert", hidden: true });
    const erreurHeure = h("p.champ__erreur", { role: "alert", hidden: true });
    const garder = () => {
      c.rdvDate = date.value;
      c.rdvHeure = heure.value;
      c.rdvType = type.value;
    };
    const valider = () => {
      erreurDate.hidden = true;
      erreurHeure.hidden = true;
      garder();
      if (!date.value || date.value < auj) {
        erreurDate.hidden = false;
        erreurDate.textContent = date.value ? "Choisissez aujourd’hui ou une date à venir." : "Choisissez la date du rendez-vous.";
        date.focus();
        return;
      }
      if (!heure.value) {
        erreurHeure.hidden = false;
        erreurHeure.textContent = "Indiquez l’heure du rendez-vous.";
        heure.focus();
        return;
      }
      terminer("rdv", { rdv: { date: date.value, heure: heure.value, type: type.value } });
    };
    return h(
      "form.resultat-panneau",
      { novalidate: true, onsubmit: (e) => (e.preventDefault(), valider()) },
      h("h3", icone("rendez-vous", "ic--p"), "Rendez-vous pris"),
      h("div.grille.grille--2", champ("Date", date, idD, erreurDate), champ("Heure", heure, idH, erreurHeure)),
      champ("Type de rendez-vous", h("div.saisie-select", type, icone("bas", "ic--p")), idT, null),
      h("p.muet.petit", "Le rendez-vous est ajouté au calendrier et à l’historique de la fiche."),
      h(
        "div.actions-ligne",
        btn("Enregistrer le rendez-vous", { ton: "primaire", type: "submit", icone: "coche" }),
        btn("Date à fixer plus tard", { onclick: () => (garder(), terminer("rdv")) }),
        btn("Annuler", { onclick: () => fermerPanneau(c) })
      )
    );
  }

  function panneauNePlusAppeler(c) {
    const nom = item.personne.nom;
    return h(
      "div.resultat-panneau",
      h("h3", icone("bloquer", "ic--p"), "Ne plus appeler ?"),
      h("p", `${nom} sera inscrit(e) à la liste interne « ne pas appeler » : elle n’apparaîtra plus dans la file et ne pourra plus être ajoutée par erreur. La mention se retire sur sa fiche.`),
      h("div.actions-ligne", btn("Inscrire à la liste", { ton: "danger-plein", icone: "bloquer", onclick: () => terminer("ne_pas_appeler") }), btn("Annuler", { onclick: () => fermerPanneau(c) }))
    );
  }

  function fermerPanneau(c) {
    c.panneau = null;
    majResultats();
    refs.resultats?.querySelector(".resultat")?.focus();
  }

  function choisirResultat(id) {
    const r = resultatDe(id);
    if (!r || !item || !etat.droits.ecrire) return;
    const c = carte(item.cle);
    if (r.suite === "rdv" || r.suite === "rappel" || id === "ne_pas_appeler") {
      c.panneau = id;
      majResultats();
      refs.resultats?.querySelector("input, select, button.btn--danger-plein")?.focus();
      return;
    }
    terminer(id);
  }

  function zoneResultats() {
    const z = h("section.resultats-zone", { "aria-label": "Résultat de l’appel" });
    refs.resultats = z;
    majResultats();
    return z;
  }
  function majResultats() {
    const z = refs.resultats;
    if (!z || !item) return;
    const c = carte(item.cle);
    if (!etat.droits.ecrire) {
      z.replaceChildren(avis({ ton: "info", titre: "Lecture seule", texte: "Votre accès ne permet pas de consigner un appel." }));
      return;
    }
    if (c.panneau === "rappeler") z.replaceChildren(panneauRappel(c));
    else if (c.panneau === "rdv") z.replaceChildren(panneauRdv(c));
    else if (c.panneau === "ne_pas_appeler") z.replaceChildren(panneauNePlusAppeler(c));
    else {
      z.replaceChildren(
        h("h3.resultats__titre", "Comment s’est passé l’appel ?"),
        h(
          "div.resultats",
          RESULTATS.map((r) =>
            h(
              "button.resultat",
              { type: "button", class: `resultat--${r.ton}`, "data-resultat": r.id, "aria-keyshortcuts": r.touche, onclick: () => choisirResultat(r.id) },
              icone(r.icone),
              h("span.resultat__libelle", r.court),
              h("kbd", r.touche)
            )
          )
        ),
        h("p.muet.petit", "Le résultat enregistre l’appel dans l’historique, termine la tâche et passe à la personne suivante.")
      );
    }
  }

  function zonePasser(it) {
    if (it.direct) {
      const retour = s.direct?.retour || "/appels";
      return h("div.appel__nav", btn("Annuler cet appel", { petit: true, ton: "discret", icone: "fermer", onclick: () => ((s.direct = null), naviguer(retour)) }));
    }
    return h(
      "div.appel__nav",
      btn("Passer", { petit: true, ton: "discret", icone: "saut", onclick: passerCarte, aria: "Passer cette personne (elle reviendra en fin de file)" }),
      h("kbd", { title: "Raccourci" }, "S")
    );
  }
  function passerCarte() {
    if (!item || item.direct) return;
    const avant = item.cle;
    passer(avant);
    dessiner();
    if (item && item.cle === avant) toast("Il n’y a personne d’autre à appeler pour l’instant.", { ton: "info", duree: 3000 });
    focusAppeler();
  }

  // ----- À suivre --------------------------------------------------------------------------------------------------------------------------
  function contenuSuivants(file, it) {
    if (!file) return null;
    const suiv = file.restants.filter((x) => x.cle !== it.cle);
    if (!suiv.length) return null;
    return panneau(
      { titre: "À suivre", compteur: String(suiv.length), niveau: 3, classe: "appel__suivants" },
      h(
        "ul.registre-liste",
        suiv.slice(0, MAX_SUIVANTS).map((x) =>
          h(
            "li",
            h(
              "button.ligne.appel__suivant",
              { type: "button", onclick: () => (choisir(x.cle), dessiner(), focusAppeler()) },
              avatar(x.personne.nom, { taille: "s" }),
              h("span.ligne__texte", h("span.ligne__titre", x.personne.nom), h("span.ligne__sous", [x.personne.fonction, x.personne.entreprise?.nom, x.essai > 1 ? libelleEssai(x.essai, etat.config.appels.essais_max) : ""].filter(Boolean).join(" · "))),
              h("span.ligne__fin.muet", x.personne.numeros[0]?.affiche || "")
            )
          )
        )
      ),
      suiv.length > MAX_SUIVANTS ? h("p.muet.petit.appel__suite-liste", `Et ${pluriel(suiv.length - MAX_SUIVANTS, "autre")}.`) : null
    );
  }
  function majSuivants(file, it) {
    if (!refs.suivants) return;
    remplir(refs.suivants, contenuSuivants(file, it));
  }

  // ----- Fin de file, fiche illisible ---------------------------------------------------------------------------------------
  function ecranFin() {
    const cpt = compteursSeance();
    return panneau(
      {},
      etatVide({
        icone: cpt.appels ? "ok" : "casque",
        titre: cpt.appels ? "File terminée" : "Personne à appeler pour l’instant",
        texte: cpt.appels
          ? `${pluriel(cpt.appels, "appel fait", "appels faits")} pendant cette séance : ${cpt.joints} personne${cpt.joints > 1 ? "s jointes" : " jointe"}${cpt.rdv ? `, ${pluriel(cpt.rdv, "rendez-vous pris", "rendez-vous pris")}` : ""}${cpt.secondes ? `, ${dureeTexte(cpt.secondes)} au téléphone` : ""}.`
          : "Ajoutez des personnes à la file ou attendez qu’un rappel arrive à échéance.",
        action: h(
          "div.actions-ligne",
          btn("Retour à la file", { ton: "primaire", href: "#/appels" }),
          etat.droits.ecrire ? btn("Ajouter des personnes", { icone: "ajout-liste", onclick: () => ouvrirAjoutFile() }) : null,
          cpt.appels ? btn("Terminer la séance", { onclick: () => (terminerSeance(), naviguer("/appels")) }) : null
        ),
      })
    );
  }
  function ecranIllisible() {
    return panneau({}, etatVide({ icone: "alerte", titre: "Cette fiche ne peut pas être appelée", texte: "La personne n’existe plus ou la tâche n’est liée à aucune fiche.", action: btn("Retour", { ton: "primaire", href: s.direct ? `#${s.direct.retour}` : "#/appels" }) }));
  }

  // ----- Assemblage ---------------------------------------------------------------------------------------------------------------
  function focusAppeler() {
    const cible = racine.querySelector(".numero__appeler") || racine.querySelector(".appel__nom") || racine;
    cible.focus?.({ preventScroll: false });
    scrollTo({ top: 0, behavior: "instant" });
  }

  function dessiner() {
    const { it, file } = trouver();
    item = it;
    remplir(racine);
    refs.chrono = null;
    refs.majChrono = null;
    refs.notes = null;
    refs.resultats = null;
    refs.bandeau = bandeau(file);
    racine.append(refs.bandeau);
    if (!it) {
      racine.append(ecranFin());
      return;
    }
    if (!it.personne.cible) {
      racine.append(ecranIllisible());
      return;
    }
    const c = carte(it.cle);
    signature = signatureDe(it);
    refs.horaire = h("div.appel__horaire");
    majHoraire();
    refs.suivants = h("div.appel__suivants-zone");
    majSuivants(file, it);
    racine.append(
      h(
        "div.appel",
        h("div.appel__principal", zoneTete(it), refs.horaire, zoneNumeros(it, c), zoneContexte(it), zoneScript(it, c)),
        h("aside.appel__lateral", { "aria-label": "Notes et résultat de l’appel" }, zoneNotes(c), zoneSuite(c), zoneResultats(), zonePasser(it))
      ),
      refs.suivants
    );
  }

  // ----- Clavier ---------------------------------------------------------------------------------------------------------------------------
  function surTouche(e) {
    if (e.ctrlKey || e.metaKey || e.altKey || document.querySelector("dialog[open]")) return;
    const cible = e.target;
    const saisie = cible instanceof HTMLElement && (cible.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(cible.tagName));
    const c = item ? carte(item.cle) : null;
    if (e.key === "Escape") {
      if (c?.panneau) {
        e.preventDefault();
        fermerPanneau(c);
      } else if (saisie) cible.blur();
      return;
    }
    if (saisie || !item || !item.personne.cible || c.panneau) return;
    const k = e.key.toLowerCase();
    const r = RESULTATS.find((x) => x.touche === k);
    if (r) {
      e.preventDefault();
      choisirResultat(r.id);
    } else if (k === "a") {
      const bouton = racine.querySelector(".numero__appeler");
      if (bouton) {
        e.preventDefault();
        bouton.click();
      }
    } else if (k === "s" && !item.direct) {
      e.preventDefault();
      passerCarte();
    } else if (k === "n") {
      e.preventDefault();
      refs.notes?.focus();
    }
  }

  function tic() {
    ticks++;
    if (refs.chrono && item) refs.chrono.textContent = chronoTexte(secondesEcoulees(carte(item.cle)));
    if (ticks % 20 === 0) majHoraire();
  }

  // Les noms et les scripts des listes ne viennent pas avec les fiches : on les lit une fois si un appel de la file en dépend.
  if (etat.collections.taches.some((t) => t.type === "appel" && t.statut !== "fait" && t.liste_id)) chargerListes().catch(() => {});
  dessiner();
  minuteur = setInterval(tic, 1000);
  document.addEventListener("keydown", surTouche);
  offSession = surChangement(() => {
    // Un résultat envoyé ou un compteur du jour qui change : seul le bandeau a besoin d'être refait.
    if (item || refs.bandeau) majBandeau(item && !s.direct ? fileDeSeance() : null);
  });

  return {
    titre: "Appel en cours",
    noeud: racine,
    miseAJour() {
      const avant = item?.cle || null;
      const { it, file } = trouver();
      if ((it?.cle || null) !== avant || !it) {
        if (avant && !it && !s.direct) toast("Cette personne vient de quitter la file.", { ton: "info", duree: 3000 });
        dessiner();
        return true;
      }
      item = it;
      if (signatureDe(it) !== signature) {
        const actif = document.activeElement;
        const enNotes = actif === refs.notes ? { debut: actif.selectionStart, fin: actif.selectionEnd } : null;
        dessiner();
        if (enNotes && refs.notes) {
          refs.notes.focus({ preventScroll: true });
          refs.notes.setSelectionRange(enNotes.debut, enNotes.fin);
        }
        return true;
      }
      majSuivants(file, it);
      majBandeau(file);
      return true;
    },
    detruire() {
      clearInterval(minuteur);
      document.removeEventListener("keydown", surTouche);
      offSession?.();
    },
  };
}
