// =============================================================================
// Une liste d'appels : où elle en est, qui reste à appeler, et pour chaque personne l'état et le dernier résultat. C'est ici qu'on
// puise des appels dans la liste, qu'on la met en pause, qu'on retire ses appels de la file ou qu'on exporte le suivi.
// =============================================================================
import { h, remplir, idUnique, anti_rebond, enregistrerFichier } from "../../noyau/dom.js";
import { icone } from "../../noyau/icones.js";
import { etat, maintenant } from "../../noyau/etat.js";
import { ErreurApi } from "../../noyau/api.js";
import { lienFiche } from "../../noyau/routeur.js";
import { versCsv } from "../../noyau/csv.js";
import { ilYa, normaliser, pluriel } from "../../commun/format.js";
import { partiesLocales } from "../../commun/dates.js";
import { resultatDe } from "../../commun/appels.js";
import { ETATS_LIGNE, RAISONS_EXCLU } from "../../commun/listes-appels.js";
import { avatar, btn, panneau, pastille, etatVide, avis, chargement, menuActions } from "../../ui/composants.js";
import { personneDe } from "../../noyau/acces-appels.js";
import { detailListe, appelsOuvertsDeListe } from "../../noyau/listes-appels.js";
import { commencer } from "./session.js";
import { ouvrirPuiser, ouvrirModifier, changerStatut, retirerLesAppels, supprimerAvecConfirmation } from "./liste-actions.js";
import { barreProgres, dateDeCreation, pastilleStatut } from "./listes.js";

const PAGE = 80;
const FILTRES = [{ id: "tous", libelle: "Toutes" }, ...ETATS_LIGNE.map((e) => ({ id: e.id, libelle: { a_appeler: "À appeler", file: "Dans la file", appele: "Appelées", exclu: "Exclues" }[e.id] }))];
const TON_ETAT = { a_appeler: "info", file: "attention", appele: "ok", exclu: "erreur" };

/** « Jeanne Roy — Acme » : les mots à chercher pour retrouver une ligne. */
const texteDeLigne = (p) => normaliser([p.nom, p.entreprise?.nom, p.fonction, ...(p.numeros || []).map((n) => n.affiche)].filter(Boolean).join(" "));

function slug(texte) {
  return normaliser(texte).replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 40) || "liste";
}

/** « 2026-10-21 14:05 » à l’heure de Montréal (le serveur garde l’instant en UTC). */
function heureLocale(iso) {
  const ms = Date.parse(iso);
  if (!Number.isFinite(ms)) return "";
  const p = partiesLocales(ms);
  return `${p.date} ${p.heure}`;
}

export function monterListe(ctx) {
  const id = ctx.params.liste;
  const memo = ctx.memoire;
  const cleMemo = `liste:${id}`;
  const st = memo.get(cleMemo) || { filtre: "tous", q: "", limite: PAGE };
  memo.set(cleMemo, st);
  const peutEcrire = etat.droits.ecrire;
  const zone = h("div.pile");
  let donnees = null; // { liste, lignes }
  let echec = null;
  let dernierChargement = 0;
  let detruit = false;
  let sansListe = false;

  function charger() {
    dernierChargement = Date.now();
    return detailListe(id)
      .then((r) => {
        donnees = r;
        echec = null;
        sansListe = false;
      })
      .catch((e) => {
        if (e instanceof ErreurApi && e.statut === 404) sansListe = true;
        else echec = e;
      })
      .finally(() => {
        if (!detruit) remplirZone();
      });
  }

  /** Les lignes avec la personne correspondante (nom, entreprise, numéros), d'après les fiches du navigateur. */
  function lignesAvecPersonne() {
    return donnees.lignes.map((l) => ({ l, p: personneDe(l.t, l.id) }));
  }

  function exporter() {
    const { liste } = donnees;
    const colonnes = [
      { titre: "Nom", valeur: (x) => x.p.nom },
      { titre: "Entreprise", valeur: (x) => (x.l.t === "entreprises" ? "" : x.p.entreprise?.nom || "") },
      { titre: "Téléphone", valeur: (x) => x.p.numeros?.[0]?.affiche || "" },
      { titre: "État", valeur: (x) => ETATS_LIGNE.find((e) => e.id === x.l.etat)?.libelle || "" },
      { titre: "Raison de l’exclusion", valeur: (x) => (x.l.raison ? RAISONS_EXCLU[x.l.raison] || "" : "") },
      { titre: "Dernier résultat", valeur: (x) => (x.l.resultat ? resultatDe(x.l.resultat)?.court || "" : "") },
      { titre: "Dernier appel", valeur: (x) => (x.l.appele_le ? heureLocale(x.l.appele_le) : "") },
      { titre: "Appels depuis l’importation", valeur: (x) => x.l.appels || 0 },
    ];
    enregistrerFichier(`suivi-${slug(liste.nom)}.csv`, versCsv(colonnes, lignesAvecPersonne()), "text/csv;charset=utf-8");
  }

  function actions(liste) {
    const c = liste.compteurs;
    const nFile = appelsOuvertsDeListe(liste.id);
    const apres = () => charger();
    const el = [
      peutEcrire ? { libelle: "Modifier le nom, la description ou le script", icone: "modifier", onclick: () => ouvrirModifier(liste).then((m) => m && apres()) } : null,
      peutEcrire && liste.statut === "active" ? { libelle: "Mettre en pause", icone: "sablier", onclick: () => changerStatut(liste, "pausee").then(apres) } : null,
      peutEcrire && liste.statut !== "active" ? { libelle: liste.statut === "pausee" ? "Reprendre la liste" : "Remettre en service", icone: "lecture", onclick: () => changerStatut(liste, "active").then(apres) } : null,
      peutEcrire && liste.statut !== "archivee" ? { libelle: "Archiver", icone: "archiver", onclick: () => changerStatut(liste, "archivee").then(apres) } : null,
      peutEcrire && nFile > 0 ? { libelle: `Retirer de la file (${nFile})`, icone: "fermer", onclick: () => retirerLesAppels(liste).then(apres) } : null,
      { libelle: "Exporter le suivi (CSV)", icone: "telecharger", onclick: exporter },
      peutEcrire ? "separateur" : null,
      peutEcrire ? { libelle: "Supprimer la liste", icone: "corbeille", danger: true, onclick: () => supprimerAvecConfirmation(liste) } : null,
    ].filter(Boolean);
    const peutPuiser = peutEcrire && liste.statut === "active" && c.a_appeler > 0;
    return h(
      "div.liste-detail__actions",
      peutPuiser ? btn("Ajouter des appels à la file", { ton: "primaire", icone: "ajout-liste", onclick: () => ouvrirPuiser(liste).then((n) => n && apres()) }) : null,
      peutEcrire && nFile > 0 ? btn("Commencer les appels", { icone: "lecture", onclick: () => commencer(null) }) : null,
      menuActions({ aria: "Plus d’actions pour cette liste", fixe: true, elements: el })
    );
  }

  function entete(liste) {
    const scripts = etat.config.appels.scripts || [];
    const script = scripts.find((s) => s.id === liste.script_id);
    const meta = [`Importée le ${dateDeCreation(liste)}`, liste.fichier || null, script ? `Script : ${script.nom}` : null].filter(Boolean).join(" · ");
    return h(
      "header.liste-detail__tete",
      h("a.retour", { href: "#/appels/listes" }, icone("retour", "ic--p"), "Toutes les listes"),
      h("div.liste-detail__titre", h("h2", liste.nom), pastilleStatut(liste)),
      liste.description ? h("p.liste-detail__description", liste.description) : null,
      h("p.muet.petit", meta)
    );
  }

  function bilan(liste) {
    const c = liste.compteurs;
    const items = [["À appeler", c.a_appeler], ["Dans la file", c.file], ["Appelées", c.appeles], ["Jointes", c.joints], ["Rendez-vous", c.rdv]];
    const resultats = Object.entries(c.par_resultat || {})
      .map(([r, n]) => ({ r: resultatDe(r), n }))
      .filter((x) => x.r)
      .sort((a, b) => b.n - a.n);
    return h(
      "section.panneau.panneau--accent.liste-bilan",
      { "aria-label": "Avancement de la liste" },
      h("dl.liste-bilan__chiffres", items.map(([lib, n]) => h("div.liste-bilan__item", h("dt.liste-bilan__libelle", lib), h("dd.liste-bilan__nombre.tnum", String(n))))),
      barreProgres(c),
      h("p.muet.petit", `${pluriel(c.appeles, "personne appelée", "personnes appelées")} sur ${c.total}.${c.exclu ? ` ${pluriel(c.exclu, "personne a été exclue", "personnes ont été exclues")} de la liste depuis l’importation (« ne pas appeler », fiche supprimée, numéro retiré…).` : ""}`),
      resultats.length ? h("ul.liste-resultats", resultats.map(({ r, n }) => h("li", pastille(`${r.court} · ${n}`, r.ton === "ok" ? "ok" : r.ton === "erreur" ? "erreur" : r.ton === "attention" ? "attention" : "info")))) : null
    );
  }

  function ligne(x, liste) {
    const { l, p } = x;
    const cible = p.cible || { entite: l.t, id: l.id };
    const sous = [p.fonction, l.t === "contacts" ? p.entreprise?.nom : null].filter(Boolean).join(" · ");
    const tel = p.numeros?.[0];
    let marque;
    if (l.etat === "exclu") marque = pastille(RAISONS_EXCLU[l.raison] || "Exclu", "erreur");
    else if (l.etat === "file") marque = pastille(l.essai > 1 ? `Dans la file · essai ${l.essai}` : "Dans la file", "attention");
    else marque = pastille(ETATS_LIGNE.find((e) => e.id === l.etat).libelle, TON_ETAT[l.etat]);
    const dernier = l.resultat ? resultatDe(l.resultat) : null;
    return h(
      "li.liste-ligne",
      avatar(p.nom || "?"),
      h(
        "div.liste-ligne__texte",
        p.cible ? h("a.liste-ligne__nom", { href: lienFiche(cible.entite, cible.id), title: "Ouvrir la fiche" }, p.nom || "Fiche sans nom") : h("span.liste-ligne__nom.muet", "(fiche supprimée ou introuvable)"),
        sous ? h("small.muet", sous) : null
      ),
      h("div.liste-ligne__tel", tel ? h("span.tnum", tel.affiche) : h("span.muet", "—")),
      h("div.liste-ligne__etat", marque),
      h(
        "div.liste-ligne__dernier",
        { class: { "liste-ligne__dernier--vide": !dernier } },
        dernier ? [h("span", dernier.court), h("small.muet", `${ilYa(Date.parse(l.appele_le), maintenant())}${l.appels > 1 ? ` · ${l.appels} appels` : ""}`)] : h("span.muet", "—")
      ),
      h(
        "div.liste-ligne__action",
        peutEcrire && l.etat === "a_appeler" && liste.statut === "active"
          ? btn("Ajouter", { petit: true, icone: "ajout-liste", aria: `Ajouter ${p.nom || "cette personne"} à la file d’appels`, onclick: () => ouvrirPuiser(liste, { cibles: [{ entite: l.t, id: l.id }] }).then((n) => n && charger()) })
          : null
      )
    );
  }

  function lignes(liste) {
    const c = liste.compteurs;
    const nombreDe = { tous: c.total, a_appeler: c.a_appeler, file: c.file, appele: c.appele, exclu: c.exclu };
    const idRech = idUnique("liste-rech");
    const recherche = h("input.saisie", { id: idRech, type: "search", placeholder: "Nom, entreprise ou numéro", autocomplete: "off", spellcheck: "false", "aria-label": "Rechercher dans la liste", "data-focus-id": "liste-recherche" });
    recherche.value = st.q;
    const corps = h("ul.registre-liste.liste-lignes");
    const pied = h("div.ajout__pied");
    const compteur = h("p.muet.petit", { role: "status", "aria-live": "polite" });
    const toutes = lignesAvecPersonne().map((x) => ({ ...x, texte: texteDeLigne(x.p) }));

    function dessiner() {
      const jetons = normaliser(st.q).split(/\s+/).filter(Boolean);
      let rangees = toutes.filter((x) => st.filtre === "tous" || x.l.etat === st.filtre);
      if (jetons.length) rangees = rangees.filter((x) => jetons.every((j) => x.texte.includes(j)));
      const visibles = rangees.slice(0, st.limite);
      if (!rangees.length) {
        corps.replaceChildren(h("li", etatVide({ icone: "recherche", titre: jetons.length ? "Personne ne correspond" : "Rien à montrer ici", texte: jetons.length ? "Essayez d’autres mots." : "Aucune personne de la liste n’est dans cet état." })));
      } else corps.replaceChildren(...visibles.map((x) => ligne(x, liste)));
      compteur.textContent = rangees.length > visibles.length ? `${visibles.length} personnes affichées sur ${rangees.length}.` : pluriel(rangees.length, "personne", "personnes") + ".";
      pied.replaceChildren(rangees.length > visibles.length ? btn("Afficher plus", { petit: true, onclick: () => ((st.limite += PAGE), dessiner()) }) : "");
    }
    recherche.addEventListener(
      "input",
      anti_rebond(() => {
        st.q = recherche.value;
        st.limite = PAGE;
        dessiner();
      }, 120)
    );
    const commut = h(
      "div.commutateur.commutateur--filtres",
      { role: "group", "aria-label": "Filtrer les personnes de la liste" },
      FILTRES.map((f) =>
        h("button.commutateur__bouton", { type: "button", "aria-pressed": String(st.filtre === f.id), onclick: () => ((st.filtre = f.id), (st.limite = PAGE), remplirZone()) }, h("span", f.libelle), h("span.commutateur__nombre", String(nombreDe[f.id] ?? 0)))
      )
    );
    dessiner();
    return panneau(
      { titre: "Personnes de la liste", niveau: 3, classe: "panneau--liste" },
      h("div.liste-detail__outils", commut, h("div.ajout__recherche", h("label.sr-only", { for: idRech }, "Rechercher dans la liste"), recherche)),
      corps,
      h("div.liste-detail__pied", compteur, pied)
    );
  }

  function remplirZone() {
    if (detruit) return;
    // Une actualisation (synchronisation, relecture des chiffres) ne doit pas faire perdre la main à qui est en train de chercher.
    const actif = document.activeElement;
    const garder = actif instanceof HTMLInputElement && actif.dataset.focusId === "liste-recherche" ? { debut: actif.selectionStart, fin: actif.selectionEnd } : null;
    dessinerZone();
    if (garder) {
      const champ = zone.querySelector('[data-focus-id="liste-recherche"]');
      champ?.focus({ preventScroll: true });
      try {
        champ?.setSelectionRange(garder.debut, garder.fin);
      } catch {
        /* champ sans sélection */
      }
    }
  }

  function dessinerZone() {
    if (sansListe) {
      remplir(zone, etatVide({ icone: "liste", titre: "Cette liste n’existe plus", texte: "Elle a été supprimée, ou l’adresse est périmée.", action: btn("Voir les listes", { ton: "primaire", href: "#/appels/listes" }) }));
      return;
    }
    if (!donnees) {
      remplir(
        zone,
        h("a.retour", { href: "#/appels/listes" }, icone("retour", "ic--p"), "Toutes les listes"),
        echec
          ? avis({ ton: "erreur", titre: "La liste n’a pas pu être lue", texte: echec.message, actions: btn("Réessayer", { petit: true, onclick: () => ((echec = null), remplirZone(), charger()) }) })
          : chargement("Chargement de la liste…")
      );
      return;
    }
    const liste = donnees.liste;
    remplir(
      zone,
      entete(liste),
      actions(liste),
      liste.statut === "pausee" ? avis({ ton: "attention", titre: "Cette liste est en pause", texte: "On ne peut pas y puiser de nouveaux appels pour l’instant. Les appels déjà dans la file restent à faire." }) : null,
      liste.statut === "archivee" ? avis({ ton: "info", titre: "Cette liste est archivée", texte: "Remettez-la en service pour y puiser de nouveaux appels." }) : null,
      echec ? avis({ ton: "erreur", titre: "La liste n’a pas pu être actualisée", texte: echec.message }) : null,
      bilan(liste),
      lignes(liste)
    );
  }

  remplirZone();
  charger();

  return {
    noeud: zone,
    miseAJour(changes) {
      if (donnees) remplirZone();
      if (changes.has("taches") && Date.now() - dernierChargement > 5000) charger();
      return true;
    },
    detruire() {
      detruit = true;
    },
  };
}
