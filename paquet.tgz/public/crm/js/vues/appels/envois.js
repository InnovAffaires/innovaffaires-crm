// =============================================================================
// Bandeau des appels qui n'ont pas encore pu être enregistrés (connexion coupée,
// erreur du serveur). Un appel consigné n'est jamais perdu en silence : on le voit
// ici, on peut le renvoyer, copier ses notes ou y renoncer.
// =============================================================================
import { h, remplir, copierTexte } from "../../noyau/dom.js";
import { pluriel } from "../../commun/format.js";
import { resultatDe } from "../../commun/appels.js";
import { avis, btn, pastille } from "../../ui/composants.js";
import { ouvrirDialogue, confirmer } from "../../ui/dialogue.js";
import { toast } from "../../ui/toast.js";
import { surChangement, envoisEnAttente, envoisEnEchec, reessayerEnvois, abandonnerEnvoi } from "./session.js";

function ouvrirDetails() {
  ouvrirDialogue({
    titre: "Appels non enregistrés",
    taille: "moyen",
    contenu: (ctx) => {
      const zone = h("div.pile");
      const dessiner = () => {
        const echecs = envoisEnEchec();
        if (!echecs.length) {
          ctx.fermer();
          return;
        }
        remplir(
          zone,
          h("p", "Ces appels ont bien eu lieu, mais le CRM n’a pas réussi à les enregistrer. Rien n’est perdu tant que cette page reste ouverte : vous pouvez réessayer, ou copier vos notes pour les coller sur la fiche."),
          h(
            "ul.envois__liste",
            echecs.map((e) => {
              const r = resultatDe(e.resultat);
              return h(
                "li.envois__item",
                h("div.envois__tete", h("strong", e.nom || "Appel"), r ? pastille(r.court, r.ton, { icone: r.icone }) : null),
                h("p.envois__erreur", e.erreur || "Erreur inconnue."),
                e.notes ? h("blockquote.envois__notes", e.notes) : null,
                h(
                  "div.actions-ligne",
                  e.notes
                    ? btn("Copier les notes", {
                        petit: true, icone: "copier",
                        onclick: async () => toast((await copierTexte(e.notes)) ? "Notes copiées." : "La copie a échoué : sélectionnez le texte à la main.", { ton: "info", duree: 2500 }),
                      })
                    : null,
                  btn("Renoncer à cet appel", {
                    petit: true, ton: "danger", icone: "corbeille",
                    onclick: async () => {
                      const ok = await confirmer({ titre: "Renoncer à cet appel ?", message: "L’appel ne sera pas ajouté à l’historique de la fiche et la tâche d’appel restera à faire.", libelleConfirmer: "Renoncer", danger: true });
                      if (!ok) return;
                      abandonnerEnvoi(e.id);
                      dessiner();
                    },
                  })
                )
              );
            })
          )
        );
      };
      dessiner();
      ctx.definirPied(
        btn("Fermer", { onclick: () => ctx.fermer() }),
        btn("Réessayer maintenant", { ton: "primaire", icone: "rafraichir", onclick: () => (reessayerEnvois(), ctx.fermer()) })
      );
      return zone;
    },
  });
}

/** Bandeau à placer en haut des écrans d'appels. Retourne { noeud, detruire }. */
export function bandeauEnvois() {
  const zone = h("div.appel__envois");
  function dessiner() {
    // Un envoi qui n'a pas encore échoué une fois est en route : inutile d'en parler. Au-delà, la connexion est en cause.
    const reprises = envoisEnAttente().filter((e) => e.tentatives > 0);
    const echecs = envoisEnEchec();
    remplir(
      zone,
      reprises.length
        ? avis({
            ton: "attention",
            titre: `${pluriel(reprises.length, "appel attend", "appels attendent")} d’être enregistré${reprises.length > 1 ? "s" : ""}`,
            texte: "La connexion semble instable. Le CRM réessaie tout seul : gardez cette page ouverte.",
          })
        : null,
      echecs.length
        ? avis({
            ton: "erreur",
            titre: `${pluriel(echecs.length, "appel n’a pas pu être enregistré", "appels n’ont pas pu être enregistrés")}`,
            texte: echecs[0].erreur || "Erreur inconnue.",
            actions: [btn("Réessayer", { petit: true, icone: "rafraichir", onclick: reessayerEnvois }), btn("Détails", { petit: true, onclick: ouvrirDetails })],
          })
        : null
    );
  }
  dessiner();
  return { noeud: zone, detruire: surChangement(dessiner) };
}

