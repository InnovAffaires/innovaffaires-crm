// =============================================================================
// Importer une liste d'appels : choisir le fichier (Excel ou CSV) ou coller des lignes, associer les colonnes, vérifier ce qui entrera
// dans la liste, puis importer. Le navigateur lit le fichier; le serveur nettoie chaque ligne, écarte les doublons et les personnes à ne
// pas appeler, et ne crée rien tant qu'on n'a pas confirmé (la vérification se fait à blanc).
// =============================================================================
import { h, remplir, idUnique, enregistrerFichier } from "../../noyau/dom.js";
import { icone } from "../../noyau/icones.js";
import { etat, maintenant } from "../../noyau/etat.js";
import { ErreurApi } from "../../noyau/api.js";
import { synchroniser } from "../../noyau/synchro.js";
import { lireCsv, versCsv } from "../../noyau/csv.js";
import { lireXlsx, ErreurXlsx, TAILLE_MAX_XLSX, ressembleAXlsx, ressembleAAncienExcel } from "../../noyau/xlsx.js";
import { importerListe, chargerListes } from "../../noyau/listes-appels.js";
import { dateComplete, pluriel } from "../../commun/format.js";
import { aujourdhui } from "../../commun/dates.js";
import {
  MAX_LIGNES_LISTE, MAX_NOM_LISTE, MAX_DESCRIPTION_LISTE, MAX_COLONNES_EXTRA, CHAMPS_LISTE, RAISONS_IGNOREES, deviner, estChampListe,
} from "../../commun/listes-appels.js";
import { btn, panneau, avis } from "../../ui/composants.js";
import { confirmer } from "../../ui/dialogue.js";
import { ouvrirPuiser } from "./liste-actions.js";

const TAILLE_MAX_TEXTE = 3_000_000;
const MAX_COLONNES = 60;
const TAILLE_MAX_ENVOI = 2_900_000;
const CHAMPS_NOM = ["entreprise", "nom_complet", "nom_prenom", "prenom", "nom", "courriel"];
const CHAMPS_TEL = ["telephone", "mobile", "telephone_entreprise"];
const MODELE = {
  entetes: ["Entreprise", "Prénom", "Nom", "Fonction", "Téléphone", "Courriel", "Ville"],
  lignes: [
    ["Gestion Boréal inc.", "Marie", "Tremblay", "Directrice", "514 555-0101", "marie@exemple.ca", "Montréal"],
    ["Atelier Lumière", "Luc", "Roy", "Propriétaire", "450 555-0102", "", "Laval"],
  ],
};

/** « seront ajoutés » / « sera ajoutée » : des contacts (ou des contacts et des entreprises) au masculin, des entreprises seules au féminin. */
function accordAjoute(rap) {
  const n = (rap.contacts_crees || 0) + (rap.entreprises_creees || 0);
  const f = !rap.contacts_crees && rap.entreprises_creees > 0 ? "e" : "";
  return n > 1 ? `seront ajouté${f}s` : `sera ajouté${f}`;
}

/** « Déjà dans votre CRM » → « déjà dans votre CRM » : seule la première lettre passe en minuscule (les sigles restent intacts). */
const minusculeInitiale = (texte) => (texte ? texte.charAt(0).toLowerCase() + texte.slice(1) : "");

function cleOperation() {
  const octets = crypto.getRandomValues(new Uint8Array(12));
  return [...octets].map((o) => o.toString(16).padStart(2, "0")).join("");
}

/** Lit un fichier texte : UTF-8, sinon Windows-1252 (l'enregistrement habituel d'Excel en français). */
function decoder(octets) {
  try {
    return new TextDecoder("utf-8", { fatal: true }).decode(octets);
  } catch {
    return new TextDecoder("windows-1252").decode(octets);
  }
}

/** Lit un fichier choisi : { entetes, lignes, numeros }. Lance une Error dont le message est lisible tel quel. */
async function lireFichier(fichier) {
  const nom = fichier.name || "";
  const octets = await fichier.arrayBuffer();
  if (/\.xls[xm]?$/i.test(nom) || ressembleAXlsx(octets) || ressembleAAncienExcel(octets)) {
    if (octets.byteLength > TAILLE_MAX_XLSX) throw new Error("Ce classeur est trop volumineux (3 Mo au plus). Découpez-le en plusieurs fichiers.");
    return lireXlsx(octets);
  }
  if (octets.byteLength > TAILLE_MAX_TEXTE) throw new Error("Ce fichier est trop volumineux (3 Mo au plus). Découpez-le en plusieurs fichiers.");
  if (new Uint8Array(octets, 0, Math.min(octets.byteLength, 4096)).includes(0)) throw new Error("Ce fichier n’est pas un fichier texte ni un classeur Excel (.xlsx). Enregistrez-le au format CSV, puis réessayez.");
  return lireCsv(decoder(octets));
}

function nomParDefaut(nomFichier) {
  const base = String(nomFichier || "").replace(/\.[a-z0-9]{2,5}$/i, "").replace(/[_\-.]+/g, " ").replace(/\s+/g, " ").trim();
  if (base) return (base[0].toUpperCase() + base.slice(1)).slice(0, MAX_NOM_LISTE).trim();
  return `Liste du ${dateComplete(aujourdhui(maintenant()))}`.slice(0, MAX_NOM_LISTE);
}

export function monterImportListe() {
  const racine = h("div.pile.pile--l");
  if (!etat.droits.ecrire) {
    racine.append(avis({ ton: "info", titre: "Accès en lecture seule", texte: "Vous pouvez consulter les listes d’appels, mais pas en importer. Demandez un accès en modification à l’administrateur.", actions: btn("Voir les listes", { petit: true, href: "#/appels/listes" }) }));
    return { noeud: racine, miseAJour: () => true };
  }
  chargerListes().catch(() => {});

  const st = {
    mode: "fichier", nomFichier: "", entetes: [], lignes: [], numeros: [], cibles: [],
    nom: "", description: "", scriptId: "", inclure: false, cle: null, simulation: null,
  };
  let dejaAffiche = false;
  const montrerEtape = () => {
    if (dejaAffiche) racine.scrollIntoView({ block: "start" });
    dejaAffiche = true;
  };

  // ----- Étape 1 : la source ---------------------------------------------------------------------------------------------------
  function ouvrirLecture(lecture, nomFichier, alerte) {
    const refuser = (m) => {
      alerte.hidden = false;
      alerte.textContent = m;
    };
    return lecture.then(
      (csv) => {
        if (!csv.entetes.length || !csv.lignes.length) return refuser("Il n’y a aucune ligne de données : la première ligne doit porter le titre des colonnes, les suivantes les personnes à appeler.");
        if (csv.lignes.length > MAX_LIGNES_LISTE) return refuser(`Cette liste compte ${pluriel(csv.lignes.length, "ligne")} : importez ${pluriel(MAX_LIGNES_LISTE, "ligne")} au plus à la fois. Découpez-la en plusieurs fichiers.`);
        if (csv.entetes.length > MAX_COLONNES) return refuser(`Cette liste compte ${csv.entetes.length} colonnes : ${MAX_COLONNES} au plus. Retirez les colonnes inutiles, puis réessayez.`);
        st.nomFichier = nomFichier;
        st.entetes = csv.entetes;
        st.lignes = csv.lignes;
        st.numeros = csv.numeros || csv.lignes.map((_, i) => i + 2);
        st.cibles = deviner(csv.entetes, csv.lignes);
        st.nom = st.nom || nomParDefaut(nomFichier);
        st.simulation = null;
        st.cle = null;
        etapeAssociation();
      },
      (e) => refuser(e instanceof ErreurXlsx || e instanceof Error ? e.message : "Ce fichier n’a pas pu être lu. Enregistrez-le de nouveau au format CSV.")
    );
  }

  function etapeSource() {
    const alerte = h("div.formulaire__alerte", { role: "alert", hidden: true });
    const entree = h("input", { type: "file", accept: ".xlsx,.xlsm,.csv,.txt,.tsv,text/csv,text/plain,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", hidden: true, "aria-hidden": "true", tabindex: "-1" });
    const choisir = (fichier) => {
      alerte.hidden = true;
      if (!fichier) return;
      st.nom = "";
      ouvrirLecture(lireFichier(fichier), fichier.name, alerte);
    };
    entree.addEventListener("change", () => {
      const fichier = entree.files?.[0];
      entree.value = "";
      choisir(fichier);
    });

    const depot = h("div.depot", { "data-actif": "false" });
    for (const evt of ["dragenter", "dragover"]) {
      depot.addEventListener(evt, (e) => {
        e.preventDefault();
        depot.dataset.actif = "true";
      });
    }
    for (const evt of ["dragleave", "dragend"]) depot.addEventListener(evt, () => (depot.dataset.actif = "false"));
    depot.addEventListener("drop", (e) => {
      e.preventDefault();
      depot.dataset.actif = "false";
      choisir(e.dataTransfer?.files?.[0]);
    });
    depot.append(
      icone("televerser", "ic--g"),
      h("p.depot__texte", "Déposez ici votre fichier Excel (.xlsx) ou CSV"),
      h("p.muet.petit", "ou"),
      btn("Choisir un fichier…", { ton: "primaire", icone: "fichier-haut", onclick: () => entree.click() }),
      entree
    );

    const idColler = idUnique("coller");
    const zoneColler = h("textarea.saisie.saisie--long.coller", { id: idColler, rows: 9, spellcheck: "false", autocomplete: "off", placeholder: "Collez ici les lignes copiées depuis Excel ou Google Sheets, titres de colonnes compris." });
    const suite = btn("Continuer", {
      ton: "primaire", icone: "suivant",
      onclick: () => {
        alerte.hidden = true;
        st.nom = "";
        ouvrirLecture(Promise.resolve().then(() => lireCsv(zoneColler.value)), "", alerte);
      },
    });

    const commut = h(
      "div.commutateur",
      { role: "group", "aria-label": "Source de la liste" },
      h("button.commutateur__bouton", { type: "button", "aria-pressed": String(st.mode === "fichier"), onclick: () => ((st.mode = "fichier"), etapeSource()) }, h("span", "Un fichier")),
      h("button.commutateur__bouton", { type: "button", "aria-pressed": String(st.mode === "coller"), onclick: () => ((st.mode = "coller"), etapeSource()) }, h("span", "Copier-coller"))
    );

    montrerEtape();
    racine.replaceChildren(
      panneau(
        { titre: "Choisir la liste à importer", sous: "Un fichier Excel ou CSV, ou des lignes copiées depuis un tableur.", niveau: 3 },
        h(
          "div.pile",
          commut,
          alerte,
          st.mode === "fichier" ? depot : h("div.pile.pile--s", h("label.champ__etiquette", { for: idColler }, "Lignes à importer"), zoneColler, h("div.actions-ligne", suite)),
          h(
            "ul.liste-simple",
            h("li", "La première ligne porte le titre des colonnes (Entreprise, Prénom, Nom, Téléphone…). À l’étape suivante, vous vérifiez ce que contient chaque colonne."),
            h("li", `Jusqu’à ${pluriel(MAX_LIGNES_LISTE, "ligne")} par liste. Les numéros écrits de plusieurs façons sont reconnus, et un second numéro dans la même cellule est gardé.`),
            h("li", "Les doublons, les lignes sans numéro et les personnes de votre liste « ne pas appeler » sont écartés. Vous voyez le détail avant que la moindre fiche soit créée.")
          ),
          h("div.actions-ligne", btn("Télécharger un modèle de fichier", { petit: true, icone: "telecharger", onclick: () => enregistrerFichier("modele-liste-appels.csv", versCsv(MODELE.entetes.map((t, i) => ({ titre: t, valeur: (l) => l[i] })), MODELE.lignes), "text/csv;charset=utf-8") }))
        )
      ),
      avis({
        ton: "info", titre: "Avant de téléphoner",
        texte: "Le CRM ne consulte pas la Liste nationale de numéros de télécommunication exclus (LNNTE) : c’est à vous de vérifier que vous avez le droit d’appeler les numéros de la liste. Pendant les appels, la personne qui demande à ne plus être appelée est inscrite à votre liste « ne pas appeler » (résultat « Ne plus appeler »), et le CRM ne la propose plus.",
      })
    );
  }

  // ----- Étape 2 : associer les colonnes, vérifier ------------------------------------------------------------------------------------
  function etapeAssociation() {
    const zoneResultat = h("div.pile", { role: "status", "aria-live": "polite" });
    const alerte = h("div.formulaire__alerte", { role: "alert", hidden: true });
    const importerBtn = btn("Importer", { ton: "primaire", icone: "televerser", desactive: true });
    const verifier = btn("Vérifier la liste", { ton: "primaire", icone: "ok" });

    const invalider = () => {
      st.simulation = null;
      st.cle = null;
      importerBtn.disabled = true;
      importerBtn.querySelector("span").textContent = "Importer";
      zoneResultat.replaceChildren();
    };

    // La liste : nom, description, script, doublons avec le CRM.
    const idNom = idUnique("il-n");
    const idDesc = idUnique("il-d");
    const idScript = idUnique("il-s");
    const idInclure = idUnique("il-i");
    const nom = h("input.saisie", { id: idNom, type: "text", maxlength: MAX_NOM_LISTE, autocomplete: "off", spellcheck: "true", "aria-required": "true" });
    nom.value = st.nom;
    const erreurNom = h("p.champ__erreur", { role: "alert", hidden: true });
    nom.addEventListener("input", () => {
      st.nom = nom.value;
      erreurNom.hidden = true;
      invalider();
    });
    const description = h("textarea.saisie.saisie--long", { id: idDesc, rows: 2, maxlength: MAX_DESCRIPTION_LISTE, spellcheck: "true" });
    description.value = st.description;
    description.addEventListener("input", () => {
      st.description = description.value;
      invalider();
    });
    const scripts = etat.config.appels.scripts || [];
    const script = h("select.saisie", { id: idScript }, h("option", { value: "" }, "Selon la personne (script habituel)"), scripts.map((s) => h("option", { value: s.id }, s.nom)));
    script.value = scripts.some((s) => s.id === st.scriptId) ? st.scriptId : "";
    script.addEventListener("change", () => {
      st.scriptId = script.value;
      invalider();
    });
    const inclure = h("input", { id: idInclure, type: "checkbox" });
    inclure.checked = st.inclure;
    inclure.addEventListener("change", () => {
      st.inclure = inclure.checked;
      invalider();
    });

    // Les colonnes.
    const options = [
      h("option", { value: "ignorer" }, "Ne pas importer"),
      h("option", { value: "extra" }, "Ajouter aux notes de la fiche"),
      CHAMPS_LISTE.map((c) => h("option", { value: c.id }, c.libelle)),
    ];
    const lignesMappage = st.entetes.map((entete, i) => {
      const exemples = st.lignes.map((l) => String(l[i] ?? "").trim()).filter(Boolean).slice(0, 2);
      const sel = h("select.saisie", { "aria-label": `Information contenue dans la colonne « ${entete || `colonne ${i + 1}`} »` }, options.map((o) => (Array.isArray(o) ? o.map((x) => x.cloneNode(true)) : o.cloneNode(true))));
      sel.value = st.cibles[i] || "ignorer";
      sel.addEventListener("change", () => {
        st.cibles[i] = sel.value;
        alerte.hidden = true;
        invalider();
      });
      return h(
        "li.mappage__ligne",
        h("div.mappage__source", h("strong", entete || `Colonne ${i + 1}`), exemples.length ? h("span.muet", exemples.join(" · ")) : h("span.muet", "(vide)")),
        icone("suivant", "ic--p mappage__fleche"),
        h("div.saisie-select", sel, icone("bas", "ic--p"))
      );
    });

    function construireLignes() {
      const parChamp = new Map();
      const extras = [];
      st.cibles.forEach((c, i) => {
        if (c === "extra") extras.push({ i, etiquette: (st.entetes[i] || `Colonne ${i + 1}`).slice(0, 60) });
        else if (estChampListe(c)) parChamp.set(c, i);
      });
      return st.lignes.map((l, k) => {
        const o = { ligne: st.numeros[k] ?? k + 2 };
        for (const [champ, i] of parChamp) {
          const v = String(l[i] ?? "").trim();
          if (v) o[champ] = v.slice(0, 1000);
        }
        const ex = [];
        for (const e of extras) {
          const v = String(l[e.i] ?? "").trim();
          if (v) ex.push({ etiquette: e.etiquette, valeur: v.slice(0, 500) });
        }
        if (ex.length) o.extras = ex;
        return o;
      });
    }

    /** Contrôle l'association avant tout envoi ; retourne un message, ou null si tout va bien. */
    function controler() {
      const utilises = st.cibles.filter(estChampListe);
      const doublon = utilises.find((c, i) => utilises.indexOf(c) !== i);
      if (doublon) return `L’information « ${CHAMPS_LISTE.find((c) => c.id === doublon).libelle} » est associée à deux colonnes. Choisissez-en une seule.`;
      if (!CHAMPS_NOM.some((c) => utilises.includes(c))) return "Associez au moins une colonne au nom de la personne ou de l’entreprise.";
      if (!CHAMPS_TEL.some((c) => utilises.includes(c))) return "Associez au moins une colonne à un numéro de téléphone : sans numéro, on ne peut pas appeler.";
      if (st.cibles.filter((c) => c === "extra").length > MAX_COLONNES_EXTRA) return `Au plus ${MAX_COLONNES_EXTRA} colonnes peuvent être ajoutées aux notes. Choisissez « Ne pas importer » pour les autres.`;
      if (!st.nom.trim()) {
        erreurNom.hidden = false;
        erreurNom.textContent = "Donnez un nom à la liste.";
        nom.focus();
        return "Donnez un nom à la liste.";
      }
      return null;
    }

    function corps(simuler) {
      st.cle ||= cleOperation();
      return {
        cle: st.cle, simuler, nom: st.nom.trim(), description: st.description.trim(), script_id: st.scriptId, fichier: st.nomFichier,
        inclure_existants: st.inclure, lignes: construireLignes(),
      };
    }

    function afficherSimulation(r) {
      const rap = r.rapport;
      const ignorees = Object.entries(rap.ignorees || {}).filter(([, n]) => n > 0);
      const nIgnorees = ignorees.reduce((s, [, n]) => s + n, 0);
      const fiches = [rap.contacts_crees ? pluriel(rap.contacts_crees, "contact", "contacts") : null, rap.entreprises_creees ? pluriel(rap.entreprises_creees, "entreprise", "entreprises") : null].filter(Boolean);
      const retires = [rap.retires?.courriel ? pluriel(rap.retires.courriel, "courriel invalide", "courriels invalides") : null, rap.retires?.site_web ? pluriel(rap.retires.site_web, "site Web invalide", "sites Web invalides") : null, rap.retires?.neq ? pluriel(rap.retires.neq, "NEQ invalide", "NEQ invalides") : null].filter(Boolean);
      const ligne = (x) => h("li", h("strong", `Ligne ${x.ligne}`), ` — ${RAISONS_IGNOREES[x.raison] || x.raison}`, x.detail ? h("span.muet", ` (${x.detail})`) : null);
      const aff = (r.lignes_ignorees || []).slice(0, 40);
      remplir(
        zoneResultat,
        avis({
          ton: rap.dans_la_liste ? (nIgnorees ? "attention" : "ok") : "erreur",
          titre: rap.dans_la_liste ? `${pluriel(rap.dans_la_liste, "ligne entrera", "lignes entreront")} dans la liste` : "Aucune ligne n’entrera dans la liste",
          texte: `${pluriel(rap.lus, "ligne lue", "lignes lues")}${nIgnorees ? `, ${pluriel(nIgnorees, "ignorée", "ignorées")}` : ""}.`,
        }),
        h(
          "ul.liste-simple",
          fiches.length ? h("li", `Le CRM créera ${fiches.join(" et ")}, avec la provenance « Liste de prospection » et l’étiquette « ${st.nom.trim()} ».`) : null,
          rap.existants_inclus ? h("li", `${pluriel(rap.existants_inclus, "personne déjà dans le CRM est ajoutée", "personnes déjà dans le CRM sont ajoutées")} à la liste, sans que sa fiche soit modifiée.`) : null,
          ...ignorees.map(([raison, n]) => h("li", `${pluriel(n, "ligne", "lignes")} : ${minusculeInitiale(RAISONS_IGNOREES[raison] || raison)}.`)),
          retires.length ? h("li", `Laissés de côté, sans refuser la ligne : ${retires.join(", ")}.`) : null,
          rap.numeros_incomplets ? h("li", `${pluriel(rap.numeros_incomplets, "numéro", "numéros")} sans indicatif régional (moins de 10 chiffres) non retenu${rap.numeros_incomplets > 1 ? "s" : ""}.`) : null
        ),
        r.apercu?.length
          ? h(
              "div.pile.pile--s",
              h("p", h("strong", "Aperçu des premières lignes")),
              h(
                "div.registre-conteneur",
                h(
                  "table.registre.apercu-import",
                  h("thead", h("tr", h("th", { scope: "col" }, "Ligne"), h("th", { scope: "col" }, "Nom"), h("th", { scope: "col" }, "Entreprise"), h("th", { scope: "col" }, "Téléphone"))),
                  h("tbody", r.apercu.map((a) => h("tr", h("td.tnum", String(a.ligne)), h("td", a.nom || "—", a.existant ? h("small.muet", " (déjà dans le CRM)") : null), h("td", a.entreprise || "—"), h("td.tnum", a.telephone || "—"))))
                )
              )
            )
          : null,
        aff.length
          ? h(
              "details.replie",
              h("summary.replie__titre", icone("alerte", "ic--p"), h("span", "Lignes ignorées"), h("span.replie__compte.muet", String(r.lignes_ignorees.length)), icone("droite", "replie__fleche")),
              h("div.replie__corps", h("ul.liste-simple", aff.map(ligne)), r.lignes_ignorees.length > aff.length ? h("p.muet.petit", `… et ${pluriel(r.lignes_ignorees.length - aff.length, "autre ligne", "autres lignes")}. Corrigez le fichier et recommencez, ou importez le reste : les lignes ignorées ne sont simplement pas ajoutées.`) : h("p.muet.petit", "Corrigez le fichier et recommencez, ou importez le reste : les lignes ignorées ne sont simplement pas ajoutées."))
            )
          : null
      );
      importerBtn.disabled = !rap.dans_la_liste;
      importerBtn.querySelector("span").textContent = rap.dans_la_liste ? `Importer ${pluriel(rap.dans_la_liste, "ligne", "lignes")}` : "Importer";
    }

    function afficherErreur(e, titre) {
      if (e instanceof ErreurApi && e.code === "nom_pris") {
        erreurNom.hidden = false;
        erreurNom.textContent = e.champs?.nom || e.message;
        nom.focus();
        st.cle = null;
        zoneResultat.replaceChildren();
        return;
      }
      if (e instanceof ErreurApi && e.code === "liste_vide") {
        zoneResultat.replaceChildren(avis({ ton: "erreur", titre: "Aucune ligne n’a pu entrer dans la liste", texte: "Vérifiez l’association des colonnes (nom et téléphone) et le détail des lignes ignorées en cliquant sur « Vérifier la liste »." }));
        return;
      }
      if (e instanceof ErreurApi) {
        zoneResultat.replaceChildren(avis({ ton: "erreur", titre, texte: e.message }));
        return;
      }
      throw e;
    }

    /** Empêche d'envoyer un corps trop gros : le serveur le refuserait sans dire pourquoi. */
    function enverrable(c) {
      if (JSON.stringify(c).length <= TAILLE_MAX_ENVOI) return true;
      alerte.hidden = false;
      alerte.textContent = "Cette liste contient trop de texte pour être importée d’un coup. Retirez les colonnes inutiles (« Ne pas importer »), ou découpez le fichier en deux.";
      return false;
    }

    verifier.addEventListener("click", async () => {
      alerte.hidden = true;
      erreurNom.hidden = true;
      const probleme = controler();
      if (probleme) {
        if (!erreurNom.hidden) return;
        alerte.hidden = false;
        alerte.textContent = probleme;
        return;
      }
      const c = corps(true);
      if (!enverrable(c)) return;
      verifier.disabled = true;
      verifier.setAttribute("aria-busy", "true");
      zoneResultat.replaceChildren(h("p.muet", "Vérification en cours…"));
      try {
        st.simulation = await importerListe(c);
        if (st.simulation.deja) {
          terminer(st.simulation);
          return;
        }
        afficherSimulation(st.simulation);
      } catch (e) {
        afficherErreur(e, "La vérification a échoué");
      } finally {
        verifier.disabled = false;
        verifier.removeAttribute("aria-busy");
      }
    });

    importerBtn.addEventListener("click", async () => {
      const sim = st.simulation;
      if (!sim?.rapport?.dans_la_liste) return;
      const rap = sim.rapport;
      const crees = [rap.contacts_crees ? pluriel(rap.contacts_crees, "contact", "contacts") : null, rap.entreprises_creees ? pluriel(rap.entreprises_creees, "entreprise", "entreprises") : null].filter(Boolean);
      const ok = await confirmer({
        titre: `Créer la liste « ${st.nom.trim()} » ?`,
        message: `${crees.length ? `${crees.join(" et ")} ${accordAjoute(rap)} au CRM, avec la provenance « Liste de prospection » et l’étiquette « ${st.nom.trim()} ». ` : "Aucune fiche n’est créée : la liste ne contient que des personnes déjà dans le CRM. "}Vous pourrez ensuite puiser des appels dans la liste à votre rythme.`,
        libelleConfirmer: "Créer la liste",
      });
      if (!ok) return;
      const c = corps(false);
      if (!enverrable(c)) return;
      importerBtn.disabled = true;
      importerBtn.setAttribute("aria-busy", "true");
      verifier.disabled = true;
      zoneResultat.replaceChildren(h("p.muet", "Importation en cours…"));
      try {
        const r = await importerListe(c);
        await synchroniser({ complet: true }).catch(() => {});
        terminer(r);
      } catch (e) {
        importerBtn.disabled = false;
        verifier.disabled = false;
        afficherErreur(e, "L’importation a échoué");
      } finally {
        importerBtn.removeAttribute("aria-busy");
      }
    });

    montrerEtape();
    racine.replaceChildren(
      panneau(
        { titre: "Associer les colonnes", sous: `${st.nomFichier || "Lignes collées"} — ${pluriel(st.lignes.length, "ligne")}, ${pluriel(st.entetes.length, "colonne")}.`, niveau: 3 },
        h(
          "div.pile",
          h("p.reglages__note", "Pour chaque colonne, choisissez l’information qu’elle contient. Le CRM a déjà deviné ce qu’il a pu : vérifiez, puis cliquez sur « Vérifier la liste ». Rien n’est créé à cette étape."),
          h("ul.mappage", lignesMappage)
        )
      ),
      panneau(
        { titre: "La liste", niveau: 3 },
        h(
          "div.pile",
          h("div.champ", h("label.champ__etiquette", { for: idNom }, "Nom de la liste"), nom, erreurNom, h("p.champ__aide", "Il sert aussi d’étiquette sur les fiches créées, pour les retrouver plus tard.")),
          h("div.champ", h("label.champ__etiquette", { for: idDesc }, "Description (facultatif)"), description),
          h("div.champ", h("label.champ__etiquette", { for: idScript }, "Script d’appel (facultatif)"), h("div.saisie-select", script, icone("bas", "ic--p")), h("p.champ__aide", "Pendant les appels de cette liste, ce script s’affiche en premier.")),
          h("div.champ.champ--case", h("label.case", { for: idInclure }, inclure, h("span.case__boite", { "aria-hidden": "true" }, icone("coche", "ic--p")), h("span", "Inclure aussi les personnes déjà dans mon CRM")), h("p.champ__aide", "Par défaut, elles sont ignorées. Cochée, elles s’ajoutent à la liste pour être appelées avec les autres; leur fiche n’est pas modifiée."))
        )
      ),
      h("div.pile", alerte, h("div.actions-ligne", btn("Choisir un autre fichier", { onclick: () => etapeSource() }), verifier, importerBtn), zoneResultat)
    );
  }

  // ----- Étape 3 : terminé -----------------------------------------------------------------------------------------------------------------
  function terminer(r) {
    const liste = r.liste;
    const rap = r.rapport || {};
    const fiches = [rap.contacts_crees ? pluriel(rap.contacts_crees, "contact créé", "contacts créés") : null, rap.entreprises_creees ? pluriel(rap.entreprises_creees, "entreprise créée", "entreprises créées") : null].filter(Boolean);
    montrerEtape();
    racine.replaceChildren(
      panneau(
        { titre: r.deja ? "Cette liste existe déjà" : "Liste créée", niveau: 3 },
        h(
          "div.pile",
          avis({
            ton: "ok", titre: `« ${liste.nom} » : ${pluriel(liste.nb_lignes, "ligne", "lignes")}`,
            texte: r.deja ? "Cette importation avait déjà été faite (le renvoi n’a rien ajouté de plus)." : fiches.length ? `${fiches.join(" · ")}. Elles portent l’étiquette « ${liste.nom} ».` : "Aucune fiche n’a été créée.",
          }),
          h(
            "div.actions-ligne",
            btn("Ouvrir la liste", { ton: "primaire", icone: "liste", href: `#/appels/listes/${encodeURIComponent(liste.id)}` }),
            btn("Ajouter des appels à la file", { icone: "ajout-liste", onclick: () => ouvrirPuiser({ ...liste, compteurs: liste.compteurs || { a_appeler: liste.nb_lignes } }) }),
            btn("Importer une autre liste", {
              onclick: () => {
                Object.assign(st, { nomFichier: "", entetes: [], lignes: [], numeros: [], cibles: [], nom: "", description: "", scriptId: "", inclure: false, cle: null, simulation: null });
                etapeSource();
              },
            })
          )
        )
      )
    );
  }

  etapeSource();
  // Les synchronisations (toutes les 45 s) ne doivent jamais refaire l'assistant : ce qui est choisi à l'écran serait perdu.
  return { noeud: racine, miseAJour: () => true };
}
