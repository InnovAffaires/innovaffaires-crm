// =============================================================================
// Onglet « File d'attente » : qui appeler aujourd'hui, dans quel ordre, et le bouton
// qui lance la séance. La file vient des tâches de type « appel » encore à faire.
// =============================================================================
import { h, remplir } from "../../noyau/dom.js";
import { icone } from "../../noyau/icones.js";
import { etat, maintenant } from "../../noyau/etat.js";
import { lienFiche } from "../../noyau/routeur.js";
import { modifierFiche, tenter } from "../../noyau/ecriture.js";
import { toast } from "../../ui/toast.js";
import { pluriel } from "../../commun/format.js";
import { aujourdhui } from "../../commun/dates.js";
import { plageHoraire, heureCourte, dureeTexte } from "../../commun/appels.js";
import { avatar, btn, menuActions, panneau, pastille, etatVide, avis } from "../../ui/composants.js";
import { confirmer } from "../../ui/dialogue.js";
import { noeudEcheance, heureTexte } from "../aides.js";
import { fileDAppels } from "../../noyau/acces-appels.js";
import { nomDeListe, chargerListes } from "../../noyau/listes-appels.js";
import { session, surChangement, commencer, chargerStatsJour, compteursSeance, sansTraitees } from "./session.js";
import { ouvrirAjoutFile } from "./ajouter.js";

const GROUPES = [
  { id: 0, titre: "À faire maintenant", ton: "erreur", aide: "En retard, ou rappel dont l’heure est arrivée." },
  { id: 1, titre: "Aujourd’hui", ton: "attention" },
  { id: 2, titre: "Plus tard aujourd’hui", ton: "neutre", aide: "Rappels à une heure précise." },
  { id: 3, titre: "À venir", ton: "neutre" },
  { id: 4, titre: "Sans échéance", ton: "neutre" },
];

const RAISONS_EXCLUS = {
  sans_numero: "Aucun numéro de téléphone sur la fiche.",
  ne_pas_appeler: "Sur la liste « ne pas appeler » : on ne l’appelle plus.",
  archive: "Fiche archivée : on ne l’appelle pas. Désarchivez-la pour la remettre dans la file.",
  anonymise: "Fiche anonymisée : il ne reste plus aucune coordonnée à appeler.",
  sans_fiche: "La tâche n’est liée à aucune fiche : on ne sait pas qui appeler.",
};

/** Texte du titre d'une tâche quand il apporte plus que « Appeler Marie » (ex. : « Appeler pour valider le budget »). */
function motifTache(it) {
  const t = it.tache?.titre || "";
  if (!t || /^(rappeler|appeler)\s/i.test(t) && t.toLowerCase().includes(String(it.personne.nom).toLowerCase())) return "";
  return t;
}

const nomListeDe = (t) => (t?.liste_id ? nomDeListe(t.liste_id) : "");

export function monterFile(ctx) {
  const memo = ctx.memoire;
  const st = memo.get("file") || { portee: "jour" };
  memo.set("file", st);
  const peutEcrire = etat.droits.ecrire;
  const zone = h("div.pile");
  let off = null;

  function retirerDeLaFile(item) {
    return async () => {
      const ok = await confirmer({
        titre: "Retirer de la file ?", message: `Retirer ${item.personne.nom || "cette personne"} de la file d’appels ? ${pluriel(item.taches.length, "tâche d’appel sera marquée", "tâches d’appel seront marquées")} comme terminée${item.taches.length > 1 ? "s" : ""}, sans consigner d’appel.`,
        libelleConfirmer: "Retirer de la file",
      });
      if (!ok) return;
      let n = 0;
      for (const t of item.taches) {
        const r = await tenter(() => modifierFiche("taches", t, { statut: "fait" }), { entite: "taches" });
        if (r) n++;
      }
      if (n) toast(`${item.personne.nom} a été retiré de la file.`, { ton: "info" });
    };
  }

  function ligne(it, file) {
    const p = it.personne;
    const t = it.tache;
    const motif = motifTache(it);
    const max = etat.config.appels.essais_max;
    const tel = p.numeros[0];
    const cible = p.cible;
    return h(
      "li.file__ligne",
      avatar(p.nom),
      h(
        "div.file__texte",
        peutEcrire
          ? h("button.file__nom", { type: "button", onclick: () => commencer(it.cle), title: "Appeler cette personne maintenant" }, p.nom)
          : cible
            ? h("a.file__nom", { href: lienFiche(cible.entite, cible.id), title: "Ouvrir la fiche" }, p.nom)
            : h("span.file__nom", p.nom),
        h("small.muet", [p.fonction, p.entreprise && p.cible?.entite !== "entreprises" ? p.entreprise.nom : null].filter(Boolean).join(" · ") || (p.demande ? "Demande reçue par le site" : "")),
        motif ? h("small.file__motif", motif) : null,
        nomListeDe(t) ? h("a.file__lien-liste", { href: `#/appels/listes/${encodeURIComponent(t.liste_id)}`, title: `Liste d’appels : ${nomListeDe(t)}` }, icone("liste", "ic--p"), h("span", nomListeDe(t))) : null
      ),
      h(
        "div.file__marques",
        it.essai > 1 ? pastille(`Essai ${it.essai} sur ${max}`, "info") : null,
        p.demande ? pastille("Demande du site", "neutre") : null,
        t?.priorite === "haute" ? h("span.file__priorite", icone("drapeau", "ic--p"), h("span", "Prioritaire")) : null
      ),
      h("div.file__quand", t?.echeance ? noeudEcheance(t.echeance) : h("span.muet", "Sans échéance"), t?.heure ? h("small.muet", heureTexte(t.heure)) : null),
      h("div.file__tel", tel ? h("span.tnum", tel.affiche) : null, p.numeros.length > 1 ? h("small.muet", `+${p.numeros.length - 1} autre${p.numeros.length > 2 ? "s" : ""}`) : null),
      h(
        "div.file__actions",
        peutEcrire ? btn("Appeler", { petit: true, ton: "primaire", icone: "telephone", onclick: () => commencer(it.cle), aria: `Appeler ${p.nom}` }) : null,
        menuActions({
          aria: `Plus d’actions pour ${p.nom}`, fixe: true,
          elements: [
            cible ? { libelle: "Ouvrir la fiche", icone: "voir", onclick: () => (location.hash = lienFiche(cible.entite, cible.id)) } : null,
            peutEcrire ? { libelle: "Retirer de la file", icone: "fermer", onclick: retirerDeLaFile(it) } : null,
          ].filter(Boolean),
        })
      )
    );
  }

  function groupe(def, items, file) {
    return h(
      "section.groupe-taches",
      h("h3.groupe-taches__titre", { class: `groupe-taches__titre--${def.ton}` }, def.titre, h("span.panneau__compteur", String(items.length)), def.aide ? h("small.muet.groupe-taches__aide", def.aide) : null),
      h("ul.file__liste", items.map((it) => ligne(it, file)))
    );
  }

  function exclus(file) {
    if (!file.exclus.length) return null;
    return h(
      "details.replie.file__exclus",
      h("summary.replie__titre", icone("alerte", "ic--p"), h("span", "Personnes qui ne peuvent pas être appelées"), h("span.replie__compte.muet", String(file.exclus.length)), icone("droite", "replie__fleche")),
      h(
        "div.replie__corps",
        h("p.muet", "Ces tâches d’appel sont à faire, mais la personne n’apparaît pas dans la file."),
        h(
          "ul.file__exclus-liste",
          file.exclus.map((x) => {
            const cible = x.personne.cible;
            return h(
              "li",
              h("div", h("strong", x.personne.nom || x.taches[0]?.titre || "Tâche sans fiche"), h("small.muet", RAISONS_EXCLUS[x.raison])),
              h(
                "div.actions-ligne",
                cible ? btn("Ouvrir la fiche", { petit: true, href: lienFiche(cible.entite, cible.id) }) : btn("Voir les tâches", { petit: true, href: "#/taches" }),
                peutEcrire && x.raison !== "sans_numero" ? btn("Retirer de la file", { petit: true, onclick: retirerDeLaFile(x) }) : null
              )
            );
          })
        )
      )
    );
  }

  /** Les deux files (d'aujourd'hui, et toute la file) sans les personnes déjà appelées pendant la séance. */
  function chargerFiles() {
    const jour = fileDAppels({ portee: "jour" });
    const tout = fileDAppels({ portee: "tout" });
    return { jour: { ...jour, items: sansTraitees(jour.items) }, tout: { ...tout, items: sansTraitees(tout.items) } };
  }

  function resume(jour) {
    const s = session();
    const a = etat.config.appels;
    const auj = aujourdhui(maintenant());
    const objectif = a.objectif_jour || 0;
    const fait = s.statsPour ? (s.statsJour?.total ?? 0) : compteursSeance().appels;
    const part = objectif ? Math.min(1, fait / objectif) : 0;
    const plage = plageHoraire(etat.config, maintenant());
    const aFaire = jour.items.filter((it) => it.groupe <= 1).length;
    const plusTard = jour.items.length - aFaire;
    const enRetard = jour.items.filter((it) => it.groupe === 0 && it.tache.echeance < auj).length;
    const maintenantN = jour.items.filter((it) => it.groupe === 0).length;
    return h(
      "section.panneau.panneau--accent.file__resume",
      { "aria-label": "Résumé de la file d’appels" },
      h(
        "div.file__chiffre",
        h("p.file__nombre", String(aFaire)),
        h(
          "p.file__legende",
          aFaire ? pluriel(aFaire, "personne à appeler", "personnes à appeler") : "Personne à appeler pour l’instant",
          enRetard ? h("small.file__retard", ` · ${enRetard} en retard`) : null,
          plusTard ? h("small.muet", ` · ${pluriel(plusTard, "rappel prévu plus tard aujourd’hui", "rappels prévus plus tard aujourd’hui")}`) : null
        )
      ),
      objectif
        ? h(
            "div.file__objectif",
            h("p.file__objectif-texte", h("strong", `${fait} sur ${objectif}`), " appels aujourd’hui"),
            h("div.progres", { role: "progressbar", "aria-valuemin": "0", "aria-valuemax": String(objectif), "aria-valuenow": String(Math.min(fait, objectif)), "aria-label": "Appels faits aujourd’hui" }, h("span.progres__barre", { css: { "--p": part.toFixed(3) } })),
            s.statsJour?.secondes ? h("small.muet", `Temps au téléphone : ${dureeTexte(s.statsJour.secondes)}`) : null
          )
        : null,
      h(
        "div.file__demarrer",
        peutEcrire ? btn(maintenantN && aFaire ? "Commencer les appels" : "Commencer", { ton: "primaire", icone: "lecture", classe: "btn--large", desactive: !aFaire, onclick: () => commencer(null) }) : null,
        peutEcrire ? btn("Ajouter des personnes", { icone: "ajout-liste", onclick: () => ouvrirAjoutFile() }) : null
      ),
      !peutEcrire
        ? h("div.file__heures", avis({ ton: "info", titre: "Accès en lecture seule", texte: "Vous pouvez consulter la file d’appels, mais pas lancer d’appels ni en consigner. Demandez un accès en modification à l’administrateur." }))
        : null,
      !plage.dansPlage && a.avertir_heures
        ? h("div.file__heures", avis({ ton: "attention", titre: "En dehors des heures d’appel habituelles", texte: `Il est ${heureCourte(plage.heure)} : les appels de vente sont permis ${plage.finDeSemaine ? "la fin de semaine" : "en semaine"} de ${heureCourte(plage.debut)} à ${heureCourte(plage.fin)}. Vous pouvez régler ces heures dans Paramètres → Appels.` }))
        : null
    );
  }

  function rendre() {
    const { jour, tout } = chargerFiles();
    const file = st.portee === "tout" ? tout : jour;
    const aVenir = tout.items.length - jour.items.length;
    const commut = h(
      "div.commutateur",
      { role: "group", "aria-label": "Étendue de la file" },
      h("button.commutateur__bouton", { type: "button", "aria-pressed": String(st.portee === "jour"), onclick: () => ((st.portee = "jour"), rendre()) }, h("span", "À faire aujourd’hui")),
      h("button.commutateur__bouton", { type: "button", "aria-pressed": String(st.portee === "tout"), onclick: () => ((st.portee = "tout"), rendre()) }, h("span", "Toute la file"), aVenir > 0 ? h("span.commutateur__nombre", `+${aVenir}`) : null)
    );
    const contenu = [];
    if (!file.items.length && !file.exclus.length) {
      contenu.push(
        panneau(
          {},
          etatVide({
            icone: "casque", titre: st.portee === "tout" ? "Votre file d’appels est vide" : "Aucun appel à faire aujourd’hui",
            texte: st.portee === "tout"
              ? "Ajoutez des contacts, des entreprises ou des demandes du site : chacun reçoit une tâche « Appeler » et se retrouve ici, prêt à être appelé. Les tâches d’appel créées ailleurs dans le CRM s’y ajoutent aussi."
              : aVenir > 0 ? `${pluriel(aVenir, "appel est prévu", "appels sont prévus")} plus tard : choisissez « Toute la file » pour les voir.` : "Ajoutez des personnes à appeler, ou créez une tâche de type « Appel » depuis une fiche.",
            action: peutEcrire ? btn("Ajouter des personnes", { ton: "primaire", icone: "ajout-liste", onclick: () => ouvrirAjoutFile() }) : null,
          })
        )
      );
    } else {
      const groupes = GROUPES.map((g) => ({ g, items: file.items.filter((it) => it.groupe === g.id) })).filter((x) => x.items.length);
      if (groupes.length) contenu.push(panneau({ classe: "panneau--liste file__panneau" }, groupes.map(({ g, items }) => groupe(g, items, file))));
    }
    const ex = exclus(file);
    remplir(zone, resume(jour), h("div.file__outils", commut), contenu, ex);
  }

  rendre();
  chargerStatsJour();
  // Le nom d'une liste ne vient pas avec les tâches : on le lit une fois si un appel de la file en dépend.
  if (etat.collections.taches.some((t) => t.type === "appel" && t.statut !== "fait" && t.liste_id)) chargerListes().catch(() => {});
  off = surChangement(() => {
    // Les compteurs du jour changent quand un résultat est envoyé : on redessine seulement l'en-tête.
    const resumeActuel = zone.querySelector(".file__resume");
    if (resumeActuel) resumeActuel.replaceWith(resume(chargerFiles().jour));
  });

  return {
    noeud: zone,
    miseAJour() {
      rendre();
      return true;
    },
    detruire: () => off?.(),
  };
}
