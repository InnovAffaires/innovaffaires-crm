// =============================================================================
// Appels : le poste d'appel. La file d'attente d'aujourd'hui, la séance d'appels
// (une personne à la fois, avec son script), le journal des appels et les
// statistiques. Chaque section est dans vues/appels/*.js; cet écran choisit
// laquelle montrer et garde au-dessus l'alerte des appels non enregistrés.
// =============================================================================
import { h } from "../noyau/dom.js";
import { naviguer } from "../noyau/routeur.js";
import { enTete } from "../ui/composants.js";
import { monterFile } from "./appels/file.js";
import { monterCarte } from "./appels/carte.js";
import { monterJournal } from "./appels/journal.js";
import { monterStats } from "./appels/stats.js";
import { monterListes } from "./appels/listes.js";
import { monterListe } from "./appels/liste.js";
import { monterImportListe } from "./appels/importer-liste.js";
import { bandeauEnvois } from "./appels/envois.js";

export const depend = ["taches", "contacts", "entreprises", "demandes", "opportunites", "dossiers", "factures", "config", "listes_appels"];

const ONGLETS = [
  { id: "file", libelle: "File d’attente", chemin: "/appels" },
  { id: "listes", libelle: "Listes", chemin: "/appels/listes" },
  { id: "journal", libelle: "Journal", chemin: "/appels/journal" },
  { id: "stats", libelle: "Statistiques", chemin: "/appels/stats" },
];
// Les écrans d'une liste (détail, importation) appartiennent à l'onglet « Listes ».
const SECTIONS = { file: monterFile, listes: monterListes, liste: monterListe, "importer-liste": monterImportListe, journal: monterJournal, stats: monterStats };
const ONGLET_DE = { liste: "listes", "importer-liste": "listes" };
const TITRES = { liste: "Liste d’appels", "importer-liste": "Importer une liste" };

function sousNavigation(actif) {
  return h(
    "nav.sous-nav",
    { "aria-label": "Sections des appels" },
    ONGLETS.map((o) => h("a.sous-nav__lien", { href: `#${o.chemin}`, "aria-current": o.id === actif ? "page" : null }, o.libelle))
  );
}

export default async function appels(ctx) {
  const section = ctx.params.section || ctx.route.section || "file";

  // La séance d'appels occupe tout l'écran : pas d'en-tête ni d'onglets, seulement l'alerte d'enregistrement.
  if (section === "session") {
    const envois = bandeauEnvois();
    const carte = monterCarte();
    return {
      titre: "Appel en cours",
      noeud: h("div.appels-session", envois.noeud, carte.noeud),
      miseAJour: (changes) => carte.miseAJour?.(changes) === true,
      detruire: () => {
        carte.detruire?.();
        envois.detruire?.();
      },
    };
  }

  const monter = SECTIONS[section];
  if (!monter) {
    naviguer("/appels", { remplacer: true });
    return { titre: "Appels", noeud: h("div") };
  }
  const envois = bandeauEnvois();
  const contenu = monter(ctx);
  const onglet = ONGLETS.find((o) => o.id === (ONGLET_DE[section] || section));
  return {
    titre: section === "file" ? "Appels" : `${TITRES[section] || onglet.libelle} — Appels`,
    noeud: h(
      "div.appels",
      enTete({ titre: "Appels", sous: "Appelez vos contacts et les personnes qui vous ont écrit, une à la fois, avec le script sous les yeux." }),
      sousNavigation(ONGLET_DE[section] || section),
      envois.noeud,
      contenu.noeud
    ),
    miseAJour: (changes) => contenu.miseAJour?.(changes) === true,
    detruire: () => {
      contenu.detruire?.();
      envois.detruire?.();
    },
  };
}
