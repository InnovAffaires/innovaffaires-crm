// =============================================================================
// Fiche d'une affaire : la frise des étapes, le client, la valeur, les tâches,
// les dossiers et factures qui en découlent, et l'historique des échanges.
// =============================================================================
import { h } from "../noyau/dom.js";
import { etat, actives, liees, fiche, nomUtilisateur, sourceDe, etapeDe, maintenant } from "../noyau/etat.js";
import { lienFiche, naviguer } from "../noyau/routeur.js";
import { supprimerAvecAnnulation } from "../noyau/ecriture.js";
import { aujourdhui, differenceJours } from "../commun/dates.js";
import { RAISONS_PERTE, SERVICES } from "../commun/schema.js";
import { argent, dateLongue, nomComplet, pluriel } from "../commun/format.js";
import { btn, enTete, menuActions, panneau, listeDef, avis, tampon } from "../ui/composants.js";
import { journal } from "../ui/journal.js";
import { frise } from "../ui/frise.js";
import { libelleOption, noeudEcheance, dateSansAnneeCourante } from "./aides.js";
import { nouvelleFiche, modifierLaFiche } from "./formulaires.js";
import { deplacerAffaire } from "./etapes.js";
import { creerVueFiche, marquesFiche, panneauClient, panneauLie, panneauTaches, panneauNotes, piedFiche, ligneDossier, ligneFacture } from "./fiche.js";

export const depend = ["opportunites", "entreprises", "contacts", "dossiers", "factures", "taches", "evenements", "equipe", "config"];

const TONS_ETAPE = { ouverte: "info", gagnee: "ok", perdue: "erreur" };

// ----- En-tête -----------------------------------------------------------------------------------------------------------------------------------------
function menuAjouter(o) {
  const liens = { ...(o.entreprise_id ? { entreprise_id: o.entreprise_id } : {}), ...(o.contact_id ? { contact_id: o.contact_id } : {}) };
  // Une facture ou un devis suit l'affaire, et son dossier de financement quand il n'y en a qu'un.
  const dossiers = liees("dossiers", "opportunite_id", o.id);
  const rattache = { opportunite_id: o.id, ...(dossiers.length === 1 ? { dossier_id: dossiers[0].id } : {}) };
  return menuActions({
    libelle: "Ajouter", icone: "plus", ton: "primaire", aria: "Ajouter une tâche, un dossier ou une facture à cette affaire",
    elements: [
      { libelle: "Tâche", icone: "taches", onclick: () => document.querySelector('[data-focus-id="affaire-ajout"]')?.focus() },
      { libelle: "Rendez-vous", icone: "calendrier", onclick: () => nouvelleFiche("evenements", { lie_type: "opportunites", lie_id: o.id }) },
      "separateur",
      { libelle: "Dossier de financement", icone: "dossiers", onclick: () => nouvelleFiche("dossiers", { ...liens, opportunite_id: o.id }) },
      { libelle: "Facture", icone: "factures", onclick: () => nouvelleFiche("factures", { type: "facture", ...liens, ...rattache, objet: o.titre }) },
      { libelle: "Devis", icone: "document", onclick: () => nouvelleFiche("factures", { type: "devis", ...liens, ...rattache, objet: o.titre }) },
    ],
  });
}

function enteteAffaire(o) {
  const etape = etapeDe(o.etape);
  const ent = o.entreprise_id ? fiche("entreprises", o.entreprise_id) : null;
  const con = o.contact_id ? fiche("contacts", o.contact_id) : null;
  const sous = [];
  if (ent && !ent.supprime) sous.push(h("a.lien-fiche", { href: lienFiche("entreprises", ent.id) }, ent.nom));
  if (ent && !ent.supprime && con && !con.supprime) sous.push(" — ");
  if (con && !con.supprime) sous.push(h("a.lien-fiche", { href: lienFiche("contacts", con.id) }, nomComplet(con) || con.courriel));
  const actions = [];
  if (etat.droits.ecrire) {
    actions.push(menuAjouter(o));
    actions.push(btn("Modifier", { icone: "modifier", onclick: () => modifierLaFiche("opportunites", fiche("opportunites", o.id) || o) }));
    actions.push(
      menuActions({
        aria: "Plus d’actions sur cette affaire",
        elements: [{ libelle: "Mettre à la corbeille", icone: "corbeille", danger: true, onclick: () => supprimerAvecAnnulation("opportunites", o.id, { apres: () => naviguer("/affaires") }) }],
      })
    );
  }
  return enTete({
    retour: { href: "#/affaires", libelle: "Affaires" },
    titre: o.titre,
    apres: marquesFiche(o, { etats: etape && etape.type !== "ouverte" ? [tampon(etape.nom, TONS_ETAPE[etape.type])] : [] }),
    sous: sous.length ? sous : null,
    actions,
  });
}

// ----- Blocs --------------------------------------------------------------------------------------------------------------------------------------------
/** La frise : une étape par bouton ; la courante est en relief, les étapes franchies en teinte légère. */
function friseEtapes(o) {
  const peutEcrire = etat.droits.ecrire;
  return panneau(
    { titre: "Étape" },
    frise({
      etapes: etat.config.etapes.map((e) => ({ id: e.id, nom: e.nom, ton: e.type })), courant: o.etape, ecrire: peutEcrire,
      surChoix: (e) => deplacerAffaire(o.id, e.id), libelleChemin: "Étapes de l’affaire", libelleIssues: "Issue défavorable", titreBouton: (e) => `Déplacer l’affaire vers « ${e.nom} »`,
    }),
    peutEcrire ? h("p.frise__aide.muet.petit", "Cliquez sur une étape pour y déplacer l’affaire. Le motif est demandé quand elle est perdue.") : null
  );
}

function avisPerte(o) {
  const etape = etapeDe(o.etape);
  if (etape?.type !== "perdue") return null;
  const raison = libelleOption(RAISONS_PERTE, o.raison_perte);
  const premiereOuverte = etat.config.etapes.find((e) => e.type === "ouverte");
  return avis({
    ton: "erreur", titre: "Affaire perdue",
    texte: [raison ? `Raison : ${raison}.` : "Aucune raison n’a été indiquée.", o.fermee_le ? ` Classée le ${dateLongue(o.fermee_le)}.` : ""].join(""),
    actions: etat.droits.ecrire && premiereOuverte ? btn("Rouvrir l’affaire", { petit: true, icone: "annuler", onclick: () => deplacerAffaire(o.id, premiereOuverte.id) }) : null,
  });
}

function blocValeur(o) {
  const etape = etapeDe(o.etape);
  const ouverte = etape?.type === "ouverte";
  const proba = o.probabilite !== undefined && o.probabilite !== null ? +o.probabilite : +(etape?.probabilite ?? 0);
  const valeur = +o.valeur || 0;
  const depuis = o.etape_depuis ? Math.max(0, differenceJours(o.etape_depuis, aujourdhui(maintenant()))) : null;
  const chiffres = h(
    "dl.registre-chiffres",
    h("div.registre-chiffres__ligne.registre-chiffres__ligne--principale", h("dt", "Honoraires estimés"), h("dd", valeur ? argent(valeur) : "—")),
    ouverte ? h("div.registre-chiffres__ligne", h("dt", "Probabilité"), h("dd", `${proba} %`)) : null,
    ouverte && valeur ? h("div.registre-chiffres__ligne", h("dt", "Valeur pondérée"), h("dd", argent((valeur * proba) / 100))) : null
  );
  const def = listeDef([
    ["Service", libelleOption(SERVICES, o.service) || null],
    ouverte ? ["Fermeture prévue", o.date_fermeture_prevue ? noeudEcheance(o.date_fermeture_prevue) : null] : ["Fermée le", o.fermee_le ? dateSansAnneeCourante(o.fermee_le) : null],
    ["À cette étape", depuis === null ? null : depuis === 0 ? "depuis aujourd’hui" : `depuis ${pluriel(depuis, "jour", "jours")}`],
  ]);
  return panneau({ titre: "Valeur" }, chiffres, def.children.length ? h("div.valeur__def", def) : null);
}

function tachesAffaire(o) {
  const dossiers = new Set(liees("dossiers", "opportunite_id", o.id).map((d) => d.id));
  return actives("taches").filter((t) => (t.lie_type === "opportunites" && t.lie_id === o.id) || (t.lie_type === "dossiers" && dossiers.has(t.lie_id)));
}

function blocDossiers(o) {
  const lignes = liees("dossiers", "opportunite_id", o.id).slice().sort((a, b) => String(b.maj || "").localeCompare(String(a.maj || "")));
  if (lignes.length) return panneauLie({ titre: "Dossiers de financement", lignes: lignes.map((d) => ligneDossier(d)) });
  const etape = etapeDe(o.etape);
  if (etape?.type === "gagnee" && etat.droits.ecrire) {
    return avis({
      ton: "info", titre: "Aucun dossier de financement lié",
      texte: "Créez le dossier de ce mandat : les tâches prévues à chaque statut s’ajoutent automatiquement et vous y dressez la liste des documents à obtenir.",
      actions: btn("Créer le dossier", { petit: true, icone: "dossiers", onclick: () => nouvelleFiche("dossiers", { entreprise_id: o.entreprise_id, contact_id: o.contact_id, opportunite_id: o.id }) }),
    });
  }
  return null;
}

function blocHistorique(o0) {
  let entreprise = null;
  let j = null;
  const conteneur = h("div");
  function monter(o) {
    entreprise = o.entreprise_id || null;
    j = journal({ lieType: "opportunites", lieId: o.id, lie2: entreprise ? { type: "entreprises", id: entreprise } : null, aide: "Notes, appels, courriels et rencontres liés à cette affaire, et les changements d’étape." });
    conteneur.replaceChildren(j.noeud);
  }
  monter(o0);
  return {
    noeud: conteneur,
    miseAJour(changes, o) {
      if ((o.entreprise_id || null) !== entreprise) monter(o);
      else if (["dossiers", "factures"].some((c) => changes.has(c))) j.recharger();
    },
  };
}

export default creerVueFiche({
  entite: "opportunites",
  liste: { href: "#/affaires", libelle: "Affaires" },
  entete: { depend: ["opportunites", "entreprises", "contacts", "config"], dessiner: enteteAffaire },
  blocs: [
    { id: "frise", colonne: "principal", ordre: 0, depend: ["opportunites", "config"], dessiner: friseEtapes },
    { id: "perte", colonne: "principal", ordre: 1, depend: ["opportunites", "config"], dessiner: avisPerte },
    { id: "valeur", colonne: "lateral", ordre: 2, depend: ["opportunites", "config"], dessiner: blocValeur },
    { id: "client", colonne: "lateral", ordre: 3, depend: ["opportunites", "entreprises", "contacts"], dessiner: (o) => panneauClient(o) },
    {
      id: "taches", colonne: "principal", ordre: 4, depend: ["taches", "dossiers"],
      dessiner: (o) =>
        panneauTaches({
          taches: tachesAffaire(o), lieType: "opportunites", lieId: o.id, placeholder: "Nouvelle tâche pour cette affaire…", focusId: "affaire-ajout",
          estDirecte: (t) => t.lie_type === "opportunites" && t.lie_id === o.id,
        }),
    },
    { id: "dossiers", colonne: "principal", ordre: 5, depend: ["dossiers", "opportunites", "config"], dessiner: blocDossiers },
    {
      id: "factures", colonne: "principal", ordre: 6, depend: ["factures"],
      dessiner: (o) => {
        const lignes = liees("factures", "opportunite_id", o.id).slice().sort((a, b) => String(b.date_emission || "9999").localeCompare(String(a.date_emission || "9999")));
        return lignes.length ? panneauLie({ titre: "Factures et devis", lignes: lignes.map((x) => ligneFacture(x)) }) : null;
      },
    },
    { id: "historique", colonne: "principal", ordre: 7, creer: blocHistorique },
    {
      id: "suivi", colonne: "lateral", ordre: 8, depend: ["opportunites", "equipe", "config"],
      dessiner: (o) => {
        const demande = o.demande_id ? fiche("demandes", o.demande_id) : null;
        const def = listeDef([
          ["Responsable", nomUtilisateur(o.responsable_id) || null],
          ["Provenance", sourceDe(o.source) || null],
          ["Demande d’origine", demande && !demande.supprime ? h("a.lien-fiche", { href: lienFiche("demandes", demande.id) }, `Demande du site du ${dateSansAnneeCourante(String(demande.recu).slice(0, 10))}`) : null],
        ]);
        return def.children.length ? panneau({ titre: "Suivi" }, def) : null;
      },
    },
    { id: "notes", colonne: "lateral", ordre: 9, depend: ["opportunites"], dessiner: (o) => panneauNotes("opportunites", o) },
    { id: "pied", colonne: "lateral", ordre: 10, depend: ["opportunites", "equipe"], dessiner: (o) => piedFiche("opportunites", o) },
  ],
});
