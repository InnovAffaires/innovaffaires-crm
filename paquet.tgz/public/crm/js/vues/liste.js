// =============================================================================
// Fabrique d'écrans « liste » : recherche, filtres, tri, export CSV, état vide.
// Chaque liste (contacts, entreprises, dossiers, factures) décrit ses colonnes
// et ses filtres ; le reste est partagé.
// =============================================================================
import { h } from "../noyau/dom.js";
import { icone } from "../noyau/icones.js";
import { etat, actives, texteRecherche } from "../noyau/etat.js";
import { normaliser, pluriel } from "../commun/format.js";
import { ENTITES } from "../commun/schema.js";
import { aujourdhui } from "../commun/dates.js";
import { enTete, btn, etatVide } from "../ui/composants.js";
import { tableau } from "../ui/tableau.js";
import { barreFiltres } from "../ui/filtres.js";
import { majRequete, lireAdresse } from "../noyau/routeur.js";
import { versCsv } from "../noyau/csv.js";
import { enregistrerFichier } from "../noyau/dom.js";
import { toast } from "../ui/toast.js";

/**
 * def : {
 *   entite, titre, sous?, pluralTexte? ("contacts"), nouveau?: { libelle, valeurs? },
 *   lignes?(): fiches (défaut : toutes les fiches actives),
 *   archive?(f): bool — fiches masquées sauf si « Afficher les archivés » est coché,
 *   filtres?: [{ id, libelle, tout, options(): [{id,libelle}], test(f, valeur) }],
 *   colonnes, triDefaut?: { col, dir }, href(f),
 *   exporter?: { nom, colonnes: [{ titre, valeur(f) }] },
 *   vide: { icone, titre, texte },
 *   pied?(lignes): Node  — ligne de totaux
 *   actionsAvant?(ctx), actions?(ctx): boutons ajoutés avant / après « Exporter » et « Nouveau »
 * }
 */
export function creerVueListe(def) {
  return async function vueListe(ctx) {
    const memo = ctx.memoire;
    const st = memo.get("etat") || { q: "", filtres: {}, tri: def.triDefaut || null, archives: false };
    memo.set("etat", st);
    for (const f of def.filtres || []) {
      const v = ctx.requete.get(f.id);
      if (v !== null) st.filtres[f.id] = v;
    }
    if (ctx.requete.has("q")) st.q = ctx.requete.get("q");

    const ent = ENTITES[def.entite];
    const jetons = () => normaliser(st.q).split(/\s+/).filter(Boolean);

    function source() {
      return def.lignes ? def.lignes() : actives(def.entite);
    }
    function filtrees() {
      const tous = source();
      const j = jetons();
      const auj = aujourdhui();
      return tous.filter((f) => {
        if (def.archive && !st.archives && def.archive(f)) return false;
        if (j.length) {
          const t = texteRecherche(def.entite, f);
          if (!j.every((x) => t.includes(x))) return false;
        }
        for (const flt of def.filtres || []) {
          const v = st.filtres[flt.id];
          if (v && !flt.test(f, v, auj)) return false;
        }
        return true;
      });
    }

    function enregistrerUrl() {
      const params = {};
      if (st.q) params.q = st.q;
      for (const [k, v] of Object.entries(st.filtres)) if (v) params[k] = v;
      majRequete(params, { chemin: lireAdresse().chemin });
    }

    const filtresUi = (def.filtres || []).map((f) => ({
      id: f.id, libelle: f.libelle, tout: f.tout, options: f.options, valeur: st.filtres[f.id] || "",
      surChangement: (v) => {
        st.filtres[f.id] = v;
        tableauUi.reinitialiserLimite();
        rafraichirTableau();
        enregistrerUrl();
      },
    }));

    const caseArchives = def.archive
      ? h(
          "label.case",
          h("input", { type: "checkbox", checked: st.archives, onchange: (e) => { st.archives = e.target.checked; rafraichirTableau(); } }),
          h("span.case__boite", { "aria-hidden": "true" }, icone("coche", "ic--p")),
          h("span", def.libelleArchives || "Afficher les archivés")
        )
      : null;

    const barre = barreFiltres({
      placeholder: def.placeholder || `Rechercher parmi les ${ent.pluriel}…`, q: st.q, aria: `Rechercher parmi les ${ent.pluriel}`,
      surRecherche: (q) => {
        st.q = q;
        tableauUi.reinitialiserLimite();
        rafraichirTableau();
        enregistrerUrl();
      },
      surReinitialiser: () => {
        st.q = "";
        st.filtres = {};
        tableauUi.reinitialiserLimite();
        rafraichirTableau();
        enregistrerUrl();
      },
      filtres: filtresUi, droite: caseArchives,
    });

    const actif = () => !!st.q.trim() || Object.values(st.filtres).some(Boolean);
    const videFiltre = () =>
      etatVide({
        icone: "recherche", titre: "Aucun résultat", texte: "Aucune fiche ne correspond à votre recherche ou à vos filtres.",
        action: btn("Tout réinitialiser", { onclick: () => {
          st.q = "";
          st.filtres = {};
          for (const f of filtresUi) f.valeur = "";
          barre.entree.value = "";
          barre.maj();
          rafraichirTableau();
          enregistrerUrl();
        } }),
      });
    const videTotal = () =>
      etatVide({
        icone: def.vide?.icone || "etincelle", titre: def.vide?.titre || "Rien ici pour l’instant", texte: def.vide?.texte || "",
        action: etat.droits.ecrire && def.nouveau ? btn(def.nouveau.libelle, { ton: "primaire", icone: "plus", onclick: nouveau }) : null,
      });

    const tableauUi = tableau({
      colonnes: def.colonnes, lignes: [], href: def.href, tri: st.tri, surTri: (t) => (st.tri = t), libelle: def.titre, ligneTotal: def.pied || null,
      vide: () => (source().length ? videFiltre() : videTotal()),
    });

    function rafraichirTableau() {
      const lignes = filtrees();
      const total = source().length;
      tableauUi.majLignes(lignes);
      barre.definirCompte(lignes.length === total || !actif() ? pluriel(lignes.length, ent.singulier, ent.pluriel) : `${lignes.length} sur ${pluriel(total, ent.singulier, ent.pluriel)}`);
    }

    async function nouveau() {
      const f = await import("./formulaires.js");
      f.nouvelleFiche(def.nouveau.entite || def.entite, def.nouveau.valeurs?.() || {});
    }

    function exporter() {
      const lignes = tableauUi.lignesAffichees();
      if (!lignes.length) return toast("Rien à exporter avec ces filtres.", { ton: "info" });
      const nom = `${def.exporter.nom}-${aujourdhui()}.csv`;
      enregistrerFichier(nom, versCsv(def.exporter.colonnes, lignes), "text/csv;charset=utf-8");
      toast(`${pluriel(lignes.length, "fiche exportée", "fiches exportées")} dans ${nom}.`, { ton: "info" });
    }

    const actions = [...(def.actionsAvant?.(ctx) || [])];
    if (def.exporter) actions.push(btn("Exporter", { icone: "telecharger", onclick: exporter, titre: "Télécharger la liste affichée (CSV pour Excel)" }));
    if (etat.droits.ecrire && def.nouveau) actions.push(btn(def.nouveau.libelle, { ton: "primaire", icone: "plus", onclick: nouveau }));
    for (const a of def.actions?.(ctx) || []) actions.push(a);

    const noeud = h("div", enTete({ titre: def.titre, sous: typeof def.sous === "function" ? def.sous() : def.sous, actions }), h("div.pile.pile--s", barre.noeud, tableauUi.noeud));
    rafraichirTableau();

    return {
      titre: def.titre,
      noeud,
      miseAJour() {
        rafraichirTableau();
        return true;
      },
    };
  };
}
