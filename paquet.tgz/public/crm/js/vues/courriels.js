// =============================================================================
// Courriels : « Remplir mon CRM avec mes courriels ».
// Le CRM lit la boîte Gmail de la personne (avec son accord), repère les gens avec qui elle échange et lui propose de les
// ajouter, ou de compléter leurs fiches. Cet écran choisit ce qu'il faut montrer (explications, avancement, propositions)
// et laisse chaque onglet (vues/courriels/*.js) faire son travail. La page gère elle-même ses redessins : la sélection
// en cours et le focus du clavier survivent à une mise à jour.
// =============================================================================
import { h } from "../noyau/dom.js";
import { etat } from "../noyau/etat.js";
import { ErreurApi } from "../noyau/api.js";
import { naviguer } from "../noyau/routeur.js";
import { compteGoogle } from "../noyau/google.js";
import { enTete, btn, avis, etatVide, chargement, pastille } from "../ui/composants.js";
import {
  chargerVue, vueConnue, vueEstFraiche, surVue, surAnalyse, etatAnalyse, lancerAnalyse, effacerErreurAnalyse, libellePeriode, raisonBloquee,
} from "../noyau/classement.js";
import { panneauBloque, panneauActivation } from "./courriels/activation.js";
import { blocAvancement, quand } from "./courriels/commun.js";
import { monterNouveaux } from "./courriels/nouveaux.js";
import { monterCompleter } from "./courriels/completer.js";
import { monterAjouts } from "./courriels/ajouts.js";
import { monterReglages } from "./courriels/reglages.js";

export const depend = ["classement", "contacts", "entreprises", "google"];

const SECTIONS = [
  { id: "nouveaux", libelle: "Nouvelles personnes", monter: monterNouveaux, compte: (v) => v.nouveaux_total ?? v.nouveaux?.length ?? 0 },
  { id: "completer", libelle: "Fiches à compléter", monter: monterCompleter, compte: (v) => v.completer_total ?? v.completer?.length ?? 0 },
  { id: "ajouts", libelle: "Derniers ajouts", monter: monterAjouts },
  { id: "reglages", libelle: "Réglages", monter: monterReglages },
];
const chemin = (id) => (id === "nouveaux" ? "/courriels" : `/courriels/${id}`);

/** Le message du serveur quand il ne peut pas lire la boîte (connexion à renouveler, accès retiré…). */
const blocageDuServeur = (b) => ({
  code: b.code, titre: "Google n’est pas disponible pour le moment", texte: b.message, libelleAction: "Ouvrir les réglages de Google", chemin: "/parametres/google",
});

export default async function courriels(ctx) {
  const demande = ctx.params.section;
  const def = SECTIONS.find((s) => s.id === (demande || "nouveaux"));
  if (!def) {
    naviguer("/courriels", { remplacer: true });
    return { titre: "Courriels", noeud: h("div") };
  }
  if (!etat.droits.ecrire) {
    return { titre: "Courriels", noeud: h("div.courriels", enTete({ titre: "Courriels" }), panneauBloque(raisonBloquee())) };
  }

  let vue = vueConnue();
  let erreurChargement = null;
  let detruit = false;
  let section = null;
  let minuterieDessin = null;
  let minuterieRelecture = null;
  let enMarche = etatAnalyse().enCours;
  let verifie = false;

  const progression = blocAvancement();
  const corps = h("div.courriels__corps");
  const boutonAnalyser = btn("Analyser maintenant", { icone: "rafraichir", onclick: () => lancerAnalyse({ manuel: true }).catch(() => {}) });
  const racine = h("div.courriels", enTete({ titre: "Courriels", sous: "Retrouvez dans vos échanges Gmail les personnes à ajouter à votre CRM.", actions: boutonAnalyser }), corps);

  const P = {
    ctx, memoire: ctx.memoire,
    get vue() {
      return vue;
    },
    /** Après une action : le module a déjà relu la vue ; on redessine tout de suite avec ce qu'il sait. */
    actualiser() {
      vue = vueConnue() || vue;
      dessiner();
    },
  };

  function majBouton(e = etatAnalyse()) {
    const actif = !!vue?.actif;
    boutonAnalyser.hidden = !actif;
    boutonAnalyser.disabled = e.enCours || !!raisonBloquee();
    if (e.enCours) boutonAnalyser.setAttribute("aria-busy", "true");
    else boutonAnalyser.removeAttribute("aria-busy");
    const texte = boutonAnalyser.querySelector("span");
    if (texte) texte.textContent = e.enCours ? "Analyse en cours…" : "Analyser maintenant";
  }

  function reessayer() {
    effacerErreurAnalyse();
    lancerAnalyse({ manuel: true }).catch(() => {});
  }

  function resume() {
    const derniere = vue.derniere;
    return h(
      "p.courriels__etat.muet.petit",
      h("span", `Boîte analysée : ${vue.compte || compteGoogle() || "—"}`),
      h("span", `Période : ${libellePeriode(vue.fenetre_jours)}`),
      h("span", derniere ? `Dernière analyse ${quand(derniere.fin)}` : "Aucune analyse terminée pour l’instant"),
      vue.mode === "auto" ? pastille("Mode automatique", "info") : null
    );
  }

  function sousNavigation() {
    return h(
      "nav.sous-nav",
      { "aria-label": "Sections de la page Courriels" },
      SECTIONS.map((s) => {
        const n = s.compte ? s.compte(vue) : 0;
        return h("a.sous-nav__lien", { href: `#${chemin(s.id)}`, "aria-current": s.id === def.id ? "page" : null }, s.libelle, n ? h("span.sous-nav__compteur", String(n)) : null);
      })
    );
  }

  function bandeaux(blocage) {
    if (blocage) {
      return [
        avis({
          ton: "attention", titre: blocage.titre, texte: blocage.texte,
          actions: blocage.chemin ? btn(blocage.libelleAction, { ton: "primaire", petit: true, href: `#${blocage.chemin}` }) : null,
        }),
      ];
    }
    const e = etatAnalyse();
    if (e.enCours) return [];
    const erreur = e.erreur ? { message: e.erreur.message, quand: "" } : vue.erreur ? { message: vue.erreur.message, quand: quand(vue.erreur.t) } : null;
    if (!erreur) return [];
    return [
      avis({
        ton: "erreur", titre: "L’analyse n’a pas pu se terminer", texte: `${erreur.quand ? `Dernière tentative ${erreur.quand} : ` : ""}${erreur.message}`,
        actions: btn("Réessayer", { petit: true, icone: "rafraichir", onclick: reessayer }),
      }),
    ];
  }

  function contenu() {
    if (!vue) {
      return [
        erreurChargement
          ? etatVide({ icone: "alerte", titre: "Cette page n’a pas pu s’afficher", texte: erreurChargement.message, action: btn("Réessayer", { ton: "primaire", icone: "rafraichir", onclick: () => charger({ force: true }) }) })
          : chargement("Chargement…"),
      ];
    }
    const blocage = raisonBloquee() || (vue.actif && vue.bloque ? blocageDuServeur(vue.bloque) : null);
    if (!vue.actif) {
      return [blocage ? panneauBloque(blocage) : panneauActivation({ vue, surActive: () => P.actualiser() })];
    }
    section = def.monter(P);
    return [...bandeaux(blocage), progression.noeud, resume(), sousNavigation(), section.noeud];
  }

  function dessiner() {
    if (detruit) return;
    const actif = document.activeElement;
    const focus = actif instanceof HTMLElement && corps.contains(actif) ? actif.dataset.focusId || null : null;
    section?.detruire?.();
    section = null;
    corps.replaceChildren(...contenu());
    if (focus) corps.querySelector(`[data-focus-id="${CSS.escape(focus)}"]`)?.focus({ preventScroll: true });
    majBouton();
    verifierAnalyse();
  }

  /** Une analyse est à reprendre ou due : elle démarre toute seule, sans que la personne ait à la demander. */
  function verifierAnalyse() {
    if (verifie || !vue?.actif) return;
    verifie = true;
    if ((vue.analyse || vue.due) && !etatAnalyse().enCours && !raisonBloquee()) lancerAnalyse({ manuel: false }).catch(() => {});
  }

  function planifierDessin() {
    clearTimeout(minuterieDessin);
    minuterieDessin = setTimeout(dessiner, 120);
  }

  async function charger({ force = false } = {}) {
    erreurChargement = null;
    try {
      await chargerVue({ force }); // la vue arrive par l'abonnement ci-dessous
    } catch (e) {
      if (!(e instanceof ErreurApi)) throw e;
      if (!vue) {
        erreurChargement = e;
        dessiner();
      }
    }
  }

  const desabonnerVue = surVue((v) => {
    vue = v;
    planifierDessin();
  });
  const desabonnerAnalyse = surAnalyse((e) => {
    majBouton(e);
    // Au début et à la fin d'une analyse, la page change (bandeau d'erreur, propositions) : on la redessine.
    if (e.enCours !== enMarche) planifierDessin();
    enMarche = e.enCours;
  });

  dessiner();
  if (!vueEstFraiche()) charger();

  return {
    titre: def.id === "nouveaux" ? "Courriels" : `${def.libelle} — Courriels`,
    noeud: racine,
    miseAJour: (changes) => {
      // Les propositions dépendent du contenu du CRM (une personne ajoutée par un collègue n'est plus « nouvelle »).
      if (changes.has("contacts") || changes.has("entreprises")) {
        clearTimeout(minuterieRelecture);
        minuterieRelecture = setTimeout(() => {
          if (!detruit && !vueEstFraiche()) chargerVue({ force: true }).catch(() => {});
        }, 1500);
      }
      if (changes.has("google")) planifierDessin();
      return true;
    },
    detruire: () => {
      detruit = true;
      clearTimeout(minuterieDessin);
      clearTimeout(minuterieRelecture);
      section?.detruire?.();
      progression.detruire();
      desabonnerVue();
      desabonnerAnalyse();
    },
  };
}
