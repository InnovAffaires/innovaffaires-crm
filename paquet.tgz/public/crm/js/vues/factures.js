// Liste des factures et des devis.
import { h } from "../noyau/dom.js";
import { etat, nomFiche } from "../noyau/etat.js";
import { argent, dateCourte } from "../commun/format.js";
import { STATUTS_FACTURE } from "../commun/schema.js";
import { lienFiche } from "../noyau/routeur.js";
import { btn, lienVers } from "../ui/composants.js";
import { creerVueListe } from "./liste.js";
import { etatDocument, pastilleEtatDocument, totauxDe, soldeDu, noeudEcheance } from "./aides.js";

export const depend = ["factures", "entreprises", "config"];

const ETATS = [
  ...STATUTS_FACTURE,
  { id: "acceptee", libelle: "Devis accepté" },
  { id: "refusee", libelle: "Devis refusé" },
  { id: "expiree", libelle: "Devis expiré" },
];
const emise = (f) => f.type !== "devis" && f.statut !== "brouillon" && f.statut !== "annulee";
const anneeDe = (f) => (f.date_emission || f.cree || "").slice(0, 4);

export default creerVueListe({
  entite: "factures",
  titre: "Factures et devis",
  sous: () => "Honoraires facturés, paiements reçus et propositions de prix.",
  nouveau: { libelle: "Nouvelle facture", valeurs: () => ({ type: "facture" }) },
  placeholder: "Rechercher un numéro, un client, un objet…",
  triDefaut: { col: "emission", dir: "desc" },
  href: (f) => lienFiche("factures", f.id),
  vide: { icone: "factures", titre: "Aucune facture pour l’instant", texte: "Créez un devis ou une facture : les taxes (TPS et TVQ) se calculent automatiquement et la numérotation se fait à l’émission." },
  filtres: [
    { id: "type", libelle: "Type", tout: "Factures et devis", options: () => [{ id: "facture", libelle: "Factures" }, { id: "devis", libelle: "Devis" }], test: (f, v) => (f.type || "facture") === v },
    { id: "etat", libelle: "État", tout: "Tous les états", options: () => ETATS, test: (f, v) => etatDocument(f).cle === v },
    {
      id: "annee", libelle: "Année", tout: "Toutes les années",
      options: () => [...new Set((etat.collections.factures || []).filter((f) => !f.supprime).map(anneeDe).filter(Boolean))].sort().reverse().map((a) => ({ id: a, libelle: a })),
      test: (f, v) => anneeDe(f) === v,
    },
  ],
  colonnes: [
    {
      id: "numero", titre: "Numéro", classe: "cellule-titre", valeur: (f) => f.numero || "~",
      rendu: (f) => h("div.identite__texte", h("a", { href: lienFiche("factures", f.id) }, f.numero || (f.type === "devis" ? "Devis (brouillon)" : "Facture (brouillon)")), h("small.muet", f.type === "devis" ? "Devis" : "Facture")),
    },
    { id: "client", titre: "Client", valeur: (f) => nomFiche("entreprises", f.entreprise_id), rendu: (f) => lienVers("entreprises", f.entreprise_id) },
    { id: "objet", titre: "Objet", valeur: (f) => f.objet, rendu: (f) => f.objet || h("span.muet", "—"), mobile: "cache" },
    { id: "emission", titre: "Émission", valeur: (f) => f.date_emission || f.cree || "", rendu: (f) => (f.date_emission ? dateCourte(f.date_emission) : h("span.muet", "—")), mobile: "cache" },
    {
      id: "echeance", titre: "Échéance", valeur: (f) => f.date_echeance || "",
      rendu: (f) => (f.date_echeance ? noeudEcheance(f.date_echeance, { fait: !(emise(f) && soldeDu(f) > 0) }) : h("span.muet", "—")),
    },
    { id: "total", titre: "Total", classe: "num", valeur: (f) => totauxDe(f).total, rendu: (f) => argent(totauxDe(f).total) },
    { id: "solde", titre: "Solde", classe: "num", valeur: (f) => soldeDu(f), rendu: (f) => (emise(f) ? (soldeDu(f) > 0 ? argent(soldeDu(f)) : h("span.muet", "0,00 $")) : h("span.muet", "—")) },
    { id: "etat", titre: "État", valeur: (f) => etatDocument(f).libelle, rendu: (f) => pastilleEtatDocument(f) },
  ],
  pied: (lignes) => {
    const ems = lignes.filter(emise);
    if (!ems.length) return null;
    const total = ems.reduce((n, f) => n + totauxDe(f).total, 0);
    const solde = ems.reduce((n, f) => n + soldeDu(f), 0);
    return h("tr.ligne-total", h("td", { colSpan: 5 }, `${ems.length} facture${ems.length > 1 ? "s" : ""} émise${ems.length > 1 ? "s" : ""} dans cette liste`), h("td.num", argent(total)), h("td.num", argent(solde)), h("td"));
  },
  actions: () =>
    etat.droits.ecrire ? [btn("Nouveau devis", { icone: "document", onclick: async () => (await import("./formulaires.js")).nouvelleFiche("factures", { type: "devis" }) })] : [],
  exporter: {
    nom: "factures-innovaffaires",
    colonnes: [
      { titre: "Type", valeur: (f) => (f.type === "devis" ? "Devis" : "Facture") }, { titre: "Numéro", valeur: (f) => f.numero }, { titre: "Client", valeur: (f) => nomFiche("entreprises", f.entreprise_id) },
      { titre: "Objet", valeur: (f) => f.objet }, { titre: "Date d’émission", valeur: (f) => f.date_emission }, { titre: "Échéance", valeur: (f) => f.date_echeance },
      { titre: "Sous-total", valeur: (f) => totauxDe(f).sous_total }, { titre: "TPS", valeur: (f) => totauxDe(f).tps }, { titre: "TVQ", valeur: (f) => totauxDe(f).tvq },
      { titre: "Total", valeur: (f) => totauxDe(f).total }, { titre: "Payé", valeur: (f) => totauxDe(f).paye }, { titre: "Solde", valeur: (f) => soldeDu(f) },
      { titre: "État", valeur: (f) => etatDocument(f).libelle },
    ],
  },
});
