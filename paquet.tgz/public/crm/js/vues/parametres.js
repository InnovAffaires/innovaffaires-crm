// =============================================================================
// Paramètres : un menu de sections (colonne à gauche, liste sur téléphone) et le
// contenu de la section choisie. Chaque section est un module chargé à la demande
// (vues/parametres/*.js) ; elle gère elle-même son état, d'où l'absence de
// redessin automatique : une saisie en cours ne doit jamais être perdue.
// =============================================================================
import { h } from "../noyau/dom.js";
import { icone } from "../noyau/icones.js";
import { etat } from "../noyau/etat.js";
import { enTete, etatVide, btn, avis } from "../ui/composants.js";

export const depend = [];

/** niveau : "tous" | "ecriture" (peut modifier des fiches) | "admin" */
export const SECTIONS = [
  {
    groupe: "Mon compte",
    items: [
      { id: "profil", libelle: "Profil et apparence", icone: "utilisateur", sous: "Votre nom, l’apparence du CRM et les notifications.", niveau: "tous", charger: () => import("./parametres/profil.js") },
      { id: "securite", libelle: "Mot de passe et sécurité", icone: "cadenas", sous: "Mot de passe, double vérification et codes de récupération.", niveau: "tous", charger: () => import("./parametres/securite.js") },
    ],
  },
  {
    groupe: "Mon entreprise",
    items: [
      { id: "entreprise", libelle: "Entreprise", icone: "entreprises", sous: "Nom, coordonnées et numéros de taxes inscrits sur vos factures.", niveau: "admin", charger: () => import("./parametres/entreprise.js") },
      { id: "facturation", libelle: "Facturation et honoraires", icone: "factures", sous: "Taxes, numérotation, conditions de paiement et tarifs habituels.", niveau: "admin", charger: () => import("./parametres/facturation.js") },
    ],
  },
  {
    groupe: "Fonctionnement",
    items: [
      { id: "etapes", libelle: "Étapes et statuts", icone: "affaires", sous: "Les étapes d’une affaire et les statuts d’un dossier de financement.", niveau: "admin", charger: () => import("./parametres/etapes.js") },
      { id: "listes", libelle: "Provenances et étiquettes", icone: "etoile", sous: "D’où viennent vos clients, et les étiquettes pour les classer.", niveau: "admin", charger: () => import("./parametres/listes.js") },
      { id: "taches", libelle: "Tâches automatiques", icone: "liste-verif", sous: "Les tâches créées quand un dossier change de statut.", niveau: "admin", charger: () => import("./parametres/taches.js") },
      { id: "courriels", libelle: "Gabarits de courriel", icone: "courriel", sous: "Vos messages types, avec les champs qui se remplissent seuls.", niveau: "admin", charger: () => import("./parametres/courriels.js") },
      { id: "demandes", libelle: "Demandes du site", icone: "demandes", sous: "Délai de réponse, jours fériés et alertes par courriel.", niveau: "admin", charger: () => import("./parametres/demandes.js") },
      { id: "calendrier", libelle: "Calendrier externe", icone: "calendrier", sous: "Voir vos rendez-vous et échéances dans Google, Apple ou Outlook.", niveau: "admin", charger: () => import("./parametres/calendrier.js") },
    ],
  },
  {
    groupe: "Administration",
    items: [
      { id: "equipe", libelle: "Équipe et accès", icone: "contacts", sous: "Ajouter des personnes, changer leur rôle ou fermer un accès.", niveau: "admin", charger: () => import("./parametres/equipe.js") },
      { id: "securite-org", libelle: "Sécurité de l’organisation", icone: "bouclier", sous: "Double vérification obligatoire et durée des sessions.", niveau: "admin", charger: () => import("./parametres/securite-org.js") },
      { id: "journal", libelle: "Journal d’activité", icone: "historique", sous: "Qui a fait quoi, et quand.", niveau: "admin", charger: () => import("./parametres/journal.js") },
      { id: "sauvegardes", libelle: "Sauvegardes et exemples", icone: "sauvegarde", sous: "Copier vos données, les restaurer, charger ou retirer les exemples.", niveau: "admin", charger: () => import("./parametres/sauvegardes.js") },
      { id: "confidentialite", libelle: "Vie privée (Loi 25)", icone: "carte-id", sous: "Conservation, accès aux renseignements et anonymisation.", niveau: "admin", charger: () => import("./parametres/confidentialite.js") },
    ],
  },
  {
    groupe: "Données",
    items: [
      { id: "importer", libelle: "Importer des contacts", icone: "televerser", sous: "Reprendre une liste de contacts ou d’entreprises depuis un fichier.", niveau: "ecriture", charger: () => import("./parametres/importer.js") },
      { id: "apropos", libelle: "État du système", icone: "info", sous: "Version, stockage et vérification du bon fonctionnement.", niveau: "tous", charger: () => import("./parametres/apropos.js") },
    ],
  },
];

const permis = (s) => s.niveau === "tous" || (s.niveau === "ecriture" && etat.droits.ecrire) || (s.niveau === "admin" && etat.droits.administrer);

export const sectionsPermises = () => SECTIONS.map((g) => ({ ...g, items: g.items.filter(permis) })).filter((g) => g.items.length);
export const trouverSection = (id) => SECTIONS.flatMap((g) => g.items).find((s) => s.id === id) || null;

function menu(groupes, actifId, defautId) {
  return h(
    "nav.reglages__nav",
    { "aria-label": "Sections des paramètres" },
    groupes.map((g) =>
      h(
        "div.reglages__groupe",
        h("p.reglages__groupe-titre", g.groupe),
        h(
          "ul",
          g.items.map((s) =>
            h(
              "li",
              h(
                "a.reglages__lien",
                { href: `#/parametres/${s.id}`, class: { "reglages__lien--defaut": s.id === defautId }, "aria-current": s.id === actifId ? "page" : null },
                icone(s.icone),
                h("span.reglages__lien-texte", h("strong", s.libelle), h("small", s.sous))
              )
            )
          )
        )
      )
    )
  );
}

export default async function vueParametres(ctx) {
  const idDemande = ctx.params.section || null;
  const groupes = sectionsPermises();
  const toutes = groupes.flatMap((g) => g.items);
  const demandee = idDemande ? trouverSection(idDemande) : null;
  // Sans section dans l'adresse : sur un grand écran, la première section s'affiche ; sur téléphone, seul le menu.
  const section = idDemande ? (demandee && permis(demandee) ? demandee : null) : toutes[0];
  const mode = idDemande ? "section" : "index";

  const contenu = h("div.reglages__contenu");
  let detruire = null;

  if (idDemande && !demandee) {
    contenu.append(etatVide({ icone: "recherche", titre: "Cette section n’existe pas", texte: "Choisissez une section dans le menu.", action: btn("Retour aux paramètres", { ton: "primaire", href: "#/parametres" }) }));
  } else if (idDemande && !section) {
    contenu.append(h("div.pile", h("h2.reglages__titre", demandee.libelle), avis({ ton: "attention", titre: "Section réservée", texte: "Seules les personnes qui administrent le CRM peuvent modifier ces réglages." })));
  } else {
    contenu.append(
      h("a.retour.reglages__retour", { href: "#/parametres" }, icone("retour", "ic--p"), "Paramètres"),
      h("header.reglages__tete", h("h2.reglages__titre", section.libelle), h("p.reglages__intro.muet", section.sous))
    );
    try {
      const module = await section.charger();
      const rendu = await module.default({ section, ctx });
      const noeud = rendu instanceof Node ? rendu : rendu.noeud;
      detruire = rendu instanceof Node ? null : rendu.detruire || null;
      contenu.append(h("div.reglages__corps", noeud));
    } catch (e) {
      console.error(`[paramètres/${section.id}]`, e);
      contenu.append(avis({ ton: "erreur", titre: "Cette section n’a pas pu s’afficher", texte: "Rechargez la page. Si le problème revient, signalez-le avec le nom de la section." }));
    }
  }

  return {
    titre: section && idDemande ? `${section.libelle} — Paramètres` : "Paramètres",
    noeud: h(
      "div",
      enTete({ titre: "Paramètres", sous: "Réglez le CRM selon votre façon de travailler." }),
      h("div.reglages", { dataset: { mode } }, menu(groupes, idDemande && section ? section.id : null, !idDemande && section ? section.id : null), contenu)
    ),
    detruire: () => detruire?.(),
  };
}
