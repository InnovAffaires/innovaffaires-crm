// Sécurité du compte : mot de passe, double vérification, codes de récupération.
import { h } from "../../noyau/dom.js";
import { icone } from "../../noyau/icones.js";
import { etat, appliquerSession } from "../../noyau/etat.js";
import { envoyer, lire, ErreurApi } from "../../noyau/api.js";
import { btn, champMotDePasse, avis, panneau } from "../../ui/composants.js";
import { ouvrirDialogue } from "../../ui/dialogue.js";
import { blocActivation2fa, montrerCodesRecuperation } from "../acces.js";
import { demanderMotDePasse } from "./commun.js";

async function relireSession() {
  const rep = await lire("/session");
  appliquerSession(rep);
}

// ----- Mot de passe -------------------------------------------------------------------------------------
function panneauMotDePasse() {
  const alerte = h("div.formulaire__alerte", { role: "alert", hidden: true });
  const statut = h("span.reglages__statut", { role: "status", "aria-live": "polite" });
  const cActuel = champMotDePasse({ libelle: "Mot de passe actuel", autocomplete: "current-password" });
  const cNouveau = champMotDePasse({ libelle: "Nouveau mot de passe", autocomplete: "new-password", aide: "12 caractères au minimum. Une phrase de quelques mots sans lien entre eux est idéale." });
  const cConf = champMotDePasse({ libelle: "Confirmez le nouveau mot de passe", autocomplete: "new-password" });
  const bouton = btn("Changer le mot de passe", { ton: "primaire", type: "submit" });
  const champs = { actuel: cActuel, nouveau: cNouveau };

  async function soumettre(e) {
    e.preventDefault();
    alerte.hidden = true;
    statut.textContent = "";
    for (const c of [cActuel, cNouveau, cConf]) c.erreur(null);
    if (!cActuel.lire()) return (cActuel.erreur("Entrez votre mot de passe actuel."), cActuel.focus());
    if (!cNouveau.lire()) return (cNouveau.erreur("Choisissez un nouveau mot de passe."), cNouveau.focus());
    if (cNouveau.lire() !== cConf.lire()) return (cConf.erreur("Les deux mots de passe ne sont pas identiques."), cConf.focus());
    bouton.disabled = true;
    bouton.setAttribute("aria-busy", "true");
    try {
      await envoyer("/mot-de-passe", { actuel: cActuel.lire(), nouveau: cNouveau.lire() });
      for (const c of [cActuel, cNouveau, cConf]) c.input.value = "";
      statut.replaceChildren(icone("coche", "ic--p"), " Mot de passe changé. Vos autres appareils ont été déconnectés.");
    } catch (err) {
      if (!(err instanceof ErreurApi)) throw err;
      let premier = null;
      for (const [k, m] of Object.entries(err.champs || {})) {
        if (champs[k]) {
          champs[k].erreur(m);
          premier ||= champs[k];
        }
      }
      alerte.hidden = false;
      alerte.textContent = premier ? "Un champ est à corriger." : err.message;
      premier?.focus();
    } finally {
      bouton.disabled = false;
      bouton.removeAttribute("aria-busy");
    }
  }

  return panneau(
    { titre: "Mot de passe", sous: "En le changeant, vous fermez aussi vos sessions ouvertes sur vos autres appareils.", niveau: 3 },
    h("form.formulaire", { novalidate: true, onsubmit: soumettre }, alerte, h("div.grille.grille--1.grille--etroite", cActuel.noeud, cNouveau.noeud, cConf.noeud), h("div.reglages__pied", statut, bouton))
  );
}

// ----- Double vérification -------------------------------------------------------------------------------
function panneau2fa() {
  const corps = h("div.pile");
  const exigee = !!etat.config?.securite?.double_facteur_obligatoire;

  function dessiner() {
    corps.replaceChildren();
    if (etat.utilisateur.mfa) {
      corps.append(
        avis({ ton: "ok", titre: "La double vérification est activée", texte: "À chaque connexion, le CRM demande aussi le code de votre application d’authentification." }),
        exigee
          ? h("p.muet", "Votre organisation l’exige : elle ne peut pas être désactivée.")
          : h("div.actions-ligne", btn("Désactiver la double vérification…", { ton: "danger", onclick: desactiver }))
      );
      return;
    }
    corps.append(
      h("p", "Un deuxième verrou protège votre compte : en plus du mot de passe, il faut un code à 6 chiffres affiché par une application sur votre téléphone. Même si quelqu’un découvre votre mot de passe, il ne pourra pas entrer."),
      h("div.actions-ligne", btn("Activer la double vérification", { ton: "primaire", icone: "bouclier", onclick: activer }))
    );
  }

  function activer() {
    corps.replaceChildren(
      blocActivation2fa({
        utilisateur: etat.utilisateur,
        surActive: async (codes) => {
          await relireSession().catch(() => {});
          if (codes?.length) corps.replaceChildren(montrerCodesRecuperation({ codes, integre: true, surTermine: () => (rafraichirTout(), dessiner()) }));
          else {
            rafraichirTout();
            dessiner();
          }
        },
      }),
      h("div.actions-ligne", btn("Annuler", { onclick: dessiner }))
    );
  }

  async function desactiver() {
    const ok = await demanderMotDePasse({
      titre: "Désactiver la double vérification ?", message: "Votre compte ne sera plus protégé que par votre mot de passe. Confirmez avec votre mot de passe.",
      libelleAction: "Désactiver", ton: "danger", action: (mdp) => envoyer("/2fa/desactiver", { mot_de_passe: mdp }),
    });
    if (!ok) return;
    await relireSession().catch(() => {});
    rafraichirTout();
    dessiner();
  }

  dessiner();
  return panneau({ titre: "Double vérification", niveau: 3 }, corps);
}

// ----- Codes de récupération ------------------------------------------------------------------------------
let rafraichirCodes = () => {};
const rafraichirTout = () => rafraichirCodes();

function panneauCodes() {
  const corps = h("div.pile");

  function dessiner() {
    const n = etat.utilisateur.codes_restants ?? 0;
    corps.replaceChildren(
      h("p", "Si vous perdez votre mot de passe ou votre téléphone, un code de récupération vous permet de rentrer dans votre compte. Chaque code ne sert qu’une fois."),
      h("p", h("strong", `${n} code${n > 1 ? "s" : ""} de récupération restant${n > 1 ? "s" : ""}.`), n <= 2 ? h("span.muet", " Pensez à en générer de nouveaux.") : null),
      h("div.actions-ligne", btn("Générer de nouveaux codes…", { icone: "cle", onclick: regenerer })),
      h("p.muet.petit", "Les anciens codes cessent de fonctionner dès que de nouveaux sont générés.")
    );
  }

  async function regenerer() {
    const r = await demanderMotDePasse({
      titre: "Générer de nouveaux codes ?", message: "Les codes actuels seront remplacés. Confirmez avec votre mot de passe.", libelleAction: "Générer",
      action: (mdp) => envoyer("/codes-recuperation", { mot_de_passe: mdp }),
    });
    if (!r || !r.codes) return;
    await ouvrirDialogue({
      titre: "Vos nouveaux codes de récupération", taille: "moyen", fermable: false,
      contenu: (ctx) => montrerCodesRecuperation({ codes: r.codes, integre: true, surTermine: () => ctx.fermer(true) }),
    }).promesse;
    await relireSession().catch(() => {});
    dessiner();
  }

  rafraichirCodes = dessiner;
  dessiner();
  return panneau({ titre: "Codes de récupération", niveau: 3 }, corps);
}

export default async function securite() {
  return h("div.pile.pile--l", panneauMotDePasse(), panneau2fa(), panneauCodes());
}
