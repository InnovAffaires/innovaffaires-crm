// =============================================================================
// Pièces communes des sections de Paramètres : enregistrement de la
// configuration, panneaux de formulaire, listes modifiables, fenêtres qui
// demandent le mot de passe ou affichent un secret une seule fois.
// =============================================================================
import { h } from "../../noyau/dom.js";
import { icone } from "../../noyau/icones.js";
import { annoncer, copierTexte } from "../../noyau/dom.js";
import { etat, notifier } from "../../noyau/etat.js";
import { modifier, ErreurApi } from "../../noyau/api.js";
import { synchroniser } from "../../noyau/synchro.js";
import { validerValeur } from "../../commun/valider.js";
import { btn, btnIcone, champMotDePasse, panneau } from "../../ui/composants.js";
import { creerChamp } from "../../ui/formulaire.js";
import { ouvrirDialogue } from "../../ui/dialogue.js";

export const enc = encodeURIComponent;

// ----- Enregistrement de la configuration ---------------------------------------------------------------
/**
 * Enregistre une ou plusieurs sections de la configuration (administrateur) et met à jour la copie locale.
 * En cas de modification simultanée par un autre administrateur, recharge la configuration et prévient.
 */
export async function enregistrerConfig(patch) {
  try {
    const rep = await modifier("/config", { ...patch, v: etat.config.v });
    etat.config = rep.config;
    notifier("config");
    return rep.config;
  } catch (e) {
    if (e instanceof ErreurApi && e.estConflit) {
      await synchroniser({ complet: true }).catch(() => {});
      throw new ErreurApi("Un autre administrateur vient de modifier les paramètres. Vérifiez vos valeurs, puis enregistrez de nouveau.", { statut: 409, code: "conflit" });
    }
    throw e;
  }
}

// ----- Lecture et validation d'un champ ------------------------------------------------------------------
const NUMERIQUES = new Set(["nombre", "montant", "pourcent"]);

/** Lit un champ créé par creerChamp et le valide : { valeur } ou { erreur }. Un champ facultatif vide donne "" (ou null pour un nombre). */
export function lireChamp(champ, { requis = !!champ.spec.requis, config = etat.config } = {}) {
  const { spec } = champ;
  const brut = champ.lire();
  if (spec.type === "booleen") return { valeur: !!brut };
  if (spec.type === "multi") return validerValeur(spec, brut, { config });
  if (brut === null || brut === undefined || (typeof brut === "string" && brut.trim() === "")) {
    if (requis) return { erreur: "Ce champ est obligatoire." };
    return { valeur: NUMERIQUES.has(spec.type) ? null : "" };
  }
  return validerValeur(spec, brut, { config });
}

// ----- Panneau de formulaire --------------------------------------------------------------------------
/**
 * panneauFormulaire({ titre, sous, groupes, enregistrer, libelle, succes })
 *   groupes : [{ titre?, aide?, colonnes?, champs: [{ cle, spec, valeur, opts?, requis? }] }]
 *   enregistrer(valeurs) : Promise — reçoit les valeurs validées ; une ErreurApi est affichée dans le panneau.
 * Retourne { noeud, champs, lire() }.
 */
export function panneauFormulaire({ titre, sous = null, groupes, enregistrer, libelle = "Enregistrer", succes = "Enregistré.", desactive = false, actionsPied = null, niveau = 3 }) {
  const champs = new Map();
  const alerte = h("div.formulaire__alerte", { role: "alert", hidden: true });
  const statut = h("span.reglages__statut", { role: "status", "aria-live": "polite" });
  let minuteur = null;

  const sections = groupes.map((g) => {
    const grille = h("div.grille", { class: `grille--${g.colonnes || 2}` });
    for (const d of g.champs) {
      const c = creerChamp(d.cle, d.spec, d.valeur, { ...(d.opts || {}), requis: d.requis ?? d.opts?.requis ?? d.spec.requis, desactive: desactive || d.opts?.desactive });
      champs.set(d.cle, { ...c, def: d });
      if (d.etendu) c.noeud.classList.add("champ--etendu");
      grille.append(c.noeud);
    }
    return h("section.groupe", g.titre ? h("h4.groupe__titre", g.titre) : null, g.aide ? h("p.groupe__aide", g.aide) : null, grille);
  });

  const bouton = btn(libelle, { ton: "primaire", type: "submit", desactive });

  function lire() {
    const valeurs = {};
    const erreurs = {};
    for (const [cle, c] of champs) {
      const r = lireChamp(c, { requis: c.def.requis ?? c.def.opts?.requis ?? c.spec.requis });
      if (r.erreur) erreurs[cle] = r.erreur;
      else valeurs[cle] = r.valeur;
    }
    return { valeurs, erreurs };
  }

  function montrerErreurs(erreurs, message = null) {
    for (const c of champs.values()) c.erreur(null);
    let premier = null;
    for (const [k, m] of Object.entries(erreurs)) {
      const c = champs.get(k);
      if (!c) continue;
      c.erreur(m);
      premier ||= c;
    }
    alerte.hidden = !message && !premier;
    if (!alerte.hidden) alerte.replaceChildren(h("strong", message || (Object.keys(erreurs).length === 1 ? "Un champ est à corriger." : "Certains champs sont à corriger.")));
    premier?.focus();
  }

  async function soumettre(e) {
    e?.preventDefault();
    clearTimeout(minuteur);
    statut.textContent = "";
    montrerErreurs({});
    const { valeurs, erreurs } = lire();
    if (Object.keys(erreurs).length) return montrerErreurs(erreurs);
    bouton.disabled = true;
    bouton.setAttribute("aria-busy", "true");
    try {
      await enregistrer(valeurs);
      statut.replaceChildren(icone("coche", "ic--p"), ` ${succes}`);
      minuteur = setTimeout(() => (statut.textContent = ""), 7000);
    } catch (err) {
      if (!(err instanceof ErreurApi)) throw err;
      const parChamp = {};
      for (const [k, m] of Object.entries(err.champs || {})) if (champs.has(k)) parChamp[k] = m;
      // Le message du serveur redit souvent celui du champ : on ne l'affiche en haut que s'il n'est lié à aucun champ.
      montrerErreurs(parChamp, Object.keys(parChamp).length ? null : err.message);
    } finally {
      bouton.disabled = desactive;
      bouton.removeAttribute("aria-busy");
    }
  }

  const form = h(
    "form.formulaire",
    { novalidate: true, autocomplete: "off", onsubmit: soumettre },
    alerte,
    ...sections,
    desactive ? null : h("div.reglages__pied", statut, actionsPied, bouton)
  );
  form.addEventListener("input", () => (statut.textContent = ""));
  return { noeud: panneau({ titre, sous, niveau }, form), champs, lire };
}

// ----- Identifiants d'éléments de liste --------------------------------------------------------------
/** « Appel découverte » → « appel-decouverte » (unique parmi `utilises`). */
export function slugifier(texte, utilises = new Set(), repli = "element") {
  let base = String(texte || "")
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 26)
    .replace(/-+$/g, "");
  if (!base) base = repli;
  let id = base;
  let n = 2;
  while (utilises.has(id)) id = `${base}-${n++}`;
  return id;
}

// ----- Liste modifiable ---------------------------------------------------------------------------------
/**
 * editeurListe({ items, colonnes, nouveau, idDe, nomPourId, libelleLigne, protege, minimum, maximum, libelleAjout, ordonnable, vide })
 *   colonnes : [{ cle, libelle, spec, largeur?, opts? }]   (spec : même forme que dans le schéma)
 *   compacte : une ligne par élément (étiquettes visibles seulement sur la première) ; sinon une carte par élément, titrée « prefixeLigne N »
 *   protege(valeur) : texte qui explique pourquoi la ligne ne peut pas être retirée, ou null
 * Retourne { noeud, lire() → { valeurs, erreurs }, brut(), definir(items), ajouter(), nombre() }.
 * Une ligne garde son `id` ; une nouvelle ligne reçoit un identifiant tiré de `nomPourId`.
 */
export function editeurListe({
  items = [], colonnes, nouveau, nomPourId = (v) => v.nom || v.titre || v.libelle, libelleLigne = (v, i) => `ligne ${i + 1}`, protege = () => null,
  minimum = 0, maximum = 50, libelleAjout = "Ajouter", ordonnable = true, vide = "Aucun élément pour l’instant.", classe = "", suffixeId = true,
  compacte = false, prefixeLigne = "Élément", elements = ["élément", "éléments"],
}) {
  const lignes = [];
  const liste = h("ol.liste-edit", { class: [classe, { "liste-edit--compacte": compacte }], css: { "--cols": colonnes.filter((c) => !c.etendu).map((c) => c.largeur || "minmax(0, 1fr)").join(" ") } });
  const message = h("p.liste-edit__vide.muet", vide);
  // Un bouton « Retirer » inactif reste atteignable : un clic (ou un appui sur téléphone) explique pourquoi.
  const raison = h("p.liste-edit__raison", { role: "status", "aria-live": "polite", hidden: true });
  const boutonAjout = btn(libelleAjout, { petit: true, icone: "plus", onclick: () => ajouter() });
  const noeud = h("div.liste-edit-bloc", liste, message, raison, h("div.liste-edit__pied", boutonAjout));

  function creerLigne(valeur) {
    const champs = new Map();
    const grille = h("div.liste-edit__champs");
    for (const col of colonnes) {
      const c = creerChamp(col.cle, col.spec, valeur[col.cle], { libelle: col.libelle, ...(col.opts || {}) });
      if (col.etendu) c.noeud.classList.add("champ--etendu");
      champs.set(col.cle, c);
      grille.append(c.noeud);
    }
    const ligne = { valeur, champs, noeud: null, haut: null, bas: null, supprimer: null };
    ligne.haut = btnIcone("haut", "Monter", () => deplacer(ligne, -1));
    ligne.bas = btnIcone("bas", "Descendre", () => deplacer(ligne, 1));
    ligne.supprimer = btnIcone("corbeille", "Retirer", () => retirer(ligne), { classe: "btn-icone--danger" });
    ligne.motifBlocage = null;
    ligne.noeud = h(
      "li.liste-edit__ligne",
      h("div.liste-edit__rang", { "aria-hidden": "true", dataset: { prefixe: prefixeLigne } }),
      h("div.liste-edit__actions", ordonnable ? [ligne.haut, ligne.bas] : null, ligne.supprimer),
      grille
    );
    return ligne;
  }

  function nomLigne(l, i) {
    const v = {};
    for (const [k, c] of l.champs) v[k] = c.lire();
    return libelleLigne({ ...l.valeur, ...v }, i);
  }

  function majEtat() {
    const n = lignes.length;
    message.hidden = n > 0;
    boutonAjout.disabled = n >= maximum;
    lignes.forEach((l, i) => {
      const nom = nomLigne(l, i);
      l.haut.disabled = i === 0;
      l.bas.disabled = i === n - 1;
      l.haut.setAttribute("aria-label", `Monter « ${nom} »`);
      l.haut.title = "Monter";
      l.bas.setAttribute("aria-label", `Descendre « ${nom} »`);
      l.bas.title = "Descendre";
      const motif = protege(l.valeur, l) || (n <= minimum ? `Il faut garder au moins ${minimum} ${minimum > 1 ? elements[1] : elements[0]}.` : null);
      l.motifBlocage = motif;
      if (motif) l.supprimer.setAttribute("aria-disabled", "true");
      else l.supprimer.removeAttribute("aria-disabled");
      l.supprimer.setAttribute("aria-label", `Retirer « ${nom} »`);
      l.supprimer.title = motif || "Retirer";
    });
  }

  function placer(l) {
    liste.append(l.noeud);
  }

  function deplacer(l, sens) {
    raison.hidden = true;
    const i = lignes.indexOf(l);
    const j = i + sens;
    if (j < 0 || j >= lignes.length) return;
    lignes.splice(i, 1);
    lignes.splice(j, 0, l);
    liste.replaceChildren(...lignes.map((x) => x.noeud));
    majEtat();
    (sens < 0 ? l.haut : l.bas).focus();
    annoncer(`« ${nomLigne(l, j)} » déplacé en position ${j + 1} sur ${lignes.length}.`);
  }

  function retirer(l) {
    const i = lignes.indexOf(l);
    if (i < 0) return;
    const nom = nomLigne(l, i);
    if (l.motifBlocage) {
      raison.hidden = false;
      raison.textContent = `« ${nom} » ne peut pas être retiré : ${l.motifBlocage.charAt(0).toLowerCase()}${l.motifBlocage.slice(1)}`;
      return;
    }
    raison.hidden = true;
    lignes.splice(i, 1);
    l.noeud.remove();
    majEtat();
    (lignes[Math.min(i, lignes.length - 1)]?.champs.values().next().value?.controle || boutonAjout).focus();
    annoncer(`« ${nom} » retiré. Enregistrez pour confirmer.`);
  }

  function ajouter(valeur = nouveau(), { focus = true } = {}) {
    if (lignes.length >= maximum) return null;
    raison.hidden = true;
    const l = creerLigne(valeur);
    lignes.push(l);
    placer(l);
    majEtat();
    if (focus) l.champs.values().next().value?.focus();
    return l;
  }

  function definir(nouveaux) {
    lignes.length = 0;
    liste.replaceChildren();
    for (const v of nouveaux) ajouter(v, { focus: false });
    majEtat();
  }

  liste.addEventListener("input", majEtat);
  liste.addEventListener("change", majEtat);
  definir(items);

  function lire() {
    const valeurs = [];
    const erreurs = {};
    const ids = new Set(lignes.map((l) => l.valeur.id).filter(Boolean));
    lignes.forEach((l, i) => {
      const v = {};
      for (const col of colonnes) {
        const c = l.champs.get(col.cle);
        const r = lireChamp(c, { requis: col.opts?.requis ?? col.spec.requis });
        c.erreur(r.erreur || null);
        if (r.erreur) erreurs[`${i}.${col.cle}`] = r.erreur;
        else v[col.cle] = r.valeur;
      }
      if (suffixeId) {
        if (l.valeur.id) v.id = l.valeur.id;
        else {
          v.id = slugifier(nomPourId({ ...l.valeur, ...v }), ids);
          ids.add(v.id);
        }
      }
      valeurs.push(v);
    });
    return { valeurs, erreurs };
  }

  /** Valeurs saisies telles quelles, sans validation ni message d'erreur. */
  const brut = () => lignes.map((l) => Object.fromEntries([...l.champs].map(([k, c]) => [k, c.lire()])));

  return { noeud, lire, brut, definir, ajouter, nombre: () => lignes.length, premierChampEnErreur: () => lignes.flatMap((l) => [...l.champs.values()]).find((c) => c.noeud.classList.contains("champ--erreur")) || null };
}

// ----- Panneau d'une liste modifiable ---------------------------------------------------------------
/**
 * panneauListeEditable({ titre, sous, intro, editeur, valider, enregistrer, succes, actionsPied })
 *   editeur : résultat de editeurListe ; valider(valeurs) : message d'erreur portant sur l'ensemble de la liste, ou null.
 *   enregistrer(valeurs) : Promise qui retourne les valeurs enregistrées (la liste est alors redessinée avec leurs identifiants).
 * Retourne { noeud, statut }.
 */
export function panneauListeEditable({ titre, sous = null, intro = null, editeur, valider = () => null, enregistrer, succes = "Enregistré.", actionsPied = null, libelle = "Enregistrer", niveau = 3 }) {
  const alerte = h("div.formulaire__alerte", { role: "alert", hidden: true });
  const statut = h("span.reglages__statut", { role: "status", "aria-live": "polite" });
  const bouton = btn(libelle, { ton: "primaire", type: "submit" });
  let minuteur = null;

  const montrer = (message) => {
    alerte.hidden = !message;
    alerte.textContent = message || "";
  };

  async function soumettre(e) {
    e?.preventDefault();
    clearTimeout(minuteur);
    statut.textContent = "";
    montrer(null);
    const { valeurs, erreurs } = editeur.lire();
    const n = Object.keys(erreurs).length;
    if (n) {
      montrer(n === 1 ? "Un champ est à corriger." : "Certains champs sont à corriger.");
      editeur.premierChampEnErreur()?.focus();
      return;
    }
    const probleme = valider(valeurs);
    if (probleme) return montrer(probleme);
    bouton.disabled = true;
    bouton.setAttribute("aria-busy", "true");
    try {
      const enregistrees = await enregistrer(valeurs);
      if (Array.isArray(enregistrees)) editeur.definir(enregistrees);
      statut.replaceChildren(icone("coche", "ic--p"), ` ${succes}`);
      minuteur = setTimeout(() => (statut.textContent = ""), 7000);
    } catch (err) {
      if (!(err instanceof ErreurApi)) throw err;
      montrer(err.message);
    } finally {
      bouton.disabled = false;
      bouton.removeAttribute("aria-busy");
    }
  }

  const form = h(
    "form.formulaire",
    { novalidate: true, autocomplete: "off", onsubmit: soumettre },
    intro ? h("div.pile.pile--s", intro) : null,
    alerte,
    editeur.noeud,
    h("div.reglages__pied", statut, actionsPied, bouton)
  );
  form.addEventListener("input", () => (statut.textContent = ""));
  return { noeud: panneau({ titre, sous, niveau }, form), statut };
}

// ----- Fenêtres ---------------------------------------------------------------------------------------------
/** Zone d'erreur à l'intérieur d'une fenêtre (les notifications restent derrière les fenêtres). */
export function zoneErreurDialogue() {
  const z = h("div.formulaire__alerte", { role: "alert", hidden: true });
  return {
    noeud: z,
    afficher(msg) {
      z.hidden = !msg;
      z.textContent = msg || "";
    },
  };
}

/**
 * Demande le mot de passe avant une action sensible. `action(mdp)` s'exécute dans la fenêtre :
 * en cas d'erreur, le message reste affiché dedans. La promesse reçoit la valeur retournée (ou undefined si annulé).
 */
export function demanderMotDePasse({ titre, message, libelleAction, ton = "primaire", action }) {
  return ouvrirDialogue({
    titre, taille: "petit",
    contenu: (ctx) => {
      const c = champMotDePasse({ libelle: "Votre mot de passe", autocomplete: "current-password" });
      const zone = zoneErreurDialogue();
      async function soumettre() {
        zone.afficher("");
        c.erreur(null);
        if (!c.lire()) {
          c.erreur("Entrez votre mot de passe.");
          c.focus();
          return;
        }
        ctx.occupe(true);
        try {
          const r = await action(c.lire());
          ctx.occupe(false);
          ctx.fermer(r === undefined ? true : r);
        } catch (e) {
          ctx.occupe(false);
          if (!(e instanceof ErreurApi)) throw e;
          if (e.champs?.mdp) c.erreur(e.champs.mdp);
          else zone.afficher(e.message);
          c.focus();
        }
      }
      ctx.definirPied(btn("Annuler", { onclick: () => ctx.fermer(undefined) }), btn(libelleAction, { ton, onclick: soumettre }));
      return h("form", { novalidate: true, onsubmit: (e) => (e.preventDefault(), soumettre()) }, h("p", message), zone.noeud, c.noeud);
    },
  }).promesse;
}

/** Affiche une valeur secrète (mot de passe temporaire…) une seule fois, avec un bouton pour la copier. */
export function afficherSecret({ titre, message, secret, etiquette = "À transmettre", suite = null }) {
  return ouvrirDialogue({
    titre, taille: "petit",
    contenu: (ctx) => {
      ctx.definirPied(btn("J’ai noté ce mot de passe", { ton: "primaire", onclick: () => ctx.fermer(true) }));
      return h(
        "div.pile",
        h("p", message),
        h("div.secret", h("p.secret__etiquette", etiquette), h("code.secret__valeur", secret)),
        h("div.actions-ligne", btn("Copier", { petit: true, icone: "copier", onclick: async (e) => { const b = e.currentTarget; const ok = await copierTexte(secret); b.querySelector("span").textContent = ok ? "Copié" : "Copie impossible : sélectionnez le texte"; } })),
        suite ? h("p.muet.petit", suite) : null
      );
    },
  }).promesse;
}

/** Petit paragraphe d'aide sous un titre de section. */
export const note = (texte) => h("p.reglages__note.muet", texte);
