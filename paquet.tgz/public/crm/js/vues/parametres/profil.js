// Profil de la personne connectée : nom, apparence, page de départ, notifications.
import { h } from "../../noyau/dom.js";
import { icone } from "../../noyau/icones.js";
import { etat, notifier } from "../../noyau/etat.js";
import { modifier, ErreurApi } from "../../noyau/api.js";
import { chargerEquipe } from "../../noyau/synchro.js";
import { appliquerTheme, appliquerDensite, lireTheme } from "../../noyau/theme.js";
import { btn, listeDef, panneau } from "../../ui/composants.js";
import { creerChamp } from "../../ui/formulaire.js";
import { panneauFormulaire, note } from "./commun.js";

const ROLES = { admin: "Administrateur", standard: "Utilisateur", lecture: "Lecture seule" };

async function enregistrerPreferences(patch) {
  const rep = await modifier("/moi", { preferences: patch });
  etat.utilisateur = { ...etat.utilisateur, ...rep.utilisateur };
  notifier("session");
  return rep.utilisateur;
}

/** Panneau « Apparence » : chaque choix s'applique tout de suite et s'enregistre sans bouton. */
function panneauApparence() {
  const prefs = etat.utilisateur.preferences || {};
  const statut = h("p.reglages__statut.reglages__statut--bloc", { role: "status", "aria-live": "polite" });
  const alerte = h("div.formulaire__alerte", { role: "alert", hidden: true });
  let minuteur = null;

  async function sauver(patch, avant) {
    alerte.hidden = true;
    try {
      await enregistrerPreferences(patch);
      statut.replaceChildren(icone("coche", "ic--p"), " Préférence enregistrée.");
      clearTimeout(minuteur);
      minuteur = setTimeout(() => (statut.textContent = ""), 5000);
    } catch (e) {
      if (!(e instanceof ErreurApi)) throw e;
      avant?.();
      statut.textContent = "";
      alerte.hidden = false;
      alerte.textContent = `La préférence n’a pas pu être enregistrée : ${e.message}`;
    }
  }

  const theme = creerChamp(
    "theme",
    { type: "choix", libelle: "Apparence", options: [{ id: "auto", libelle: "Automatique (comme votre appareil)" }, { id: "clair", libelle: "Clair" }, { id: "sombre", libelle: "Sombre" }] },
    prefs.theme || lireTheme(),
    { requis: true }
  );
  const densite = creerChamp(
    "densite",
    { type: "choix", libelle: "Densité des listes", options: [{ id: "confortable", libelle: "Confortable" }, { id: "compacte", libelle: "Compacte (plus de lignes à l’écran)" }] },
    prefs.densite === "compacte" ? "compacte" : "confortable",
    { requis: true }
  );
  const depart = creerChamp(
    "vue_initiale",
    {
      type: "choix", libelle: "Page de départ",
      options: [{ id: "accueil", libelle: "Accueil" }, { id: "demandes", libelle: "Demandes" }, { id: "taches", libelle: "Tâches" }, { id: "affaires", libelle: "Affaires" }, { id: "dossiers", libelle: "Dossiers" }],
    },
    prefs.vue_initiale || "accueil",
    { requis: true, aide: "L’écran qui s’ouvre quand vous entrez dans le CRM." }
  );

  let themeAvant = theme.lire();
  theme.noeud.addEventListener("change", () => {
    const v = theme.lire();
    const precedent = themeAvant;
    appliquerTheme(v);
    themeAvant = v;
    sauver({ theme: v }, () => {
      appliquerTheme(precedent);
      theme.definir(precedent);
      themeAvant = precedent;
    });
  });
  let densiteAvant = densite.lire();
  densite.noeud.addEventListener("change", () => {
    const v = densite.lire();
    const precedent = densiteAvant;
    appliquerDensite(v);
    densiteAvant = v;
    sauver({ densite: v }, () => {
      appliquerDensite(precedent);
      densite.definir(precedent);
      densiteAvant = precedent;
    });
  });
  depart.noeud.addEventListener("change", () => sauver({ vue_initiale: depart.lire() }));

  return panneau(
    { titre: "Apparence et démarrage", sous: "Ces choix ne concernent que vous et s’appliquent tout de suite.", niveau: 3 },
    h("div.formulaire", alerte, h("div.grille.grille--2", theme.noeud, densite.noeud, depart.noeud), statut)
  );
}

/** Panneau « Notifications » : autorisation du navigateur et préférence. */
function panneauNotifications() {
  const corps = h("div.pile");
  const pris = !("Notification" in window);

  function dessiner() {
    corps.replaceChildren();
    if (pris) {
      corps.append(note("Ce navigateur ne permet pas d’afficher des notifications."));
      return;
    }
    const permission = Notification.permission;
    const active = (etat.utilisateur.preferences || {}).notifications !== false;
    corps.append(
      h(
        "p",
        "Quand le CRM est ouvert dans un onglet que vous ne regardez pas, une notification apparaît à chaque nouvelle demande reçue par le site. ",
        h("span.muet", "Elle ne fonctionne que si le CRM reste ouvert dans le navigateur.")
      )
    );
    if (permission === "granted") {
      const c = creerChamp("notifications", { type: "booleen", libelle: "Me prévenir des nouvelles demandes" }, active, {});
      c.noeud.addEventListener("change", async () => {
        try {
          await enregistrerPreferences({ notifications: c.lire() });
        } catch (e) {
          if (!(e instanceof ErreurApi)) throw e;
          c.definir(!c.lire());
          corps.append(h("p.champ__erreur", { role: "alert" }, e.message));
        }
      });
      corps.append(c.noeud);
    } else if (permission === "denied") {
      corps.append(h("p.avis-simple", "Les notifications sont bloquées pour ce site. Pour les autoriser, ouvrez les réglages du site dans la barre d’adresse de votre navigateur (le cadenas), puis choisissez « Autoriser » pour les notifications."));
    } else {
      corps.append(
        h(
          "div.actions-ligne",
          btn("Activer les notifications", {
            ton: "primaire", icone: "cloche",
            onclick: async () => {
              try {
                await Notification.requestPermission();
              } catch {
                /* ancien navigateur : le résultat se lit ensuite dans Notification.permission */
              }
              dessiner();
            },
          })
        )
      );
    }
  }
  dessiner();
  return panneau({ titre: "Notifications", niveau: 3 }, corps);
}

export default async function profil() {
  const u = etat.utilisateur;
  const identite = panneauFormulaire({
    titre: "Votre profil",
    groupes: [{ colonnes: 2, champs: [{ cle: "nom", spec: { type: "texte", libelle: "Votre nom", max: 80, requis: true }, valeur: u.nom, opts: { autocomplete: "name" } }] }],
    enregistrer: async ({ nom }) => {
      const rep = await modifier("/moi", { nom });
      etat.utilisateur = { ...etat.utilisateur, ...rep.utilisateur };
      notifier("session");
      await chargerEquipe();
    },
    succes: "Nom enregistré.",
  });
  const fiche = panneau(
    { titre: "Votre compte", sous: "Ces renseignements sont gérés par l’administrateur du CRM.", niveau: 3 },
    listeDef([
      ["Courriel de connexion", u.courriel],
      ["Rôle", ROLES[u.role] || u.role],
      ["Double vérification", u.mfa ? "Activée" : "Non activée"],
    ])
  );
  return h("div.pile.pile--l", identite.noeud, fiche, panneauApparence(), panneauNotifications());
}
