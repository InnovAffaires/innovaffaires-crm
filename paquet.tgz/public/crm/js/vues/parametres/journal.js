// Journal d'activité : qui a fait quoi, et quand (Loi 25 : traçabilité des accès et des changements).
// Le journal ne contient jamais le contenu des fiches, seulement ce qui a changé et par qui.
import { h, remplir } from "../../noyau/dom.js";
import { icone } from "../../noyau/icones.js";
import { etat, fiche, libelleFiche, maintenant } from "../../noyau/etat.js";
import { lire, ErreurApi } from "../../noyau/api.js";
import { lienFiche } from "../../noyau/routeur.js";
import { enregistrerFichier } from "../../noyau/dom.js";
import { versCsv } from "../../noyau/csv.js";
import { ENTITES } from "../../commun/schema.js";
import { aujourdhui, partiesLocales } from "../../commun/dates.js";
import { dateCourte, heure, moisAnnee, pluriel } from "../../commun/format.js";
import { btn, avis, etatVide } from "../../ui/composants.js";
import { tableau } from "../../ui/tableau.js";
import { barreFiltres } from "../../ui/filtres.js";

const CATEGORIES = [
  { id: "acces", libelle: "Connexions et sécurité" },
  { id: "equipe", libelle: "Équipe" },
  { id: "fiches", libelle: "Fiches" },
  { id: "facturation", libelle: "Facturation" },
  { id: "reglages", libelle: "Réglages" },
  { id: "donnees", libelle: "Données et sauvegardes" },
];

/** action → [libellé lisible, catégorie] */
const ACTIONS = {
  connexion: ["Connexion", "acces"],
  connexion_echec: ["Échec de connexion", "acces"],
  deconnexion: ["Déconnexion", "acces"],
  activation: ["Activation du CRM", "acces"],
  code_recuperation_utilise: ["Code de récupération utilisé", "acces"],
  mdp_change: ["Mot de passe changé", "acces"],
  mdp_echec: ["Mot de passe actuel refusé", "acces"],
  mdp_recupere: ["Mot de passe retrouvé avec un code de récupération", "acces"],
  recuperation_echec: ["Récupération d’accès refusée", "acces"],
  urgence: ["Réinitialisation d’urgence de l’accès", "acces"],
  urgence_echec: ["Réinitialisation d’urgence refusée", "acces"],
  "2fa_active": ["Double vérification activée", "acces"],
  "2fa_desactive": ["Double vérification désactivée", "acces"],
  codes_regeneres: ["Nouveaux codes de récupération", "acces"],
  utilisateur_cree: ["Compte créé", "equipe"],
  utilisateur_modifie: ["Compte modifié", "equipe"],
  mdp_reinitialise_admin: ["Mot de passe réinitialisé par un administrateur", "equipe"],
  "2fa_retiree_admin": ["Double vérification retirée par un administrateur", "equipe"],
  creation: ["Fiche créée", "fiches"],
  modification: ["Fiche modifiée", "fiches"],
  suppression: ["Fiche mise à la corbeille", "fiches"],
  restauration_fiche: ["Fiche rétablie", "fiches"],
  purge: ["Fiche effacée définitivement", "fiches"],
  suppression_activite: ["Note ou activité supprimée", "fiches"],
  demande_recue: ["Demande reçue par le site", "fiches"],
  demande_convertie: ["Demande convertie en contact", "fiches"],
  liste_ne_pas_appeler: ["Inscription à la liste « ne pas appeler »", "fiches"],
  facture_emise: ["Facture ou devis émis", "facturation"],
  paiement: ["Paiement enregistré", "facturation"],
  paiement_retire: ["Paiement retiré", "facturation"],
  facture_annulee: ["Facture annulée", "facturation"],
  config: ["Réglages modifiés", "reglages"],
  calendrier_jeton: ["Nouveau lien de calendrier externe", "reglages"],
  export_personne: ["Renseignements d’une personne exportés", "donnees"],
  anonymisation: ["Contact anonymisé", "donnees"],
  purge_echus: ["Nettoyage des données échues", "donnees"],
  purge_auto: ["Nettoyage automatique des données échues", "donnees"],
  sauvegarde_telechargee: ["Sauvegarde téléchargée", "donnees"],
  restauration: ["Données restaurées depuis une sauvegarde", "donnees"],
  import: ["Importation de fiches", "donnees"],
  exemples_charges: ["Données d’exemple ajoutées", "donnees"],
  exemples_retires: ["Données d’exemple retirées", "donnees"],
  troncature: ["Anciens événements retirés du journal", "donnees"],
};

const SECTIONS_CONFIG = {
  entreprise: "Entreprise", taxes: "Taxes", facturation: "Facturation", honoraires: "Honoraires", delai_reponse_heures: "Délai de réponse",
  jours_feries_supplementaires: "Jours fériés", etapes: "Étapes des affaires", statuts_dossier: "Statuts des dossiers", sources: "Provenances",
  etiquettes: "Étiquettes", gabarits_taches: "Tâches automatiques", gabarits_courriel: "Gabarits de courriel", conservation: "Conservation",
  securite: "Sécurité", calendrier: "Calendrier externe", appels: "Appels",
};
const ROLES = { admin: "administrateur", standard: "utilisateur", lecture: "lecture seule" };

const essayerJson = (t) => {
  try {
    return JSON.parse(t);
  } catch {
    return null;
  }
};

/** Détails lisibles d'un événement : liste de phrases courtes et lien éventuel vers la fiche. */
function decrire(e, nomDe) {
  const [libelle, categorie] = ACTIONS[e.action] || [e.action, "autre"];
  const details = [];
  let lien = null;
  const entite = ENTITES[e.entite];

  if (entite && e.id) {
    const f = fiche(e.entite, e.id);
    if (f && !f.supprime) lien = { href: lienFiche(e.entite, e.id), texte: libelleFiche(e.entite, f) };
    else details.push(`${entite.libelle}${f?.supprime ? " (dans la corbeille)" : " (n’existe plus)"}`);
    if (!lien && !details.length) details.push(entite.libelle);
  } else if (e.entite && ["contacts", "entreprises"].includes(e.entite)) {
    details.push(e.entite === "contacts" ? "Contacts" : "Entreprises");
  }
  if (e.action === "config" && Array.isArray(e.champs)) details.push(`Sections : ${e.champs.map((c) => SECTIONS_CONFIG[c] || c).join(", ")}`);
  else if (Array.isArray(e.champs) && e.champs.length) details.push(`Champs : ${e.champs.map((c) => entite?.champs?.[c]?.libelle || c).join(", ")}`);
  if (e.cible) details.push(`Compte : ${nomDe(e.cible) || "personne retirée"}`);

  if (e.detail) {
    if (e.action === "utilisateur_modifie") {
      const d = essayerJson(e.detail) || {};
      if (d.role) details.push(`Nouveau rôle : ${ROLES[d.role] || d.role}`);
      if (d.actif === false) details.push("Accès fermé");
      if (d.actif === true) details.push("Accès rétabli");
    } else if (e.action === "purge_echus" || e.action === "purge_auto") {
      const d = essayerJson(e.detail);
      if (d) details.push(`Demandes archivées : ${d.demandes ?? 0} · pourriels : ${d.pourriels ?? 0} · corbeille : ${d.corbeille ?? 0}`);
    } else if (e.action === "restauration") {
      const d = essayerJson(e.detail);
      if (d) {
        const total = Object.values(d).reduce((n, x) => n + (Number(x) || 0), 0);
        details.push(`${pluriel(total, "fiche")} restaurées`);
      }
    } else details.push(e.detail);
  }
  if (e.ip_h && ["connexion_echec", "recuperation_echec", "urgence_echec", "connexion", "mdp_recupere", "urgence"].includes(e.action)) details.push(`Réseau ${String(e.ip_h).slice(0, 6)}`);
  return { libelle, categorie, details, lien };
}

export default async function journal() {
  const racine = h("div.pile.pile--l");
  const noms = new Map();
  try {
    for (const u of (await lire("/utilisateurs")).utilisateurs || []) noms.set(u.id, u.nom);
  } catch (e) {
    if (!(e instanceof ErreurApi)) throw e;
  }
  const nomDe = (id) => (id ? noms.get(id) || (etat.utilisateur?.id === id ? etat.utilisateur.nom : "") : "");

  const st = { q: "", categorie: "", mois: "" };
  let lignes = [];
  let tab = null;
  let barre = null;
  const zone = h("div.pile.pile--s");
  const selMois = h("select.saisie.saisie--filtre", { "aria-label": "Mois du journal" });
  const champMois = h("div.filtre", h("div.saisie-select", selMois, icone("bas", "ic--p")));

  function construire(evenements) {
    return evenements.map((e) => {
      const ms = Date.parse(e.t);
      const d = decrire(e, nomDe);
      const echecAnonyme = ["connexion_echec", "recuperation_echec", "urgence_echec"].includes(e.action);
      const qui = e.uid ? nomDe(e.uid) || "Compte retiré" : e.action === "demande_recue" ? "Visiteur du site" : echecAnonyme ? "Inconnu" : "Système";
      const textes = [d.libelle, qui, ...d.details, d.lien?.texte || ""].join(" ").toLowerCase();
      return { id: e.i, ms, e, ...d, qui, textes };
    });
  }

  const filtrees = () => {
    const q = st.q.trim().toLowerCase();
    return lignes.filter((l) => (!st.categorie || l.categorie === st.categorie) && (!q || l.textes.includes(q)));
  };

  function majListe() {
    const f = filtrees();
    tab?.majLignes(f);
    barre?.definirCompte(f.length === lignes.length ? pluriel(f.length, "événement") : `${f.length} sur ${pluriel(lignes.length, "événement")}`);
  }

  const colonnes = [
    {
      id: "quand", titre: "Quand", valeur: (l) => l.ms,
      rendu: (l) => {
        const p = partiesLocales(l.ms);
        return h("div.identite__texte", h("span", dateCourte(p.date)), h("small.muet", heure(l.ms)));
      },
    },
    { id: "qui", titre: "Qui", valeur: (l) => l.qui, rendu: (l) => l.qui },
    { id: "quoi", titre: "Quoi", classe: "cellule-titre", valeur: (l) => l.libelle, rendu: (l) => l.libelle },
    {
      id: "detail", titre: "Détails", triable: false,
      rendu: (l) =>
        l.lien || l.details.length
          ? h(
              "div.identite__texte",
              l.lien ? h("a.lien-fiche", { href: l.lien.href }, l.lien.texte) : null,
              l.details.map((t) => h("small.muet", t))
            )
          : null,
    },
  ];

  function exporter() {
    const csv = versCsv(
      [
        { titre: "Date", valeur: (l) => partiesLocales(l.ms).date },
        { titre: "Heure", valeur: (l) => heure(l.ms) },
        { titre: "Personne", valeur: (l) => l.qui },
        { titre: "Action", valeur: (l) => l.libelle },
        { titre: "Détails", valeur: (l) => [l.lien?.texte, ...l.details].filter(Boolean).join(" · ") },
      ],
      filtrees()
    );
    enregistrerFichier(`innovaffaires-journal-${st.mois}.csv`, csv, "text/csv;charset=utf-8");
  }

  async function charger(mois) {
    zone.replaceChildren(h("p.muet", { role: "status" }, "Chargement du journal…"));
    try {
      const rep = await lire(`/admin/audit?mois=${encodeURIComponent(mois)}`);
      st.mois = rep.mois;
      lignes = construire(rep.evenements || []);
      const mois_dispo = [...new Set([rep.mois, ...(rep.mois_disponibles || [])])].sort().reverse();
      selMois.replaceChildren(...mois_dispo.map((m) => h("option", { value: m }, moisAnnee(m))));
      selMois.value = rep.mois;

      tab = tableau({
        libelle: `Journal d’activité de ${moisAnnee(rep.mois)}`, colonnes, lignes: filtrees(), tri: { col: "quand", dir: "desc" },
        texteLimite: (n, total) => `${n} événements affichés sur ${total}.`,
        vide: () => etatVide({ icone: "historique", titre: lignes.length ? "Aucun résultat" : "Aucun événement ce mois-là", texte: lignes.length ? "Aucun événement ne correspond à cette recherche." : "Rien n’a été consigné pour ce mois." }),
      });
      remplir(
        zone,
        (rep.evenements || []).length >= 2000 ? avis({ ton: "info", texte: "Seuls les 2 000 événements les plus récents du mois sont affichés." }) : null,
        tab.noeud
      );
      majListe();
    } catch (e) {
      if (!(e instanceof ErreurApi)) throw e;
      zone.replaceChildren(avis({ ton: "erreur", titre: "Le journal n’a pas pu être chargé", texte: e.message, actions: btn("Réessayer", { petit: true, onclick: () => charger(mois) }) }));
    }
  }

  barre = barreFiltres({
    placeholder: "Chercher dans le journal…", aria: "Chercher dans le journal d’activité",
    surRecherche: (q) => {
      st.q = q;
      majListe();
    },
    surReinitialiser: () => {
      st.q = "";
      st.categorie = "";
      majListe();
    },
    filtres: [
      {
        id: "categorie", libelle: "Type d’événement", tout: "Tous les types", valeur: st.categorie, options: CATEGORIES,
        surChangement: (v) => {
          st.categorie = v;
          majListe();
        },
      },
    ],
    droite: [champMois, btn("Exporter (CSV)", { petit: true, icone: "telecharger", onclick: exporter })],
  });
  selMois.addEventListener("change", () => charger(selMois.value));

  racine.append(
    h("p.reglages__note.muet", "Chaque connexion, chaque changement d’accès ou de réglage et chaque modification de fiche y est consignée, avec la personne qui l’a faite. Le journal n’en copie jamais le contenu : seulement ce qui a changé."),
    barre.noeud,
    zone
  );
  await charger(aujourdhui(maintenant()).slice(0, 7));
  return racine;
}
