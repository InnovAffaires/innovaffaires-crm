// Importer des contacts ou des entreprises depuis un fichier CSV (Excel, Google Sheets, autre CRM).
// Le navigateur lit le fichier et associe les colonnes ; le serveur valide chaque ligne, ignore les doublons
// et ne crée rien tant qu'on n'a pas confirmé (une vérification à blanc est proposée d'abord).
import { h, remplir } from "../../noyau/dom.js";
import { icone } from "../../noyau/icones.js";
import { etat } from "../../noyau/etat.js";
import { envoyer, ErreurApi } from "../../noyau/api.js";
import { synchroniser } from "../../noyau/synchro.js";
import { lireCsv } from "../../noyau/csv.js";
import { normaliser, pluriel } from "../../commun/format.js";
import { btn, panneau, avis } from "../../ui/composants.js";
import { creerChamp } from "../../ui/formulaire.js";
import { confirmer } from "../../ui/dialogue.js";
import { lireChamp, note } from "./commun.js";

const MAX_LIGNES = 2000;
const TAILLE_MAX = 3_000_000;

/** Champs importables et façons habituelles de nommer leur colonne (comparées sans accents ni majuscules). */
const CHAMPS = {
  contacts: [
    { id: "prenom", libelle: "Prénom", synonymes: ["prenom", "first name", "firstname", "given name"] },
    { id: "nom", libelle: "Nom de famille", synonymes: ["nom", "nom de famille", "last name", "lastname", "surname", "family name"] },
    { id: "courriel", libelle: "Courriel", synonymes: ["courriel", "email", "e-mail", "adresse courriel", "adresse email", "adresse e-mail", "mail", "email address", "courrier electronique"] },
    { id: "telephone", libelle: "Téléphone", synonymes: ["telephone", "tel", "phone", "telephone bureau", "work phone", "numero de telephone"] },
    { id: "mobile", libelle: "Cellulaire", synonymes: ["cellulaire", "mobile", "cell", "portable", "cell phone", "mobile phone", "telephone mobile"] },
    { id: "titre", libelle: "Fonction", synonymes: ["fonction", "titre", "poste", "job title", "title", "position"] },
    { id: "entreprise", libelle: "Entreprise (reliée ou créée)", synonymes: ["entreprise", "societe", "organisation", "compagnie", "company", "organization", "nom de l'entreprise", "nom entreprise"] },
    { id: "ville", libelle: "Ville", synonymes: ["ville", "city", "municipalite"] },
    { id: "etiquettes", libelle: "Étiquettes", synonymes: ["etiquettes", "etiquette", "tags", "tag", "categories"] },
    { id: "notes", libelle: "Notes", synonymes: ["notes", "note", "commentaires", "commentaire", "remarques", "comments"] },
  ],
  entreprises: [
    { id: "nom", libelle: "Nom de l’entreprise", synonymes: ["nom", "entreprise", "raison sociale", "nom de l'entreprise", "company", "company name", "name", "organisation", "societe"] },
    { id: "neq", libelle: "NEQ", synonymes: ["neq", "numero d'entreprise du quebec", "no neq"] },
    { id: "site_web", libelle: "Site Web", synonymes: ["site web", "site", "website", "url", "web", "site internet"] },
    { id: "telephone", libelle: "Téléphone", synonymes: ["telephone", "tel", "phone", "numero de telephone"] },
    { id: "adresse", libelle: "Adresse", synonymes: ["adresse", "address", "rue"] },
    { id: "ville", libelle: "Ville", synonymes: ["ville", "city", "municipalite"] },
    { id: "code_postal", libelle: "Code postal", synonymes: ["code postal", "postal code", "zip", "zip code", "cp"] },
    { id: "employes", libelle: "Nombre d’employés", synonymes: ["employes", "nombre d'employes", "employees", "nb employes"] },
    { id: "annee_fondation", libelle: "Année de fondation", synonymes: ["annee de fondation", "annee fondation", "fondation", "founded"] },
    { id: "etiquettes", libelle: "Étiquettes", synonymes: ["etiquettes", "etiquette", "tags", "tag", "categories"] },
    { id: "notes", libelle: "Notes", synonymes: ["notes", "note", "commentaires", "commentaire", "remarques", "comments"] },
  ],
};
const EXIGES = { contacts: ["prenom", "nom", "courriel"], entreprises: ["nom"] };
const MESSAGE_EXIGE = { contacts: "Associez au moins une colonne au prénom, au nom ou au courriel.", entreprises: "Associez une colonne au nom de l’entreprise." };

const NOMS = { contacts: { sing: "contact", plur: "contacts", f: false }, entreprises: { sing: "entreprise", plur: "entreprises", f: true } };
/** « 3 contacts seront créés », « 1 entreprise sera créée »… (accord avec le genre du nom). */
function phrase(entite, n, [singM, plurM, singF, plurF]) {
  const x = NOMS[entite];
  const mot = pluriel(n, x.sing, x.plur);
  return `${mot} ${n > 1 ? (x.f ? plurF : plurM) : x.f ? singF : singM}`;
}
const SERONT_CREES = ["sera créé", "seront créés", "sera créée", "seront créées"]; // [sing. m., plur. m., sing. f., plur. f.]
const IMPORTES = ["importé", "importés", "importée", "importées"];

/** Lit un fichier texte : UTF-8, sinon Windows-1252 (l'enregistrement habituel d'Excel en français). */
async function lireTexte(fichier) {
  const octets = await fichier.arrayBuffer();
  try {
    return new TextDecoder("utf-8", { fatal: true }).decode(octets);
  } catch {
    return new TextDecoder("windows-1252").decode(octets);
  }
}

/** Devine le champ qui correspond à chaque colonne ; un champ n'est attribué qu'à une seule colonne. */
function deviner(entite, entetes) {
  const champs = CHAMPS[entite];
  const pris = new Set();
  const nettoyer = (t) => normaliser(t).replace(/[^a-z0-9' ]+/g, " ").replace(/\s+/g, " ").trim();
  return entetes.map((e) => {
    const n = nettoyer(e);
    if (!n) return "";
    const exact = champs.find((c) => !pris.has(c.id) && c.synonymes.includes(n));
    const proche = exact || champs.find((c) => !pris.has(c.id) && c.synonymes.some((s) => s.length >= 5 && (n.startsWith(`${s} `) || n.endsWith(` ${s}`))));
    if (!proche) return "";
    pris.add(proche.id);
    return proche.id;
  });
}

export default async function importer() {
  const racine = h("div.pile.pile--l");
  const st = { entite: "contacts", nomFichier: "", entetes: [], lignes: [], cibles: [], simulation: null };

  /** Chaque étape remplace la précédente, souvent plus courte : on remonte au titre pour ne pas rester au milieu de la page. */
  let dejaAffiche = false;
  const montrerEtape = () => {
    if (dejaAffiche) document.querySelector(".reglages__titre")?.scrollIntoView({ block: "start" });
    dejaAffiche = true;
  };

  // ----- Étape 1 : choisir le fichier -----------------------------------------------------------------------
  function etapeFichier(message = null) {
    const quoi = creerChamp("entite", { type: "choix", libelle: "Que contient le fichier ?", options: [{ id: "contacts", libelle: "Des contacts (des personnes)" }, { id: "entreprises", libelle: "Des entreprises" }], requis: true }, st.entite, {});
    const alerte = h("div.formulaire__alerte", { role: "alert", hidden: !message }, message || "");
    const entree = h("input", { type: "file", accept: ".csv,.txt,text/csv,text/plain", hidden: true, "aria-hidden": "true", tabindex: "-1" });
    entree.addEventListener("change", async () => {
      const fichier = entree.files?.[0];
      entree.value = "";
      if (!fichier) return;
      alerte.hidden = true;
      const refuser = (m) => {
        alerte.hidden = false;
        alerte.textContent = m;
      };
      if (fichier.size > TAILLE_MAX) return refuser("Ce fichier est trop volumineux (3 Mo au plus). Découpez-le en plusieurs fichiers.");
      let csv;
      try {
        csv = lireCsv(await lireTexte(fichier));
      } catch {
        return refuser("Ce fichier n’a pas pu être lu. Enregistrez-le de nouveau au format CSV.");
      }
      if (!csv.entetes.length || !csv.lignes.length) return refuser("Ce fichier ne contient aucune ligne de données : la première ligne doit porter le titre des colonnes, les suivantes les fiches.");
      if (csv.lignes.length > MAX_LIGNES) return refuser(`Ce fichier compte ${pluriel(csv.lignes.length, "ligne")} : importez ${pluriel(MAX_LIGNES, "ligne")} au plus à la fois. Découpez-le en plusieurs fichiers.`);
      st.entite = quoi.lire();
      st.nomFichier = fichier.name;
      st.entetes = csv.entetes;
      st.lignes = csv.lignes;
      st.cibles = deviner(st.entite, csv.entetes);
      st.simulation = null;
      etapeAssociation();
    });
    montrerEtape();
    racine.replaceChildren(
      panneau(
        { titre: "Choisir le fichier", sous: "Un fichier CSV, avec le titre des colonnes sur la première ligne.", niveau: 3 },
        h(
          "div.pile",
          alerte,
          h("div.grille.grille--1.grille--etroite", quoi.noeud),
          h("div.actions-ligne", btn("Choisir un fichier CSV…", { ton: "primaire", icone: "televerser", onclick: () => entree.click() }), entree),
          h(
            "ul.liste-simple",
            h("li", h("strong", "Depuis Excel : "), "Fichier › Enregistrer sous › « CSV UTF-8 ». ", h("strong", "Depuis Google Sheets : "), "Fichier › Télécharger › « Valeurs séparées par des virgules (.csv) »."),
            h("li", `Jusqu’à ${pluriel(MAX_LIGNES, "ligne")} par fichier. Les doublons (même courriel, ou même nom d’entreprise) sont ignorés.`),
            h("li", "À l’étape suivante, vous associez les colonnes aux champs du CRM, puis vous vérifiez le résultat avant que quoi que ce soit soit créé.")
          )
        )
      )
    );
  }

  // ----- Étape 2 : associer les colonnes ---------------------------------------------------------------
  function etapeAssociation() {
    const champs = CHAMPS[st.entite];
    const zoneResultat = h("div.pile", { role: "status", "aria-live": "polite" });
    const alerte = h("div.formulaire__alerte", { role: "alert", hidden: true });
    const importerBtn = btn("Importer", { ton: "primaire", icone: "televerser", desactive: true });
    const verifier = btn("Vérifier le fichier", { ton: "primaire", icone: "ok" });

    const provenance = creerChamp("provenance", { type: "choix", libelle: "Provenance de ces fiches (facultatif)", options: etat.config.sources.map((s) => ({ id: s.id, libelle: s.libelle })), requis: false }, "", {});
    const etiquette = creerChamp("etiquette", { type: "texte", libelle: "Étiquette à ajouter à toutes les fiches (facultatif)", max: 40 }, "", { aide: "Pratique pour retrouver ce qui vient de cet import, par exemple « Import octobre 2026 »." });

    const invalider = () => {
      st.simulation = null;
      importerBtn.disabled = true;
      importerBtn.querySelector("span").textContent = "Importer";
      zoneResultat.replaceChildren();
    };

    const lignesMappage = st.entetes.map((entete, i) => {
      const exemples = st.lignes.map((l) => (l[i] || "").trim()).filter(Boolean).slice(0, 2);
      const sel = h("select.saisie", { "aria-label": `Champ du CRM pour la colonne « ${entete || `colonne ${i + 1}`} »` }, h("option", { value: "" }, "Ne pas importer"), champs.map((c) => h("option", { value: c.id }, c.libelle)));
      sel.value = st.cibles[i] || "";
      sel.addEventListener("change", () => {
        st.cibles[i] = sel.value;
        invalider();
      });
      return h(
        "li.mappage__ligne",
        h("div.mappage__source", h("strong", entete || `Colonne ${i + 1}`), exemples.length ? h("span.muet", exemples.join(" · ")) : h("span.muet", "(vide)")),
        icone("suivant", "ic--p mappage__fleche"),
        h("div.saisie-select", sel, icone("bas", "ic--p"))
      );
    });

    /** Fiches à envoyer au serveur, d'après les colonnes associées. */
    function construireLignes() {
      const idxParChamp = new Map();
      st.cibles.forEach((c, i) => c && idxParChamp.set(c, i));
      const fixe = lireChamp(etiquette, { requis: false });
      const src = lireChamp(provenance, { requis: false });
      return st.lignes.map((l) => {
        const o = {};
        for (const [champ, i] of idxParChamp) {
          const v = (l[i] || "").trim();
          if (!v) continue;
          o[champ] = champ === "etiquettes" ? v.split(/[;,|]/).map((x) => x.trim()).filter(Boolean).slice(0, 30) : v;
        }
        if (fixe.valeur) o.etiquettes = [...(o.etiquettes || []), fixe.valeur].slice(0, 30);
        if (src.valeur) o.source = src.valeur;
        return o;
      });
    }

    /** Contrôle l'association avant tout envoi ; retourne un message, ou null si tout va bien. */
    function controler() {
      const utilises = st.cibles.filter(Boolean);
      const doublon = utilises.find((c, i) => utilises.indexOf(c) !== i);
      if (doublon) return `Le champ « ${champs.find((c) => c.id === doublon).libelle} » est associé à deux colonnes. Choisissez-en une seule.`;
      if (!EXIGES[st.entite].some((c) => utilises.includes(c))) return MESSAGE_EXIGE[st.entite];
      const e = lireChamp(etiquette, { requis: false });
      if (e.erreur) {
        etiquette.erreur(e.erreur);
        return "L’étiquette est à corriger.";
      }
      etiquette.erreur(null);
      return null;
    }

    function afficherSimulation(r) {
      const noms = NOMS[st.entite];
      const morceaux = [];
      if (r.doublons) morceaux.push(`${pluriel(r.doublons, "doublon ignoré", "doublons ignorés")}`);
      if (r.nb_erreurs) morceaux.push(`${pluriel(r.nb_erreurs, "ligne refusée", "lignes refusées")}`);
      if (st.entite === "contacts" && r.entreprises_creees) morceaux.push(`${pluriel(r.entreprises_creees, "nouvelle entreprise sera créée", "nouvelles entreprises seront créées")}`);
      const erreurs = (r.erreurs || []).slice(0, 10);
      remplir(
        zoneResultat,
        avis({
          ton: r.crees ? (r.nb_erreurs ? "attention" : "ok") : "erreur",
          titre: r.crees ? phrase(st.entite, r.crees, SERONT_CREES) : "Aucune fiche à créer",
          texte: morceaux.length ? `${morceaux.join(" · ")}.` : "Aucun problème détecté dans le fichier.",
        }),
        erreurs.length
          ? h(
              "div.pile.pile--s",
              h("p", h("strong", r.nb_erreurs > erreurs.length ? `Les ${erreurs.length} premières lignes refusées :` : "Lignes refusées :")),
              h("ul.liste-simple", erreurs.map((x) => h("li", h("strong", `Ligne ${x.ligne}`), ` — ${x.message}`))),
              h("p.muet.petit", "Corrigez le fichier et recommencez, ou importez le reste : les lignes refusées sont simplement ignorées.")
            )
          : null
      );
      importerBtn.disabled = !r.crees;
      importerBtn.querySelector("span").textContent = r.crees ? `Importer ${pluriel(r.crees, noms.sing, noms.plur)}` : "Importer";
    }

    async function appeler(simuler) {
      const lignes = construireLignes();
      return envoyer("/admin/importer", { entite: st.entite, lignes, simuler });
    }

    verifier.addEventListener("click", async () => {
      alerte.hidden = true;
      const probleme = controler();
      if (probleme) {
        alerte.hidden = false;
        alerte.textContent = probleme;
        return;
      }
      verifier.disabled = true;
      verifier.setAttribute("aria-busy", "true");
      zoneResultat.replaceChildren(h("p.muet", "Vérification en cours…"));
      try {
        st.simulation = await appeler(true);
        afficherSimulation(st.simulation);
      } catch (e) {
        if (!(e instanceof ErreurApi)) throw e;
        zoneResultat.replaceChildren(avis({ ton: "erreur", titre: "La vérification a échoué", texte: e.message }));
      } finally {
        verifier.disabled = false;
        verifier.removeAttribute("aria-busy");
      }
    });

    importerBtn.addEventListener("click", async () => {
      const sim = st.simulation;
      if (!sim?.crees) return;
      const noms = NOMS[st.entite];
      const ok = await confirmer({
        titre: `Importer ${pluriel(sim.crees, noms.sing, noms.plur)} ?`,
        message: `Les fiches s’ajoutent à celles que vous avez déjà. ${sim.doublons ? `${pluriel(sim.doublons, "doublon est ignoré", "doublons sont ignorés")}. ` : ""}Vous pourrez les retrouver${etiquette.lire().trim() ? ` avec l’étiquette « ${etiquette.lire().trim()} »` : ""} et les mettre à la corbeille une à une si besoin.`,
        libelleConfirmer: "Importer",
      });
      if (!ok) return;
      importerBtn.disabled = true;
      importerBtn.setAttribute("aria-busy", "true");
      verifier.disabled = true;
      try {
        const r = await appeler(false);
        await synchroniser({ complet: true });
        terminer(r);
      } catch (e) {
        if (!(e instanceof ErreurApi)) throw e;
        importerBtn.disabled = false;
        verifier.disabled = false;
        zoneResultat.replaceChildren(avis({ ton: "erreur", titre: "L’importation a échoué", texte: e.message }));
      } finally {
        importerBtn.removeAttribute("aria-busy");
      }
    });

    montrerEtape();
    racine.replaceChildren(
      panneau(
        { titre: "Associer les colonnes", sous: `${st.nomFichier} — ${pluriel(st.lignes.length, "ligne")}, ${pluriel(st.entetes.length, "colonne")}.`, niveau: 3 },
        h(
          "div.pile",
          note(`Pour chaque colonne du fichier, choisissez le champ du CRM où mettre sa valeur. Le CRM a déjà deviné ce qu’il a pu : vérifiez, puis cliquez sur « Vérifier le fichier » — rien n’est créé à cette étape.`),
          h("ul.mappage", lignesMappage)
        )
      ),
      panneau({ titre: "Options", niveau: 3 }, h("div.grille.grille--1.grille--etroite", provenance.noeud, etiquette.noeud)),
      h(
        "div.pile",
        alerte,
        h("div.actions-ligne", btn("Choisir un autre fichier", { onclick: () => etapeFichier() }), verifier, importerBtn),
        zoneResultat
      )
    );
  }

  // ----- Étape 3 : résultat -------------------------------------------------------------------------------------
  function terminer(r) {
    montrerEtape();
    racine.replaceChildren(
      panneau(
        { titre: "Importation terminée", niveau: 3 },
        h(
          "div.pile",
          avis({
            ton: "ok",
            titre: phrase(st.entite, r.crees, IMPORTES),
            texte: [r.doublons ? pluriel(r.doublons, "doublon ignoré", "doublons ignorés") : null, r.nb_erreurs ? pluriel(r.nb_erreurs, "ligne refusée", "lignes refusées") : null, r.entreprises_creees ? pluriel(r.entreprises_creees, "entreprise créée", "entreprises créées") : null].filter(Boolean).join(" · ") || "Tout a été importé.",
          }),
          h("div.actions-ligne", btn(st.entite === "contacts" ? "Voir les contacts" : "Voir les entreprises", { ton: "primaire", href: st.entite === "contacts" ? "#/contacts" : "#/entreprises" }), btn("Importer un autre fichier", { onclick: () => etapeFichier() }))
        )
      )
    );
  }

  etapeFichier();
  return racine;
}
