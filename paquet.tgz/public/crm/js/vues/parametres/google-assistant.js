// =============================================================================
// Paramètres → Google : assistant de configuration (administration) en sept étapes.
// Une seule fois, environ 15 minutes, sans frais : on crée chez Google une « application »
// privée qui représente le CRM, puis chaque personne y connecte son compte en un clic.
// Le texte donne le libellé en français puis, entre parenthèses, celui de la console
// Google en anglais : l’interface de Google change et se présente parfois dans l’autre langue.
// =============================================================================
import { h, copierTexte } from "../../noyau/dom.js";
import { icone } from "../../noyau/icones.js";
import { envoyer, ErreurApi } from "../../noyau/api.js";
import { btn, avis, champMotDePasse, champTexte } from "../../ui/composants.js";
import { creerChamp } from "../../ui/formulaire.js";
import { toastErreur } from "../../ui/toast.js";
import { definirEtatGoogle, rafraichirGoogle, connecterGoogle, FONCTIONS_LIBELLES } from "../../noyau/google.js";

const CONSOLE = "https://console.cloud.google.com";
export const LIENS = {
  projet: `${CONSOLE}/projectcreate`,
  apiGmail: `${CONSOLE}/apis/library/gmail.googleapis.com`,
  apiAgenda: `${CONSOLE}/apis/library/calendar-json.googleapis.com`,
  consentement: `${CONSOLE}/auth/overview/create`,
  public: `${CONSOLE}/auth/audience`,
  acces: `${CONSOLE}/auth/scopes`,
  client: `${CONSOLE}/auth/clients/create`,
  clients: `${CONSOLE}/auth/clients`,
  permissions: "https://myaccount.google.com/permissions",
  admin: "https://admin.google.com",
};

export const PORTEES_GOOGLE = [
  ["https://www.googleapis.com/auth/gmail.send", "Envoyer des courriels (Gmail)"],
  ["https://www.googleapis.com/auth/gmail.readonly", "Voir les courriels échangés (Gmail, lecture seule)"],
  ["https://www.googleapis.com/auth/calendar.events", "Gérer les événements de l’agenda (Google Agenda)"],
];

const FONCTIONS = ["gmail_envoi", "gmail_echanges", "agenda"];
const RE_ID_CLIENT = /^[A-Za-z0-9._-]{8,200}\.apps\.googleusercontent\.com$/;

export const lienExterne = (href, texte) => h("a", { href, target: "_blank", rel: "noopener noreferrer" }, texte, " ", icone("externe", "ic--p"));

/** Une valeur à copier telle quelle (nom du projet, adresse de redirection…), avec son bouton. */
export function blocCopie(libelle, valeur) {
  const statut = h("span.gg-copie__statut", { role: "status", "aria-live": "polite" });
  let minuteur = null;
  const bouton = btn("Copier", {
    petit: true, icone: "copier", aria: `Copier : ${libelle}`,
    onclick: async () => {
      const ok = await copierTexte(valeur);
      statut.textContent = ok ? "Copié." : "La copie n’a pas fonctionné : sélectionnez le texte et copiez-le à la main.";
      clearTimeout(minuteur);
      minuteur = setTimeout(() => (statut.textContent = ""), 4000);
    },
  });
  return h("div.gg-copie", h("span.gg-copie__lib", libelle), h("code.gg-copie__val", valeur), bouton, statut);
}

function etape(numero, titre, duree, { ouverte = false, id = null } = {}, ...corps) {
  return h(
    "li.gg-etape",
    { id },
    h(
      "details.replie",
      { open: ouverte },
      h("summary.replie__titre", icone("droite", "ic--p replie__fleche"), h("span.gg-etape__num", { "aria-hidden": "true" }, String(numero)), h("span.replie__nom", titre), duree ? h("span.replie__compte.muet", duree) : null),
      h("div.replie__corps", corps)
    )
  );
}

// ----- Formulaire de l’étape 6 (aussi utilisé pour remplacer les identifiants) -----------------------------------------
/**
 * formulaireIdentifiants({ app, fonctions, surEnregistre })
 *   app : { client_id, secret_enregistre } si des identifiants existent déjà ; fonctions : { gmail_envoi, gmail_echanges, agenda }.
 *   surEnregistre({ verif }) : appelé après l’enregistrement (verif : { ok, message }).
 */
export function formulaireIdentifiants({ app = null, fonctions = null, redirectUri = "", surEnregistre = () => {} }) {
  const idc = champTexte({
    libelle: "ID client", requis: true, maxlength: 200, valeur: app?.client_id || "", placeholder: "123456789012-abcdef….apps.googleusercontent.com",
    aide: "Se termine par .apps.googleusercontent.com.",
  });
  const sec = champMotDePasse({
    libelle: "Secret client", autocomplete: "off", requis: !app?.secret_enregistre, objet: "le secret",
    aide: app?.secret_enregistre ? "Laissez vide pour garder le secret déjà enregistré." : "Commence en général par GOCSPX-.",
  });
  for (const el of [idc.input, sec.input]) {
    el.setAttribute("data-1p-ignore", "");
    el.setAttribute("data-lpignore", "true");
  }
  const cases = Object.fromEntries(FONCTIONS.map((k) => [k, creerChamp(`f-${k}`, { type: "booleen", libelle: FONCTIONS_LIBELLES[k] }, fonctions ? !!fonctions[k] : true)]));
  const message = h("div.pile.pile--s", { role: "status", "aria-live": "polite" });
  const alerte = h("div.pile.pile--s");
  const bouton = btn("Enregistrer et vérifier", { ton: "primaire", type: "submit", icone: "coche" });

  // Lecture du fichier JSON que Google propose de télécharger : évite de recopier deux longues valeurs.
  const fichier = h("input", { type: "file", accept: "application/json,.json", hidden: true, "aria-hidden": "true", tabindex: "-1" });
  fichier.addEventListener("change", async () => {
    const f = fichier.files?.[0];
    fichier.value = "";
    message.replaceChildren();
    if (!f) return;
    try {
      if (f.size > 20_000) throw new Error("Ce fichier est trop gros pour être celui de Google.");
      const json = JSON.parse(await f.text());
      const web = json?.web;
      if (!web && json?.installed) throw new Error("Ce fichier vient d’un client de type « Application de bureau ». Créez un client de type « Application Web » (étape 5).");
      if (typeof web?.client_id !== "string" || typeof web?.client_secret !== "string") throw new Error("Ce fichier ne contient pas d’ID client ni de secret.");
      idc.input.value = web.client_id.trim();
      sec.input.value = web.client_secret.trim();
      idc.erreur(null);
      sec.erreur(null);
      const manque = redirectUri && Array.isArray(web.redirect_uris) && !web.redirect_uris.includes(redirectUri);
      message.append(
        avis({ ton: manque ? "attention" : "ok", titre: "Fichier lu", texte: manque ? `L’ID client et le secret sont remplis, mais l’adresse de redirection ${redirectUri} n’est pas dans ce client : ajoutez-la dans la console Google (étape 5), sinon la connexion échouera.` : "L’ID client et le secret sont remplis. Vous pouvez supprimer le fichier de votre dossier Téléchargements après l’enregistrement." })
      );
    } catch (e) {
      message.append(avis({ ton: "erreur", titre: "Fichier illisible", texte: e instanceof SyntaxError ? "Ce fichier n’est pas un fichier JSON valide." : e.message }));
    }
  });

  async function soumettre(ev) {
    ev?.preventDefault();
    message.replaceChildren();
    alerte.replaceChildren();
    idc.erreur(null);
    sec.erreur(null);
    const clientId = idc.lire().trim();
    const secret = sec.lire().trim();
    if (!clientId) {
      idc.erreur("Collez l’ID client.");
      return idc.focus();
    }
    if (!RE_ID_CLIENT.test(clientId)) {
      idc.erreur("L’ID client ressemble à 123456789-abcdef.apps.googleusercontent.com. Copiez-le de nouveau, sans espace.");
      return idc.focus();
    }
    const change = !app || app.client_id !== clientId;
    if (!secret && (change || !app?.secret_enregistre)) {
      sec.erreur("Collez aussi le secret client.");
      return sec.focus();
    }
    const choix = Object.fromEntries(FONCTIONS.map((k) => [k, !!cases[k].lire()]));
    if (!FONCTIONS.some((k) => choix[k])) {
      alerte.append(avis({ ton: "erreur", texte: "Gardez au moins une fonction cochée." }));
      return;
    }
    bouton.disabled = true;
    bouton.setAttribute("aria-busy", "true");
    try {
      const corps = { client_id: clientId, fonctions: choix };
      if (secret) corps.client_secret = secret;
      definirEtatGoogle(await envoyer("/google/config", corps));
      sec.input.value = "";
      let verif;
      try {
        verif = await envoyer("/google/verifier", {});
      } catch (e) {
        if (!(e instanceof ErreurApi)) throw e;
        verif = { ok: false, message: e.message };
      }
      await rafraichirGoogle().catch(() => {});
      surEnregistre({ verif });
    } catch (e) {
      if (!(e instanceof ErreurApi)) throw e;
      let lie = false;
      if (e.champs?.client_id) {
        idc.erreur(e.champs.client_id);
        lie = true;
      }
      if (e.champs?.client_secret) {
        sec.erreur(e.champs.client_secret);
        lie = true;
      }
      // Le message du serveur redit celui du champ : on ne l'affiche en bas que s'il n'est lié à aucun champ.
      if (!lie || e.champs?.fonctions) alerte.append(avis({ ton: "erreur", texte: e.message }));
    } finally {
      bouton.disabled = false;
      bouton.removeAttribute("aria-busy");
    }
  }

  return h(
    "form.formulaire.pile",
    { novalidate: true, autocomplete: "off", onsubmit: soumettre },
    h(
      "div.actions-ligne",
      btn("Remplir à partir du fichier JSON de Google…", { petit: true, icone: "fichier-haut", onclick: () => fichier.click() }),
      fichier
    ),
    message,
    h("div.grille.grille--1", idc.noeud, sec.noeud),
    h("section.groupe", h("h4.groupe__titre", "Fonctions offertes à l’équipe"), h("div.pile.pile--s", FONCTIONS.map((k) => cases[k].noeud))),
    alerte,
    h("div.reglages__pied", bouton)
  );
}

// ----- Assistant ------------------------------------------------------------------------------------------------------
/**
 * assistantConfiguration({ redirectUri, ouvert, formulaire })
 *   formulaire : nœud de l’étape 6 (formulaireIdentifiants) ; ouvert : numéro de l’étape à ouvrir au départ.
 */
export function assistantConfiguration({ redirectUri, ouvert = 1, formulaire, configure = false }) {
  const o = (n) => n === ouvert;
  const sousEtapes = (...items) => h("ol.liste-numerotee", items.map((i) => h("li", i)));

  const etapes = [
    etape(1, "Créer un projet chez Google", "environ 3 min", { ouverte: o(1) },
      h("p", "Un projet est l’espace, chez Google, qui regroupe les réglages de votre CRM. Il est gratuit et ne demande aucune facturation."),
      sousEtapes(
        ["Ouvrez ", lienExterne(LIENS.projet, "la page « Créer un projet »"), " avec le compte Google de votre entreprise (celui de votre adresse @innovaffaires.com). Acceptez les conditions si Google les affiche ; si on vous propose un « essai gratuit », ignorez-le."],
        ["Nom du projet :", blocCopie("Nom du projet", "CRM InnovAffaires")],
        "Si Google affiche un champ « Organisation » ou « Emplacement », gardez innovaffaires.com.",
        "Cliquez sur « Créer », attendez la notification de Google, puis vérifiez que « CRM InnovAffaires » est bien le projet sélectionné en haut de l’écran."
      )
    ),
    etape(2, "Activer Gmail et Google Agenda", "environ 2 min", { ouverte: o(2) },
      h("p", "Le CRM parle à Gmail et à Google Agenda par leurs « API » : il faut activer chacune, une fois."),
      sousEtapes(
        ["Ouvrez ", lienExterne(LIENS.apiGmail, "la page de l’API Gmail"), " et cliquez sur « Activer » (Enable)."],
        ["Ouvrez ", lienExterne(LIENS.apiAgenda, "la page de l’API Google Agenda"), " (Google Calendar API) et cliquez sur « Activer »."],
        "Chaque fois, vérifiez en haut de l’écran que le projet « CRM InnovAffaires » est sélectionné. Un bouton « Gérer » à la place d’« Activer » veut dire que c’est déjà fait."
      )
    ),
    etape(3, "Décrire votre application (écran de consentement)", "environ 4 min", { ouverte: o(3) },
      h("p", "C’est l’écran que Google affichera quand vous ou une personne de l’équipe autoriserez le CRM à utiliser son compte."),
      sousEtapes(
        ["Ouvrez ", lienExterne(LIENS.consentement, "l’assistant « Google Auth Platform »"), ". Si Google affiche plutôt un bouton « Commencer » (Get started), cliquez dessus."],
        ["Nom de l’application :", blocCopie("Nom de l’application", "CRM InnovAffaires"), "Adresse courriel d’assistance : la vôtre. Cliquez sur « Suivant »."],
        [
          "Public (Audience) : choisissez ", h("strong", "Interne"), " (Internal) si votre adresse @innovaffaires.com est un compte Google Workspace (vous le savez si vous pouvez ouvrir ", lienExterne(LIENS.admin, "admin.google.com"),
          "). C’est le cas le plus simple : aucune vérification par Google et aucune expiration. Sinon, choisissez ", h("strong", "Externe"), " (External) et lisez l’encadré ci-dessous.",
        ],
        "Coordonnées : votre adresse courriel. Cochez l’acceptation des règles de Google, puis cliquez sur « Créer »."
      ),
      h(
        "details.replie",
        h("summary.replie__titre", icone("droite", "ic--p replie__fleche"), h("span.replie__nom", "Si vous avez choisi « Externe »")),
        h(
          "div.replie__corps",
          h("p", "Deux gestes de plus sont nécessaires :"),
          sousEtapes(
            ["Ouvrez ", lienExterne(LIENS.public, "la page « Public »"), ", cliquez sur « Publier l’application » (Publish app) et confirmez. Sans cela, Google coupe la connexion de chaque personne au bout de 7 jours."],
            "À la première connexion, Google affichera « Google n’a pas validé cette application ». Cliquez sur « Paramètres avancés » (Advanced), puis sur « Accéder à CRM InnovAffaires (non sécurisé) ». C’est normal : l’application est la vôtre, Google ne l’a simplement pas examinée. Ce mode accepte jusqu’à 100 personnes."
          )
        )
      )
    ),
    etape(4, "Indiquer ce que le CRM peut faire (accès aux données)", "environ 3 min", { ouverte: o(4) },
      h("p", "Vous précisez à Google les seules autorisations dont le CRM a besoin."),
      sousEtapes(
        ["Ouvrez ", lienExterne(LIENS.acces, "la page « Accès aux données »"), " (Data Access) et cliquez sur « Ajouter ou supprimer des niveaux d’accès » (Add or remove scopes)."],
        [
          "Cochez dans la liste les trois autorisations ci-dessous. Si la fenêtre offre une zone « Ajouter manuellement » (Manually add scopes), vous pouvez aussi y coller les trois lignes, puis cliquer sur « Ajouter au tableau ».",
          h("div.pile.pile--s", PORTEES_GOOGLE.map(([url, libelle]) => blocCopie(libelle, url)), blocCopie("Les trois, une par ligne", PORTEES_GOOGLE.map(([url]) => url).join("\n"))),
        ],
        "Cliquez sur « Mettre à jour » (Update), puis sur « Enregistrer » (Save) tout en bas de la page."
      ),
      h("p.muet.petit", "Google range ces autorisations parmi les accès « sensibles » : c’est normal pour l’envoi de courriels et la gestion d’un agenda. Le CRM ne modifie ni n’efface que les rendez-vous qu’il a lui-même créés dans votre agenda, et il ne lit jamais le contenu complet de vos courriels : seulement l’objet, l’expéditeur, la date et un court extrait.")
    ),
    etape(5, "Créer l’ID client et le secret", "environ 3 min", { ouverte: o(5) },
      h("p", "Ces deux clés permettent au CRM de se présenter à Google."),
      sousEtapes(
        ["Ouvrez ", lienExterne(LIENS.client, "la page « Créer un ID client OAuth »"), " (Create OAuth client ID)."],
        ["Type d’application : « Application Web » (Web application). Nom :", blocCopie("Nom du client", "CRM InnovAffaires")],
        [
          "Plus bas, dans « URI de redirection autorisés » (Authorized redirect URIs), cliquez sur « Ajouter un URI » et collez exactement cette adresse :",
          redirectUri ? blocCopie("Adresse de redirection", redirectUri) : h("p.muet", "L’adresse s’affichera ici une fois la page chargée."),
          "Laissez « Origines JavaScript autorisées » vide.",
        ],
        ["Cliquez sur « Créer ». Google affiche alors l’ID client et le secret client, ", h("strong", "une seule fois"), ". Copiez-les (ou cliquez sur « Télécharger le JSON ») et gardez cette fenêtre ouverte jusqu’à l’étape suivante."]
      ),
      avis({ ton: "attention", titre: "Le secret ne se partage pas", texte: "Ne l’envoyez jamais par courriel ni par message : il se colle seulement dans le CRM, à l’étape suivante." }),
      h("p.muet.petit", ["Fenêtre fermée trop tôt ? Ouvrez ", lienExterne(LIENS.clients, "la liste des clients"), ", choisissez le vôtre, puis « Ajouter un secret » : Google en crée un nouveau."])
    ),
    etape(6, "Coller l’ID client et le secret dans le CRM", "environ 1 min", { ouverte: o(6), id: "google-etape-6" },
      h("p", configure ? "Les identifiants sont déjà enregistrés. Utilisez ce formulaire seulement pour les remplacer." : "Le secret est conservé chiffré sur le serveur du CRM et ne s’affiche plus jamais. Google peut mettre quelques minutes à reconnaître un nouvel identifiant : si la vérification échoue juste après sa création, attendez cinq minutes et réessayez."),
      formulaire || h("p.muet", "Les identifiants sont déjà enregistrés : voir « Identifiants enregistrés » plus haut.")
    ),
    etape(7, "Connecter votre compte Google", "environ 1 min", { ouverte: o(7) },
      h("p", "Dernier geste : donner au CRM l’accès à votre propre compte. Sur la page de Google, choisissez votre compte et laissez toutes les cases cochées."),
      h("div.actions-ligne", btn("Connecter mon compte Google", { ton: "primaire", icone: "lien", onclick: lancerConnexion })),
      h("p.muet.petit", "Chaque personne de l’équipe fait ce geste une fois, avec son propre compte, depuis cette même page.")
    ),
  ];

  return h(
    "div.pile",
    avis({
      ton: "info",
      titre: "Une seule fois, environ 15 minutes, sans frais",
      texte: "Les écrans de Google évoluent : si un libellé diffère un peu de celui d’ici, cherchez le mot le plus proche, la marche à suivre reste la même. Gardez la console Google ouverte dans un autre onglet.",
    }),
    h("ol.gg-etapes", etapes)
  );
}

async function lancerConnexion(ev) {
  const b = ev.currentTarget;
  b.disabled = true;
  try {
    await connecterGoogle();
  } catch (e) {
    b.disabled = false;
    if (!(e instanceof ErreurApi)) throw e;
    toastErreur(e);
  }
}
