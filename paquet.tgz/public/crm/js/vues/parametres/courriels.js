// Gabarits de courriel : les messages types proposés quand vous écrivez à un client.
// Ces textes se remplissent avec les données de la fiche ; le message part de Gmail (compte Google relié) ou s'ouvre dans la messagerie.
import { h } from "../../noyau/dom.js";
import { etat } from "../../noyau/etat.js";
import { ErreurApi } from "../../noyau/api.js";
import { GABARITS_COURRIEL_DEFAUT } from "../../commun/defauts.js";
import { btn, btnIcone, panneau, etatVide } from "../../ui/composants.js";
import { creerChamp } from "../../ui/formulaire.js";
import { ouvrirDialogue, confirmer } from "../../ui/dialogue.js";
import { toast, toastErreur } from "../../ui/toast.js";
import { remplirGabarit } from "../../ui/courriel.js";
import { enregistrerConfig, lireChamp, slugifier, zoneErreurDialogue, note } from "./commun.js";

/** Les champs qui se remplissent tout seuls : [nom dans le gabarit, étiquette du bouton, explication]. */
const CHAMPS = [
  ["prenom", "Prénom", "Le prénom du contact"],
  ["nom", "Nom complet", "Le prénom et le nom du contact"],
  ["entreprise", "Entreprise", "Le nom de l’entreprise du contact"],
  ["programme", "Programme", "Le programme visé par le dossier"],
  ["date_limite", "Date limite", "La date limite de dépôt du dossier"],
  ["delai", "Délai de réponse", "Par exemple « dans les 48 heures ouvrables »"],
  ["montant", "Montant", "Le montant à payer (facture) ou proposé (devis)"],
  ["numero", "Numéro", "Le numéro de la facture ou du devis"],
  ["echeance", "Échéance", "L’échéance de la facture ou la fin de validité du devis"],
  ["signature", "Signature", "Votre signature (section Entreprise)"],
];

function exemple() {
  const c = etat.config;
  return {
    prenom: "Marie", nom: "Marie Tremblay", entreprise: "Ferme Tremblay inc.", programme: "Programme de soutien à l’innovation",
    date_limite: "15 novembre 2026", delai: `dans les ${c.delai_reponse_heures} heures ouvrables`, montant: "2 874,38 $", numero: "F-2026-0007",
    echeance: "15 novembre 2026", signature: c.entreprise.signature,
  };
}

/** Insère du texte à la position du curseur d'un champ, comme si on l'avait tapé. */
function inserer(champ, texte) {
  const el = champ.controle;
  const debut = el.selectionStart ?? el.value.length;
  const fin = el.selectionEnd ?? debut;
  el.setRangeText(texte, debut, fin, "end");
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.focus();
}

/**
 * Fenêtre de modification d'un gabarit. `existant` : le gabarit modifié, ou null pour un nouveau ;
 * `depart` : valeurs de départ (copie d'un autre gabarit). Retourne true si enregistré.
 */
function editerGabarit({ existant = null, depart = null }) {
  const base = existant || depart || { nom: "", objet: "", corps: "" };
  const defaut = existant ? GABARITS_COURRIEL_DEFAUT.find((g) => g.id === existant.id) : null;
  return ouvrirDialogue({
    titre: existant ? "Modifier le gabarit" : "Nouveau gabarit",
    taille: "grand",
    contenu: (ctx) => {
      const zone = zoneErreurDialogue();
      const nom = creerChamp("nom", { type: "texte", libelle: "Nom du gabarit", max: 100, requis: true }, base.nom, { aide: "Ce que vous voyez dans la liste de choix quand vous écrivez un courriel." });
      const objet = creerChamp("objet", { type: "texte", libelle: "Objet du courriel", max: 200 }, base.objet, {});
      const corps = creerChamp("corps", { type: "texte_long", libelle: "Message", max: 4000 }, base.corps, { rows: 12 });
      let dernier = corps;
      objet.noeud.addEventListener("focusin", () => (dernier = objet));
      corps.noeud.addEventListener("focusin", () => (dernier = corps));

      const apercuObjet = h("p.apercu-courriel__objet");
      const apercuCorps = h("p.apercu-courriel__corps");
      const majApercu = () => {
        const v = exemple();
        apercuObjet.textContent = remplirGabarit(objet.lire(), v) || "(sans objet)";
        apercuCorps.textContent = remplirGabarit(corps.lire(), v);
      };
      objet.noeud.addEventListener("input", majApercu);
      corps.noeud.addEventListener("input", majApercu);
      majApercu();

      const insertion = h(
        "div.champs-fusion",
        { role: "group", "aria-label": "Insérer un champ qui se remplit tout seul" },
        CHAMPS.map(([cle, libelle, aide]) => btn(libelle, { petit: true, titre: aide, onclick: () => inserer(dernier, `{{${cle}}}`) }))
      );

      async function enregistrer() {
        zone.afficher("");
        let faute = null;
        const valeurs = {};
        for (const c of [nom, objet, corps]) {
          const r = lireChamp(c, { requis: !!c.spec.requis });
          c.erreur(r.erreur || null);
          if (r.erreur) faute ||= c;
          else valeurs[c.cle] = r.valeur;
        }
        if (!valeurs.corps && !faute) {
          corps.erreur("Écrivez le message.");
          faute = corps;
        }
        if (faute) return faute.focus();
        const liste = etat.config.gabarits_courriel.map((g) => ({ ...g }));
        if (existant) {
          const i = liste.findIndex((g) => g.id === existant.id);
          if (i < 0) return zone.afficher("Ce gabarit n’existe plus. Fermez cette fenêtre et rechargez la page.");
          liste[i] = { ...liste[i], ...valeurs };
        } else {
          liste.push({ id: slugifier(valeurs.nom, new Set(liste.map((g) => g.id)), "gabarit"), ...valeurs });
        }
        ctx.occupe(true);
        try {
          await enregistrerConfig({ gabarits_courriel: liste });
          ctx.occupe(false);
          ctx.fermer(true);
        } catch (e) {
          ctx.occupe(false);
          if (!(e instanceof ErreurApi)) throw e;
          zone.afficher(e.message);
        }
      }

      ctx.definirPied(
        defaut
          ? btn("Rétablir le texte d’origine", {
              petit: true,
              onclick: () => {
                nom.definir(defaut.nom);
                objet.definir(defaut.objet);
                corps.definir(defaut.corps);
                majApercu();
                ctx.modifie(true);
              },
            })
          : null,
        btn("Annuler", { onclick: () => ctx.fermer(false) }),
        btn("Enregistrer", { ton: "primaire", onclick: enregistrer })
      );

      const formulaire = h(
        "form.formulaire",
        { novalidate: true, onsubmit: (e) => (e.preventDefault(), enregistrer()) },
        zone.noeud,
        nom.noeud,
        objet.noeud,
        corps.noeud,
        h("div.champ", h("p.champ__etiquette", "Champs qui se remplissent tout seuls"), insertion, h("p.champ__aide", "Cliquez sur un champ pour l’insérer à l’endroit du curseur. Il sera remplacé par la donnée de la fiche au moment d’écrire le courriel.")),
        h("div.apercu-courriel", h("p.apercu-courriel__titre", "Aperçu avec des données d’exemple"), apercuObjet, apercuCorps)
      );
      formulaire.addEventListener("input", () => ctx.modifie(true));
      return formulaire;
    },
  }).promesse;
}

function ligneGabarit(g, { surModifier, surDupliquer, surRetirer }) {
  return h(
    "li.gabarit",
    h("div.gabarit__texte", h("strong", g.nom), h("span.muet", g.objet || "(sans objet)")),
    h(
      "div.gabarit__actions",
      btn("Modifier", { petit: true, icone: "modifier", onclick: surModifier }),
      btnIcone("copier", `Dupliquer « ${g.nom} »`, surDupliquer),
      btnIcone("corbeille", `Retirer « ${g.nom} »`, surRetirer, { classe: "btn-icone--danger" })
    )
  );
}

export default async function courriels() {
  const liste = h("div");

  async function modifierListe(nouvelle, message) {
    try {
      await enregistrerConfig({ gabarits_courriel: nouvelle });
      toast(message);
      dessiner();
    } catch (e) {
      toastErreur(e);
    }
  }

  async function ouvrirEditeur(opts) {
    if (await editerGabarit(opts)) {
      toast("Gabarit enregistré.");
      dessiner();
    }
  }

  async function retirer(g) {
    const ok = await confirmer({
      titre: "Retirer ce gabarit ?",
      message: `« ${g.nom} » ne sera plus proposé quand vous écrivez un courriel.`,
      detail: GABARITS_COURRIEL_DEFAUT.some((d) => d.id === g.id) ? "C’est un gabarit fourni au départ : vous pourrez le réajouter plus tard." : null,
      libelleConfirmer: "Retirer", danger: true,
    });
    if (ok) await modifierListe(etat.config.gabarits_courriel.filter((x) => x.id !== g.id), "Gabarit retiré.");
  }

  function dessiner() {
    const gabarits = etat.config.gabarits_courriel;
    const manquants = GABARITS_COURRIEL_DEFAUT.filter((d) => !gabarits.some((g) => g.id === d.id));
    liste.replaceChildren(
      gabarits.length
        ? h("ul.gabarits", gabarits.map((g) => ligneGabarit(g, {
            surModifier: () => ouvrirEditeur({ existant: g }),
            surDupliquer: () => ouvrirEditeur({ depart: { nom: `${g.nom} (copie)`.slice(0, 100), objet: g.objet, corps: g.corps } }),
            surRetirer: () => retirer(g),
          })))
        : etatVide({ icone: "courriel", titre: "Aucun gabarit", texte: "Créez un premier message type pour gagner du temps.", action: btn("Nouveau gabarit", { ton: "primaire", icone: "plus", onclick: () => ouvrirEditeur({}) }) }),
      h(
        "div.actions-ligne",
        gabarits.length ? btn("Nouveau gabarit", { ton: "primaire", icone: "plus", onclick: () => ouvrirEditeur({}) }) : null,
        manquants.length
          ? btn(`Réajouter les gabarits d’origine (${manquants.length})`, {
              onclick: () => modifierListe([...gabarits, ...structuredClone(manquants)], manquants.length > 1 ? "Gabarits d’origine réajoutés." : "Gabarit d’origine réajouté."),
            })
          : null
      )
    );
  }
  dessiner();

  return h(
    "div.pile.pile--l",
    panneau(
      { titre: "Vos gabarits", sous: "Proposés dans la fenêtre « Écrire un courriel » d’un contact, d’un dossier, d’une demande ou d’une facture.", niveau: 3 },
      note(["Avec votre compte Google relié (", h("a", { href: "#/parametres/google" }, "Paramètres → Google"), "), « Envoyer avec Gmail » envoie le message de votre adresse. Sinon, il s’ouvre dans votre logiciel de courriel, prêt à relire et à envoyer."]),
      liste
    )
  );
}
