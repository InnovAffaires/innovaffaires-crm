// Vie privée (Loi 25) : durées de conservation, nettoyage, accès aux renseignements d'une personne, hébergement.
import { h } from "../../noyau/dom.js";
import { etat } from "../../noyau/etat.js";
import { envoyer, ErreurApi } from "../../noyau/api.js";
import { synchroniser } from "../../noyau/synchro.js";
import { pluriel } from "../../commun/format.js";
import { btn, panneau, avis } from "../../ui/composants.js";
import { confirmer } from "../../ui/dialogue.js";
import { toastErreur } from "../../ui/toast.js";
import { panneauFormulaire, enregistrerConfig } from "./commun.js";

// ----- Durées de conservation ---------------------------------------------------------------------------------
function panneauConservation() {
  const c = etat.config.conservation || { demandes_archivees_mois: 24, pourriels_jours: 30 };
  const p = panneauFormulaire({
    titre: "Durées de conservation",
    sous: "Combien de temps le CRM garde certaines données avant de les effacer.",
    groupes: [
      {
        colonnes: 1,
        champs: [
          {
            cle: "demandes_archivees_mois", valeur: c.demandes_archivees_mois, requis: true,
            spec: { type: "nombre", entier: true, min: 1, max: 120, libelle: "Demandes archivées" },
            opts: { suffixe: "mois", aide: "Une demande du site que vous avez archivée est effacée après ce délai. Une demande convertie en contact reste avec la fiche du contact." },
          },
          {
            cle: "pourriels_jours", valeur: c.pourriels_jours, requis: true,
            spec: { type: "nombre", entier: true, min: 1, max: 365, libelle: "Pourriels" },
            opts: { suffixe: "jours", aide: "Un message classé pourriel est effacé après ce délai." },
          },
        ],
      },
    ],
    enregistrer: ({ demandes_archivees_mois, pourriels_jours }) => enregistrerConfig({ conservation: { demandes_archivees_mois, pourriels_jours } }),
    succes: "Durées enregistrées.",
  });
  p.noeud.querySelector(".panneau__corps").prepend(
    h("p.reglages__note.muet", { css: { "margin-bottom": "0.9rem" } }, "Les fiches mises à la corbeille sont effacées après 30 jours, quel que soit ce réglage. Les appels consignés (résultat, durée, notes) restent avec la fiche de la personne jusqu’à son anonymisation. Le nettoyage se fait tout seul, une fois par jour, après la copie automatique de vos données.")
  );
  return p.noeud;
}

// ----- Nettoyage ------------------------------------------------------------------------------------------------------
function panneauNettoyage() {
  const resultat = h("div.pile.pile--s", { role: "status", "aria-live": "polite" });
  const voir = btn("Voir ce qui serait effacé", { icone: "voir" });

  function afficher(r) {
    const total = r.demandes + r.pourriels + r.corbeille;
    if (!total) {
      resultat.replaceChildren(avis({ ton: "ok", titre: "Rien à effacer", texte: "Aucune donnée n’a dépassé sa durée de conservation." }));
      return;
    }
    const lignes = [
      [r.demandes, "demande archivée", "demandes archivées"],
      [r.pourriels, "pourriel", "pourriels"],
      [r.corbeille, "fiche de la corbeille", "fiches de la corbeille"],
    ].filter(([n]) => n > 0);
    resultat.replaceChildren(
      avis({ ton: "info", titre: `${pluriel(total, "élément est", "éléments sont")} arrivés à échéance`, texte: lignes.map(([n, s, p]) => pluriel(n, s, p)).join(", ") + "." }),
      h("div.actions-ligne", btn("Effacer maintenant", { ton: "danger", icone: "corbeille", onclick: () => effacer(total) }))
    );
  }

  async function simuler() {
    voir.disabled = true;
    resultat.replaceChildren();
    try {
      afficher(await envoyer("/admin/purge", { simuler: true }));
    } catch (e) {
      if (!(e instanceof ErreurApi)) throw e;
      resultat.replaceChildren(avis({ ton: "erreur", texte: e.message }));
    } finally {
      voir.disabled = false;
    }
  }

  async function effacer(total) {
    const ok = await confirmer({
      titre: "Effacer ces données ?",
      message: `${pluriel(total, "élément sera effacé", "éléments seront effacés")} définitivement. Une copie de vos données a été faite aujourd’hui et reste dans les copies automatiques.`,
      libelleConfirmer: "Effacer", danger: true,
    });
    if (!ok) return;
    try {
      const r = await envoyer("/admin/purge", { simuler: false });
      await synchroniser({ complet: true });
      resultat.replaceChildren(avis({ ton: "ok", titre: "Nettoyage terminé", texte: `${pluriel(r.demandes + r.pourriels + r.corbeille, "élément effacé", "éléments effacés")}.` }));
    } catch (e) {
      if (!(e instanceof ErreurApi)) throw e;
      toastErreur(e);
    }
  }

  voir.addEventListener("click", simuler);
  return panneau(
    { titre: "Nettoyage", sous: "Voir, et au besoin lancer tout de suite, l’effacement des données échues.", niveau: 3 },
    h("div.pile", h("p", "Le CRM efface déjà tout seul ce qui a dépassé sa durée de conservation. Vous pouvez vérifier ce qui serait effacé aujourd’hui, ou le faire sans attendre."), h("div.actions-ligne", voir), resultat)
  );
}

// ----- Droits des personnes ------------------------------------------------------------------------------------------
function panneauDroits() {
  return panneau(
    { titre: "Quand une personne vous demande ses renseignements", sous: "Accès à ce que vous détenez sur elle, ou effacement.", niveau: 3 },
    h(
      "div.pile",
      h("ol.liste-numerotee", [
        h("li", "Ouvrez sa fiche dans ", h("a", { href: "#/contacts" }, "Contacts"), "."),
        h("li", "En haut de la fiche, ouvrez le menu « … », puis choisissez « Télécharger ses renseignements (Loi 25) » : un fichier réunit tout ce que le CRM détient sur elle (fiche, demandes du site, affaires, dossiers, factures, tâches, rendez-vous, notes et appels)."),
        h("li", "Pour répondre à une demande d’effacement, choisissez « Anonymiser (Loi 25) » : ses coordonnées, ses notes et le texte de ses demandes sont effacés. Les factures et les dossiers restent (obligations comptables), sans permettre de l’identifier."),
      ]),
      h("p.muet.petit", "La loi prévoit un délai de 30 jours pour répondre à une demande d’accès. Chaque téléchargement et chaque anonymisation est consigné au journal d’activité.")
    )
  );
}

// ----- Hébergement ------------------------------------------------------------------------------------------------------
function panneauHebergement() {
  const responsable = etat.config.entreprise?.responsable_vie_privee;
  return panneau(
    { titre: "Où sont vos données", sous: "À mentionner dans votre politique de confidentialité.", niveau: 3 },
    h(
      "div.pile",
      avis({
        ton: "attention",
        titre: "Les données sont hébergées aux États-Unis",
        texte: "Le CRM est hébergé par Netlify, dont l’espace de stockage se trouve dans une région des États-Unis : il n’existe pas d’option canadienne. La Loi 25 demande d’en informer les personnes concernées et d’évaluer les risques d’un hébergement hors Québec. Inscrivez-le dans votre politique de confidentialité.",
      }),
      h(
        "ul.liste-simple",
        h("li", h("strong", "Calendrier externe"), " (si vous l’activez) : titres de tâches, rendez-vous et dates limites sont copiés chez Google, Apple ou Microsoft, selon votre application."),
        h("li", h("strong", "Alertes par courriel"), " (si vous les activez) : le message du visiteur passe par Resend ou SendGrid avant d’arriver dans votre boîte."),
        h("li", h("strong", "Formulaire du site"), " : les demandes sont enregistrées directement dans ce CRM, sans autre service intermédiaire.")
      ),
      h(
        "p",
        h("strong", "Responsable de la protection des renseignements personnels : "),
        responsable || "non indiqué",
        ". ",
        h("a", { href: "#/parametres/entreprise" }, "Modifier dans « Entreprise »"),
        h("span.muet", " — son titre et ses coordonnées doivent être publiés sur votre site.")
      ),
      h("p.muet.petit", "Ces renseignements sont d’ordre général et ne remplacent pas l’avis d’un conseiller juridique. Pensez aussi à tenir un registre de tout incident de confidentialité, et à aviser la Commission d’accès à l’information lorsqu’un incident présente un risque de préjudice sérieux.")
    )
  );
}

export default async function confidentialite() {
  return h("div.pile.pile--l", panneauConservation(), panneauNettoyage(), panneauDroits(), panneauHebergement());
}
