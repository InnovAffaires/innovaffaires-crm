// Appels : l'objectif du jour, le nombre d'essais, les heures d'appel, et les scripts qui s'affichent pendant un appel.
// Le CRM ne compose pas le numéro : le bouton « Appeler » ouvre l'application de téléphone de l'appareil.
import { h, remplir } from "../../noyau/dom.js";
import { etat } from "../../noyau/etat.js";
import { ErreurApi } from "../../noyau/api.js";
import { SCRIPTS_APPEL_DEFAUT } from "../../commun/defauts.js";
import { CHAMPS_SCRIPT, analyserScript, segmenterChamps } from "../../commun/appels.js";
import { pluriel, tronquer } from "../../commun/format.js";
import { btn, btnIcone, panneau, pastille, etatVide } from "../../ui/composants.js";
import { creerChamp } from "../../ui/formulaire.js";
import { ouvrirDialogue, confirmer } from "../../ui/dialogue.js";
import { toast, toastErreur } from "../../ui/toast.js";
import { enregistrerConfig, lireChamp, panneauFormulaire, slugifier, zoneErreurDialogue, note } from "./commun.js";

const MAX_SCRIPTS = 12;
const LIBELLE_CHAMP = Object.fromEntries(CHAMPS_SCRIPT.map((x) => [x.id, x.libelle]));

// ----- Règles d'appel ----------------------------------------------------------------------------------------------
function panneauRegles() {
  const a = etat.config.appels;
  const p = panneauFormulaire({
    titre: "Règles d’appel",
    sous: "L’objectif du jour, les relances automatiques et les heures pendant lesquelles vous appelez.",
    groupes: [
      {
        titre: "Objectif et essais",
        colonnes: 2,
        champs: [
          {
            cle: "objectif_jour", valeur: a.objectif_jour,
            spec: { type: "nombre", entier: true, min: 0, max: 500, libelle: "Objectif d’appels par jour" },
            opts: { suffixe: "appels", aide: "Affiché dans la file d’attente avec une barre de progression. Laissez 0 pour ne pas avoir d’objectif." },
          },
          {
            cle: "essais_max", valeur: a.essais_max, requis: true,
            spec: { type: "nombre", entier: true, min: 1, max: 10, libelle: "Nombre d’essais par personne" },
            opts: { suffixe: "essais", aide: "Quand personne ne répond, le CRM programme un nouvel appel. Il s’arrête après ce nombre d’essais, premier appel compris." },
          },
        ],
      },
      {
        titre: "Relances et rappels",
        colonnes: 2,
        champs: [
          {
            cle: "delai_relance_jours", valeur: a.delai_relance_jours, requis: true,
            spec: { type: "nombre", entier: true, min: 1, max: 30, libelle: "Délai avant un nouvel essai" },
            opts: { suffixe: "jours ouvrables", aide: "Après « Sans réponse » ou « Message laissé »." },
          },
          {
            cle: "delai_rappel_jours", valeur: a.delai_rappel_jours, requis: true,
            spec: { type: "nombre", entier: true, min: 0, max: 30, libelle: "Délai proposé pour un rappel" },
            opts: { suffixe: "jours ouvrables", aide: "Date proposée quand la personne demande qu’on la rappelle. Vous pouvez la changer à chaque appel." },
          },
          {
            cle: "heure_rappel", valeur: a.heure_rappel, requis: true,
            spec: { type: "heure", libelle: "Heure proposée pour un rappel" },
            opts: { aide: "Pour le rappel d’une personne qui vous l’a demandé." },
          },
        ],
      },
      {
        titre: "Heures d’appel",
        aide: "Le CRM vous avertit, sans vous bloquer, quand vous appelez en dehors de ces heures.",
        colonnes: 2,
        champs: [
          { cle: "avertir_heures", valeur: a.avertir_heures, spec: { type: "booleen", libelle: "M’avertir en dehors des heures d’appel" }, etendu: true },
          { cle: "semaine_debut", valeur: a.heures_semaine.debut, requis: true, spec: { type: "heure", libelle: "En semaine — de" } },
          { cle: "semaine_fin", valeur: a.heures_semaine.fin, requis: true, spec: { type: "heure", libelle: "En semaine — jusqu’à" } },
          { cle: "fds_debut", valeur: a.heures_fin_semaine.debut, requis: true, spec: { type: "heure", libelle: "La fin de semaine — de" } },
          { cle: "fds_fin", valeur: a.heures_fin_semaine.fin, requis: true, spec: { type: "heure", libelle: "La fin de semaine — jusqu’à" } },
        ],
      },
    ],
    enregistrer: async (v) => {
      const champs = {};
      if (v.semaine_fin <= v.semaine_debut) champs.semaine_fin = "La fin doit suivre le début.";
      if (v.fds_fin <= v.fds_debut) champs.fds_fin = "La fin doit suivre le début.";
      if (Object.keys(champs).length) throw new ErreurApi("Vérifiez les heures d’appel.", { statut: 422, champs });
      await enregistrerConfig({
        appels: {
          objectif_jour: v.objectif_jour ?? 0, essais_max: v.essais_max, delai_relance_jours: v.delai_relance_jours, delai_rappel_jours: v.delai_rappel_jours,
          heure_rappel: v.heure_rappel, avertir_heures: v.avertir_heures,
          heures_semaine: { debut: v.semaine_debut, fin: v.semaine_fin },
          heures_fin_semaine: { debut: v.fds_debut, fin: v.fds_fin },
        },
      });
    },
    succes: "Règles d’appel enregistrées.",
  });
  return p.noeud;
}

// ----- Scripts -------------------------------------------------------------------------------------------------------------
function exemple() {
  const c = etat.config;
  return {
    prenom: "Marie", nom: "Tremblay", entreprise: "Ferme Tremblay inc.", projet: "Acheter un tracteur et moderniser l’étable",
    mon_nom: etat.utilisateur?.nom || "Sarah Leduc", mon_entreprise: c.entreprise.nom, mon_telephone: c.entreprise.telephone,
  };
}

/** Le script tel qu'il s'affichera pendant l'appel, avec des données d'exemple. */
function apercuScript(texte) {
  const v = exemple();
  const morceaux = (ligne) =>
    segmenterChamps(ligne).map((m) => {
      if (typeof m === "string") return m;
      if (!(m.champ in LIBELLE_CHAMP)) return h("span.script__vide", { title: "Ce champ n’existe pas" }, `{{${m.champ}}} ?`);
      return h("span.script__valeur", v[m.champ] || `[${LIBELLE_CHAMP[m.champ].toLowerCase()}]`);
    });
  return analyserScript(texte).map((sec) =>
    h(
      "section.script__section",
      sec.titre ? h("h4.script__titre", sec.titre) : null,
      sec.blocs.map((b) => (b.type === "puces" ? h("ul", b.lignes.map((l) => h("li", morceaux(l)))) : h("p", morceaux(b.texte))))
    )
  );
}

function inserer(champ, texte) {
  const el = champ.controle;
  const debut = el.selectionStart ?? el.value.length;
  const fin = el.selectionEnd ?? debut;
  el.setRangeText(texte, debut, fin, "end");
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.focus();
}

/** Fenêtre de modification d'un script. `existant` : le script modifié (ou null); `depart` : valeurs de départ d'une copie. Retourne true si enregistré. */
function editerScript({ existant = null, depart = null }) {
  const base = existant || depart || { nom: "", texte: "" };
  const defaut = existant ? SCRIPTS_APPEL_DEFAUT.find((s) => s.id === existant.id) : null;
  return ouvrirDialogue({
    titre: existant ? "Modifier le script" : "Nouveau script",
    taille: "grand",
    contenu: (ctx) => {
      const zone = zoneErreurDialogue();
      const nom = creerChamp("nom", { type: "texte", libelle: "Nom du script", max: 60, requis: true }, base.nom, { aide: "Ce que vous voyez dans la liste de choix pendant un appel." });
      const texte = creerChamp("texte", { type: "texte_long", libelle: "Texte du script", max: 6000, requis: true }, base.texte, {
        rows: 14,
        aide: "Une ligne qui commence par ## ouvre une section (« ## Ouverture »). Une ligne qui commence par un tiret devient une puce.",
      });
      const apercu = h("div.apercu-courriel__corps.script__apercu");
      const majApercu = () => remplir(apercu, apercuScript(texte.lire()));
      texte.noeud.addEventListener("input", majApercu);
      majApercu();

      const insertion = h(
        "div.champs-fusion",
        { role: "group", "aria-label": "Insérer un champ qui se remplit tout seul" },
        CHAMPS_SCRIPT.map((c) => btn(c.libelle, { petit: true, onclick: () => inserer(texte, `{{${c.id}}}`) }))
      );

      async function enregistrer() {
        zone.afficher("");
        let faute = null;
        const valeurs = {};
        for (const c of [nom, texte]) {
          const r = lireChamp(c, { requis: true });
          c.erreur(r.erreur || null);
          if (r.erreur) faute ||= c;
          else valeurs[c.cle] = r.valeur;
        }
        if (faute) return faute.focus();
        const liste = etat.config.appels.scripts.map((s) => ({ ...s }));
        if (existant) {
          const i = liste.findIndex((s) => s.id === existant.id);
          if (i < 0) return zone.afficher("Ce script n’existe plus. Fermez cette fenêtre et rechargez la page.");
          liste[i] = { ...liste[i], ...valeurs };
        } else {
          liste.push({ id: slugifier(valeurs.nom, new Set(liste.map((s) => s.id)), "script"), ...valeurs });
        }
        ctx.occupe(true);
        try {
          await enregistrerConfig({ appels: { scripts: liste } });
          ctx.occupe(false);
          ctx.fermer(true);
        } catch (e) {
          ctx.occupe(false);
          if (!(e instanceof ErreurApi)) throw e;
          zone.afficher(e.message);
        }
      }

      ctx.definirPied(
        defaut
          ? btn("Rétablir le texte d’origine", {
              petit: true,
              onclick: () => {
                nom.definir(defaut.nom);
                texte.definir(defaut.texte);
                majApercu();
                ctx.modifie(true);
              },
            })
          : null,
        btn("Annuler", { onclick: () => ctx.fermer(false) }),
        btn("Enregistrer", { ton: "primaire", onclick: enregistrer })
      );

      const formulaire = h(
        "form.formulaire",
        { novalidate: true, onsubmit: (e) => (e.preventDefault(), enregistrer()) },
        zone.noeud,
        nom.noeud,
        texte.noeud,
        h("div.champ", h("p.champ__etiquette", "Champs qui se remplissent tout seuls"), insertion, h("p.champ__aide", "Cliquez sur un champ pour l’insérer à l’endroit du curseur. Pendant l’appel, il est remplacé par la donnée de la fiche; s’il manque, il apparaît entre crochets.")),
        h("div.apercu-courriel", h("p.apercu-courriel__titre", "Aperçu avec des données d’exemple"), apercu)
      );
      formulaire.addEventListener("input", () => ctx.modifie(true));
      return formulaire;
    },
  }).promesse;
}

function ligneScript(s, { usages, surModifier, surDupliquer, surRetirer }) {
  const premiere = analyserScript(s.texte).flatMap((x) => x.blocs).find((b) => b.type === "p");
  return h(
    "li.gabarit",
    h(
      "div.gabarit__texte",
      h("strong", s.nom, " ", usages.map((u) => pastille(u, "info"))),
      h("span.muet", premiere ? tronquer(premiere.texte, 120) : "(script vide)")
    ),
    h(
      "div.gabarit__actions",
      btn("Modifier", { petit: true, icone: "modifier", onclick: surModifier }),
      btnIcone("copier", `Dupliquer « ${s.nom} »`, surDupliquer),
      btnIcone("corbeille", `Retirer « ${s.nom} »`, surRetirer, { classe: "btn-icone--danger" })
    )
  );
}

function panneauScripts() {
  const liste = h("div");
  const defauts = h("div");

  async function enregistrerScripts(scripts, patch, message) {
    try {
      await enregistrerConfig({ appels: { scripts, ...patch } });
      toast(message);
      dessiner();
    } catch (e) {
      toastErreur(e);
    }
  }

  async function ouvrirEditeur(opts) {
    if (await editerScript(opts)) {
      toast("Script enregistré.");
      dessiner();
    }
  }

  async function retirer(s) {
    const a = etat.config.appels;
    const usages = [s.id === a.script_demande ? "demandes du site" : null, s.id === a.script_prospection ? "prospection" : null].filter(Boolean);
    const ok = await confirmer({
      titre: "Retirer ce script ?",
      message: `« ${s.nom} » ne sera plus proposé pendant les appels.`,
      detail: usages.length
        ? h("p", `Il était proposé d’office pour : ${usages.join(" et ")}. Le premier script de la liste le remplacera.`)
        : SCRIPTS_APPEL_DEFAUT.some((d) => d.id === s.id) ? h("p", "C’est un script fourni au départ : vous pourrez le réajouter plus tard.") : null,
      libelleConfirmer: "Retirer", danger: true,
    });
    if (!ok) return;
    const patch = {};
    if (s.id === a.script_demande) patch.script_demande = "";
    if (s.id === a.script_prospection) patch.script_prospection = "";
    await enregistrerScripts(a.scripts.filter((x) => x.id !== s.id), patch, "Script retiré.");
  }

  function dessinerDefauts() {
    const a = etat.config.appels;
    if (a.scripts.length < 2) {
      remplir(defauts);
      return;
    }
    const options = a.scripts.map((s) => ({ id: s.id, libelle: s.nom }));
    const p = panneauFormulaire({
      titre: "Script proposé d’office",
      sous: "Celui qui s’affiche en premier pendant un appel. Vous pouvez en changer à chaque appel.",
      niveau: 4,
      groupes: [
        {
          colonnes: 2,
          champs: [
            { cle: "script_demande", valeur: a.script_demande, spec: { type: "choix", libelle: "Pour une demande reçue par le site", options } },
            { cle: "script_prospection", valeur: a.script_prospection, spec: { type: "choix", libelle: "Pour les autres appels (prospection)", options } },
          ],
        },
      ],
      enregistrer: async (v) => {
        await enregistrerConfig({ appels: { script_demande: v.script_demande || "", script_prospection: v.script_prospection || "" } });
        dessinerListe();
      },
      succes: "Choix enregistrés.",
    });
    remplir(defauts, p.noeud);
  }

  function dessinerListe() {
    const a = etat.config.appels;
    const scripts = a.scripts;
    const manquants = SCRIPTS_APPEL_DEFAUT.filter((d) => !scripts.some((s) => s.id === d.id));
    const nouveau = btn("Nouveau script", { ton: "primaire", icone: "plus", desactive: scripts.length >= MAX_SCRIPTS, onclick: () => ouvrirEditeur({}) });
    remplir(
      liste,
      scripts.length
        ? h(
            "ul.gabarits",
            scripts.map((s) =>
              ligneScript(s, {
                usages: [s.id === (a.script_demande || scripts[0]?.id) ? "Demandes du site" : null, s.id === (a.script_prospection || scripts[0]?.id) ? "Prospection" : null].filter(Boolean),
                surModifier: () => ouvrirEditeur({ existant: s }),
                surDupliquer: () => ouvrirEditeur({ depart: { nom: `${s.nom} (copie)`.slice(0, 60), texte: s.texte } }),
                surRetirer: () => retirer(s),
              })
            )
          )
        : etatVide({ icone: "note", titre: "Aucun script", texte: "Un script est le texte que vous avez sous les yeux pendant un appel : ouverture, questions à poser, réponse aux objections.", action: nouveau }),
      h(
        "div.actions-ligne",
        scripts.length ? nouveau : null,
        manquants.length
          ? btn(`Réajouter les scripts d’origine (${manquants.length})`, {
              desactive: scripts.length + manquants.length > MAX_SCRIPTS,
              onclick: () => enregistrerScripts([...scripts, ...structuredClone(manquants)], {}, manquants.length > 1 ? "Scripts d’origine réajoutés." : "Script d’origine réajouté."),
            })
          : null
      ),
      scripts.length >= MAX_SCRIPTS ? note(`La liste est pleine (${pluriel(MAX_SCRIPTS, "script")} au plus).`) : null
    );
  }

  function dessiner() {
    dessinerListe();
    dessinerDefauts();
  }
  dessiner();

  return panneau(
    { titre: "Scripts d’appel", sous: "Le texte qui s’affiche à côté de la fiche pendant un appel.", niveau: 3 },
    note("Les champs entre doubles accolades, comme {{prenom}}, se remplissent avec les données de la personne appelée."),
    liste,
    defauts
  );
}

// ----- Rappel des règles ----------------------------------------------------------------------------------------------
function panneauRegleCrtc() {
  const lien = (href, texte) => h("a", { href, target: "_blank", rel: "noopener noreferrer" }, texte);
  return panneau(
    { titre: "Ce que les règles du CRTC demandent", sous: "Un rappel à titre d’information : ce n’est pas un avis juridique.", niveau: 3 },
    h(
      "ul.liste-simple.liste-simple--espacee",
      h("li", h("strong", "Les heures d’appel. "), "Les appels de télémarketing sont permis de 9 h à 21 h 30 en semaine, et de 10 h à 18 h la fin de semaine. C’est ce que le CRM vous rappelle, selon les heures réglées plus haut."),
      h("li", h("strong", "Vous présenter. "), "Le télévendeur doit se présenter clairement dès le début de l’appel. Les scripts d’origine commencent ainsi."),
      h("li", h("strong", "La liste interne de numéros exclus. "), "Quand quelqu’un demande de ne plus être appelé, son numéro doit être ajouté à votre propre liste dans les 14 jours, et y rester pendant 3 ans et 14 jours. Le résultat « Ne plus appeler » le fait tout de suite : la personne disparaît de la file et ne peut plus y être ajoutée. La mention reste sur sa fiche jusqu’à ce que vous la retiriez."),
      h("li", h("strong", "La liste nationale (LNNTE). "), "Un télévendeur doit s’y inscrire avant de faire des appels non sollicités, même si ses appels sont exemptés. Les appels à un numéro d’entreprise ne sont pas visés par les règles de la LNNTE, mais ils restent soumis aux règles de télémarketing. Le CRM ne consulte pas la LNNTE : si vous appelez des particuliers, vérifiez les numéros avant d’appeler.")
    ),
    h("p.muet", "Pour les détails et les exemptions : ", lien("https://crtc.gc.ca/fra/phone/telemarketing/tobligations/regles-rules.htm", "principales règles du CRTC"), " et ", lien("https://crtc.gc.ca/fra/phone/telemarketing/exempt.htm", "appels exemptés"), ". En cas de doute, consultez un conseiller juridique.")
  );
}

export default async function appels() {
  return h(
    "div.pile.pile--l",
    note("Le CRM ne compose pas le numéro à votre place : le bouton « Appeler » ouvre l’application de téléphone de votre appareil. Le CRM garde la file d’attente, le script, le chronomètre et l’historique des appels."),
    panneauRegles(),
    panneauScripts(),
    panneauRegleCrtc()
  );
}
