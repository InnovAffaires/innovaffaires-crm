// Calendrier externe : un lien secret pour voir vos tâches datées, vos rendez-vous et vos dates limites
// dans Google Agenda, le Calendrier d'Apple ou Outlook.
import { h, copierTexte, idUnique } from "../../noyau/dom.js";
import { icone } from "../../noyau/icones.js";
import { etat, notifier } from "../../noyau/etat.js";
import { envoyer, ErreurApi } from "../../noyau/api.js";
import { google } from "../../noyau/google.js";
import { btn, panneau, avis, listeDef } from "../../ui/composants.js";
import { confirmer } from "../../ui/dialogue.js";
import { toastErreur } from "../../ui/toast.js";
import { enregistrerConfig } from "./commun.js";

const lien = (jeton) => `${location.origin}/api/calendrier/${jeton}.ics`;

const APPLICATIONS = [
  {
    nom: "Google Agenda",
    etapes: [
      "Sur un ordinateur, ouvrez calendar.google.com.",
      "À gauche, à côté de « Autres agendas », cliquez sur « + », puis sur « À partir de l’URL ».",
      "Collez le lien copié, puis cliquez sur « Ajouter l’agenda ».",
    ],
    aide: "L’application Google Agenda du téléphone ne permet pas d’ajouter un abonnement : faites-le sur ordinateur, il apparaîtra ensuite aussi sur le téléphone.",
  },
  {
    nom: "Calendrier d’Apple (Mac, iPhone, iPad)",
    etapes: [
      "Le plus simple : cliquez sur « Ouvrir dans mon application » ci-dessus depuis l’appareil Apple, puis confirmez l’abonnement.",
      "Sur Mac, vous pouvez aussi choisir Fichier › Nouvel abonnement à un calendrier, puis coller le lien.",
      "Sur iPhone : Réglages › Calendrier › Comptes › Ajouter un compte › Autre › Ajouter un calendrier avec abonnement.",
    ],
  },
  {
    nom: "Outlook",
    etapes: [
      "Ouvrez Outlook sur le web (outlook.office.com), puis la vue Calendrier.",
      "Cliquez sur « Ajouter un calendrier », puis sur « S’abonner à partir du web ».",
      "Collez le lien, donnez un nom au calendrier (par exemple « CRM InnovAffaires »), puis cliquez sur « Importer ».",
    ],
  },
];

const CONTENU = [
  ["Tâches", "Les tâches non terminées qui ont une échéance, précédées de ☐. Le titre et la description de la tâche sont copiés."],
  ["Rendez-vous", "Les rendez-vous et événements de votre calendrier du CRM, avec leur lieu et leurs notes."],
  ["Dates limites", "La date limite de dépôt des dossiers de financement encore en préparation, précédée de ⚑, avec un rappel la veille. Le nom du programme et du client y figurent."],
];

function blocApplications() {
  return h(
    "div.replies",
    APPLICATIONS.map((a) =>
      h(
        "details.replie",
        h("summary.replie__titre", icone("droite", "ic--p replie__fleche"), h("span.replie__nom", a.nom)),
        h("div.replie__corps", h("ol.liste-numerotee", a.etapes.map((e) => h("li", e))), a.aide ? h("p.muet.petit", a.aide) : null)
      )
    )
  );
}

export default async function calendrier() {
  const racine = h("div.pile.pile--l");
  const cal = () => etat.config.calendrier || { actif: false, jeton: "" };

  async function activer() {
    try {
      await enregistrerConfig({ calendrier: { actif: true } });
      dessiner();
    } catch (e) {
      if (!(e instanceof ErreurApi)) throw e;
      toastErreur(e);
    }
  }

  async function desactiver() {
    const ok = await confirmer({
      titre: "Désactiver le calendrier externe ?",
      message: "Le lien cesse de fonctionner tout de suite : les calendriers qui y sont abonnés ne se mettront plus à jour.",
      detail: h("p.muet", "Si vous le réactivez plus tard, vous retrouverez le même lien."),
      libelleConfirmer: "Désactiver",
    });
    if (!ok) return;
    try {
      await enregistrerConfig({ calendrier: { actif: false } });
      dessiner();
    } catch (e) {
      if (!(e instanceof ErreurApi)) throw e;
      toastErreur(e);
    }
  }

  async function regenerer() {
    const ok = await confirmer({
      titre: "Générer un nouveau lien ?",
      message: "L’ancien lien cessera de fonctionner tout de suite. Les calendriers déjà abonnés n’afficheront plus rien tant que vous ne les aurez pas abonnés au nouveau lien.",
      detail: h("p.muet", "À faire si vous pensez que le lien a été vu par quelqu’un qui ne devrait pas."),
      libelleConfirmer: "Générer un nouveau lien", danger: true,
    });
    if (!ok) return;
    try {
      const rep = await envoyer("/config/calendrier-jeton", {});
      etat.config = rep.config;
      notifier("config");
      dessiner({ nouveau: true });
    } catch (e) {
      if (!(e instanceof ErreurApi)) throw e;
      toastErreur(e);
    }
  }

  /** Inclure (ou non) les rendez-vous dans le lien : utile quand Google Agenda les reçoit déjà directement. */
  async function reglerRendezVous(entree) {
    entree.disabled = true;
    try {
      await enregistrerConfig({ calendrier: { rendez_vous: entree.checked } });
      dessiner({ reglage: true });
    } catch (e) {
      if (!(e instanceof ErreurApi)) throw e;
      entree.checked = !entree.checked;
      entree.disabled = false;
      toastErreur(e);
    }
  }

  function dessiner({ nouveau = false, reglage = false } = {}) {
    const c = cal();
    const avecRdv = c.rendez_vous !== false;
    const contenu = panneau(
      { titre: "Ce qui apparaît dans le calendrier", niveau: 3 },
      listeDef(CONTENU.map(([k, v]) => (k === "Rendez-vous" && c.actif && !avecRdv ? [k, "Non inclus : vous avez choisi de les retirer du lien (option « Inclure les rendez-vous dans le lien » ci-dessus)."] : [k, v])), { classe: "def--roles" })
    );

    if (!c.actif || !c.jeton) {
      racine.replaceChildren(
        panneau(
          { titre: "Abonnement au calendrier", sous: "Voir le CRM dans l’application de calendrier que vous utilisez déjà.", niveau: 3 },
          h(
            "div.pile",
            h("p", "En activant cette fonction, le CRM crée un lien secret auquel vous abonnez Google Agenda, le Calendrier d’Apple ou Outlook. Vos tâches datées, vos rendez-vous et vos dates limites s’y affichent alors à côté du reste de votre vie."),
            h("p.muet", "La fonction est désactivée : aucun calendrier n’est publié."),
            h("div.actions-ligne", btn("Activer le calendrier externe", { ton: "primaire", icone: "calendrier-plus", onclick: activer }))
          )
        ),
        contenu
      );
      return;
    }

    const url = lien(c.jeton);
    const statut = h("p.reglages__statut.reglages__statut--bloc", { role: "status", "aria-live": "polite" });
    if (nouveau) statut.replaceChildren(icone("coche", "ic--p"), " Nouveau lien généré. L’ancien ne fonctionne plus : abonnez vos calendriers à celui-ci.");
    if (reglage) statut.replaceChildren(icone("coche", "ic--p"), " Réglage enregistré. Les calendriers abonnés se mettent à jour d’eux-mêmes.");
    const idRdv = idUnique("ics-rdv");
    const caseRdv = h("input", { id: idRdv, type: "checkbox", onchange: (ev) => reglerRendezVous(ev.currentTarget) });
    caseRdv.checked = avecRdv;
    const champ = h("input.saisie.saisie--lien", { type: "text", readOnly: true, value: url, "aria-label": "Lien d’abonnement au calendrier", spellcheck: "false", onfocus: (e) => e.target.select() });

    racine.replaceChildren(
      panneau(
        { titre: "Votre lien d’abonnement", sous: "Le calendrier externe est activé.", niveau: 3 },
        h(
          "div.pile",
          h("div.lien-secret", champ),
          h(
            "div.actions-ligne",
            btn("Copier le lien", {
              ton: "primaire", icone: "copier",
              onclick: async () => {
                const ok = await copierTexte(url);
                statut.replaceChildren(ok ? icone("coche", "ic--p") : "", ok ? " Lien copié. Collez-le dans votre application de calendrier." : "La copie n’a pas fonctionné : cliquez dans le champ, sélectionnez le lien et copiez-le à la main.");
              },
            }),
            btn("Ouvrir dans mon application", { icone: "externe", href: url.replace(/^https?:/, "webcal:") })
          ),
          statut,
          h(
            "div.pile.pile--s",
            h("label.case", { for: idRdv }, caseRdv, h("span.case__boite", { "aria-hidden": "true" }, icone("coche", "ic--p")), h("span", "Inclure les rendez-vous dans le lien")),
            google().configure && google().fonctions?.agenda && avecRdv
              ? avis({
                  ton: "info", titre: "Google Agenda reçoit déjà les rendez-vous directement",
                  texte: "Les personnes qui relient leur compte Google (Paramètres → Google) reçoivent leurs rendez-vous dans leur Google Agenda. Si elles abonnent aussi Google Agenda à ce lien, ces rendez-vous apparaîtront en double : décochez l’option ci-dessus pour les retirer du lien.",
                })
              : null
          ),
          avis({
            ton: "attention",
            titre: "Ce lien est un secret",
            texte: "Toute personne qui possède ce lien peut lire vos tâches, vos rendez-vous et vos dates limites. Ne le partagez pas. Ces renseignements sont aussi copiés chez le fournisseur de votre calendrier (Google, Apple, Microsoft). Si le lien a été vu par quelqu’un qui ne devrait pas, générez-en un nouveau.",
          }),
          h(
            "div.actions-ligne",
            btn("Générer un nouveau lien…", { icone: "cle", onclick: regenerer }),
            btn("Désactiver le calendrier externe…", { ton: "danger", onclick: desactiver })
          )
        )
      ),
      panneau({ titre: "Comment l’ajouter", sous: "Une seule fois par application ; les changements arrivent ensuite d’eux-mêmes.", niveau: 3 }, h("div.pile", blocApplications(), h("p.muet.petit", "Le calendrier se met à jour tout seul, mais pas en direct : comptez de quelques minutes à une journée selon l’application (Google Agenda est la plus lente)."))),
      contenu
    );
    if (reglage) caseRdv.focus();
  }

  dessiner();
  return racine;
}
