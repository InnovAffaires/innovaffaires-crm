// Les étapes d'une affaire (du premier contact au mandat) et les statuts d'un dossier de financement.
import { h } from "../../noyau/dom.js";
import { etat, actives } from "../../noyau/etat.js";
import { ETAPES_DEFAUT, STATUTS_DOSSIER_DEFAUT } from "../../commun/defauts.js";
import { normaliser, pluriel } from "../../commun/format.js";
import { btn } from "../../ui/composants.js";
import { confirmer } from "../../ui/dialogue.js";
import { editeurListe, panneauListeEditable, enregistrerConfig, note } from "./commun.js";

const TYPES_ETAPE = [
  { id: "ouverte", libelle: "En cours" },
  { id: "gagnee", libelle: "Gagnée" },
  { id: "perdue", libelle: "Perdue" },
];
const TYPES_STATUT = [
  { id: "en-cours", libelle: "En cours" },
  { id: "accepte", libelle: "Accepté" },
  { id: "refuse", libelle: "Refusé" },
  { id: "termine", libelle: "Terminé" },
];

/** Nombre de fiches actives de `entite` dont `champ` vaut `id` : ce qui sert encore ne peut pas être retiré. */
const usage = (entite, champ, id) => (id ? actives(entite).filter((f) => f[champ] === id).length : 0);

/** Deux lignes portent-elles le même nom ? Retourne le nom en double, ou null. */
function nomEnDouble(valeurs, cle) {
  const vus = new Set();
  for (const v of valeurs) {
    const n = normaliser(v[cle]);
    if (vus.has(n)) return v[cle];
    vus.add(n);
  }
  return null;
}

async function retablir(editeur, defauts, quoi) {
  const ok = await confirmer({
    titre: "Rétablir la liste d’origine ?",
    message: `${quoi} reprendront leur forme de départ dans cet écran. Rien ne change tant que vous n’avez pas cliqué sur « Enregistrer ».`,
    libelleConfirmer: "Rétablir",
  });
  if (ok) editeur.definir(structuredClone(defauts));
}

function panneauEtapes() {
  const editeur = editeurListe({
    items: etat.config.etapes,
    colonnes: [
      { cle: "nom", libelle: "Nom de l’étape", spec: { type: "texte", max: 60, requis: true } },
      { cle: "probabilite", libelle: "Chances de gagner", largeur: "9.5rem", spec: { type: "pourcent", requis: true } },
      { cle: "type", libelle: "Signification", largeur: "10.5rem", spec: { type: "choix", options: TYPES_ETAPE, requis: true } },
    ],
    nouveau: () => ({ nom: "", probabilite: 50, type: "ouverte" }),
    nomPourId: (v) => v.nom,
    libelleLigne: (v) => v.nom || "Nouvelle étape",
    protege: (v) => {
      const n = usage("opportunites", "etape", v.id);
      return n ? `${pluriel(n, "affaire utilise", "affaires utilisent")} cette étape : déplacez-les d’abord.` : null;
    },
    minimum: 3, maximum: 15, libelleAjout: "Ajouter une étape", compacte: true, elements: ["étape", "étapes"],
  });

  const panneau = panneauListeEditable({
    titre: "Étapes d’une affaire",
    sous: "Elles forment les colonnes du tableau des affaires, de gauche à droite.",
    intro: [
      note("Utilisez les flèches pour changer l’ordre. Les chances de gagner servent à estimer la valeur de vos affaires en cours."),
      note("« Gagnée » veut dire mandat obtenu ; « Perdue » ferme l’affaire sans mandat (il n’y en a qu’une). Une étape retirée doit d’abord ne plus servir."),
    ],
    editeur,
    valider: (v) => {
      if (!v.some((e) => e.type === "ouverte")) return "Gardez au moins une étape « En cours ».";
      if (!v.some((e) => e.type === "gagnee")) return "Gardez au moins une étape « Gagnée ».";
      if (v.filter((e) => e.type === "perdue").length !== 1) return "Il faut exactement une étape « Perdue ».";
      const double = nomEnDouble(v, "nom");
      return double ? `Deux étapes portent le même nom : « ${double} ».` : null;
    },
    enregistrer: async (valeurs) => (await enregistrerConfig({ etapes: valeurs })).etapes,
    succes: "Étapes enregistrées.",
    actionsPied: btn("Rétablir la liste d’origine", { petit: true, onclick: () => retablir(editeur, ETAPES_DEFAUT, "Les étapes") }),
  });
  return panneau.noeud;
}

function panneauStatuts() {
  const editeur = editeurListe({
    items: etat.config.statuts_dossier,
    colonnes: [
      { cle: "nom", libelle: "Nom du statut", spec: { type: "texte", max: 60, requis: true } },
      { cle: "type", libelle: "Signification", largeur: "10.5rem", spec: { type: "choix", options: TYPES_STATUT, requis: true } },
    ],
    nouveau: () => ({ nom: "", type: "en-cours" }),
    nomPourId: (v) => v.nom,
    libelleLigne: (v) => v.nom || "Nouveau statut",
    protege: (v) => {
      const n = usage("dossiers", "statut", v.id);
      return n ? `${pluriel(n, "dossier utilise", "dossiers utilisent")} ce statut : changez-les d’abord.` : null;
    },
    minimum: 3, maximum: 20, libelleAjout: "Ajouter un statut", compacte: true, elements: ["statut", "statuts"],
  });

  const panneau = panneauListeEditable({
    titre: "Statuts d’un dossier de financement",
    sous: "Du début de la préparation jusqu’à la reddition de comptes.",
    intro: [
      note("Les tâches automatiques (section voisine) se déclenchent quand un dossier arrive à un statut."),
      note("« En cours » : le dossier est en préparation ou en analyse. « Accepté » : l’aide est accordée et le suivi continue. « Refusé » : le CRM demande la raison du refus. « Terminé » : le dossier est clos."),
    ],
    editeur,
    valider: (v) => {
      for (const [type, nom] of [["en-cours", "En cours"], ["accepte", "Accepté"], ["refuse", "Refusé"]]) {
        if (!v.some((s) => s.type === type)) return `Gardez au moins un statut « ${nom} ».`;
      }
      const double = nomEnDouble(v, "nom");
      return double ? `Deux statuts portent le même nom : « ${double} ».` : null;
    },
    enregistrer: async (valeurs) => (await enregistrerConfig({ statuts_dossier: valeurs })).statuts_dossier,
    succes: "Statuts enregistrés.",
    actionsPied: btn("Rétablir la liste d’origine", { petit: true, onclick: () => retablir(editeur, STATUTS_DOSSIER_DEFAUT, "Les statuts") }),
  });
  return panneau.noeud;
}

export default async function etapes() {
  return h("div.pile.pile--l", panneauEtapes(), panneauStatuts());
}
