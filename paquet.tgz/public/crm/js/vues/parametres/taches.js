// Les tâches que le CRM crée tout seul quand un dossier arrive à un statut.
import { h } from "../../noyau/dom.js";
import { icone } from "../../noyau/icones.js";
import { etat } from "../../noyau/etat.js";
import { ErreurApi } from "../../noyau/api.js";
import { GABARITS_TACHES_DEFAUT, STATUTS_AVANT_DEPOT } from "../../commun/defauts.js";
import { pluriel } from "../../commun/format.js";
import { btn, panneau, avis } from "../../ui/composants.js";
import { confirmer } from "../../ui/dialogue.js";
import { editeurListe, enregistrerConfig, note } from "./commun.js";

const TYPES = [
  { id: "tache", libelle: "Tâche" },
  { id: "appel", libelle: "Appel" },
  { id: "courriel", libelle: "Courriel" },
  { id: "rendezvous", libelle: "Rendez-vous" },
  { id: "texto", libelle: "Texto" },
];
const PRIORITES = [
  { id: "haute", libelle: "Haute" },
  { id: "normale", libelle: "Normale" },
  { id: "basse", libelle: "Basse" },
];

const libelleTaches = (n) => (n ? pluriel(n, "tâche") : "aucune tâche");

function creerEditeur(statutId) {
  return editeurListe({
    items: etat.config.gabarits_taches?.[statutId] || [],
    colonnes: [
      { cle: "titre", libelle: "Ce qu’il y a à faire", etendu: true, spec: { type: "texte_long", max: 300, requis: true }, opts: { rows: 2 } },
      { cle: "type", libelle: "Genre", largeur: "minmax(0, 11rem)", spec: { type: "choix", options: TYPES, requis: true } },
      { cle: "priorite", libelle: "Priorité", largeur: "minmax(0, 10rem)", spec: { type: "choix", options: PRIORITES, requis: true } },
      { cle: "delai", libelle: "Délai (jours)", largeur: "minmax(0, 8rem)", spec: { type: "nombre", entier: true, min: 0, max: 365 }, opts: { placeholder: "Aucun" } },
      { cle: "description", libelle: "Précisions (facultatif)", etendu: true, spec: { type: "texte_long", max: 500 }, opts: { rows: 1 } },
    ],
    nouveau: () => ({ titre: "", type: "tache", priorite: "normale", delai: 3, description: "" }),
    libelleLigne: (v) => v.titre || "Nouvelle tâche",
    suffixeId: false, minimum: 0, maximum: 40, libelleAjout: "Ajouter une tâche", prefixeLigne: "Tâche",
    vide: "Aucune tâche automatique pour ce statut.",
  });
}

export default async function taches() {
  const statuts = etat.config.statuts_dossier;
  const alerte = h("div.formulaire__alerte", { role: "alert", hidden: true });
  const statut = h("span.reglages__statut", { role: "status", "aria-live": "polite" });
  const bouton = btn("Enregistrer les tâches", { ton: "primaire", type: "submit" });
  let minuteur = null;

  const blocs = statuts.map((s) => {
    const editeur = creerEditeur(s.id);
    const compte = h("span.replie__compte.muet");
    const majCompte = () => (compte.textContent = libelleTaches(editeur.nombre()));
    majCompte();
    const retablir = btn("Rétablir les tâches d’origine", {
      petit: true,
      onclick: async () => {
        const defaut = GABARITS_TACHES_DEFAUT[s.id] || [];
        const ok = await confirmer({
          titre: "Rétablir les tâches d’origine ?",
          message: `Les tâches du statut « ${s.nom} » reprendront leur forme de départ dans cet écran. Rien ne change tant que vous n’avez pas cliqué sur « Enregistrer les tâches ».`,
          libelleConfirmer: "Rétablir",
        });
        if (!ok) return;
        editeur.definir(structuredClone(defaut));
        majCompte();
      },
    });
    const avantDepot = STATUTS_AVANT_DEPOT.includes(s.id);
    const details = h(
      "details.replie",
      h("summary.replie__titre", icone("droite", "ic--p replie__fleche"), h("span.replie__nom", s.nom), compte),
      h(
        "div.replie__corps",
        h("p.muet.petit", avantDepot ? "Créées quand un dossier arrive à ce statut. Aucune n’est datée après la date limite du dossier." : "Créées quand un dossier arrive à ce statut."),
        editeur.noeud,
        h("div.actions-ligne", retablir)
      )
    );
    // Les zones de texte se mesurent mal tant que la section est fermée : on les ajuste à l'ouverture.
    details.addEventListener("toggle", () => {
      if (details.open) for (const ta of details.querySelectorAll("textarea")) ta.dispatchEvent(new Event("input", { bubbles: true }));
    });
    details.addEventListener("click", () => queueMicrotask(majCompte));
    details.addEventListener("input", () => queueMicrotask(majCompte));
    return { s, editeur, details };
  });

  async function soumettre(e) {
    e.preventDefault();
    clearTimeout(minuteur);
    statut.textContent = "";
    alerte.hidden = true;
    const resultat = {};
    let premier = null;
    let fautes = 0;
    for (const b of blocs) {
      const { valeurs, erreurs } = b.editeur.lire();
      const n = Object.keys(erreurs).length;
      if (n) {
        fautes += n;
        b.details.open = true;
        premier ||= b.editeur.premierChampEnErreur();
      }
      resultat[b.s.id] = valeurs.map((v) => {
        const t = { titre: v.titre.replace(/\s+/g, " ").trim(), type: v.type, priorite: v.priorite, delai: v.delai ?? null };
        if (v.description) t.description = v.description;
        return t;
      });
    }
    if (fautes) {
      alerte.hidden = false;
      alerte.textContent = fautes === 1 ? "Un champ est à corriger." : "Certains champs sont à corriger.";
      premier?.focus();
      return;
    }
    bouton.disabled = true;
    bouton.setAttribute("aria-busy", "true");
    try {
      const config = await enregistrerConfig({ gabarits_taches: resultat });
      for (const b of blocs) b.editeur.definir(config.gabarits_taches?.[b.s.id] || []);
      statut.replaceChildren(icone("coche", "ic--p"), " Tâches enregistrées.");
      minuteur = setTimeout(() => (statut.textContent = ""), 7000);
    } catch (err) {
      if (!(err instanceof ErreurApi)) throw err;
      alerte.hidden = false;
      alerte.textContent = err.message;
    } finally {
      bouton.disabled = false;
      bouton.removeAttribute("aria-busy");
    }
  }

  const form = h(
    "form.formulaire",
    { novalidate: true, autocomplete: "off", onsubmit: soumettre },
    alerte,
    h("div.replies", blocs.map((b) => b.details)),
    h("div.reglages__pied", statut, bouton)
  );
  form.addEventListener("input", () => (statut.textContent = ""));

  return h(
    "div.pile.pile--l",
    avis({
      ton: "info",
      titre: "Comment ça marche",
      texte: "Quand un dossier est créé ou change de statut, le CRM ajoute à ce dossier les tâches prévues pour ce statut. Le délai se compte en jours à partir de ce moment ; sans délai, la tâche n’a pas de date.",
    }),
    panneau(
      { titre: "Tâches par statut", sous: "Ouvrez un statut pour voir et modifier ses tâches.", niveau: 3 },
      h(
        "div.pile",
        note("Une tâche déjà créée dans un dossier n’est jamais recréée, même si vous la supprimez. Changer cette liste ne touche pas aux tâches déjà créées."),
        form
      )
    )
  );
}
