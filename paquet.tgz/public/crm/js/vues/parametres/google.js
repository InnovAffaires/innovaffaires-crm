// =============================================================================
// Paramètres → Google (Gmail et Google Agenda).
//   • « Mon compte Google » : connecter son compte, voir ce qui est actif, tester, se déconnecter.
//   • Administration : assistant de configuration (une seule fois), identifiants, fonctions offertes, équipe.
// La page gère elle-même son état : une saisie en cours n'est jamais perdue par un redessin automatique.
// =============================================================================
import { h } from "../../noyau/dom.js";
import { icone } from "../../noyau/icones.js";
import { etat, nomUtilisateur } from "../../noyau/etat.js";
import { envoyer, supprimer, modifier, ErreurApi } from "../../noyau/api.js";
import { lireAdresse, majRequete } from "../../noyau/routeur.js";
import { dateCourte, ilYa, pluriel } from "../../commun/format.js";
import { btn, panneau, avis, listeDef, pastille, chargement, etatVide } from "../../ui/composants.js";
import { confirmer } from "../../ui/dialogue.js";
import { toast, toastErreur } from "../../ui/toast.js";
import { creerChamp } from "../../ui/formulaire.js";
import { definirEtatGoogle, rafraichirGoogle, connecterGoogle, synchroniserAgenda, resumeSynchro, google, FONCTIONS_LIBELLES } from "../../noyau/google.js";
import { classement, propositionsEnAttente } from "../../noyau/classement.js";
import { assistantConfiguration, formulaireIdentifiants } from "./google-assistant.js";

const FONCTIONS = ["gmail_envoi", "gmail_echanges", "agenda"];

const DESCRIPTIONS = {
  gmail_envoi: "Les courriels écrits depuis une fiche partent de votre adresse Gmail et se retrouvent dans vos « Envoyés ».",
  gmail_echanges: "Sur la fiche d’un contact, d’une entreprise ou d’un dossier, la liste des courriels échangés avec ses adresses (objet, date et court extrait seulement : rien n’est copié dans le CRM). La page « Courriels » s’en sert aussi, si vous l’activez, pour vous proposer les personnes à ajouter à votre CRM.",
  agenda: "Vos rendez-vous du CRM apparaissent dans votre Google Agenda (avec un lien Google Meet si vous le demandez), et vos autres événements s’affichent dans le calendrier du CRM.",
};

/** Ce que la personne lit quand Google la renvoie au CRM avec une erreur (…?google=erreur&motif=…). */
const MOTIFS = {
  refuse: ["Connexion annulée", "Vous avez refusé l’autorisation sur la page de Google : rien n’a été connecté. Vous pouvez recommencer quand vous voulez."],
  portees: ["Autorisations refusées", "Google n’a accordé aucune des autorisations demandées. Recommencez et laissez toutes les cases cochées sur la page de Google (certaines y sont parfois décochées au départ)."],
  etat: ["Lien de retour expiré", "Le retour de Google a expiré ou a déjà servi (il ne vaut que 10 minutes). Cliquez de nouveau sur « Connecter mon compte Google »."],
  cookie: ["Connexion lancée depuis un autre navigateur", "Recommencez depuis cette page, avec le même navigateur et sans passer par un autre appareil. Vérifiez aussi que ce site peut enregistrer des témoins (cookies)."],
  identifiants: ["Identifiants refusés par Google", "Google ne reconnaît pas l’ID client ou le secret enregistrés. Une personne qui administre le CRM doit les vérifier (étape 6 de la configuration)."],
  echange: ["Google a refusé la dernière étape", "Réessayez. Si cela se répète, vérifiez que l’adresse de redirection enregistrée chez Google est exactement celle de l’étape 5 de la configuration."],
  courriel: ["Adresse courriel manquante", "Google n’a pas transmis l’adresse du compte. Recommencez en laissant toutes les cases cochées."],
  refresh: ["Connexion durable non accordée", "Google n’a pas remis la clé qui garde la connexion active. Retirez l’accès « CRM InnovAffaires » dans votre compte Google (myaccount.google.com/permissions), puis recommencez."],
  config: ["Configuration modifiée", "La configuration de Google a changé pendant la connexion. Recommencez."],
  limite: ["Trop de tentatives", "Patientez quelques minutes avant de réessayer."],
  google: ["Google a signalé un problème", "Réessayez dans un moment. Si Google affiche « accès bloqué » ou « application non validée », reprenez l’étape 3 de la configuration (type de public)."],
  interne: ["Erreur inattendue", "Réessayez dans un moment."],
};

/** Lit (et efface de l'adresse) le résultat d'un retour de Google. */
function lireRetour() {
  const q = lireAdresse().requete;
  const g = q.get("google");
  if (!g) return null;
  const motif = q.get("motif") || "interne";
  majRequete({}, { chemin: "/parametres/google" });
  return g === "ok" ? { ok: true } : { ok: false, motif: motif in MOTIFS ? motif : "interne" };
}

const ms = (iso) => {
  const t = Date.parse(iso || "");
  return Number.isFinite(t) ? t : 0;
};

export default async function pageGoogle() {
  const racine = h("div.pile.pile--l.gg-page");
  const admin = !!etat.droits.administrer;
  let banniere = lireRetour();
  let e = null;
  let verif = null; // résultat de la dernière vérification des identifiants (administration)
  let message = null; // confirmation brève en haut de page

  async function charger() {
    racine.replaceChildren(chargement("Chargement de l’état de Google…"));
    try {
      e = await rafraichirGoogle();
    } catch (err) {
      if (!(err instanceof ErreurApi)) throw err;
      racine.replaceChildren(
        etatVide({ icone: "alerte", titre: "L’état de Google est introuvable", texte: err.message, action: btn("Réessayer", { ton: "primaire", icone: "rafraichir", onclick: charger }) })
      );
      return;
    }
    dessiner();
  }

  /** Reprend l'état partagé après un appel qui l'a modifié. */
  const reprendre = (rep) => {
    if (rep) definirEtatGoogle(rep);
    e = google();
  };

  // ----- Bandeaux ----------------------------------------------------------------------------------------------------------
  function bandeaux() {
    const out = [];
    if (banniere) {
      if (banniere.ok) {
        const manquantes = e.moi?.manquantes || [];
        out.push(
          avis({
            ton: "ok", role: "status", titre: "Compte Google connecté",
            texte: `${e.moi?.courriel ? `Votre compte ${e.moi.courriel} est connecté. ` : ""}${manquantes.length ? "" : "Les fonctions activées par l’administration sont prêtes."}`,
          })
        );
      } else {
        const [titre, texte] = MOTIFS[banniere.motif];
        out.push(avis({ ton: "erreur", titre, texte }));
      }
    }
    if (message) out.push(avis({ ton: message.ton || "ok", role: "status", texte: message.texte }));
    return out;
  }

  // ----- Mon compte Google ----------------------------------------------------------------------------------------------
  function panneauCompte() {
    const moi = e.moi || { connecte: false };
    const id = "google-compte";

    if (!e.configure) {
      return panneau(
        { titre: "Mon compte Google", sous: "Gmail et Google Agenda, depuis le CRM.", niveau: 3, id },
        avis({
          ton: "info", titre: "Google n’est pas encore configuré",
          texte: admin ? "Faites d’abord la configuration ci-dessus (une seule fois) : vous pourrez ensuite connecter votre compte." : "Une personne qui administre le CRM doit d’abord faire la configuration (une seule fois, environ 15 minutes). Vous pourrez ensuite connecter votre compte ici.",
        })
      );
    }

    const offertes = FONCTIONS.filter((k) => e.fonctions[k]);

    if (!moi.connecte) {
      return panneau(
        { titre: "Mon compte Google", sous: "Connectez votre compte pour utiliser Gmail et Google Agenda depuis le CRM.", niveau: 3, id },
        h(
          "div.pile",
          listeDef(offertes.map((k) => [FONCTIONS_LIBELLES[k], DESCRIPTIONS[k]]), { classe: "def--roles" }),
          h("p.muet", "Google vous demandera d’autoriser le CRM : choisissez votre compte et laissez toutes les cases cochées. Vous pouvez vous déconnecter à tout moment, ici ou dans les réglages de sécurité de votre compte Google."),
          h("div.actions-ligne", btn("Connecter mon compte Google", { ton: "primaire", icone: "lien", onclick: seConnecter }))
        )
      );
    }

    const aReconnecter = moi.etat === "a_reconnecter";
    const zoneInfos = h("div");
    const zoneActions = h("div.actions-ligne");
    const zoneResultat = h("div.pile.pile--s", { role: "status", "aria-live": "polite" });
    let signatureActions = "";

    /** La liste des fonctions avec l'état de chacune pour cette personne. */
    const listeFonctions = () => {
      const m = e.moi;
      return h(
        "ul.gg-fonctions",
        FONCTIONS.map((k) => {
          let ton = "ok";
          let texte = "Active";
          if (!e.fonctions[k]) [ton, texte] = ["neutre", "Désactivée par l’administration"];
          else if (m.etat === "a_reconnecter") [ton, texte] = ["attention", "À reconnecter"];
          else if (!m.accordees?.[k]) [ton, texte] = ["attention", "Non autorisée par Google"];
          else if ((k === "agenda" && m.prefs?.agenda === false) || (k === "gmail_echanges" && m.prefs?.echanges === false)) [ton, texte] = ["neutre", "En pause (à votre demande)"];
          return h("li.gg-fonction", h("span.gg-fonction__nom", FONCTIONS_LIBELLES[k]), pastille(texte, ton));
        })
      );
    };

    /** Redessine ce qui dépend de l'état (fonctions, dernière synchronisation, boutons offerts) sans toucher au reste de la page. */
    const dessinerZones = () => {
      const m = e.moi;
      const act = m.actives || {};
      zoneInfos.replaceChildren(
        listeDef([
          ["Compte Google", m.courriel],
          ["Connecté depuis", m.cree ? dateCourte(m.cree.slice(0, 10)) : null],
          ["Dernière synchronisation de l’agenda", act.agenda ? (m.derniere_synchro ? ilYa(ms(m.derniere_synchro)) : "Pas encore faite") : null],
          ["Fonctions", listeFonctions()],
        ])
      );
      // Les boutons ne sont redessinés que si l'offre change : le focus du clavier reste là où il est.
      const signature = `${!!act.gmail_envoi}|${!!act.agenda}`;
      if (signature !== signatureActions) {
        signatureActions = signature;
        zoneActions.replaceChildren(...boutons(act));
      }
    };

    // Préférences personnelles : interrupteurs enregistrés tout de suite.
    const interrupteur = (pref, libelle, offerte) => {
      if (!offerte) return null;
      const champ = creerChamp(`gg-pref-${pref}`, { type: "booleen", libelle }, moi.prefs?.[pref] !== false);
      champ.noeud.addEventListener("change", async () => {
        const voulu = !!champ.lire();
        champ.desactiver(true);
        try {
          reprendre(await modifier("/google/preferences", { [pref]: voulu }));
          dessinerZones();
        } catch (err) {
          if (!(err instanceof ErreurApi)) throw err;
          champ.definir(!voulu);
          toastErreur(err);
        } finally {
          champ.desactiver(false);
        }
      });
      return champ.noeud;
    };

    const preferences = [
      interrupteur("agenda", "Synchroniser mes rendez-vous avec mon Google Agenda", e.fonctions.agenda && moi.accordees?.agenda),
      interrupteur("echanges", "Afficher les courriels échangés sur les fiches", e.fonctions.gmail_echanges && moi.accordees?.gmail_echanges),
    ].filter(Boolean);

    /** « Remplir mon CRM avec mes courriels » : où en est la fonction pour cette personne, et la porte vers sa page. */
    const blocCourriels = () => {
      if (!etat.droits.ecrire || !e.fonctions.gmail_echanges || !moi.accordees?.gmail_echanges) return null;
      const c = classement();
      const attente = propositionsEnAttente();
      const texte = c.actif
        ? attente ? `${pluriel(attente, "proposition attend", "propositions attendent")} votre réponse.` : "Aucune proposition en attente pour le moment."
        : "Le CRM peut repérer, dans vos courriels, les personnes à ajouter à vos contacts (avec leur entreprise, leur fonction et leur téléphone). Rien n’est ajouté sans votre accord.";
      return h(
        "div.gg-courriels",
        h("div.gg-courriels__texte", h("p.gg-courriels__titre", "Remplir mon CRM avec mes courriels", pastille(c.actif ? "Activé" : "Désactivé", c.actif ? "ok" : "neutre")), h("p.muet", texte)),
        btn(c.actif ? "Ouvrir la page Courriels" : "Découvrir cette fonction", { href: "#/courriels", icone: "courriel" })
      );
    };

    async function montrerEtapes(promesse, attente) {
      zoneResultat.replaceChildren(h("p.muet", attente));
      try {
        const rep = await promesse;
        zoneResultat.replaceChildren(
          h(
            "ul.gg-test",
            rep.etapes.map((s) => h("li.gg-test__ligne", { class: s.ok ? "gg-test__ligne--ok" : "gg-test__ligne--non" }, icone(s.ok ? "ok" : "non"), h("div", h("strong", s.titre), h("p", s.detail))))
          )
        );
        await rafraichirGoogle().then((x) => (e = x)).catch(() => {});
        dessinerZones();
      } catch (err) {
        if (!(err instanceof ErreurApi)) throw err;
        zoneResultat.replaceChildren(avis({ ton: "erreur", texte: err.message }));
      }
    }

    const boutons = (act) => [
      btn("Tester la connexion", { icone: "coche", onclick: (ev) => occuper(ev, () => montrerEtapes(envoyer("/google/test", {}), "Test en cours…")) }),
      act.gmail_envoi
        ? btn("M’envoyer un courriel d’essai", { icone: "envoyer", titre: "Envoie un petit message de votre adresse Gmail à elle-même", onclick: (ev) => occuper(ev, () => montrerEtapes(envoyer("/google/test", { envoi_essai: true }), "Envoi d’un courriel d’essai…")) })
        : null,
      act.agenda
        ? btn("Synchroniser l’agenda maintenant", {
            icone: "rafraichir",
            onclick: (ev) =>
              occuper(ev, async () => {
                zoneResultat.replaceChildren(h("p.muet", "Synchronisation de l’agenda…"));
                const r = resumeSynchro(await synchroniserAgenda());
                e = google();
                dessinerZones();
                zoneResultat.replaceChildren(avis({ ton: r.ton, texte: r.texte, role: "status" }));
              }),
          })
        : null,
      btn("Reconnecter", { icone: "lien", onclick: seConnecter, titre: "Repasser par Google, par exemple pour accorder une autorisation manquante" }),
      btn("Déconnecter mon compte…", { ton: "danger", onclick: seDeconnecter }),
    ];
    dessinerZones();

    const derniere = moi.derniere_erreur;
    const manquantes = moi.manquantes || [];

    return panneau(
      { titre: "Mon compte Google", sous: `Connecté en tant que ${moi.courriel}.`, niveau: 3, id, actions: aReconnecter ? pastille("À reconnecter", "attention") : pastille("Connecté", "ok", { icone: "coche" }) },
      h(
        "div.pile",
        aReconnecter
          ? avis({ ton: "attention", titre: "Reconnexion nécessaire", texte: "Google ne reconnaît plus la connexion de votre compte (mot de passe changé, accès retiré ou délai expiré). Reconnectez-vous pour reprendre là où vous étiez.", actions: btn("Reconnecter", { ton: "primaire", onclick: seConnecter }) })
          : null,
        manquantes.length && !aReconnecter
          ? avis({
              ton: "attention", titre: "Autorisation manquante",
              texte: `Google n’a pas accordé : ${manquantes.map((k) => FONCTIONS_LIBELLES[k].toLowerCase()).join(", ")}. Reconnectez votre compte et laissez toutes les cases cochées.`,
              actions: btn("Reconnecter", { onclick: seConnecter }),
            })
          : null,
        derniere && !aReconnecter
          ? avis({ ton: "attention", titre: `Dernier problème signalé ${ms(derniere.t) ? ilYa(ms(derniere.t)) : ""}`.trim(), texte: derniere.message })
          : null,
        zoneInfos,
        preferences.length ? h("div.pile.pile--s", ...preferences) : null,
        blocCourriels(),
        zoneActions,
        zoneResultat
      )
    );
  }

  /** Désactive le bouton pendant une action asynchrone. */
  async function occuper(ev, action) {
    const b = ev.currentTarget;
    b.disabled = true;
    b.setAttribute("aria-busy", "true");
    try {
      await action();
    } catch (err) {
      if (!(err instanceof ErreurApi)) throw err;
      toastErreur(err);
    } finally {
      b.disabled = false;
      b.removeAttribute("aria-busy");
    }
  }

  async function seConnecter(ev) {
    const b = ev?.currentTarget;
    if (b) b.disabled = true;
    try {
      await connecterGoogle();
    } catch (err) {
      if (b) b.disabled = false;
      if (!(err instanceof ErreurApi)) throw err;
      toastErreur(err);
    }
  }

  async function seDeconnecter() {
    const ok = await confirmer({
      titre: "Déconnecter votre compte Google ?",
      message: "Le CRM ne pourra plus envoyer de courriels avec Gmail ni synchroniser votre agenda. L’accès du CRM est aussi retiré chez Google.",
      detail: h("p.muet", "Les courriels déjà envoyés restent dans Gmail. Les rendez-vous déjà créés restent dans votre Google Agenda, mais ne se mettront plus à jour."),
      libelleConfirmer: "Déconnecter", danger: true,
    });
    if (!ok) return;
    try {
      reprendre(await envoyer("/google/deconnexion", {}));
      message = { texte: "Votre compte Google est déconnecté." };
      banniere = null;
      dessiner();
    } catch (err) {
      if (!(err instanceof ErreurApi)) throw err;
      toastErreur(err);
    }
  }

  // ----- Administration ---------------------------------------------------------------------------------------------------
  function surIdentifiantsEnregistres({ verif: v }) {
    verif = v;
    e = google();
    message = null;
    banniere = null;
    dessiner();
    if (v.ok) document.getElementById("google-compte")?.scrollIntoView({ block: "start" });
  }

  function panneauConfigurationInitiale() {
    return panneau(
      { titre: "Configuration de Google", sous: "À faire une seule fois par une personne qui administre le CRM, puis chaque personne connecte son compte.", niveau: 3 },
      assistantConfiguration({
        redirectUri: e.redirect_uri, ouvert: 1,
        formulaire: formulaireIdentifiants({ app: null, fonctions: null, redirectUri: e.redirect_uri, surEnregistre: surIdentifiantsEnregistres }),
      })
    );
  }

  function panneauxAdministration() {
    const app = e.app;
    const sortie = [];

    // Résultat de la dernière vérification
    const resultat = verif
      ? avis({ ton: verif.ok ? "ok" : "erreur", role: "status", titre: verif.ok ? "Identifiants reconnus par Google" : "Google ne valide pas ces identifiants", texte: verif.message })
      : null;

    // Fonctions offertes
    const cases = Object.fromEntries(FONCTIONS.map((k) => [k, creerChamp(`gg-fn-${k}`, { type: "booleen", libelle: FONCTIONS_LIBELLES[k] }, !!e.fonctions[k])]));
    const statutFonctions = h("span.reglages__statut", { role: "status", "aria-live": "polite" });
    const boutonFonctions = btn("Enregistrer les fonctions", {
      icone: "coche",
      onclick: (ev) =>
        occuper(ev, async () => {
          statutFonctions.textContent = "";
          const choix = Object.fromEntries(FONCTIONS.map((k) => [k, !!cases[k].lire()]));
          if (!FONCTIONS.some((k) => choix[k])) {
            statutFonctions.textContent = "Gardez au moins une fonction cochée.";
            return;
          }
          reprendre(await envoyer("/google/config", { client_id: app.client_id, fonctions: choix }));
          statutFonctions.replaceChildren(icone("coche", "ic--p"), " Enregistré.");
        }),
    });

    const adresseDiffere = app.redirect_uri && e.redirect_uri && app.redirect_uri !== e.redirect_uri;
    const formulaireRemplacement = h(
      "details.replie",
      h("summary.replie__titre", icone("droite", "ic--p replie__fleche"), h("span.replie__nom", "Remplacer l’ID client ou le secret")),
      h(
        "div.replie__corps",
        h("p.muet", "À utiliser si vous avez créé un nouvel identifiant chez Google. Changer d’ID client déconnecte tout le monde : chaque personne devra se reconnecter."),
        formulaireIdentifiants({ app, fonctions: e.fonctions, redirectUri: e.redirect_uri, surEnregistre: surIdentifiantsEnregistres })
      )
    );

    sortie.push(
      panneau(
        { titre: "Configuration de Google", sous: "Identifiants du projet Google et fonctions offertes à l’équipe.", niveau: 3 },
        h(
          "div.pile",
          resultat,
          adresseDiffere
            ? avis({
                ton: "attention", titre: "L’adresse du CRM a changé",
                texte: `L’adresse de redirection enregistrée chez Google est ${app.redirect_uri}, mais le CRM est ouvert à l’adresse ${e.redirect_uri}. Ouvrez le CRM à l’adresse enregistrée pour connecter un compte, ou ajoutez la nouvelle adresse dans la console Google et rouvrez l’étape 6.`,
              })
            : null,
          !app.verifie_le && !verif ? avis({ ton: "attention", titre: "Identifiants pas encore vérifiés", texte: "Cliquez sur « Vérifier auprès de Google » pour confirmer que l’ID client et le secret sont bons." }) : null,
          listeDef([
            ["ID client", h("code.gg-code", app.client_id)],
            ["Secret client", "Enregistré, chiffré (jamais réaffiché)"],
            ["Vérifié auprès de Google", app.verifie_le ? `${dateCourte(app.verifie_le.slice(0, 10))} (${ilYa(ms(app.verifie_le))})` : "Pas encore"],
            ["Adresse de redirection", h("code.gg-code", app.redirect_uri)],
          ]),
          h(
            "div.actions-ligne",
            btn("Vérifier auprès de Google", {
              icone: "coche",
              onclick: (ev) =>
                occuper(ev, async () => {
                  verif = await envoyer("/google/verifier", {});
                  await rafraichirGoogle();
                  e = google();
                  dessiner();
                }),
            })
          ),
          h("section.groupe", h("h4.groupe__titre", "Fonctions offertes à l’équipe"), h("div.pile.pile--s", FONCTIONS.map((k) => cases[k].noeud))),
          h("p.muet.petit", "Si vous activez une fonction après coup, chaque personne doit se reconnecter une fois pour l’autoriser, et son autorisation doit aussi figurer à l’étape 4 de la configuration."),
          h("div.reglages__pied", statutFonctions, boutonFonctions),
          formulaireRemplacement,
          h("div.actions-ligne", btn("Retirer la configuration Google…", { ton: "danger", onclick: retirerConfiguration }))
        )
      )
    );

    // Équipe
    const equipe = e.equipe || [];
    sortie.push(
      panneau(
        { titre: "Équipe connectée à Google", sous: "Les personnes qui ont connecté leur compte.", niveau: 3 },
        equipe.length
          ? h(
              "ul.gabarits",
              equipe.map((p) =>
                h(
                  "li.gabarit",
                  h(
                    "div.gabarit__texte",
                    h("strong", nomUtilisateur(p.id) || "Personne retirée de l’équipe"),
                    h("span.muet", `${p.courriel}${p.etat === "ok" && p.derniere_synchro ? ` · synchronisé ${ilYa(ms(p.derniere_synchro))}` : ""}`)
                  ),
                  h(
                    "div.gabarit__actions",
                    pastille(p.etat === "ok" ? "Connecté" : "À reconnecter", p.etat === "ok" ? "ok" : "attention"),
                    btn("Déconnecter", { petit: true, onclick: () => deconnecterQuelquUn(p) })
                  )
                )
              )
            )
          : h("p.muet", "Personne n’a encore connecté son compte Google.")
      )
    );

    // Étapes de configuration, pour les revoir ou les refaire
    sortie.push(
      h(
        "details.replie",
        h("summary.replie__titre", icone("droite", "ic--p replie__fleche"), h("span.replie__nom", "Revoir les étapes de configuration")),
        h("div.replie__corps", assistantConfiguration({ redirectUri: e.redirect_uri, ouvert: 0, formulaire: null, configure: true }))
      )
    );
    return sortie;
  }

  async function retirerConfiguration() {
    const ok = await confirmer({
      titre: "Retirer la configuration Google ?",
      message: "Tout le monde est déconnecté de Google et l’ID client et le secret sont effacés du CRM. Les accès du CRM sont aussi révoqués chez Google.",
      detail: h("p.muet", "Les courriels déjà envoyés restent dans Gmail et les rendez-vous déjà créés restent dans Google Agenda. Vous pourrez reconfigurer Google plus tard avec l’assistant."),
      libelleConfirmer: "Retirer la configuration", danger: true,
    });
    if (!ok) return;
    try {
      const rep = await supprimer("/google/config");
      reprendre(rep.etat);
      verif = null;
      message = { texte: `La configuration de Google est retirée${rep.deconnectes ? ` (${pluriel(rep.deconnectes, "compte déconnecté", "comptes déconnectés")})` : ""}.` };
      dessiner();
    } catch (err) {
      if (!(err instanceof ErreurApi)) throw err;
      toastErreur(err);
    }
  }

  async function deconnecterQuelquUn(p) {
    const nom = nomUtilisateur(p.id) || p.courriel;
    const ok = await confirmer({
      titre: `Déconnecter ${nom} de Google ?`,
      message: `Le compte ${p.courriel} ne sera plus relié au CRM. La personne pourra le reconnecter quand elle le voudra.`,
      libelleConfirmer: "Déconnecter", danger: true,
    });
    if (!ok) return;
    try {
      reprendre(await supprimer(`/google/utilisateurs/${encodeURIComponent(p.id)}`));
      toast(`${nom} est déconnecté de Google.`);
      dessiner();
    } catch (err) {
      if (!(err instanceof ErreurApi)) throw err;
      toastErreur(err);
    }
  }

  // ----- Assemblage ---------------------------------------------------------------------------------------------------------
  function dessiner() {
    const blocs = [...bandeaux()];
    const compte = panneauCompte();
    if (admin && !e.configure) blocs.push(panneauConfigurationInitiale(), compte);
    else {
      blocs.push(compte);
      if (admin) blocs.push(...panneauxAdministration());
    }
    racine.replaceChildren(...blocs);
  }

  await charger();
  return racine;
}
