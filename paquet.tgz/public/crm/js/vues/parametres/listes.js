// D'où viennent les clients (provenances) et les étiquettes qui servent à les classer.
import { h } from "../../noyau/dom.js";
import { etat, actives } from "../../noyau/etat.js";
import { SOURCES_DEFAUT } from "../../commun/defauts.js";
import { pluriel } from "../../commun/format.js";
import { btn, panneau } from "../../ui/composants.js";
import { confirmer } from "../../ui/dialogue.js";
import { tableau } from "../../ui/tableau.js";
import { etiquettesConnues } from "../../ui/formulaire.js";
import { editeurListe, panneauListeEditable, panneauFormulaire, enregistrerConfig, note } from "./commun.js";

const AVEC_PROVENANCE = ["contacts", "entreprises", "opportunites"];
const usageProvenance = (id) => (id ? AVEC_PROVENANCE.reduce((n, e) => n + actives(e).filter((f) => f.source === id).length, 0) : 0);

function panneauProvenances() {
  const editeur = editeurListe({
    items: etat.config.sources,
    colonnes: [{ cle: "libelle", libelle: "Provenance", spec: { type: "texte", max: 80, requis: true } }],
    nouveau: () => ({ libelle: "" }),
    nomPourId: (v) => v.libelle,
    libelleLigne: (v) => v.libelle || "Nouvelle provenance",
    protege: (v) => {
      if (v.id === "site") return "Les demandes reçues par le site sont rangées sous cette provenance : vous pouvez la renommer, pas la retirer.";
      const n = usageProvenance(v.id);
      return n ? `${pluriel(n, "fiche utilise", "fiches utilisent")} cette provenance : choisissez-en une autre dans ces fiches d’abord.` : null;
    },
    minimum: 1, maximum: 30, libelleAjout: "Ajouter une provenance", compacte: true, elements: ["provenance", "provenances"],
  });

  const double = (valeurs) => {
    const vus = new Set();
    for (const v of valeurs) {
      const cle = v.libelle.toLowerCase();
      if (vus.has(cle)) return v.libelle;
      vus.add(cle);
    }
    return null;
  };

  return panneauListeEditable({
    titre: "Provenances",
    sous: "Où un client a entendu parler de vous : elles servent à voir ce qui fonctionne le mieux.",
    intro: note("Utilisez les flèches pour changer l’ordre de la liste de choix."),
    editeur,
    valider: (v) => {
      const d = double(v);
      return d ? `Deux provenances portent le même nom : « ${d} ».` : null;
    },
    enregistrer: async (valeurs) => (await enregistrerConfig({ sources: valeurs })).sources,
    succes: "Provenances enregistrées.",
    actionsPied: btn("Rétablir la liste d’origine", {
      petit: true,
      onclick: async () => {
        const ok = await confirmer({ titre: "Rétablir la liste d’origine ?", message: "Les provenances reprendront leur forme de départ dans cet écran. Rien ne change tant que vous n’avez pas cliqué sur « Enregistrer ».", libelleConfirmer: "Rétablir" });
        if (ok) editeur.definir(structuredClone(SOURCES_DEFAUT));
      },
    }),
  }).noeud;
}

function panneauEtiquettes() {
  return panneauFormulaire({
    titre: "Étiquettes proposées",
    sous: "Elles s’offrent quand vous classez un contact ou une entreprise.",
    groupes: [
      {
        colonnes: 1,
        champs: [
          {
            cle: "etiquettes", spec: { type: "multi", libelle: "Étiquettes" }, valeur: etat.config.etiquettes,
            opts: { placeholder: "Écrivez une étiquette, puis appuyez sur Entrée", aide: "30 étiquettes au plus, 40 caractères chacune. Une étiquette retirée d’ici reste sur les fiches qui l’ont déjà.", suggestions: () => etiquettesConnues() },
          },
        ],
      },
    ],
    enregistrer: ({ etiquettes }) => enregistrerConfig({ etiquettes }),
    succes: "Étiquettes enregistrées.",
  }).noeud;
}

/** Étiquettes réellement posées sur des fiches, avec leur nombre (sans tenir compte des majuscules). */
function lignesUtilisation() {
  const parCle = new Map();
  for (const entite of ["contacts", "entreprises"]) {
    for (const f of actives(entite)) {
      for (const e of f.etiquettes || []) {
        const cle = e.toLowerCase();
        const l = parCle.get(cle) || { nom: e, contacts: 0, entreprises: 0 };
        l[entite] += 1;
        parCle.set(cle, l);
      }
    }
  }
  return [...parCle.values()];
}

function panneauUtilisation() {
  const lignes = lignesUtilisation();
  const contenu = lignes.length
    ? tableau({
        libelle: "Étiquettes utilisées dans vos fiches",
        colonnes: [
          { id: "nom", titre: "Étiquette", valeur: (l) => l.nom, rendu: (l) => l.nom, classe: "cellule-titre" },
          { id: "contacts", titre: "Contacts", valeur: (l) => l.contacts, rendu: (l) => String(l.contacts), classe: "num" },
          { id: "entreprises", titre: "Entreprises", valeur: (l) => l.entreprises, rendu: (l) => String(l.entreprises), classe: "num" },
        ],
        lignes,
        tri: { col: "nom", dir: "asc" },
        cartes: false,
      }).noeud
    : h("p.muet", "Aucune étiquette n’est encore posée sur une fiche.");
  return panneau({ titre: "Étiquettes utilisées", sous: "Ce que portent actuellement vos contacts et vos entreprises.", niveau: 3 }, contenu);
}

export default async function listes() {
  return h("div.pile.pile--l", panneauProvenances(), panneauEtiquettes(), panneauUtilisation());
}
