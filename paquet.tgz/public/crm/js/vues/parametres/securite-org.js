// Sécurité de l'organisation : double vérification pour tout le monde et durée des sessions.
import { h } from "../../noyau/dom.js";
import { etat } from "../../noyau/etat.js";
import { lire, ErreurApi } from "../../noyau/api.js";
import { pluriel } from "../../commun/format.js";
import { btn, panneau, avis, listeDef } from "../../ui/composants.js";
import { panneauFormulaire, enregistrerConfig } from "./commun.js";

export default async function securiteOrg() {
  const s = etat.config.securite || { double_facteur_obligatoire: false, duree_session_heures: 12 };
  const exigee = !!s.double_facteur_obligatoire;

  let comptes = null;
  try {
    comptes = ((await lire("/utilisateurs")).utilisateurs || []).filter((u) => u.actif);
  } catch (e) {
    if (!(e instanceof ErreurApi)) throw e;
  }

  const sans = comptes ? comptes.filter((u) => !u.mfa) : [];
  const moiSans = !etat.utilisateur.mfa;
  const bloque = moiSans && !exigee; // on ne peut l'exiger qu'après avoir activé la sienne

  const etatActuel = [];
  if (comptes) {
    const avec = comptes.length - sans.length;
    etatActuel.push(
      avis({
        ton: sans.length ? (exigee ? "attention" : "info") : "ok",
        titre: `${pluriel(avec, "personne a", "personnes ont")} activé la double vérification sur ${pluriel(comptes.length, "accès ouvert", "accès ouverts")}`,
        texte: sans.length
          ? `Sans double vérification : ${sans.map((u) => u.nom).join(", ")}.${exigee ? " Ces personnes devront la configurer à leur prochaine action dans le CRM." : ""}`
          : "Tout le monde est protégé par un deuxième verrou.",
      })
    );
  }
  if (bloque) {
    etatActuel.push(
      avis({
        ton: "attention",
        titre: "Activez d’abord la vôtre",
        texte: "Pour l’exiger de toute l’équipe, votre propre compte doit déjà être protégé : cela évite de vous bloquer vous-même.",
        actions: btn("Configurer ma double vérification", { href: "#/parametres/securite", petit: true }),
      })
    );
  }

  const formulaire = panneauFormulaire({
    titre: "Règles de connexion",
    sous: "S’appliquent à toutes les personnes qui ont accès au CRM.",
    groupes: [
      {
        colonnes: 1,
        champs: [
          {
            cle: "double_facteur_obligatoire", valeur: exigee,
            spec: { type: "booleen", libelle: "Exiger la double vérification pour tout le monde" },
            opts: {
              desactive: bloque,
              aide: "Chaque personne devra, en plus de son mot de passe, entrer un code à 6 chiffres affiché par une application sur son téléphone. Une fois exigée, personne ne peut la désactiver de son côté.",
            },
          },
          {
            cle: "duree_session_heures", valeur: s.duree_session_heures, requis: true,
            spec: { type: "nombre", entier: true, min: 1, max: 72, libelle: "Fermer une session inactive après" },
            opts: { suffixe: "heures", aide: "Une session reste ouverte tant qu’on s’en sert, et se ferme après ce temps sans activité ; au plus tard 14 jours après la connexion. Le changement s’applique aux prochaines connexions." },
          },
        ],
      },
    ],
    enregistrer: ({ double_facteur_obligatoire, duree_session_heures }) => enregistrerConfig({ securite: { double_facteur_obligatoire, duree_session_heures } }),
    succes: "Règles enregistrées.",
  });

  const dejaPrevu = panneau(
    { titre: "Ce qui protège déjà vos données", niveau: 3 },
    listeDef(
      [
        ["Mots de passe", "Jamais conservés tels quels : le CRM n’en garde qu’une empreinte, impossible à retransformer en mot de passe."],
        ["Essais de connexion", "Limités : après plusieurs essais ratés, la connexion est suspendue un moment."],
        ["Sessions", "Fermées après inactivité, et au plus tard 14 jours après la connexion. Un changement de mot de passe ferme les autres sessions."],
        ["Connexion", "Chiffrée en tout temps (HTTPS). Le CRM n’est jamais indexé par les moteurs de recherche."],
        ["Traçabilité", "Les connexions, les accès, les réglages et les exports sont consignés dans le journal d’activité (section voisine)."],
      ],
      { classe: "def--roles" }
    )
  );

  return h("div.pile.pile--l", ...etatActuel, formulaire.noeud, dejaPrevu);
}
