// Sauvegardes : copier vos données hors du CRM, les restaurer, charger ou retirer les données d'exemple.
import { h, remplir, enregistrerFichier } from "../../noyau/dom.js";
import { icone } from "../../noyau/icones.js";
import { etat } from "../../noyau/etat.js";
import { lire, envoyer, telechargerFichier, ErreurApi } from "../../noyau/api.js";
import { synchroniser } from "../../noyau/synchro.js";
import { NOMS_ENTITES, ENTITES } from "../../commun/schema.js";
import { dateLongue, heure, dateCourte, pluriel } from "../../commun/format.js";
import { partiesLocales } from "../../commun/dates.js";
import { btn, panneau, avis } from "../../ui/composants.js";
import { creerChamp } from "../../ui/formulaire.js";
import { ouvrirDialogue, confirmer } from "../../ui/dialogue.js";
import { toastErreur } from "../../ui/toast.js";
import { enc, note } from "./commun.js";

const TAILLE_MAX = 5_000_000;

const ko = (octets) => (octets < 1024 * 1024 ? `${Math.max(1, Math.round(octets / 1024))} Ko` : `${(octets / 1024 / 1024).toFixed(1).replace(".", ",")} Mo`);

/** « 3 contacts, 2 entreprises… » à partir de { entite: nombre }. */
function resumeCompte(compte) {
  const parties = NOMS_ENTITES.filter((n) => compte[n] > 0).map((n) => pluriel(compte[n], ENTITES[n].singulier, ENTITES[n].pluriel));
  return parties.length ? parties.join(", ") : "aucune fiche";
}
const compteActuel = () => Object.fromEntries(NOMS_ENTITES.map((n) => [n, etat.collections[n].filter((f) => !f.supprime).length]));

/** Nom lisible d'un instantané : « 2026-10-15 » ou « avant-restauration-2026-10-15T14-22-03-123Z ». */
function libelleInstantane(nom) {
  const jour = /^(\d{4}-\d{2}-\d{2})$/.exec(nom);
  if (jour) return { titre: dateLongue(jour[1]), sous: "Copie automatique du jour" };
  // Le nom porte l'heure UTC : on l'affiche à l'heure de Toronto, comme tout le reste du CRM.
  const m = /^avant-restauration-(\d{4}-\d{2}-\d{2})T(\d{2})-(\d{2})-(\d{2})(?:-(\d{3}))?Z?$/.exec(nom);
  const ms = m ? Date.parse(`${m[1]}T${m[2]}:${m[3]}:${m[4]}.${m[5] || "000"}Z`) : NaN;
  if (Number.isFinite(ms)) return { titre: `Avant une restauration — ${dateCourte(partiesLocales(ms).date)}, ${heure(ms)}`, sous: "État de vos données juste avant une restauration" };
  return { titre: nom, sous: "" };
}

// ----- Télécharger ----------------------------------------------------------------------------------------------
function panneauTelechargement() {
  const statut = h("p.reglages__statut.reglages__statut--bloc", { role: "status", "aria-live": "polite" });
  const alerte = h("div.formulaire__alerte", { role: "alert", hidden: true });
  const bouton = btn("Télécharger une sauvegarde", { ton: "primaire", icone: "telecharger" });
  bouton.addEventListener("click", async () => {
    statut.textContent = "";
    alerte.hidden = true;
    bouton.disabled = true;
    bouton.setAttribute("aria-busy", "true");
    try {
      const { blob, nom } = await telechargerFichier("/admin/sauvegarde");
      enregistrerFichier(nom, blob);
      statut.replaceChildren(icone("coche", "ic--p"), ` Sauvegarde téléchargée : ${nom} (${ko(blob.size)}). Gardez-la dans un endroit sûr.`);
    } catch (e) {
      if (!(e instanceof ErreurApi)) throw e;
      alerte.hidden = false;
      alerte.textContent = e.message;
    } finally {
      bouton.disabled = false;
      bouton.removeAttribute("aria-busy");
    }
  });

  return panneau(
    { titre: "Télécharger une copie de vos données", sous: "Un seul fichier, à garder hors du CRM.", niveau: 3 },
    h(
      "div.pile",
      h("p", `Il contient tout ce qui est dans le CRM aujourd’hui : ${resumeCompte(compteActuel())}, vos réglages et l’historique des notes. Les mots de passe n’en font pas partie.`),
      h("p.muet", "Prenez l’habitude d’en télécharger une chaque semaine. Ce fichier contient des renseignements personnels sur vos clients : rangez-le comme vous rangeriez un dossier papier confidentiel."),
      alerte,
      h("div.actions-ligne", bouton),
      statut
    )
  );
}

// ----- Copies automatiques ---------------------------------------------------------------------------------------
async function panneauInstantanes() {
  const corps = h("div.pile");
  let noms = [];
  try {
    noms = (await lire("/admin/instantanes")).instantanes || [];
  } catch (e) {
    if (!(e instanceof ErreurApi)) throw e;
    corps.append(avis({ ton: "erreur", titre: "La liste n’a pas pu être chargée", texte: e.message }));
  }

  async function telecharger(nom, bouton) {
    bouton.disabled = true;
    try {
      const r = await telechargerFichier(`/admin/instantanes/${enc(nom)}`);
      enregistrerFichier(r.nom, r.blob);
    } catch (e) {
      if (!(e instanceof ErreurApi)) throw e;
      toastErreur(e);
    } finally {
      bouton.disabled = false;
    }
  }

  if (!corps.children.length) {
    corps.append(
      h("p", "Chaque jour, le CRM garde une copie de vos données (les 14 derniers jours, et celles d’avant une restauration). Si vous supprimez ou modifiez quelque chose par erreur, vous pouvez retrouver l’état d’un jour précédent."),
      h("p.muet", "Ces copies sont conservées au même endroit que le CRM : elles protègent contre une erreur de manipulation, pas contre la perte du service lui-même. Téléchargez aussi une copie sur votre ordinateur."),
      noms.length
        ? h(
            "ul.gabarits",
            noms.map((nom) => {
              const l = libelleInstantane(nom);
              const b = btn("Télécharger", { petit: true, icone: "telecharger", aria: `Télécharger la copie : ${l.titre}` });
              b.addEventListener("click", () => telecharger(nom, b));
              return h("li.gabarit", h("div.gabarit__texte", h("strong", l.titre), l.sous ? h("span.muet", l.sous) : null), h("div.gabarit__actions", b));
            })
          )
        : h("p.muet", "Aucune copie pour l’instant : la première est créée à la première connexion de la journée, dès que le CRM contient des fiches."),
      note("Pour remettre une de ces copies dans le CRM, téléchargez-la puis utilisez « Restaurer une sauvegarde » ci-dessous.")
    );
  }
  return panneau({ titre: "Copies automatiques", sous: "Faites chaque jour par le CRM.", niveau: 3 }, corps);
}

// ----- Restaurer ---------------------------------------------------------------------------------------------------
function fenetreRestauration(sauv, nomFichier) {
  const compteSauv = Object.fromEntries(NOMS_ENTITES.map((n) => [n, Array.isArray(sauv.collections?.[n]) ? sauv.collections[n].length : 0]));
  const cree = Date.parse(sauv.genere_le);
  return ouvrirDialogue({
    titre: "Restaurer cette sauvegarde ?",
    fermable: true,
    contenu: (ctx) => {
      const zone = h("div.pile.pile--s");
      const accord = creerChamp("accord", { type: "booleen", libelle: "Je comprends que mes données actuelles seront remplacées." }, false, {});
      const erreurs = h("div.formulaire__alerte", { role: "alert", hidden: true });
      const lancer = btn("Restaurer", { ton: "danger", onclick: async () => {
        erreurs.hidden = true;
        if (!accord.lire()) {
          accord.erreur("Cochez la case pour confirmer.");
          accord.focus();
          return;
        }
        accord.erreur(null);
        ctx.occupe(true);
        try {
          const r = await envoyer("/admin/restauration", { sauvegarde: sauv });
          ctx.occupe(false);
          termine(r);
        } catch (e) {
          ctx.occupe(false);
          if (!(e instanceof ErreurApi)) throw e;
          erreurs.hidden = false;
          remplir(erreurs, h("strong", e.message), e.details?.length ? h("ul.liste-simple", e.details.map((d) => h("li", d))) : null);
        }
      } });

      function termine(r) {
        ctx.definirPied(btn("Recharger le CRM", { ton: "primaire", onclick: () => location.reload() }));
        zone.replaceChildren(
          avis({ ton: "ok", titre: "Restauration terminée", texte: `Vos données sont celles de la sauvegarde : ${resumeCompte(r.restaure || {})}. L’état d’avant a été gardé dans les copies automatiques.` }),
          h("p.muet", "Rechargez le CRM pour afficher les données restaurées.")
        );
      }

      ctx.definirPied(btn("Annuler", { onclick: () => ctx.fermer(false) }), lancer);
      zone.append(
        h("p", `Fichier : ${nomFichier}${Number.isFinite(cree) ? ` — créé le ${dateLongue(partiesLocales(cree).date)} à ${heure(cree)}` : ""}.`),
        h("dl.def", h("div.def__ligne", h("dt", "La sauvegarde contient"), h("dd", resumeCompte(compteSauv))), h("div.def__ligne", h("dt", "Votre CRM contient"), h("dd", resumeCompte(compteActuel())))),
        avis({ ton: "attention", titre: "Toutes vos données actuelles seront remplacées", texte: "Fiches, réglages et historique : tout sera remplacé par le contenu de la sauvegarde. Les comptes et les mots de passe ne changent pas. Une copie de l’état actuel est gardée automatiquement." }),
        erreurs,
        accord.noeud
      );
      return zone;
    },
  }).promesse;
}

function panneauRestauration() {
  const alerte = h("div.formulaire__alerte", { role: "alert", hidden: true });
  const entree = h("input", { type: "file", accept: ".json,application/json", hidden: true, "aria-hidden": "true", tabindex: "-1" });
  const choisir = btn("Choisir un fichier de sauvegarde…", { icone: "televerser", onclick: () => entree.click() });

  entree.addEventListener("change", async () => {
    alerte.hidden = true;
    const fichier = entree.files?.[0];
    entree.value = "";
    if (!fichier) return;
    const erreur = (msg) => {
      alerte.hidden = false;
      alerte.textContent = msg;
    };
    if (fichier.size > TAILLE_MAX) return erreur(`Ce fichier fait ${ko(fichier.size)} : il dépasse la taille permise pour une restauration (${ko(TAILLE_MAX)}).`);
    let sauv;
    try {
      sauv = JSON.parse(await fichier.text());
    } catch {
      return erreur("Ce fichier n’est pas lisible. Choisissez un fichier de sauvegarde téléchargé depuis le CRM (extension .json).");
    }
    if (!sauv || sauv.format !== "innovaffaires-crm") return erreur("Ce fichier n’est pas une sauvegarde du CRM InnovAffaires.");
    await fenetreRestauration(sauv, fichier.name);
  });

  return panneau(
    { titre: "Restaurer une sauvegarde", sous: "Remettre dans le CRM les données d’un fichier de sauvegarde.", niveau: 3 },
    h("div.pile", h("p", "À utiliser si des données ont été perdues ou abîmées, ou pour déménager le CRM. Le CRM vous montre le contenu du fichier et vous demande de confirmer avant de toucher à quoi que ce soit."), alerte, h("div.actions-ligne", choisir, entree))
  );
}

// ----- Données d'exemple ----------------------------------------------------------------------------------------
function panneauExemples() {
  const corps = h("div.pile");
  const aDesExemples = () => NOMS_ENTITES.some((n) => etat.collections[n].some((f) => f.exemple && !f.supprime));
  let message = null;

  async function agir(action) {
    if (action === "retirer") {
      const ok = await confirmer({
        titre: "Retirer les données d’exemple ?",
        message: "Toutes les fiches d’exemple (contacts, entreprises, affaires, dossiers, factures, demandes…) seront supprimées définitivement. Vos propres fiches ne sont pas touchées.",
        libelleConfirmer: "Retirer les exemples", danger: true,
      });
      if (!ok) return;
    }
    try {
      await envoyer("/admin/exemples", { action });
      await synchroniser({ complet: true });
      message = action === "charger" ? "Données d’exemple ajoutées." : "Données d’exemple retirées.";
    } catch (e) {
      if (!(e instanceof ErreurApi)) throw e;
      toastErreur(e);
      return;
    }
    dessiner();
  }

  function dessiner() {
    const present = aDesExemples();
    remplir(
      corps,
      present
        ? h("p", "Des fiches d’exemple sont présentes dans votre CRM. Elles portent la mention « (exemple) » ou une adresse en @exemple.test. Retirez-les avant de saisir vos vraies données.")
        : h("p", "Pour essayer le CRM sans rien risquer, ajoutez des fiches fictives (contacts, affaires, dossiers, factures…). Vous pourrez toutes les retirer en un clic."),
      h("div.actions-ligne", present ? btn("Retirer les données d’exemple", { ton: "danger", icone: "corbeille", onclick: () => agir("retirer") }) : btn("Ajouter des données d’exemple", { icone: "etincelle", onclick: () => agir("charger") })),
      message ? h("p.reglages__statut.reglages__statut--bloc", { role: "status", "aria-live": "polite" }, icone("coche", "ic--p"), ` ${message}`) : null
    );
  }
  dessiner();
  return panneau({ titre: "Données d’exemple", sous: "Des fiches fictives pour essayer le CRM.", niveau: 3 }, corps);
}

export default async function sauvegardes() {
  return h("div.pile.pile--l", panneauTelechargement(), await panneauInstantanes(), panneauRestauration(), panneauExemples());
}
