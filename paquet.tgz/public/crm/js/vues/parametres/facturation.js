// Facturation : taxes, numérotation, conditions de paiement et tarifs habituels.
import { h } from "../../noyau/dom.js";
import { etat } from "../../noyau/etat.js";
import { avis } from "../../ui/composants.js";
import { aujourdhui } from "../../commun/dates.js";
import { panneauFormulaire, enregistrerConfig } from "./commun.js";

export default async function facturation() {
  const c = etat.config;
  const fa = c.facturation;
  const annee = aujourdhui().slice(0, 4);

  const taxes = panneauFormulaire({
    titre: "Taxes",
    sous: "Un changement s’applique aux prochaines factures. Les documents déjà émis ne changent pas.",
    groupes: [
      {
        colonnes: 2,
        champs: [
          { cle: "tps", spec: { type: "nombre", libelle: "TPS (taxe fédérale)", min: 0, max: 30, requis: true }, valeur: c.taxes.tps, opts: { suffixe: "%", aide: "Au Québec : 5 %." } },
          { cle: "tvq", spec: { type: "nombre", libelle: "TVQ (taxe provinciale)", min: 0, max: 30, requis: true }, valeur: c.taxes.tvq, opts: { suffixe: "%", aide: "Au Québec : 9,975 %." } },
        ],
      },
    ],
    enregistrer: ({ tps, tvq }) => enregistrerConfig({ taxes: { tps, tvq } }),
    succes: "Taxes enregistrées.",
  });

  const numerotation = panneauFormulaire({
    titre: "Numérotation et conditions",
    sous: `Le numéro est attribué à l’émission. Exemple : ${fa.prefixe_facture || ""}${annee}-0001.`,
    groupes: [
      {
        titre: "Numéros", colonnes: 2,
        champs: [
          { cle: "prefixe_facture", spec: { type: "texte", libelle: "Début des numéros de facture", max: 8 }, valeur: fa.prefixe_facture, opts: { aide: "Lettres, chiffres ou tirets (8 au maximum).", placeholder: "F-" } },
          { cle: "prefixe_devis", spec: { type: "texte", libelle: "Début des numéros de devis", max: 8 }, valeur: fa.prefixe_devis, opts: { placeholder: "D-" } },
        ],
      },
      {
        titre: "Délais", colonnes: 2,
        champs: [
          { cle: "delai_echeance_jours", spec: { type: "nombre", libelle: "Délai de paiement d’une facture", min: 0, max: 365, entier: true, requis: true }, valeur: fa.delai_echeance_jours, opts: { suffixe: "jours", aide: "L’échéance se calcule à partir de la date d’émission." } },
          { cle: "validite_devis_jours", spec: { type: "nombre", libelle: "Durée de validité d’un devis", min: 1, max: 365, entier: true, requis: true }, valeur: fa.validite_devis_jours, opts: { suffixe: "jours" } },
        ],
      },
      {
        titre: "Textes imprimés", colonnes: 1,
        champs: [
          { cle: "conditions", spec: { type: "texte", libelle: "Conditions de paiement", max: 120 }, valeur: fa.conditions, opts: { aide: "Sur les factures seulement. Exemple : Payable dans les 30 jours." } },
          { cle: "note_facture", spec: { type: "texte", libelle: "Mot de fin au bas du document", max: 300 }, valeur: fa.note_facture, opts: { aide: "Exemple : Merci de votre confiance." } },
        ],
      },
    ],
    enregistrer: (v) => enregistrerConfig({ facturation: v }),
    succes: "Facturation enregistrée.",
  });

  const h0 = c.honoraires;
  const honoraires = panneauFormulaire({
    titre: "Tarifs habituels",
    sous: "Ces montants sont proposés quand vous ajoutez une ligne à une facture ou à un devis. Vous pouvez toujours les modifier ligne par ligne.",
    groupes: [
      {
        colonnes: 3,
        champs: [
          { cle: "taux_horaire", spec: { type: "montant", libelle: "Taux horaire", min: 0, max: 10000, requis: true }, valeur: h0.taux_horaire, opts: { aide: "Par heure de consultation." } },
          { cle: "diagnostic", spec: { type: "montant", libelle: "Diagnostic de financement", min: 0, max: 1e7, requis: true }, valeur: h0.diagnostic },
          { cle: "dossier", spec: { type: "montant", libelle: "Préparation d’un dossier", min: 0, max: 1e7, requis: true }, valeur: h0.dossier },
        ],
      },
    ],
    enregistrer: (v) => enregistrerConfig({ honoraires: v }),
    succes: "Tarifs enregistrés.",
  });

  const sansTaxes = !etat.config.entreprise.no_tps || !etat.config.entreprise.no_tvq;
  return h(
    "div.pile.pile--l",
    sansTaxes
      ? avis({ ton: "attention", titre: "Numéros de taxes à saisir", texte: "Ajoutez votre numéro de TPS et de TVQ dans la section Entreprise : ils s’impriment sur vos factures.", actions: h("a.btn.btn--secondaire.btn--petit", { href: "#/parametres/entreprise" }, "Aller à Entreprise") })
      : null,
    taxes.noeud,
    numerotation.noeud,
    honoraires.noeud
  );
}
