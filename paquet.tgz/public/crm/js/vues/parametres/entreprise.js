// Identité de l'entreprise : elle s'imprime sur les factures et les devis et alimente la signature des courriels.
import { h } from "../../noyau/dom.js";
import { etat } from "../../noyau/etat.js";
import { avis } from "../../ui/composants.js";
import { panneauFormulaire, enregistrerConfig } from "./commun.js";

const T = (libelle, max, extra = {}) => ({ type: "texte", libelle, max, ...extra });

export default async function entreprise() {
  const e = etat.config.entreprise;
  const manque = !e.no_tps || !e.no_tvq;
  const f = panneauFormulaire({
    titre: "Coordonnées et numéros d’entreprise",
    sous: "Ces renseignements figurent en tête de vos factures et de vos devis.",
    groupes: [
      {
        titre: "Identité", colonnes: 2,
        champs: [
          { cle: "nom", spec: T("Nom de l’entreprise", 120, { requis: true }), valeur: e.nom },
          { cle: "nom_legal", spec: T("Nom légal, s’il est différent", 160), valeur: e.nom_legal },
          { cle: "neq", spec: T("Numéro d’entreprise du Québec (NEQ)", 20), valeur: e.neq, opts: { aide: "10 chiffres. Facultatif.", placeholder: "1234567890" } },
        ],
      },
      {
        titre: "Numéros de taxes", aide: "Obligatoires sur vos factures si vous êtes inscrite aux fichiers de taxes : c’est ce qui permet à vos clients de réclamer leurs crédits.", colonnes: 2,
        champs: [
          { cle: "no_tps", spec: T("Numéro de TPS", 20), valeur: e.no_tps, opts: { aide: "Format : 123456789 RT0001", placeholder: "123456789 RT0001" } },
          { cle: "no_tvq", spec: T("Numéro de TVQ", 20), valeur: e.no_tvq, opts: { aide: "Format : 1234567890 TQ0001", placeholder: "1234567890 TQ0001" } },
        ],
      },
      {
        titre: "Adresse et contact", colonnes: 2,
        champs: [
          { cle: "adresse", spec: T("Adresse", 160), valeur: e.adresse, etendu: true },
          { cle: "ville", spec: T("Ville", 80), valeur: e.ville },
          { cle: "province", spec: T("Province", 40), valeur: e.province },
          { cle: "code_postal", spec: T("Code postal", 10), valeur: e.code_postal },
          { cle: "telephone", spec: { type: "tel", libelle: "Téléphone" }, valeur: e.telephone },
          { cle: "courriel", spec: { type: "courriel", libelle: "Courriel" }, valeur: e.courriel },
          { cle: "site_web", spec: { type: "url", libelle: "Site Web", max: 200 }, valeur: e.site_web },
        ],
      },
      {
        titre: "Protection des renseignements personnels", colonnes: 1,
        champs: [{ cle: "responsable_vie_privee", spec: T("Personne responsable", 120), valeur: e.responsable_vie_privee, opts: { aide: "La Loi 25 exige de désigner une personne responsable. Son nom peut figurer dans votre politique de confidentialité." } }],
      },
      {
        titre: "Signature des courriels", colonnes: 1,
        champs: [{ cle: "signature", spec: { type: "texte_long", libelle: "Signature", max: 600 }, valeur: e.signature, opts: { rows: 5, aide: "Elle remplace le champ {{signature}} dans vos gabarits de courriel." } }],
      },
    ],
    enregistrer: (valeurs) => enregistrerConfig({ entreprise: valeurs }),
    succes: "Coordonnées enregistrées.",
  });
  return h(
    "div.pile",
    manque
      ? avis({ ton: "attention", titre: "Numéros de taxes manquants", texte: "Vos factures n’affichent pas encore votre numéro de TPS ni de TVQ. Ajoutez-les ci-dessous si vous y êtes inscrite." })
      : null,
    f.noeud
  );
}
