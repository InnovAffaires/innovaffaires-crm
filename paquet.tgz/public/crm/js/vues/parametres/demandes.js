// Demandes reçues par le site : le délai de réponse promis, les jours où vous ne répondez pas, et les alertes par courriel.
import { h } from "../../noyau/dom.js";
import { icone } from "../../noyau/icones.js";
import { etat, maintenant } from "../../noyau/etat.js";
import { envoyer, ErreurApi } from "../../noyau/api.js";
import { aujourdhui, ajouterJours, jourSemaine, joursFeriesQc, echeanceOuvrable, partiesLocales } from "../../commun/dates.js";
import { dateCourte, dateLongue, heure, pluriel } from "../../commun/format.js";
import { btn, panneau, avis } from "../../ui/composants.js";
import { creerChamp } from "../../ui/formulaire.js";
import { ouvrirDialogue } from "../../ui/dialogue.js";
import { editeurListe, panneauListeEditable, panneauFormulaire, enregistrerConfig, lireChamp, zoneErreurDialogue, note } from "./commun.js";

const MAX_DATES = 40;
const NOMS_FERIES = ["Jour de l’An", "Vendredi saint", "Journée nationale des patriotes", "Fête nationale du Québec", "Fête du Canada", "Fête du Travail", "Action de grâce", "Noël"];

/** Les prochains jours fériés que le CRM exclut d'office du calcul. */
function prochainsFeries(n = 4) {
  const auj = aujourdhui(maintenant());
  const an = +auj.slice(0, 4);
  const liste = [];
  for (const a of [an, an + 1]) joursFeriesQc(a).forEach((date, i) => liste.push({ date, nom: NOMS_FERIES[i] }));
  return liste.filter((f) => f.date >= auj).slice(0, n);
}

// ----- Délai de réponse -----------------------------------------------------------------------------------
function panneauDelai() {
  const p = panneauFormulaire({
    titre: "Délai de réponse",
    sous: "Le délai que vous promettez aux personnes qui vous écrivent par le site.",
    groupes: [
      {
        colonnes: 1,
        champs: [
          {
            cle: "delai_reponse_heures", valeur: etat.config.delai_reponse_heures, requis: true,
            spec: { type: "nombre", entier: true, min: 1, max: 240, libelle: "Délai de réponse" },
            opts: { suffixe: "heures ouvrables", aide: "Seuls les jours ouvrables comptent : du lundi au vendredi, sans les jours fériés. Les fins de semaine ne s’ajoutent pas au délai." },
          },
        ],
      },
    ],
    enregistrer: ({ delai_reponse_heures }) => enregistrerConfig({ delai_reponse_heures }).then(majApercu),
    succes: "Délai enregistré.",
  });

  const champ = p.champs.get("delai_reponse_heures");
  const apercu = h("p.reglages__note", { role: "status", "aria-live": "polite" });
  function majApercu() {
    const brut = String(champ.lire()).trim();
    const n = /^\d+$/.test(brut) ? +brut : NaN;
    if (!(n >= 1 && n <= 240)) {
      apercu.textContent = "";
      return;
    }
    const fin = echeanceOuvrable(maintenant(), n, etat.config.jours_feries_supplementaires || []);
    apercu.textContent = `Une demande reçue maintenant serait à traiter avant le ${dateLongue(partiesLocales(fin).date)}, à ${heure(fin)}.`;
  }
  champ.noeud.append(apercu);
  champ.noeud.addEventListener("input", majApercu);
  majApercu();

  return h(
    "div.pile",
    p.noeud,
    avis({
      ton: "attention",
      titre: "Le texte de votre site ne change pas tout seul",
      texte: "Ce délai sert dans le CRM : date limite de chaque demande, tâche de réponse, alertes et gabarits de courriel. La phrase affichée sur les pages publiques du site (« dans les 48 heures ouvrables ») reste celle du site : si vous changez le délai, faites aussi mettre le site à jour.",
    })
  );
}

// ----- Jours fériés et fermetures -------------------------------------------------------------------------
const trierDates = (valeurs) => [...valeurs].sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));

/** Jours de semaine de `du` à `au` (inclus). */
function joursOuvrablesEntre(du, au) {
  const jours = [];
  for (let d = du; d <= au; d = ajouterJours(d, 1)) {
    const j = jourSemaine(d);
    if (j !== 0 && j !== 6) jours.push(d);
  }
  return jours;
}

/** Fenêtre « Ajouter une période » : ajoute les jours de semaine de la période à la liste. Retourne le nombre de jours ajoutés. */
function fenetrePeriode(editeur) {
  return ouvrirDialogue({
    titre: "Ajouter une période de fermeture",
    taille: "petit",
    contenu: (ctx) => {
      const zone = zoneErreurDialogue();
      const du = creerChamp("du", { type: "date", libelle: "Du", requis: true }, "", {});
      const au = creerChamp("au", { type: "date", libelle: "Au (inclus)", requis: true }, "", { aide: "Pour une seule journée, entrez la même date." });

      function ajouter() {
        zone.afficher("");
        let faute = null;
        const v = {};
        for (const c of [du, au]) {
          const r = lireChamp(c, { requis: true });
          c.erreur(r.erreur || null);
          if (r.erreur) faute ||= c;
          else v[c.cle] = r.valeur;
        }
        if (faute) return faute.focus();
        if (v.au < v.du) {
          au.erreur("La fin doit venir après le début.");
          return au.focus();
        }
        if (v.au > ajouterJours(v.du, 366)) {
          au.erreur("La période ne peut pas dépasser un an.");
          return au.focus();
        }
        const existantes = new Set(editeur.brut().map((x) => x.date).filter(Boolean));
        const nouvelles = joursOuvrablesEntre(v.du, v.au).filter((d) => !existantes.has(d));
        if (!nouvelles.length) return zone.afficher("Ces jours sont déjà dans la liste, ou tombent une fin de semaine (déjà exclue du délai).");
        const place = MAX_DATES - existantes.size;
        if (nouvelles.length > place) return zone.afficher(`Cette période ajouterait ${pluriel(nouvelles.length, "jour")}, mais la liste n’accepte que ${MAX_DATES} dates (il reste ${pluriel(Math.max(place, 0), "place")}). Retirez d’abord des dates passées.`);
        editeur.definir(trierDates([...existantes].map((date) => ({ date })).concat(nouvelles.map((date) => ({ date })))));
        ctx.fermer(nouvelles.length);
      }

      ctx.definirPied(btn("Annuler", { onclick: () => ctx.fermer(0) }), btn("Ajouter", { ton: "primaire", onclick: ajouter }));
      const form = h(
        "form.formulaire",
        { novalidate: true, onsubmit: (e) => (e.preventDefault(), ajouter()) },
        h("p.muet", "Les jours de semaine de la période sont ajoutés à la liste, un par ligne. Les fins de semaine sont déjà exclues."),
        zone.noeud,
        du.noeud,
        au.noeud
      );
      form.addEventListener("input", () => ctx.modifie(true));
      return form;
    },
  }).promesse;
}

function panneauFeries() {
  const editeur = editeurListe({
    items: (etat.config.jours_feries_supplementaires || []).map((date) => ({ date })),
    colonnes: [{ cle: "date", libelle: "Journée sans réponse", spec: { type: "date", requis: true } }],
    nouveau: () => ({ date: "" }),
    libelleLigne: (v) => (v.date ? dateCourte(v.date) : "Nouvelle journée"),
    suffixeId: false, minimum: 0, maximum: MAX_DATES, compacte: true, libelleAjout: "Ajouter une journée", elements: ["date", "dates"],
    vide: "Aucune journée de fermeture ajoutée.",
  });

  const feries = prochainsFeries();
  const p = panneauListeEditable({
    titre: "Jours fériés et fermetures",
    sous: "Les journées où vous ne répondez pas : elles ne comptent pas dans le délai.",
    intro: [
      h(
        "div.pile.pile--s",
        h("p.reglages__note", h("strong", "Déjà exclus d’office : "), "les fins de semaine et les jours fériés du Québec (jour de l’An, Vendredi saint, Journée nationale des patriotes, Fête nationale, Fête du Canada, Fête du Travail, Action de grâce, Noël)."),
        feries.length
          ? h("ul.liste-simple", feries.map((f) => h("li", h("strong", f.nom), h("span.muet", ` — ${dateLongue(f.date)}`))))
          : null
      ),
      note("Ajoutez ici vos congés, vos vacances ou une journée de fermeture. Seules les journées de la liste s’ajoutent à celles-là."),
    ],
    editeur,
    valider: (v) => {
      const vues = new Set();
      for (const { date } of v) {
        if (vues.has(date)) return `La date du ${dateCourte(date)} apparaît deux fois.`;
        vues.add(date);
      }
      return null;
    },
    enregistrer: async (valeurs) => {
      const config = await enregistrerConfig({ jours_feries_supplementaires: trierDates(valeurs).map((x) => x.date) });
      return (config.jours_feries_supplementaires || []).map((date) => ({ date }));
    },
    succes: "Journées enregistrées.",
    actionsPied: [
      btn("Ajouter une période…", {
        petit: true, icone: "calendrier-plus",
        onclick: async () => {
          const n = await fenetrePeriode(editeur);
          if (n) p.statut.replaceChildren(icone("coche", "ic--p"), ` ${pluriel(n, "journée ajoutée", "journées ajoutées")} : enregistrez pour les appliquer.`);
        },
      }),
      btn("Retirer les dates passées", {
        petit: true,
        onclick: () => {
          const auj = aujourdhui(maintenant());
          const brut = editeur.brut();
          const gardees = brut.filter((x) => !x.date || x.date >= auj);
          if (gardees.length === brut.length) {
            p.statut.textContent = "Aucune date passée dans la liste.";
            return;
          }
          editeur.definir(gardees);
          p.statut.replaceChildren(icone("coche", "ic--p"), ` ${pluriel(brut.length - gardees.length, "date passée retirée", "dates passées retirées")} : enregistrez pour confirmer.`);
        },
      }),
    ],
  });
  return p.noeud;
}

// ----- Alertes par courriel -------------------------------------------------------------------------------
const NOMS_FOURNISSEURS = { resend: "Resend", sendgrid: "SendGrid" };

function panneauAlertes() {
  const c = etat.courriel;
  const corps = h("div.pile");

  if (c?.configure) {
    const resultat = h("div", { role: "status", "aria-live": "polite" });
    const bouton = btn("Envoyer un courriel d’essai", { icone: "envoyer" });
    bouton.addEventListener("click", async () => {
      resultat.replaceChildren();
      bouton.disabled = true;
      bouton.setAttribute("aria-busy", "true");
      try {
        const r = await envoyer("/config/courriel-essai", {});
        resultat.replaceChildren(avis({ ton: "ok", titre: "Courriel d’essai envoyé", texte: `Un message est parti vers ${r.destinataire}. Il devrait arriver en quelques instants ; pensez à vérifier les indésirables.` }));
      } catch (e) {
        if (!(e instanceof ErreurApi)) throw e;
        resultat.replaceChildren(avis({ ton: "erreur", titre: "L’essai a échoué", texte: e.message }));
      } finally {
        bouton.disabled = false;
        bouton.removeAttribute("aria-busy");
      }
    });
    corps.append(
      avis({
        ton: "ok",
        titre: "Les alertes par courriel sont actives",
        texte: `À chaque nouvelle demande reçue par le site, un courriel est envoyé à ${c.destinataire} (service ${NOMS_FOURNISSEURS[c.fournisseur] || c.fournisseur}). Il contient le message du visiteur et la date limite de réponse.`,
      }),
      h("div.actions-ligne", bouton),
      resultat
    );
  } else {
    corps.append(
      avis({
        ton: "info",
        titre: "Les alertes par courriel ne sont pas activées",
        texte: "Ce n’est pas obligatoire. Tant que le CRM est ouvert dans un onglet, il vérifie les nouvelles demandes chaque minute et vous les signale à l’écran, avec une notification du navigateur si vous l’avez autorisée (section « Profil et apparence »).",
      }),
      h("p", "Pour être aussi prévenue lorsque le CRM est fermé, activez les alertes par courriel : un message part dès qu’une demande arrive. Cela demande une courte configuration chez votre hébergeur."),
      h("div.actions-ligne", btn("Voir comment les activer", { href: "#/aide/alertes", icone: "aide" }))
    );
  }
  return panneau({ titre: "Alertes par courriel", sous: "Être prévenue quand le CRM est fermé.", niveau: 3 }, corps);
}

export default async function demandes() {
  return h("div.pile.pile--l", panneauDelai(), panneauFeries(), panneauAlertes());
}
