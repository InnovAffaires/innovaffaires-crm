// État du système : version, stockage et vérification du bon fonctionnement.
import { h } from "../../noyau/dom.js";
import { icone } from "../../noyau/icones.js";
import { etat, maintenant } from "../../noyau/etat.js";
import { publicGet, ErreurApi } from "../../noyau/api.js";
import { NOMS_ENTITES, ENTITES } from "../../commun/schema.js";
import { heure, pluriel } from "../../commun/format.js";
import { btn, panneau, avis, listeDef } from "../../ui/composants.js";

const STOCKAGES = {
  "netlify-blobs": "Stockage Netlify (permanent)",
  fichiers: "Fichiers locaux (essai)",
  memoire: "Mémoire temporaire (essai : les données disparaissent à l’arrêt)",
};

export default async function apropos() {
  const zone = h("div.pile", { role: "status", "aria-live": "polite" });
  const bouton = btn("Relancer la vérification", { icone: "ok" });

  async function verifier() {
    bouton.disabled = true;
    zone.replaceChildren(h("p.muet", "Vérification en cours…"));
    const avant = Date.now();
    try {
      const r = await publicGet("/sante");
      const delai = Date.now() - avant;
      // Écart entre l'horloge de l'appareil et celle du serveur (un appareil mal réglé fausse les « il y a … » et les échéances).
      const ecartMs = Date.parse(r.heure) - (avant + delai / 2);
      const ecartMin = Math.round(Math.abs(ecartMs) / 60000);
      zone.replaceChildren(
        avis(
          r.ok && r.ecriture
            ? { ton: "ok", titre: "Tout fonctionne", texte: "Le CRM répond et enregistre bien vos données." }
            : { ton: "erreur", titre: "Un problème a été détecté", texte: r.probleme || "Le CRM n’arrive pas à enregistrer vos données pour l’instant. Réessayez dans quelques minutes ; si le problème persiste, consultez le guide." }
        ),
        listeDef(
          [
            ["Réponse du serveur", `${delai} ms`],
            ["Enregistrement des données", r.ecriture ? "Fonctionne" : "En panne"],
            ["Alertes par courriel", r.courriel ? "Activées" : "Non activées (facultatif)"],
            ["Heure du serveur", heure(Date.parse(r.heure))],
            ecartMin >= 3 ? ["Horloge de votre appareil", `Décalée d’environ ${pluriel(ecartMin, "minute")} : corrigez-la, les échéances pourraient sembler fausses.`] : null,
          ].filter(Boolean),
          { classe: "def--roles" }
        )
      );
    } catch (e) {
      if (!(e instanceof ErreurApi)) throw e;
      zone.replaceChildren(avis({ ton: "erreur", titre: "Le CRM ne répond pas", texte: e.message }));
    } finally {
      bouton.disabled = false;
    }
  }
  bouton.addEventListener("click", verifier);
  verifier();

  const compte = NOMS_ENTITES.map((n) => [ENTITES[n].libellePluriel, String(etat.collections[n].filter((f) => !f.supprime).length)]);

  return h(
    "div.pile.pile--l",
    panneau({ titre: "Vérification du bon fonctionnement", sous: "Le CRM s’interroge lui-même.", niveau: 3 }, h("div.pile", zone, h("div.actions-ligne", bouton))),
    panneau(
      { titre: "Ce CRM", niveau: 3 },
      listeDef(
        [
          ["Version", etat.version || "—"],
          ["Adresse", `${location.origin}${location.pathname}`],
          ["Votre rôle", { admin: "Administrateur", standard: "Utilisateur", lecture: "Lecture seule" }[etat.droits.role] || etat.droits.role],
          ["Heure (Toronto)", heure(maintenant())],
        ],
        { classe: "def--roles" }
      )
    ),
    panneau({ titre: "Vos données", sous: "Fiches actuellement dans le CRM (hors corbeille).", niveau: 3 }, listeDef(compte, { classe: "def--roles" })),
    h("p.reglages__note.muet", icone("info", "ic--p"), " Besoin d’aide ? Consultez ", h("a", { href: "#/aide" }, "la page d’aide"), " : elle explique les sauvegardes, la récupération d’accès et les alertes par courriel.")
  );
}
