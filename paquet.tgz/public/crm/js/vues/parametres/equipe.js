// Équipe et accès : qui peut entrer dans le CRM, et avec quel rôle.
// Le CRM n'envoie aucune invitation : l'administrateur remet lui-même l'adresse et le mot de passe temporaire.
import { h, remplir } from "../../noyau/dom.js";
import { etat, maintenant, notifier } from "../../noyau/etat.js";
import { lire, envoyer, modifier, ErreurApi } from "../../noyau/api.js";
import { chargerEquipe } from "../../noyau/synchro.js";
import { ilYa, pluriel } from "../../commun/format.js";
import { btn, panneau, pastille, avatar, avis, menuActions, listeDef } from "../../ui/composants.js";
import { creerChamp } from "../../ui/formulaire.js";
import { ouvrirDialogue, confirmer } from "../../ui/dialogue.js";
import { toast, toastErreur } from "../../ui/toast.js";
import { enc, lireChamp, zoneErreurDialogue, afficherSecret } from "./commun.js";

export const ROLES = [
  { id: "admin", libelle: "Administrateur", explication: "Fait tout ce que fait un utilisateur, et règle aussi le CRM : paramètres, accès de l’équipe, sauvegardes, journal d’activité, effacement définitif des fiches." },
  { id: "standard", libelle: "Utilisateur", explication: "Consulte, ajoute et modifie les fiches (contacts, dossiers, factures…) et peut importer des contacts. Ne touche pas aux réglages de l’entreprise." },
  { id: "lecture", libelle: "Lecture seule", explication: "Consulte les fiches sans rien pouvoir modifier. Pratique pour un comptable ou un collaborateur de passage." },
];
export const libelleRole = (id) => ROLES.find((r) => r.id === id)?.libelle || id;

/** Adresse où se connecter, à remettre avec le mot de passe temporaire. */
const adresseConnexion = () => `${location.origin}${location.pathname}`;
const estMoi = (u) => u.id === etat.utilisateur?.id;

// ----- Fenêtres -------------------------------------------------------------------------------------------
/** Sélecteur de rôle avec, dessous, ce que le rôle choisi permet. */
function champRole(valeur, { desactive = false } = {}) {
  const role = creerChamp("role", { type: "choix", libelle: "Rôle", options: ROLES.map(({ id, libelle }) => ({ id, libelle })), requis: true }, valeur, { desactive });
  const explication = h("p.champ__aide.explication-role");
  const maj = () => (explication.textContent = ROLES.find((r) => r.id === role.lire())?.explication || "");
  role.noeud.addEventListener("change", maj);
  maj();
  role.noeud.append(explication);
  return role;
}

/** Fenêtre pour inviter une personne. Retourne { utilisateur, motDePasseTemporaire } si le compte est créé, sinon null. */
function fenetreInviter() {
  return ouvrirDialogue({
    titre: "Inviter une personne",
    contenu: (ctx) => {
      const zone = zoneErreurDialogue();
      const nom = creerChamp("nom", { type: "texte", libelle: "Nom complet", max: 100, requis: true }, "", {});
      const courriel = creerChamp("courriel", { type: "courriel", libelle: "Courriel", max: 200, requis: true }, "", { aide: "La personne se connectera avec cette adresse." });
      const role = champRole("standard");
      const champs = [nom, courriel, role];

      async function creer() {
        zone.afficher("");
        const valeurs = {};
        let premier = null;
        for (const c of champs) {
          const r = lireChamp(c, { requis: true });
          c.erreur(r.erreur || null);
          if (r.erreur) premier ||= c;
          else valeurs[c.cle] = r.valeur;
        }
        if (premier) return premier.focus();
        ctx.occupe(true);
        try {
          const rep = await envoyer("/utilisateurs", valeurs);
          ctx.occupe(false);
          ctx.fermer(rep);
        } catch (e) {
          ctx.occupe(false);
          if (!(e instanceof ErreurApi)) throw e;
          let lie = null;
          for (const [k, m] of Object.entries(e.champs || {})) {
            const c = champs.find((x) => x.cle === k);
            if (!c) continue;
            c.erreur(e.statut === 409 ? e.message : m);
            lie ||= c;
          }
          if (lie) lie.focus();
          else zone.afficher(e.message);
        }
      }

      ctx.definirPied(btn("Annuler", { onclick: () => ctx.fermer(null) }), btn("Créer le compte", { ton: "primaire", onclick: creer }));
      const form = h(
        "form.formulaire",
        { novalidate: true, autocomplete: "off", onsubmit: (e) => (e.preventDefault(), creer()) },
        h("p.muet", "Le CRM crée le compte et vous donne un mot de passe temporaire à remettre à la personne. Aucun courriel n’est envoyé."),
        zone.noeud,
        nom.noeud,
        courriel.noeud,
        role.noeud
      );
      form.addEventListener("input", () => ctx.modifie(true));
      return form;
    },
  }).promesse;
}

/** Fenêtre pour modifier le nom et le rôle d'une personne. Retourne l'utilisateur modifié, ou null. */
function fenetreModifier(u) {
  return ouvrirDialogue({
    titre: "Modifier la personne",
    contenu: (ctx) => {
      const zone = zoneErreurDialogue();
      const moi = estMoi(u);
      const nom = creerChamp("nom", { type: "texte", libelle: "Nom complet", max: 100, requis: true }, u.nom, {});
      const role = champRole(u.role, { desactive: moi });
      if (moi) role.noeud.append(h("p.champ__aide", "Vous ne pouvez pas changer votre propre rôle : demandez-le à un autre administrateur."));

      async function enregistrer() {
        zone.afficher("");
        const r = lireChamp(nom, { requis: true });
        nom.erreur(r.erreur || null);
        if (r.erreur) return nom.focus();
        const corps = { nom: r.valeur };
        if (!moi && role.lire() !== u.role) corps.role = role.lire();
        if (corps.nom === u.nom && corps.role === undefined) return ctx.fermer(null);
        ctx.occupe(true);
        try {
          const rep = await modifier(`/utilisateurs/${enc(u.id)}`, corps);
          ctx.occupe(false);
          ctx.fermer(rep.utilisateur);
        } catch (e) {
          ctx.occupe(false);
          if (!(e instanceof ErreurApi)) throw e;
          if (e.champs?.nom) {
            nom.erreur(e.champs.nom);
            nom.focus();
          } else zone.afficher(e.message);
        }
      }

      ctx.definirPied(btn("Annuler", { onclick: () => ctx.fermer(null) }), btn("Enregistrer", { ton: "primaire", onclick: enregistrer }));
      const form = h(
        "form.formulaire",
        { novalidate: true, autocomplete: "off", onsubmit: (e) => (e.preventDefault(), enregistrer()) },
        zone.noeud,
        h("p.muet", `Courriel de connexion : ${u.courriel}`),
        nom.noeud,
        role.noeud
      );
      form.addEventListener("input", () => ctx.modifie(true));
      return form;
    },
  }).promesse;
}

// ----- Liste des personnes ---------------------------------------------------------------------------------
const ORDRE_ROLE = { admin: 0, standard: 1, lecture: 2 };
/** Accès ouverts d'abord (administrateurs, puis utilisateurs, puis lecture seule), puis par nom. */
const trier = (liste) =>
  [...liste].sort((a, b) => Number(b.actif) - Number(a.actif) || (ORDRE_ROLE[a.role] ?? 9) - (ORDRE_ROLE[b.role] ?? 9) || a.nom.localeCompare(b.nom, "fr-CA", { sensitivity: "base" }));

/** Une personne : identité et menu d'actions en haut, rôle, sécurité et dernière connexion en dessous. */
function ligne(u, actions) {
  const exigee = !!etat.config?.securite?.double_facteur_obligatoire;
  const securite = u.mfa ? pastille("Double vérification", "ok", { icone: "bouclier" }) : exigee ? pastille("À configurer", "attention") : pastille("Mot de passe seul");
  const etatCompte = !u.actif ? pastille("Accès fermé", "erreur") : u.doit_changer_mdp ? pastille("Mot de passe temporaire", "attention") : null;
  const connexion = u.derniere_connexion ? `Dernière connexion ${ilYa(Date.parse(u.derniere_connexion), maintenant())}` : "Aucune connexion pour l’instant";
  return h(
    "li.personne",
    { class: { "personne--fermee": !u.actif } },
    h(
      "div.personne__identite",
      avatar(u.nom),
      h("div.identite__texte", h("div.personne__nom", h("strong", u.nom), estMoi(u) ? h("span.muet", "(vous)") : null), h("small.muet", u.courriel))
    ),
    h("div.personne__actions", actions(u)),
    h("div.personne__infos", etatCompte, pastille(libelleRole(u.role), u.role === "admin" ? "info" : "neutre"), u.actif ? securite : null, h("span.muet.petit", connexion))
  );
}

export default async function equipe() {
  let utilisateurs = (await lire("/utilisateurs")).utilisateurs || [];

  const resume = h("p.panneau__sous");
  const majResume = () => {
    const actifs = utilisateurs.filter((u) => u.actif).length;
    resume.textContent = `${pluriel(actifs, "accès ouvert", "accès ouverts")} sur ${pluriel(utilisateurs.length, "compte", "comptes")}.`;
  };

  /** Relit la liste des comptes et la redessine. */
  async function recharger() {
    utilisateurs = (await lire("/utilisateurs")).utilisateurs || [];
    dessiner();
    majResume();
    await chargerEquipe();
  }

  /** Exécute une action sur un compte, relit la liste, puis confirme par une notification. */
  async function apres(fn, messageOk) {
    try {
      const rep = await fn();
      await recharger();
      if (messageOk) toast(messageOk);
      return rep;
    } catch (e) {
      if (!(e instanceof ErreurApi)) throw e;
      toastErreur(e);
      return null;
    }
  }

  async function inviter() {
    const rep = await fenetreInviter();
    if (!rep) return;
    await recharger().catch(() => {});
    await afficherSecret({
      titre: "Compte créé",
      message: `Transmettez à ${rep.utilisateur.nom} son mot de passe temporaire. La personne devra en choisir un nouveau dès sa première connexion.`,
      secret: rep.motDePasseTemporaire,
      etiquette: "Mot de passe temporaire",
      suite: `Adresse de connexion : ${adresseConnexion()} — courriel : ${rep.utilisateur.courriel}. Ce mot de passe ne sera plus affiché ensuite : si vous le perdez, réinitialisez-le.`,
    });
  }

  async function modifierPersonne(u) {
    const modifie = await fenetreModifier(u);
    if (!modifie) return;
    if (estMoi(u)) {
      etat.utilisateur = { ...etat.utilisateur, nom: modifie.nom };
      notifier("session");
    }
    await recharger().catch(() => {});
    toast("Modifications enregistrées.");
  }

  async function reinitialiser(u) {
    const ok = await confirmer({
      titre: "Réinitialiser le mot de passe ?",
      message: `Les sessions ouvertes de ${u.nom} seront fermées. Le CRM vous donnera un mot de passe temporaire à remettre à la personne, qui devra en choisir un nouveau à sa prochaine connexion.`,
      libelleConfirmer: "Réinitialiser",
    });
    if (!ok) return;
    const rep = await apres(() => envoyer(`/utilisateurs/${enc(u.id)}/reinitialiser`, {}));
    if (!rep) return;
    await afficherSecret({
      titre: "Mot de passe temporaire", message: `Transmettez ce mot de passe à ${u.nom}.`, secret: rep.motDePasseTemporaire, etiquette: "Mot de passe temporaire",
      suite: `Adresse de connexion : ${adresseConnexion()} — courriel : ${u.courriel}. Il ne sera plus affiché ensuite.`,
    });
  }

  async function retirer2fa(u) {
    const ok = await confirmer({
      titre: "Retirer la double vérification ?",
      message: `${u.nom} pourra se connecter avec son seul mot de passe, et devra la configurer de nouveau si votre organisation l’exige. À faire seulement si la personne a perdu son téléphone et ses codes de récupération.`,
      libelleConfirmer: "Retirer", danger: true,
    });
    if (ok) await apres(() => envoyer(`/utilisateurs/${enc(u.id)}/retirer-2fa`, {}), "Double vérification retirée.");
  }

  async function fermerAcces(u) {
    const ok = await confirmer({
      titre: "Fermer l’accès de cette personne ?",
      message: `${u.nom} ne pourra plus se connecter, et ses sessions ouvertes sont fermées tout de suite. Ses fiches et son historique sont conservés.`,
      detail: h("p.muet", "Vous pourrez rouvrir cet accès plus tard."),
      libelleConfirmer: "Fermer l’accès", danger: true,
    });
    if (ok) await apres(() => modifier(`/utilisateurs/${enc(u.id)}`, { actif: false }), "Accès fermé.");
  }

  const rouvrirAcces = (u) => apres(() => modifier(`/utilisateurs/${enc(u.id)}`, { actif: true }), "Accès rétabli.");

  function actions(u) {
    const moi = estMoi(u);
    const elements = [{ libelle: "Modifier…", icone: "modifier", onclick: () => modifierPersonne(u) }];
    // Ces gestes visent les autres comptes : pour le sien, on passe par « Mot de passe et sécurité ».
    if (!moi && u.actif) elements.push({ libelle: "Réinitialiser le mot de passe…", icone: "cle", onclick: () => reinitialiser(u) });
    if (!moi && u.mfa) elements.push({ libelle: "Retirer la double vérification…", icone: "bouclier", onclick: () => retirer2fa(u) });
    if (!moi) {
      elements.push("separateur");
      elements.push(u.actif ? { libelle: "Fermer l’accès…", icone: "bloquer", danger: true, onclick: () => fermerAcces(u) } : { libelle: "Rétablir l’accès", icone: "utilisateur-ok", onclick: () => rouvrirAcces(u) });
    }
    return menuActions({ aria: `Actions pour ${u.nom}`, elements });
  }

  const liste = h("ul.personnes", { "aria-label": "Personnes ayant accès au CRM" });
  const dessiner = () => remplir(liste, trier(utilisateurs).map((u) => ligne(u, actions)));
  dessiner();
  majResume();

  return h(
    "div.pile.pile--l",
    h(
      "section.panneau",
      { "aria-labelledby": "equipe-titre" },
      h(
        "header.panneau__tete",
        h("div.panneau__titres", h("h3", { id: "equipe-titre" }, "Personnes ayant accès"), resume),
        h("div.panneau__actions", btn("Inviter une personne", { ton: "primaire", icone: "ajout-utilisateur", onclick: inviter }))
      ),
      h("div.panneau__corps", liste)
    ),
    panneau({ titre: "Ce que permet chaque rôle", niveau: 3 }, listeDef(ROLES.map((r) => [r.libelle, r.explication]), { classe: "def--roles" })),
    avis({
      ton: "info",
      titre: "Mot de passe oublié ?",
      texte: "Une personne qui a ses codes de récupération peut retrouver l’accès seule, avec le lien « J’ai perdu l’accès à mon compte » de l’écran de connexion. Sinon, réinitialisez son mot de passe ici. Si elle a aussi perdu son téléphone, retirez sa double vérification.",
    })
  );
}
