// =============================================================================
// Demandes du site : la boîte de réception. À gauche la liste, à droite la
// lecture de la demande choisie et la suite à lui donner (répondre, convertir
// en contact et en affaire, classer). Sur téléphone, un écran à la fois.
// =============================================================================
import { h, remplir, paragraphes, idUnique } from "../noyau/dom.js";
import { icone } from "../noyau/icones.js";
import { etat, actives, fiche, maintenant, mettreAJourFiche, texteRecherche } from "../noyau/etat.js";
import { naviguer } from "../noyau/routeur.js";
import { modifierFiche, supprimerAvecAnnulation, tenter } from "../noyau/ecriture.js";
import { envoyer } from "../noyau/api.js";
import { synchroniser } from "../noyau/synchro.js";
import { aujourdhui } from "../commun/dates.js";
import { forfaitDeDemande, niveauDeDemande, titreAffaireForfait, honorairesDeDepart } from "../commun/forfaits.js";
import { argentEntier, dateCourte, ilYa, normaliser, pluriel, tronquer } from "../commun/format.js";
import { btn, avatar, pastille, tampon, panneau, listeDef, lienVers, menuActions, onglets, enTete, etatVide } from "../ui/composants.js";
import { barreFiltres } from "../ui/filtres.js";
import { ouvrirDialogue } from "../ui/dialogue.js";
import { toast } from "../ui/toast.js";
import { ouvrirCourriel, variablesCourriel } from "../ui/courriel.js";
import { creerBlocEchanges } from "../ui/echanges.js";
import { peutEnvoyerGmail, peutVoirEchanges } from "../noyau/google.js";
import { delaiReponse, echeanceReponse, lienCourriel, lienTelephone, dateHeure } from "./aides.js";
import { boutonAppeler, boutonFileAppels, texteNePasAppeler } from "./appels/raccords.js";

export const depend = ["demandes", "contacts", "entreprises", "opportunites", "taches", "config", "session", "google"];

const ONGLETS = [
  {
    id: "a-traiter", libelle: "À traiter", statuts: ["nouveau", "en-cours"],
    vide: { icone: "demandes", titre: "Aucune demande à traiter", texte: "Tout est à jour. Les messages envoyés par le formulaire de contact de votre site apparaissent ici." },
  },
  {
    id: "converties", libelle: "Converties", statuts: ["converti"],
    vide: { icone: "contacts", titre: "Aucune demande convertie", texte: "Quand vous convertissez une demande, elle devient un contact et, si vous le souhaitez, une affaire." },
  },
  {
    id: "classees", libelle: "Classées", statuts: ["archive", "pourriel"],
    vide: { icone: "archiver", titre: "Rien de classé", texte: "Les demandes archivées et les pourriels détectés par le site se retrouvent ici." },
  },
];
const ongletDe = (d) => ONGLETS.find((o) => o.statuts.includes(d.statut))?.id || "a-traiter";

const STATUTS = {
  nouveau: { libelle: "Nouvelle", ton: "attention" },
  "en-cours": { libelle: "En traitement", ton: "info" },
  converti: { libelle: "Convertie", ton: "ok" },
  archive: { libelle: "Archivée", ton: "neutre" },
  pourriel: { libelle: "Pourriel", ton: "erreur" },
};
const estOuverte = (d) => d.statut === "nouveau" || d.statut === "en-cours";

/** Demandes d'un onglet, filtrées par la recherche, les plus anciennes d'abord dans « À traiter ». */
function demandesDe(ongletId, q) {
  const o = ONGLETS.find((x) => x.id === ongletId);
  const jetons = normaliser(q).split(/\s+/).filter(Boolean);
  const lignes = actives("demandes").filter((d) => o.statuts.includes(d.statut) && (!jetons.length || jetons.every((j) => texteRecherche("demandes", d).includes(j))));
  const sens = ongletId === "a-traiter" ? 1 : -1;
  return lignes.sort((a, b) => sens * String(a.recu || "").localeCompare(String(b.recu || "")));
}

// ----- Une ligne de la liste ---------------------------------------------------------------------------------------------------
function marqueLigne(d) {
  if (estOuverte(d)) {
    const delai = delaiReponse(d);
    return delai ? pastille(delai.court, delai.ton, { icone: delai.enRetard ? "alerte" : "horloge" }) : pastille("Répondu", "ok", { icone: "courriel-ok" });
  }
  if (d.statut === "archive" || d.statut === "pourriel") return pastille(STATUTS[d.statut].libelle, STATUTS[d.statut].ton);
  return null;
}

function ligneDemande(d, selectionnee) {
  const ms = Date.parse(d.recu);
  return h(
    "li",
    h(
      "a.demande-ligne",
      { href: `#/demandes/${encodeURIComponent(d.id)}`, "aria-current": selectionnee ? "true" : null, class: { "demande-ligne--ouverte": estOuverte(d) && d.statut === "nouveau" } },
      avatar(d.nom),
      h(
        "span.demande-ligne__corps",
        h("span.demande-ligne__tete", h("strong.demande-ligne__nom", d.statut === "nouveau" ? h("span.sr-only", "Nouvelle demande : ") : null, d.nom || d.courriel), h("time.demande-ligne__quand", { datetime: d.recu, title: dateHeure(ms) }, ilYa(ms, maintenant()))),
        d.organisation ? h("span.demande-ligne__org", d.organisation) : null,
        h("span.ligne__extrait", tronquer(d.projet, 170)),
        h("span.demande-ligne__marque", marqueLigne(d))
      )
    )
  );
}

// ----- Suites données à une demande ------------------------------------------------------------------------------------------
async function changerStatut(d, statut, message) {
  const courante = fiche("demandes", d.id) || d;
  const avant = courante.statut;
  const r = await tenter(() => modifierFiche("demandes", courante, { statut }), { entite: "demandes" });
  if (!r) return;
  toast(message, {
    ton: "info", duree: 8000,
    action: { libelle: "Annuler", onclick: () => tenter(() => modifierFiche("demandes", fiche("demandes", d.id) || r.fiche, { statut: avant }), { entite: "demandes" }) },
  });
}

async function marquerRepondue(d) {
  const courante = fiche("demandes", d.id) || d;
  if (courante.reponse_le) return;
  const patch = { reponse_le: new Date(maintenant()).toISOString() };
  if (courante.statut === "nouveau") patch.statut = "en-cours";
  const r = await tenter(() => modifierFiche("demandes", courante, patch), { entite: "demandes" });
  if (!r) return;
  // La tâche « Répondre à… » créée à la conversion n'a plus de raison d'être.
  const tache = actives("taches").find((t) => t.gabarit_cle === `demande:${d.id}` && t.statut !== "fait");
  if (tache) await tenter(() => modifierFiche("taches", tache, { statut: "fait" }), { entite: "taches" });
  toast("Réponse consignée.", {
    ton: "ok", duree: 7000,
    action: { libelle: "Annuler", onclick: () => tenter(() => modifierFiche("demandes", fiche("demandes", d.id) || r.fiche, { reponse_le: null }), { entite: "demandes" }) },
  });
}

async function annulerReponse(d) {
  await tenter(() => modifierFiche("demandes", fiche("demandes", d.id) || d, { reponse_le: null }), { succes: "La réponse n’est plus consignée.", entite: "demandes" });
}

/** De quoi remplir un gabarit de courriel avec ce que la demande dit de la personne. */
function variablesDemande(d) {
  const mots = String(d.nom || "").trim().split(/\s+/).filter(Boolean);
  return variablesCourriel({ contact: { prenom: mots[0] || "", nom: mots.slice(1).join(" ") }, entreprise: d.organisation ? { nom: d.organisation } : null });
}

/**
 * Le bouton de réponse. Avec un compte Gmail connecté, il ouvre la fenêtre d'envoi : le courriel part de Gmail, s'inscrit
 * à l'historique et la demande est marquée comme répondue. Sinon, il ouvre un message dans le logiciel de courriel.
 */
function lienReponse(d, { classe = "btn btn--secondaire", libelle = "Répondre par courriel" } = {}) {
  const mots = String(d.nom || "").trim().split(/\s+/).filter(Boolean);
  const salut = mots.length ? `Bonjour ${mots[0]},` : "Bonjour,";
  const sujet = "Votre demande à InnovAffaires";
  if (peutEnvoyerGmail()) {
    return h(
      "button",
      {
        class: classe, type: "button",
        onclick: () => {
          const courante = fiche("demandes", d.id) || d;
          ouvrirCourriel({
            titre: `Répondre à ${courante.nom}`, destinataire: courante.courriel, objet: sujet, message: `${salut}\n\n`, variables: variablesDemande(courante),
            lier: { lieType: "demandes", lieId: courante.id }, surEnvoye: () => marquerRepondue(courante),
          });
        },
      },
      icone("courriel"),
      h("span", libelle)
    );
  }
  const href = `mailto:${encodeURIComponent(d.courriel).replace(/%40/g, "@")}?subject=${encodeURIComponent(sujet)}&body=${encodeURIComponent(`${salut}\n\n`)}`;
  const a = h("a", { class: classe, href }, icone("courriel"), h("span", libelle));
  a.addEventListener("click", () => {
    const courante = fiche("demandes", d.id) || d;
    if (courante.reponse_le || !etat.droits.ecrire) return;
    toast("Courriel ouvert dans votre messagerie.", { ton: "info", duree: 9000, action: { libelle: "Marquer comme répondue", onclick: () => marquerRepondue(courante) } });
  });
  return a;
}

// ----- Conversion en contact (+ entreprise + affaire + tâche) ------------------------------------------------------
function ouvrirConversion(d) {
  const existant = actives("contacts").find((c) => !c.anonymise && c.courriel && normaliser(c.courriel) === normaliser(d.courriel));
  const dejaRepondu = !!(fiche("demandes", d.id) || d).reponse_le;
  const honoraires = etat.config?.honoraires?.diagnostic || 0;
  const premiereEtape = etat.config?.etapes?.[0]?.nom || "";

  ouvrirDialogue({
    titre: "Convertir en contact", taille: "moyen",
    description: `La demande de ${d.nom} devient une fiche contact. Vous pouvez y rattacher une entreprise et ouvrir une affaire pour suivre le mandat.`,
    contenu: (ctx) => {
      const idNom = idUnique("conv-nom");
      const idListe = idUnique("conv-ent");
      const idAide = idUnique("conv-aide");
      const nom = h("input.saisie", { id: idNom, type: "text", maxlength: 160, autocomplete: "off", list: idListe, placeholder: "Facultatif — ex. : Ferme Tremblay inc.", "aria-describedby": idAide });
      const liste = h("datalist", { id: idListe }, actives("entreprises").slice(0, 400).map((e) => h("option", { value: e.nom })));
      const caseAffaire = h("input", { type: "checkbox", checked: true });
      const recap = h("ul.recap");
      const alerte = h("p.champ__erreur", { role: "alert", hidden: true });

      const entrepriseExistante = () => {
        const n = normaliser(nom.value);
        return n ? actives("entreprises").find((e) => normaliser(e.nom) === n) : null;
      };
      function majRecap() {
        const n = nom.value.trim();
        const e = entrepriseExistante();
        const lignes = [
          h("li", icone("coche", "ic--p"), h("span", h("strong", "Contact"), ` : ${d.nom} (${d.courriel}) — `, existant ? "un contact portant ce courriel existe déjà, il sera réutilisé." : "sera créé.")),
        ];
        if (n) lignes.push(h("li", icone("coche", "ic--p"), h("span", h("strong", "Entreprise"), ` : « ${tronquer(n, 60)} » — `, e ? "existante, elle sera réutilisée." : "sera créée.")));
        if (caseAffaire.checked) {
          // Une demande de forfait (page « Lancement InnovAffaires ») ouvre une affaire au nom du forfait et du niveau choisi,
          // avec pour honoraires estimés le bas de la fourchette du niveau (à ajuster avec votre soumission).
          const forfait = forfaitDeDemande(d.projet);
          const niveau = forfait ? niveauDeDemande(d.projet) : null;
          const titre = forfait ? titreAffaireForfait(forfait, { entreprise: n, nom: d.nom, niveau: niveau?.nom }) : n ? `${tronquer(n, 50)} — demande de financement` : `Demande de ${d.nom}`;
          const honorairesTexte = forfait
            ? niveau
              ? `, service « Autre mandat », honoraires estimés à ${argentEntier(honorairesDeDepart(niveau))} (bas de la fourchette du niveau ${niveau.nom}), à ajuster avec votre soumission`
              : ", service « Autre mandat », honoraires à fixer avec votre soumission"
            : honoraires ? `, honoraires estimés à ${honoraires} $ (diagnostic)` : "";
          lignes.push(h("li", icone("coche", "ic--p"), h("span", h("strong", "Affaire"), ` : « ${titre} »${premiereEtape ? `, étape « ${premiereEtape} »` : ""}${honorairesTexte}.`)));
        }
        const due = echeanceReponse(d);
        lignes.push(
          dejaRepondu
            ? h("li.recap__neutre", icone("courriel-ok", "ic--p"), h("span", "Aucune tâche de réponse : vous avez déjà répondu à cette demande."))
            : h("li", icone("coche", "ic--p"), h("span", h("strong", "Tâche"), ` : « Répondre à ${tronquer(d.nom, 40)} », à faire avant le ${dateCourte(aujourdhui(due))}.`))
        );
        remplir(recap, lignes);
      }
      nom.addEventListener("input", majRecap);
      caseAffaire.addEventListener("change", majRecap);
      majRecap();

      const form = h(
        "form.formulaire",
        { novalidate: true },
        h(
          "div.champ",
          h("label.champ__etiquette", { for: idNom }, "Entreprise ou organisme"),
          nom, liste,
          h("p.champ__aide", { id: idAide }, "Si ce nom correspond à une entreprise déjà dans le CRM, elle est réutilisée.")
        ),
        h("label.case", caseAffaire, h("span.case__boite", { "aria-hidden": "true" }, icone("coche", "ic--p")), h("span", "Ouvrir aussi une affaire pour suivre les honoraires")),
        h("div.pile.pile--s", h("h3", "Ce qui sera créé"), recap),
        alerte
      );
      const annuler = btn("Annuler", { onclick: () => ctx.fermer(undefined) });
      const ok = btn("Convertir", { ton: "primaire", icone: "ajout-utilisateur" });
      ctx.definirPied(annuler, ok);

      async function convertir() {
        alerte.hidden = true;
        ctx.occupe(true);
        const r = await tenter(
          () => envoyer(`/demandes/${encodeURIComponent(d.id)}/convertir`, { entreprise_nom: nom.value.trim() || undefined, creer_affaire: caseAffaire.checked }),
          { entite: "demandes", surErreur: (e) => { alerte.hidden = false; alerte.textContent = e.message; } }
        );
        ctx.occupe(false);
        if (!r) return;
        for (const [entite, f] of [["contacts", r.contact], ["entreprises", r.entreprise], ["opportunites", r.opportunite], ["taches", r.tache], ["demandes", r.demande]]) {
          if (f) mettreAJourFiche(entite, f);
        }
        synchroniser().catch(() => {});
        ctx.fermer(r);
        if (r.deja) {
          toast("Cette demande était déjà convertie.", { ton: "info" });
          return;
        }
        const morceaux = [r.contact_existant ? "contact existant réutilisé" : "contact créé"];
        if (r.entreprise) morceaux.push(`entreprise « ${tronquer(r.entreprise.nom, 40)} »`);
        if (r.opportunite) morceaux.push("affaire ouverte");
        if (r.tache) morceaux.push(`tâche à faire avant le ${dateCourte(r.tache.echeance)}`);
        toast(`Demande convertie : ${morceaux.join(", ")}.`, { duree: 9000 });
      }
      form.addEventListener("submit", (e) => {
        e.preventDefault();
        convertir();
      });
      ok.addEventListener("click", (e) => {
        e.preventDefault();
        convertir();
      });
      return form;
    },
  });
}

// ----- Le panneau de droite ------------------------------------------------------------------------------------------------------
function enteteDetail(d) {
  const ms = Date.parse(d.recu);
  const statut = STATUTS[d.statut] || STATUTS.nouveau;
  const marque = estOuverte(d) ? pastille(statut.libelle, statut.ton) : tampon(statut.libelle, statut.ton);
  return h(
    "header.demande__tete",
    avatar(d.nom, { taille: "l" }),
    h(
      "div.demande__titres",
      h("h2.demande__nom", d.nom || d.courriel),
      h("p.demande__recue", `Reçue ${dateHeure(ms)}`, h("span.muet", ` — ${ilYa(ms, maintenant())}`))
    ),
    h("div.demande__marque", marque)
  );
}

/** Bloc « réponse » : délai promis, ou date de la réponse envoyée. */
function blocReponse(d) {
  const peutEcrire = etat.droits.ecrire;
  const promis = etat.config?.delai_reponse_heures ?? 48;
  if (d.reponse_le) {
    const ms = Date.parse(d.reponse_le);
    const dansLeDelai = ms <= echeanceReponse(d);
    return h(
      "div.demande__reponse.demande__reponse--faite",
      icone("courriel-ok"),
      h("p", h("strong", "Réponse envoyée"), ` ${dateHeure(ms)} — `, h("span", { class: dansLeDelai ? "demande__ok" : "demande__retard" }, dansLeDelai ? `dans le délai promis (${promis} h ouvrables)` : `après le délai promis (${promis} h ouvrables)`)),
      peutEcrire ? btn("Annuler", { ton: "discret", petit: true, onclick: () => annulerReponse(d) }) : null
    );
  }
  if (!estOuverte(d) && d.statut !== "converti") return null;
  const delai = delaiReponse(d);
  return h(
    "div.demande__reponse",
    { class: delai ? `demande__reponse--${delai.ton}` : "" },
    icone(delai?.enRetard ? "alerte" : "horloge"),
    h("p", h("strong", delai?.texte || "Réponse attendue"), h("span.muet", ` — votre site promet une réponse sous ${promis} heures ouvrables`)),
    peutEcrire ? btn("J’ai répondu", { petit: true, icone: "coche", onclick: () => marquerRepondue(d) }) : null
  );
}

function boutonsAction(d) {
  const peutEcrire = etat.droits.ecrire;
  const actions = [];
  if (d.statut !== "pourriel") actions.push(lienReponse(d, { classe: `btn ${estOuverte(d) ? "btn--secondaire" : "btn--discret"}` }));
  if (peutEcrire && estOuverte(d)) actions.unshift(btn("Convertir en contact", { ton: "primaire", icone: "ajout-utilisateur", onclick: () => ouvrirConversion(d) }));
  if (d.statut === "converti" && d.contact_id && fiche("contacts", d.contact_id)) actions.unshift(btn("Ouvrir le contact", { ton: "primaire", icone: "contacts", href: `#/contacts/${encodeURIComponent(d.contact_id)}` }));
  if (d.statut !== "pourriel" && d.telephone) {
    const appeler = boutonAppeler("demandes", d, d.telephone);
    if (appeler) actions.push(appeler);
    const file = boutonFileAppels("demandes", d);
    if (file) actions.push(file);
  }
  if (peutEcrire) {
    actions.push(
      menuActions({
        libelle: "Classer", icone: "archiver", aria: "Classer ou supprimer cette demande",
        elements: () => [
          !estOuverte(d) && d.statut !== "converti" ? { libelle: "Remettre à traiter", icone: "annuler", onclick: () => changerStatut(d, "nouveau", "Demande remise à traiter.") } : null,
          estOuverte(d) ? { libelle: "Archiver", icone: "archiver", onclick: () => changerStatut(d, "archive", "Demande archivée.") } : null,
          d.statut !== "pourriel" && d.statut !== "converti" ? { libelle: "Classer comme pourriel", icone: "bloquer", onclick: () => changerStatut(d, "pourriel", "Demande classée comme pourriel.") } : null,
          d.statut === "converti" ? { libelle: "Archiver", icone: "archiver", onclick: () => changerStatut(d, "archive", "Demande archivée.") } : null,
          "separateur",
          { libelle: "Mettre à la corbeille", icone: "corbeille", danger: true, onclick: () => supprimerAvecAnnulation("demandes", d.id, { apres: () => naviguer("/demandes") }) },
        ],
      })
    );
  }
  return actions;
}

/** Notes internes : un champ qui s'enregistre à la demande. `sale()` dit s'il y a une saisie non enregistrée. */
function panneauNotes(d) {
  const peutEcrire = etat.droits.ecrire;
  const idChamp = idUnique("notes");
  const zone = h("textarea.saisie.saisie--long", {
    id: idChamp, rows: 4, maxlength: 3000, disabled: !peutEcrire, "data-focus-id": "demande-notes",
    placeholder: peutEcrire ? "Ce que vous savez déjà, ce qu’il faut vérifier, ce qui a été dit au téléphone…" : "",
  });
  zone.value = d.notes || "";
  const enregistrer = btn("Enregistrer la note", { ton: "primaire", petit: true, type: "submit", desactive: true });
  const form = h("form.demande__notes", { novalidate: true }, h("label.sr-only", { for: idChamp }, "Notes internes sur cette demande"), zone, peutEcrire ? h("div.formulaire__actions", enregistrer) : null);
  const referenceNotes = () => (fiche("demandes", d.id) || d).notes || "";
  const sale = () => zone.value !== referenceNotes();
  zone.addEventListener("input", () => (enregistrer.disabled = !sale()));
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (!sale()) return;
    enregistrer.disabled = true;
    const courante = fiche("demandes", d.id) || d;
    const texte = zone.value.trim();
    const r = await tenter(() => modifierFiche("demandes", courante, { notes: texte || null }), { succes: "Note enregistrée.", entite: "demandes" });
    if (!r) enregistrer.disabled = !sale();
  });
  return { noeud: panneau({ titre: "Notes internes", sous: "Visibles seulement dans le CRM." }, form), sale };
}

function panneauSuite(d) {
  if (d.statut !== "converti") return null;
  const paires = [
    ["Contact", d.contact_id ? lienVers("contacts", d.contact_id) : null],
    ["Entreprise", d.entreprise_id ? lienVers("entreprises", d.entreprise_id) : null],
    ["Affaire", d.opportunite_id ? lienVers("opportunites", d.opportunite_id) : null],
    ["Traitée", d.traitee_le ? `${dateHeure(Date.parse(d.traitee_le))}` : null],
  ];
  return panneau({ titre: "Suite donnée", sous: "Les fiches créées à partir de cette demande." }, listeDef(paires));
}

function detailDemande(d) {
  const zoneReponse = h("div.demande__zone");
  const zoneEntete = h("div.demande__zone");
  const rafraichirTemps = () => {
    remplir(zoneEntete, enteteDetail(d));
    remplir(zoneReponse, blocReponse(d));
  };
  rafraichirTemps();
  const notes = panneauNotes(d);
  const coordonnees = panneau(
    { titre: "Coordonnées" },
    listeDef([
      ["Courriel", lienCourriel(d.courriel)],
      ["Téléphone", d.telephone ? lienTelephone(d.telephone) : null],
      ["Ne pas appeler", texteNePasAppeler(d)],
      ["Organisation", d.organisation || null],
      ["Formulaire", d.source_page ? `Page ${d.source_page}` : null],
      ["Consentement", d.consentement ? "Accepté à l’envoi (politique de confidentialité)" : null],
    ])
  );
  // Les courriels déjà échangés avec cette personne (compte Gmail connecté) : rien pour un pourriel.
  const echanges = creerBlocEchanges("demandes", {
    contexte: (f) => ({ lier: { lieType: "demandes", lieId: f.id }, variables: variablesDemande(f) }),
    masquer: (f) => f.statut === "pourriel",
  })(d);
  echanges.noeud.hidden = echanges.vide();
  const noeud = h(
    "article.demande",
    { "aria-label": `Demande de ${d.nom}` },
    h(
      "div.demande__feuille",
      zoneEntete,
      h("div.demande__actions", boutonsAction(d)),
      zoneReponse,
      h("div.demande__projet", h("h3.sr-only", "Message reçu"), h("div.lettre", paragraphes(d.projet)))
    ),
    coordonnees,
    echanges.noeud,
    panneauSuite(d),
    notes.noeud
  );
  return { noeud, sale: notes.sale, rafraichirTemps };
}

// ----- Écran ----------------------------------------------------------------------------------------------------------------------------
export default async function demandes(ctx) {
  const memo = ctx.memoire;
  const st = memo.get("etat") || { onglet: "a-traiter", q: "", defilement: 0 };
  memo.set("etat", st);
  const idSel = ctx.params.id || null;
  const peutEcrire = etat.droits.ecrire;

  const selectionInitiale = idSel ? fiche("demandes", idSel) : null;
  if (selectionInitiale && !selectionInitiale.supprime) st.onglet = ongletDe(selectionInitiale);

  // Grand écran sans demande choisie : on ouvre la première, pour lire sans cliquer.
  if (!idSel && matchMedia("(min-width: 64rem)").matches) {
    const premiere = demandesDe(st.onglet, "")[0];
    if (premiere) naviguer(`/demandes/${encodeURIComponent(premiere.id)}`, { remplacer: true });
  }

  // --- liste (à gauche)
  const barre = barreFiltres({
    placeholder: "Rechercher une demande…", q: st.q, aria: "Rechercher parmi les demandes", focusId: "demandes-q",
    surRecherche: (q) => {
      st.q = q;
      dessinerListe();
    },
    surReinitialiser: () => {
      st.q = "";
      dessinerListe();
    },
  });
  const zoneOnglets = h("div.demandes__onglets");
  const zoneItems = h("div.demandes__items", { tabindex: "-1" });
  zoneItems.addEventListener("scroll", () => (st.defilement = zoneItems.scrollTop), { passive: true });
  const liste = h("section.demandes__liste", { "aria-label": "Liste des demandes" }, zoneOnglets, h("div.demandes__outils", barre.noeud), zoneItems);

  function dessinerOnglets() {
    const toutes = actives("demandes");
    remplir(
      zoneOnglets,
      onglets({
        aria: "Classement des demandes",
        items: ONGLETS.map((o) => ({ id: o.id, libelle: o.libelle, compteur: toutes.filter((d) => o.statuts.includes(d.statut)).length })),
        actif: st.onglet,
        surChoix: (id) => {
          if (id === st.onglet) return;
          st.onglet = id;
          st.defilement = 0;
          dessinerListe();
        },
      })
    );
  }

  function dessinerListe() {
    dessinerOnglets();
    const o = ONGLETS.find((x) => x.id === st.onglet);
    const lignes = demandesDe(st.onglet, st.q);
    const total = actives("demandes").length;
    barre.definirCompte(st.q.trim() ? `${pluriel(lignes.length, "résultat")}` : o.id === "a-traiter" && lignes.length > 1 ? "Les plus anciennes d’abord : leur délai de réponse approche." : "");
    if (!lignes.length) {
      remplir(
        zoneItems,
        st.q.trim()
          ? etatVide({ icone: "recherche", titre: "Aucun résultat", texte: "Aucune demande de cet onglet ne correspond à votre recherche." })
          : total === 0
            ? etatVide({
                icone: "demandes", titre: "Aucune demande pour l’instant",
                texte: "Quand quelqu’un remplira le formulaire de contact de votre site, sa demande apparaîtra ici et vous en serez averti dans le CRM.",
              })
            : etatVide({ ...o.vide })
      );
      return;
    }
    remplir(zoneItems, h("ul.demandes__ul", lignes.map((d) => ligneDemande(d, d.id === idSel))));
  }

  // --- détail (à droite)
  const zoneDetail = h("div.demandes__detail", { "aria-live": "off" });
  let detail = null;
  let cleDetail = "";
  const cleDe = (d) =>
    d
      ? JSON.stringify([d.id, d.v, d.supprime || "", d.contact_id || "", d.entreprise_id || "", d.opportunite_id || "", d.contact_id && !!fiche("contacts", d.contact_id), etat.droits.ecrire, peutEnvoyerGmail(), peutVoirEchanges()])
      : "absent";

  function dessinerDetail({ force = false } = {}) {
    const d = idSel ? fiche("demandes", idSel) : null;
    const cle = cleDe(d);
    if (!force && cle === cleDetail) return;
    if (!force && detail?.sale()) return; // une note est en cours de saisie : on n'écrase rien
    cleDetail = cle;
    if (!idSel) {
      detail = null;
      remplir(zoneDetail, h("div.demandes__choix", etatVide({ icone: "demandes", titre: "Choisissez une demande", texte: "Sélectionnez une demande dans la liste pour la lire, y répondre ou la convertir en contact." })));
      return;
    }
    if (!d || d.supprime) {
      detail = null;
      remplir(
        zoneDetail,
        etatVide({ icone: "recherche", titre: "Cette demande n’existe plus", texte: "Elle a été supprimée ou son adresse est périmée.", action: btn("Voir les demandes", { ton: "primaire", href: "#/demandes" }) })
      );
      return;
    }
    detail = detailDemande(d);
    remplir(zoneDetail, h("a.retour.demandes__retour", { href: "#/demandes" }, icone("retour", "ic--p"), "Toutes les demandes"), detail.noeud);
  }

  const phraseSous = () => {
    const nouvelles = actives("demandes").filter((d) => d.statut === "nouveau").length;
    return nouvelles
      ? `${pluriel(nouvelles, "nouvelle demande attend", "nouvelles demandes attendent")} votre réponse.`
      : "Les messages envoyés par le formulaire de contact de votre site.";
  };

  const noeud = h("div.demandes-page", { "data-vue": idSel ? "detail" : "liste" }, enTete({ titre: "Demandes du site", sous: phraseSous() }), h("div.demandes", liste, zoneDetail));
  const noeudSous = noeud.querySelector(".page-tete__sous");
  dessinerListe();
  dessinerDetail({ force: true });
  // La liste garde sa position quand on passe d'une demande à l'autre.
  requestAnimationFrame(() => {
    zoneItems.scrollTop = st.defilement || 0;
    const courant = zoneItems.querySelector('[aria-current="true"]');
    if (courant && !st.defilement) courant.scrollIntoView({ block: "nearest" });
  });

  // Les durées (« due dans 3 h ») avancent même si rien ne change dans les données.
  const minuteur = setInterval(() => {
    dessinerListe();
    detail?.rafraichirTemps();
  }, 60_000);

  return {
    titre: idSel && selectionInitiale ? `Demande de ${selectionInitiale.nom}` : "Demandes du site",
    noeud,
    miseAJour() {
      dessinerListe();
      dessinerDetail();
      if (noeudSous) noeudSous.textContent = phraseSous();
      return true;
    },
    detruire() {
      clearInterval(minuteur);
    },
  };
}
