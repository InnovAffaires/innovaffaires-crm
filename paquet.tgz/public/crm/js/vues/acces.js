// =============================================================================
// Écrans d'accès : activation (première utilisation), connexion, double
// vérification, codes de récupération, changement de mot de passe obligatoire.
// =============================================================================
import { h, remplir, copierTexte, enregistrerFichier } from "../noyau/dom.js";
import { icone } from "../noyau/icones.js";
import { publicPost, envoyer, ErreurApi } from "../noyau/api.js";
import { btn, champMotDePasse, champTexte, avis, logo } from "../ui/composants.js";
import { qrSvg } from "../ui/qr.js";

const racine = () => document.getElementById("racine");

function feuille({ titre, intro = null, contenu, large = false, liens = null, titreDocument = null }) {
  document.title = `${titreDocument || titre} — CRM InnovAffaires`;
  remplir(
    racine(),
    h(
      "main.accueil-acces#contenu",
      h(
        "div.feuille-acces",
        { class: { "feuille-acces--large": large } },
        h("div.feuille-acces__marque", logo(), h("span", "InnovAffaires")),
        h("h1", { tabindex: "-1", id: "titre-acces" }, titre),
        intro ? h("p.intro", intro) : null,
        contenu,
        liens ? h("div.liens", liens) : null
      )
    )
  );
  document.getElementById("titre-acces")?.focus({ preventScroll: true });
}

function zoneErreur() {
  const z = h("div.formulaire__alerte", { role: "alert", hidden: true });
  return {
    noeud: z,
    afficher(msg) {
      z.hidden = !msg;
      z.textContent = msg || "";
    },
  };
}

/** Exécute une action de formulaire en gérant le bouton occupé et les erreurs. */
async function soumettre(bouton, zone, champs, action) {
  zone.afficher("");
  for (const c of Object.values(champs)) c.erreur?.(null);
  const texte = bouton.textContent;
  bouton.disabled = true;
  bouton.setAttribute("aria-busy", "true");
  try {
    return await action();
  } catch (e) {
    if (!(e instanceof ErreurApi)) throw e;
    let affiche = false;
    for (const [k, m] of Object.entries(e.champs || {})) {
      const c = champs[k];
      if (c) {
        c.erreur(m);
        if (!affiche) {
          c.focus();
          affiche = true;
        }
      }
    }
    zone.afficher(e.message);
    return null;
  } finally {
    bouton.disabled = false;
    bouton.removeAttribute("aria-busy");
    bouton.textContent = texte;
  }
}

// ----- Connexion ------------------------------------------------------------------------------------------
export function montrerConnexion({ surSucces, message = null, courriel = "" }) {
  const zone = zoneErreur();
  const cCourriel = champTexte({ libelle: "Courriel", type: "email", autocomplete: "username", inputmode: "email", valeur: courriel, maxlength: 254 });
  const cMdp = champMotDePasse({ libelle: "Mot de passe", autocomplete: "current-password" });
  const cCode = champTexte({ libelle: "Code de vérification", autocomplete: "one-time-code", inputmode: "numeric", maxlength: 24, aide: "Les 6 chiffres affichés par votre application d’authentification, ou l’un de vos codes de récupération." });
  const blocCode = h("div", { hidden: true }, cCode.noeud);
  const bouton = h("button.btn.btn--primaire.btn--large", { type: "submit" }, "Se connecter");
  const form = h(
    "form",
    { novalidate: true, onsubmit: async (e) => {
      e.preventDefault();
      const r = await soumettre(bouton, zone, { courriel: cCourriel, mot_de_passe: cMdp, mdp: cMdp }, async () => {
        try {
          return await publicPost("/connexion", { courriel: cCourriel.lire().trim(), mot_de_passe: cMdp.lire(), code_2fa: blocCode.hidden ? undefined : cCode.lire().trim() });
        } catch (err) {
          if (err instanceof ErreurApi && err.code === "2fa_requis") {
            blocCode.hidden = false;
            cCode.focus();
            zone.afficher(err.message);
            return null;
          }
          if (err instanceof ErreurApi && err.code === "2fa_invalide") {
            cCode.erreur(err.message);
            cCode.focus();
            zone.afficher("");
            return null;
          }
          throw err;
        }
      });
      if (r) surSucces(r);
    } },
    message ? avis({ ton: "info", texte: message }) : null,
    zone.noeud,
    cCourriel.noeud,
    cMdp.noeud,
    blocCode,
    h("div.actions", bouton)
  );
  feuille({
    titre: "Connexion", intro: "Accédez à votre CRM InnovAffaires.", contenu: form,
    liens: [
      h("a", { href: "#", onclick: (e) => { e.preventDefault(); montrerRecuperation({ retour: () => montrerConnexion({ surSucces }) }); } }, "J’ai perdu l’accès à mon compte"),
    ],
  });
  (courriel ? cMdp : cCourriel).focus();
}

// ----- Activation --------------------------------------------------------------------------------------------
export function montrerActivation({ surSucces }) {
  const zone = zoneErreur();
  const cCode = champTexte({ libelle: "Code d’activation", autocomplete: "off", maxlength: 40, aide: "Le code à usage unique qui vous a été remis lors de l’installation (il ressemble à xxxx-xxxx-xxxx-xxxx-xxxx)." });
  const cNom = champTexte({ libelle: "Votre nom", autocomplete: "name", maxlength: 80, valeur: "" });
  const cCourriel = champTexte({ libelle: "Votre courriel", type: "email", autocomplete: "username", inputmode: "email", maxlength: 254 });
  const cMdp = champMotDePasse({ libelle: "Choisissez votre mot de passe", autocomplete: "new-password", aide: "12 caractères au minimum. Une phrase de quelques mots sans lien entre eux est idéale et facile à retenir. Ne la partagez avec personne." });
  const cMdp2 = champMotDePasse({ libelle: "Confirmez le mot de passe", autocomplete: "new-password" });
  const bouton = h("button.btn.btn--primaire.btn--large", { type: "submit" }, "Activer mon CRM");
  const form = h(
    "form",
    { novalidate: true, onsubmit: async (e) => {
      e.preventDefault();
      cMdp2.erreur(null);
      if (cMdp.lire() !== cMdp2.lire()) {
        cMdp2.erreur("Les deux mots de passe ne sont pas identiques.");
        cMdp2.focus();
        return;
      }
      const r = await soumettre(bouton, zone, { code: cCode, nom: cNom, courriel: cCourriel, mdp: cMdp, mot_de_passe: cMdp }, () =>
        publicPost("/activation", { code: cCode.lire().trim(), nom: cNom.lire().trim(), courriel: cCourriel.lire().trim(), mot_de_passe: cMdp.lire() })
      );
      if (r) montrerCodesRecuperation({ codes: r.codes_recuperation, titre: "Votre CRM est activé", surTermine: () => surSucces(r) });
    } },
    zone.noeud,
    cCode.noeud,
    cNom.noeud,
    cCourriel.noeud,
    cMdp.noeud,
    cMdp2.noeud,
    h("div.actions", bouton)
  );
  feuille({ titre: "Bienvenue dans votre CRM", intro: "Quelques informations pour créer votre compte d’administratrice. Vos données restent sur votre propre site.", contenu: form, large: true, titreDocument: "Activation" });
  cCode.focus();
}

// ----- Codes de récupération ---------------------------------------------------------------------------------
export function montrerCodesRecuperation({ codes, titre = "Vos codes de récupération", surTermine, integre = false }) {
  const texte = ["InnovAffaires — codes de récupération", "Chaque code ne sert qu’une seule fois. Gardez-les dans un endroit sûr (coffre-fort, gestionnaire de mots de passe, papier sous clé).", "", ...codes].join("\n");
  const confirmation = h("input", { id: "conf-codes", type: "checkbox" });
  const suite = h("button.btn.btn--primaire.btn--large", { type: "button", disabled: true, onclick: () => surTermine?.() }, "Continuer");
  confirmation.addEventListener("change", () => (suite.disabled = !confirmation.checked));
  const contenu = h(
    "div",
    avis({ ton: "attention", titre: "Conservez ces codes maintenant", texte: "Si vous perdez votre mot de passe ou votre téléphone, ces codes sont le seul moyen de retrouver l’accès sans réinitialisation d’urgence. Ils ne seront plus affichés." }),
    h("ul.codes", codes.map((c) => h("li", c))),
    h("div.actions-ligne",
      btn("Copier", { icone: "copier", onclick: async (e) => { const b = e.currentTarget; const ok = await copierTexte(texte); b.querySelector("span").textContent = ok ? "Copié" : "Copie impossible"; } }),
      btn("Télécharger", { icone: "telecharger", onclick: () => enregistrerFichier("innovaffaires-codes-recuperation.txt", texte, "text/plain;charset=utf-8") }),
      btn("Imprimer", { icone: "imprimer", onclick: () => print() })
    ),
    h("label.case.case--bloc", { for: "conf-codes" }, confirmation, h("span.case__boite", { "aria-hidden": "true" }, icone("coche", "ic--p")), h("span", "J’ai conservé mes codes de récupération dans un endroit sûr.")),
    h("div.actions", suite)
  );
  if (integre) return contenu;
  feuille({ titre, intro: null, contenu, large: true, titreDocument: "Codes de récupération" });
  return null;
}

// ----- Récupération d'accès -------------------------------------------------------------------------------------
export function montrerRecuperation({ retour }) {
  const zone = zoneErreur();
  const cCourriel = champTexte({ libelle: "Courriel du compte", type: "email", autocomplete: "username", inputmode: "email", maxlength: 254 });
  const cCode = champTexte({ libelle: "Un code de récupération", autocomplete: "off", maxlength: 40, aide: "Un des codes remis à l’activation de votre compte (xxxx-xxxx-xxxx). Chaque code ne sert qu’une fois." });
  const cMdp = champMotDePasse({ libelle: "Nouveau mot de passe", autocomplete: "new-password", aide: "12 caractères au minimum." });
  const bouton = h("button.btn.btn--primaire.btn--large", { type: "submit" }, "Changer mon mot de passe");
  const form = h(
    "form",
    { novalidate: true, onsubmit: async (e) => {
      e.preventDefault();
      const r = await soumettre(bouton, zone, { courriel: cCourriel, code: cCode, nouveau: cMdp }, () =>
        publicPost("/recuperation", { courriel: cCourriel.lire().trim(), code: cCode.lire().trim(), nouveau_mot_de_passe: cMdp.lire() })
      );
      if (r) montrerConnexion({ surSucces: window.__apresConnexion, message: `Votre mot de passe a été changé. Il vous reste ${r.codes_restants} code(s) de récupération.`, courriel: cCourriel.lire().trim() });
    } },
    zone.noeud, cCourriel.noeud, cCode.noeud, cMdp.noeud, h("div.actions", bouton)
  );
  feuille({
    titre: "Retrouver l’accès", intro: "Utilisez l’un de vos codes de récupération pour choisir un nouveau mot de passe.", contenu: form,
    liens: [
      h("a", { href: "#", onclick: (e) => { e.preventDefault(); retour(); } }, "Retour à la connexion"),
      h("a", { href: "#", onclick: (e) => { e.preventDefault(); montrerReinitialisation({ retour }); } }, "Je n’ai plus mes codes"),
    ],
  });
  cCourriel.focus();
}

// ----- Réinitialisation d'urgence (phrase secrète du site) -----------------------------------------------------------
export function montrerReinitialisation({ retour }) {
  const zone = zoneErreur();
  const cPhrase = champMotDePasse({ libelle: "Phrase secrète d’urgence", autocomplete: "off", aide: "La valeur de la variable CRM_REINITIALISATION configurée dans Netlify (voir le guide, section « Accès perdu »)." });
  const cCourriel = champTexte({ libelle: "Courriel du compte à rétablir", type: "email", autocomplete: "off", inputmode: "email", maxlength: 254 });
  const cMdp = champMotDePasse({ libelle: "Nouveau mot de passe", autocomplete: "new-password", aide: "12 caractères au minimum." });
  const bouton = h("button.btn.btn--primaire.btn--large", { type: "submit" }, "Rétablir mon accès");
  const form = h(
    "form",
    { novalidate: true, onsubmit: async (e) => {
      e.preventDefault();
      const r = await soumettre(bouton, zone, { phrase_secrete: cPhrase, courriel: cCourriel, nouveau: cMdp }, () =>
        publicPost("/reinitialisation", { phrase_secrete: cPhrase.lire(), courriel: cCourriel.lire().trim(), nouveau_mot_de_passe: cMdp.lire() })
      );
      if (r) {
        const suite = () => montrerConnexion({ surSucces: window.__apresConnexion, message: "Votre accès est rétabli. Connectez-vous avec le nouveau mot de passe.", courriel: cCourriel.lire().trim() });
        if (r.codes_recuperation?.length) montrerCodesRecuperation({ codes: r.codes_recuperation, titre: "Accès rétabli", surTermine: suite });
        else suite();
      }
    } },
    avis({ ton: "attention", texte: "Cette procédure remplace le mot de passe, désactive la double vérification du compte et ferme toutes ses sessions." }),
    zone.noeud, cPhrase.noeud, cCourriel.noeud, cMdp.noeud, h("div.actions", bouton)
  );
  feuille({
    titre: "Réinitialisation d’urgence", contenu: form,
    liens: [h("a", { href: "#", onclick: (e) => { e.preventDefault(); retour(); } }, "Retour à la connexion")],
  });
  cPhrase.focus();
}

// ----- Changement de mot de passe obligatoire --------------------------------------------------------------------------
export function montrerChangementMotDePasse({ surSucces, utilisateur }) {
  const zone = zoneErreur();
  const cActuel = champMotDePasse({ libelle: "Mot de passe temporaire", autocomplete: "current-password", aide: "Celui que votre administrateur vous a remis." });
  const cNouveau = champMotDePasse({ libelle: "Nouveau mot de passe", autocomplete: "new-password", aide: "12 caractères au minimum. Une phrase de quelques mots est idéale." });
  const cConf = champMotDePasse({ libelle: "Confirmez le nouveau mot de passe", autocomplete: "new-password" });
  const bouton = h("button.btn.btn--primaire.btn--large", { type: "submit" }, "Enregistrer et continuer");
  const form = h(
    "form",
    { novalidate: true, onsubmit: async (e) => {
      e.preventDefault();
      cConf.erreur(null);
      if (cNouveau.lire() !== cConf.lire()) {
        cConf.erreur("Les deux mots de passe ne sont pas identiques.");
        cConf.focus();
        return;
      }
      const r = await soumettre(bouton, zone, { actuel: cActuel, nouveau: cNouveau }, () => envoyer("/mot-de-passe", { actuel: cActuel.lire(), nouveau: cNouveau.lire() }));
      if (r) surSucces();
    } },
    zone.noeud, cActuel.noeud, cNouveau.noeud, cConf.noeud, h("div.actions", bouton)
  );
  feuille({ titre: "Choisissez votre mot de passe", intro: `Bonjour ${utilisateur?.nom || ""}. Pour protéger vos données, remplacez le mot de passe temporaire par le vôtre.`, contenu: form, titreDocument: "Nouveau mot de passe" });
  cActuel.focus();
}

// ----- Double vérification (activation) ----------------------------------------------------------------------------------
/**
 * Bloc d'activation de la double vérification (utilisé dans Paramètres et à l'écran obligatoire).
 * surActive(codesRecuperation|null) est appelée quand le code saisi est accepté.
 */
export function blocActivation2fa({ surActive, utilisateur }) {
  const zone = zoneErreur();
  const conteneur = h("div.bloc-2fa");
  const cCode = champTexte({ libelle: "Code à 6 chiffres", autocomplete: "one-time-code", inputmode: "numeric", maxlength: 8, aide: "Entrez le code que l’application affiche maintenant." });
  const bouton = h("button.btn.btn--primaire", { type: "submit" }, "Vérifier et activer");

  async function preparer() {
    conteneur.replaceChildren(h("p", "Préparation…"));
    try {
      const prep = await envoyer("/2fa/preparer", {});
      const lien = prep.lien;
      conteneur.replaceChildren(
        h("ol.etapes",
          h("li", h("strong", "Installez une application d’authentification"), h("p", "Par exemple Google Authenticator, Microsoft Authenticator, Authy ou 1Password.")),
          h("li", h("strong", "Ajoutez ce compte"), h("p", "Balayez le code QR avec l’application, ou entrez la clé manuellement."),
            h("div.qr-bloc", qrSvg(lien, { pixels: 184, titre: "Code QR pour l’application d’authentification" }),
              h("div.qr-cle", h("p.qr-cle__etiquette", "Clé à saisir manuellement"), h("code.qr-cle__valeur", prep.secret.replace(/(.{4})/g, "$1 ").trim()),
                h("div.actions-ligne", btn("Copier la clé", { petit: true, icone: "copier", onclick: async (e) => { const b = e.currentTarget; const ok = await copierTexte(prep.secret); b.querySelector("span").textContent = ok ? "Copiée" : "Copie impossible"; } }),
                  h("a.btn.btn--secondaire.btn--petit", { href: lien }, icone("externe"), h("span", "Ouvrir dans l’application")))))),
          h("li", h("strong", "Confirmez avec un code"), h("form", { novalidate: true, onsubmit: async (e) => {
            e.preventDefault();
            const r = await soumettre(bouton, zone, { code: cCode }, () => envoyer("/2fa/activer", { code: cCode.lire().trim() }));
            if (r) surActive(r.codes || null);
          } }, zone.noeud, cCode.noeud, h("div.actions", bouton))))
      );
      cCode.focus();
    } catch (e) {
      if (!(e instanceof ErreurApi)) throw e;
      conteneur.replaceChildren(avis({ ton: "erreur", texte: e.message }), btn("Réessayer", { onclick: preparer }));
    }
  }
  preparer();
  void utilisateur;
  return conteneur;
}

export function montrerConfiguration2fa({ surSucces, utilisateur }) {
  const contenu = h("div");
  const bloc = blocActivation2fa({
    utilisateur,
    surActive: (codes) => {
      if (codes?.length) remplir(contenu, montrerCodesRecuperation({ codes, surTermine: surSucces, integre: true }));
      else surSucces();
    },
  });
  contenu.append(avis({ ton: "attention", titre: "Votre organisation exige la double vérification", texte: "Activez-la pour accéder à vos données. Cela ne prend que deux minutes." }), bloc);
  feuille({ titre: "Activer la double vérification", contenu, large: true, titreDocument: "Double vérification" });
}
