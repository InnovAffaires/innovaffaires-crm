// =============================================================================
// Fiche d'un contact : coordonnées, suivi, tâches, affaires, dossiers, factures
// et historique des échanges, au même endroit.
// =============================================================================
import { h } from "../noyau/dom.js";
import { etat, actives, liees, fiche, nomUtilisateur, sourceDe, etapeDe, maintenant } from "../noyau/etat.js";
import { lienFiche, naviguer } from "../noyau/routeur.js";
import { modifierFiche, supprimerAvecAnnulation, tenter } from "../noyau/ecriture.js";
import { envoyer, telechargerFichier } from "../noyau/api.js";
import { synchroniser } from "../noyau/synchro.js";
import { enregistrerFichier } from "../noyau/dom.js";
import { aujourdhui, ajouterMois } from "../commun/dates.js";
import { CONSENTEMENTS, LANGUES } from "../commun/schema.js";
import { dateCourte, nomComplet } from "../commun/format.js";
import { btn, avatar, enTete, menuActions, panneau, listeDef, avis } from "../ui/composants.js";
import { confirmer } from "../ui/dialogue.js";
import { toast } from "../ui/toast.js";
import { journal } from "../ui/journal.js";
import { ecrireDepuis } from "../ui/courriel.js";
import { creerBlocEchanges } from "../ui/echanges.js";
import { peutEnvoyerGmail } from "../noyau/google.js";
import { lienCourriel, lienTelephone, puces, libelleOption } from "./aides.js";
import { nouvelleFiche, modifierLaFiche } from "./formulaires.js";
import { boutonAppeler, entreeFileAppels, marqueNePasAppeler, texteNePasAppeler } from "./appels/raccords.js";
import { creerVueFiche, marquesFiche, panneauLie, panneauTaches, panneauNotes, piedFiche, ligneAffaire, ligneDossier, ligneFacture } from "./fiche.js";

export const depend = ["contacts", "entreprises", "opportunites", "dossiers", "factures", "taches", "evenements", "equipe", "config", "google", "gmail"];

const enc = encodeURIComponent;
const nomDe = (f) => nomComplet(f) || f.courriel || "Contact sans nom";

// ----- Actions -----------------------------------------------------------------------------------------------------------------------------------------
async function archiver(f, archive) {
  await tenter(() => modifierFiche("contacts", fiche("contacts", f.id) || f, { archive }), { succes: archive ? "Contact archivé : il n’apparaît plus dans la liste." : "Contact rétabli dans la liste.", entite: "contacts" });
}

async function exporterDonnees(f) {
  const r = await tenter(() => telechargerFichier(`/contacts/${enc(f.id)}/export`));
  if (!r) return;
  enregistrerFichier(r.nom, r.blob);
  toast("Fichier d’accès téléchargé : tout ce que le CRM détient sur cette personne.", { ton: "info" });
}

async function anonymiser(f) {
  const ok = await confirmer({
    titre: "Anonymiser ce contact ?", libelleConfirmer: "Anonymiser définitivement", danger: true,
    message: `Les coordonnées, les notes, les demandes du site et l’historique de ${nomDe(f)} seront effacés, et son nom retiré des titres des tâches, rendez-vous, affaires et dossiers liés. Les affaires, dossiers et factures sont conservés pour vos obligations comptables. Cette opération est irréversible.`,
    // Effacer le numéro d'une personne inscrite à la liste « ne pas appeler » ferait perdre de quoi respecter sa demande.
    detail: f.ne_pas_appeler
      ? avis({ ton: "attention", titre: "Cette personne est sur la liste « ne pas appeler »", texte: "L’anonymisation efface aussi son numéro de téléphone : le CRM ne pourra plus empêcher qu’on la rappelle. Si vous devez continuer de respecter sa demande, conservez son numéro dans un registre à part avant de poursuivre." })
      : null,
  });
  if (!ok) return;
  const r = await tenter(() => envoyer(`/contacts/${enc(f.id)}/anonymiser`, { confirmer: true }), { entite: "contacts" });
  if (!r) return;
  await synchroniser({ complet: true }).catch(() => {});
  toast("Contact anonymisé.", { ton: "info" });
}

function menuAjouter(f) {
  const valeursLiees = { contact_id: f.id, ...(f.entreprise_id ? { entreprise_id: f.entreprise_id } : {}) };
  return menuActions({
    libelle: "Ajouter", icone: "plus", ton: "primaire", aria: "Ajouter une tâche, une affaire, un dossier ou une facture pour ce contact",
    elements: [
      { libelle: "Tâche", icone: "taches", onclick: () => document.querySelector('[data-focus-id="contact-ajout"]')?.focus() },
      { libelle: "Rendez-vous", icone: "calendrier", onclick: () => nouvelleFiche("evenements", { lie_type: "contacts", lie_id: f.id }) },
      entreeFileAppels("contacts", f),
      "separateur",
      { libelle: "Affaire", icone: "affaires", onclick: () => nouvelleFiche("opportunites", valeursLiees) },
      { libelle: "Dossier de financement", icone: "dossiers", onclick: () => nouvelleFiche("dossiers", valeursLiees) },
      { libelle: "Facture", icone: "factures", onclick: () => nouvelleFiche("factures", { type: "facture", ...valeursLiees }) },
      { libelle: "Devis", icone: "document", onclick: () => nouvelleFiche("factures", { type: "devis", ...valeursLiees }) },
    ],
  });
}

function menuPlus(f) {
  const admin = etat.droits.administrer;
  const gestion = [
    !f.anonymise ? { libelle: f.archive ? "Rétablir dans la liste" : "Archiver", icone: "archiver", onclick: () => archiver(f, !f.archive) } : null,
    admin && !f.anonymise ? { libelle: "Télécharger ses renseignements (Loi 25)", icone: "telecharger", onclick: () => exporterDonnees(f) } : null,
    admin && !f.anonymise ? { libelle: "Anonymiser (Loi 25)", icone: "cacher", onclick: () => anonymiser(f) } : null,
  ].filter(Boolean);
  // Un contact anonymisé reste en place : les affaires et factures qui le citent en dépendent, et il ne peut plus être rétabli.
  const corbeille = f.anonymise ? [] : [{ libelle: "Mettre à la corbeille", icone: "corbeille", danger: true, onclick: () => supprimerAvecAnnulation("contacts", f.id, { apres: () => naviguer("/contacts") }) }];
  if (!gestion.length && !corbeille.length) return null;
  return menuActions({ aria: "Plus d’actions sur ce contact", elements: [...gestion, ...(gestion.length && corbeille.length ? ["separateur"] : []), ...corbeille] });
}

// ----- En-tête -----------------------------------------------------------------------------------------------------------------------------------------
function enteteContact(f) {
  const peutEcrire = etat.droits.ecrire && !f.anonymise;
  const ent = f.entreprise_id ? fiche("entreprises", f.entreprise_id) : null;
  const sous = [];
  if (f.titre) sous.push(f.titre);
  if (f.titre && ent && !ent.supprime) sous.push(" chez ");
  if (ent && !ent.supprime) sous.push(h("a.lien-fiche", { href: lienFiche("entreprises", ent.id) }, ent.nom));
  const tel = f.telephone || f.mobile;
  const actions = [];
  if (!f.anonymise && f.courriel) {
    // Compte Gmail connecté : la fenêtre d'envoi (gabarits, historique). Sinon, le lien ouvre directement la messagerie.
    actions.push(
      peutEnvoyerGmail()
        ? btn("Écrire", { icone: "courriel", onclick: () => ecrireDepuis("contacts", fiche("contacts", f.id) || f) })
        : btn("Écrire", { icone: "courriel", href: `mailto:${enc(f.courriel).replace(/%40/g, "@")}` })
    );
  }
  const appeler = !f.anonymise && tel ? boutonAppeler("contacts", f, tel) : null;
  if (appeler) actions.push(appeler);
  if (peutEcrire) {
    actions.push(menuAjouter(f));
    actions.push(btn("Modifier", { icone: "modifier", onclick: () => modifierLaFiche("contacts", fiche("contacts", f.id) || f) }));
  }
  const plus = etat.droits.ecrire ? menuPlus(f) : null;
  if (plus) actions.push(plus);
  return enTete({
    retour: { href: "#/contacts", libelle: "Contacts" },
    avatar: avatar(nomDe(f), { taille: "l" }),
    titre: nomDe(f),
    apres: marquesFiche(f, { archive: f.archive, anonymise: f.anonymise, etats: [f.anonymise ? null : marqueNePasAppeler(f)].filter(Boolean) }),
    sous: sous.length ? sous : null,
    actions,
  });
}

// ----- Blocs --------------------------------------------------------------------------------------------------------------------------------------------
function texteConsentement(f) {
  const c = f.consentement || "aucun";
  const libelle = libelleOption(CONSENTEMENTS, c);
  if (!f.consentement_date) return libelle;
  if (c === "expres") return [libelle, h("br"), h("small.muet", `Donné le ${dateCourte(f.consentement_date)}`)];
  if (c !== "demande" && c !== "client") return libelle;
  const fin = ajouterMois(f.consentement_date, c === "demande" ? 6 : 24);
  const expire = fin < aujourdhui(maintenant());
  return [libelle, h("br"), h("small", { class: expire ? "echeance--erreur" : "muet" }, expire ? `Expiré le ${dateCourte(fin)}` : `Valide jusqu’au ${dateCourte(fin)}`)];
}

function tachesDuContact(f) {
  const affaires = new Set(liees("opportunites", "contact_id", f.id).map((o) => o.id));
  const dossiers = new Set(liees("dossiers", "contact_id", f.id).map((d) => d.id));
  return actives("taches").filter(
    (t) => (t.lie_type === "contacts" && t.lie_id === f.id) || (t.lie_type === "opportunites" && affaires.has(t.lie_id)) || (t.lie_type === "dossiers" && dossiers.has(t.lie_id))
  );
}

const parOuverture = (a, b) => {
  const oa = etapeDe(a.etape)?.type === "ouverte" ? 0 : 1;
  const ob = etapeDe(b.etape)?.type === "ouverte" ? 0 : 1;
  return oa - ob || String(b.maj || "").localeCompare(String(a.maj || ""));
};

/** L'historique garde sa zone de saisie : il n'est recréé que si l'entreprise du contact change. */
function blocHistorique(f0) {
  const conteneur = h("div");
  let entreprise = null;
  let j = null;
  function monter(f) {
    entreprise = f.entreprise_id || null;
    j = journal({ lieType: "contacts", lieId: f.id, lie2: entreprise ? { type: "entreprises", id: entreprise } : null, aide: "Notes, appels, courriels et rencontres avec cette personne, du plus récent au plus ancien." });
    conteneur.replaceChildren(j.noeud);
  }
  if (!f0.anonymise) monter(f0);
  return {
    noeud: conteneur,
    miseAJour(changes, f) {
      if (f.anonymise) {
        // L'anonymisation vient d'avoir lieu : l'historique est effacé, on ne montre plus rien.
        j = null;
        conteneur.replaceChildren();
      } else if (!j || (f.entreprise_id || null) !== entreprise) monter(f);
      else if (["opportunites", "dossiers", "factures"].some((c) => changes.has(c))) j.recharger();
    },
  };
}

export default creerVueFiche({
  entite: "contacts",
  liste: { href: "#/contacts", libelle: "Contacts" },
  entete: { depend: ["contacts", "entreprises", "google"], dessiner: enteteContact },
  blocs: [
    {
      id: "anonymise", colonne: "principal", ordre: 0, depend: ["contacts"],
      dessiner: (f) => (f.anonymise ? avis({ ton: "info", titre: "Contact anonymisé", texte: "Ses coordonnées, ses notes et son historique ont été effacés (Loi 25). Les affaires, dossiers et factures qui le concernent sont conservés pour vos obligations comptables." }) : null),
    },
    {
      id: "coordonnees", colonne: "lateral", ordre: 1, depend: ["contacts", "entreprises"],
      dessiner: (f) =>
        f.anonymise
          ? null
          : panneau(
              { titre: "Coordonnées" },
              listeDef([
                ["Courriel", f.courriel ? lienCourriel(f.courriel) : null],
                ["Téléphone", f.telephone ? lienTelephone(f.telephone) : null],
                ["Cellulaire", f.mobile ? lienTelephone(f.mobile) : null],
                ["Entreprise", f.entreprise_id && fiche("entreprises", f.entreprise_id) && !fiche("entreprises", f.entreprise_id).supprime ? h("a.lien-fiche", { href: lienFiche("entreprises", f.entreprise_id) }, fiche("entreprises", f.entreprise_id).nom) : null],
                ["Fonction", f.titre || null],
                ["Ville", f.ville || null],
                ["Langue", libelleOption(LANGUES, f.langue) || null],
              ])
            ),
    },
    {
      id: "taches", colonne: "principal", ordre: 2, depend: ["taches", "opportunites", "dossiers"],
      dessiner: (f) =>
        f.anonymise
          ? null
          : panneauTaches({
              taches: tachesDuContact(f), lieType: "contacts", lieId: f.id, placeholder: `Nouvelle tâche pour ${f.prenom || f.nom || "ce contact"}…`, focusId: "contact-ajout",
              estDirecte: (t) => t.lie_type === "contacts" && t.lie_id === f.id,
            }),
    },
    {
      id: "affaires", colonne: "principal", ordre: 3, depend: ["opportunites", "config"],
      dessiner: (f) => {
        const lignes = liees("opportunites", "contact_id", f.id).slice().sort(parOuverture);
        if (!lignes.length) return null;
        return panneauLie({ titre: "Affaires", lignes: lignes.map((o) => ligneAffaire(o)) });
      },
    },
    {
      id: "dossiers", colonne: "principal", ordre: 4, depend: ["dossiers", "config"],
      dessiner: (f) => {
        const lignes = liees("dossiers", "contact_id", f.id).slice().sort((a, b) => String(b.maj || "").localeCompare(String(a.maj || "")));
        if (!lignes.length) return null;
        return panneauLie({ titre: "Dossiers de financement", lignes: lignes.map((d) => ligneDossier(d)) });
      },
    },
    {
      id: "factures", colonne: "principal", ordre: 5, depend: ["factures"],
      dessiner: (f) => {
        const lignes = liees("factures", "contact_id", f.id).slice().sort((a, b) => String(b.date_emission || "9999").localeCompare(String(a.date_emission || "9999")));
        if (!lignes.length) return null;
        return panneauLie({ titre: "Factures et devis", lignes: lignes.map((x) => ligneFacture(x)) });
      },
    },
    { id: "echanges", colonne: "principal", ordre: 6, creer: creerBlocEchanges("contacts", { masquer: (f) => !!f.anonymise || !f.courriel }) },
    { id: "historique", colonne: "principal", ordre: 7, creer: blocHistorique },
    {
      id: "suivi", colonne: "lateral", ordre: 8, depend: ["contacts", "equipe", "config"],
      dessiner: (f) =>
        f.anonymise
          ? null
          : panneau(
              { titre: "Suivi" },
              listeDef([
                ["Responsable", nomUtilisateur(f.responsable_id) || null],
                ["Provenance", sourceDe(f.source) || null],
                ["Consentement", texteConsentement(f)],
                ["Ne pas appeler", texteNePasAppeler(f)],
                ["Étiquettes", f.etiquettes?.length ? puces(f.etiquettes) : null],
              ])
            ),
    },
    { id: "notes", colonne: "lateral", ordre: 9, depend: ["contacts"], dessiner: (f) => (f.anonymise ? null : panneauNotes("contacts", f)) },
    { id: "pied", colonne: "lateral", ordre: 10, depend: ["contacts", "equipe"], dessiner: (f) => piedFiche("contacts", f) },
  ],
});
