// =============================================================================
// Aide : un guide court pour utiliser le CRM au quotidien. Les explications citent
// les libellés exacts des écrans (boutons, menus, sections des paramètres).
//
// Chaque section a sa propre adresse (#/aide/alertes) : les paramètres y renvoient,
// par exemple, pour expliquer comment activer les alertes par courriel. Le sommaire
// reste visible à gauche sur grand écran ; il devient une rangée de liens sur
// téléphone. La page ne dépend d'aucune donnée : elle ne se redessine jamais seule.
// =============================================================================
import { h } from "../noyau/dom.js";
import { icone } from "../noyau/icones.js";
import { etat } from "../noyau/etat.js";
import { enTete, avis } from "../ui/composants.js";
import { sectionsPermises, trouverSection } from "./parametres.js";

export const depend = [];

const NBSP = " ";

// ----- Petits éléments de rédaction ------------------------------------------------------------------------------
/** Libellé exact d'un bouton ou d'un élément de menu. */
const q = (texte) => h("strong", `«${NBSP}${texte}${NBSP}»`);
const lien = (href, ...texte) => h("a", { href }, ...texte);
const externe = (href, texte) => h("a", { href, target: "_blank", rel: "noopener noreferrer" }, texte, " ", icone("externe", "ic--p"));
const p = (...enfants) => h("p", ...enfants);
const code = (texte) => h("code.aide__code", texte);
const gras = (texte) => h("strong", texte);
const liste = (...items) => h("ul.aide__liste", items.map((i) => h("li", i)));
const etapes = (...items) => h("ol.aide__etapes", items.map((i) => h("li", h("div.aide__etape", i))));
const combo = (...touches) => h("span.aide__combo", touches.flatMap((t, i) => (i ? [" + ", h("kbd", t)] : [h("kbd", t)])));

/** Lien vers un écran du menu (Demandes, Affaires…). */
const page = (chemin, texte) => lien(`#${chemin}`, texte);

/** Lien vers une section des paramètres, ou simple texte si la personne n'y a pas accès. */
const accessible = (id) => sectionsPermises().some((g) => g.items.some((s) => s.id === id));
function vers(id, texte = null) {
  const s = trouverSection(id);
  const libelle = texte ?? `Paramètres → ${s ? s.libelle : id}`;
  return accessible(id) ? lien(`#/parametres/${id}`, libelle) : h("span", libelle);
}

/** Question repliable (même présentation que les tâches par statut des paramètres). */
function question(titre, { ouverte = false } = {}, ...corps) {
  return h(
    "details.replie",
    { open: ouverte },
    h("summary.replie__titre", icone("droite", "ic--p replie__fleche"), h("span.replie__nom", titre)),
    h("div.replie__corps", corps)
  );
}

/** Paires « terme — explication », pour les raccourcis et les réglages Netlify. */
const paires = (lignes, { larges = false } = {}) =>
  h(
    "dl.aide__paires",
    { class: { "aide__paires--larges": larges } },
    lignes.map(([terme, explication]) => h("div.aide__paire", h("dt", terme), h("dd", explication)))
  );

// ----- Contenu des sections --------------------------------------------------------------------------------------
function demarrage() {
  const admin = etat.droits.administrer;
  return [
    h("h3", "Le parcours d’un client"),
    etapes(
      [gras("La demande arrive."), " Quand quelqu’un remplit le formulaire de votre site, sa demande apparaît dans ", page("/demandes", "Demandes"), " et le compteur du menu augmente. Chaque demande indique le temps qu’il reste pour répondre dans le délai que vous vous êtes donné (", vers("demandes"), ")."],
      [gras("Vous répondez."), " ", q("Répondre par courriel"), " ouvre un message dans votre logiciel de courriel : le CRM n’envoie rien lui-même. Une fois le message parti, cliquez sur ", q("J’ai répondu"), "."],
      [gras("Vous convertissez la demande."), " ", q("Convertir en contact"), " crée la fiche du contact, celle de son entreprise si vous en indiquez une, et ouvre une affaire. Une tâche de réponse n’est ajoutée que si vous n’avez pas déjà répondu."],
      [gras("L’affaire avance."), " Dans ", page("/affaires", "Affaires"), ", chaque carte glisse d’une étape à l’autre : Nouveau lead, Appel découverte, Proposition envoyée, Négociation, puis Mandat en cours ou Perdu. Les étapes se règlent dans ", vers("etapes"), "."],
      [gras("Le mandat devient un dossier de financement."), " Sur la fiche d’une affaire gagnée, ", q("Créer le dossier"), " ouvre le dossier. Il suit ses propres statuts, de Collecte des documents à Terminée (ou Refusée), et chaque changement de statut ajoute les tâches prévues (", vers("taches"), ")."],
      [gras("Vous facturez."), " Depuis l’affaire ou le dossier, le menu ", q("Ajouter"), " propose un devis ou une facture. Quand le client paie, ", q("Enregistrer un paiement"), "."]
    ),
    h("h3", "Vos premiers réglages"),
    p("Quelques minutes suffisent pour que le CRM porte vos couleurs et vos chiffres."),
    liste(
      [vers("entreprise"), " : vérifiez le nom, l’adresse et vos numéros de TPS et de TVQ. Ils s’impriment sur chaque facture."],
      [vers("facturation"), " : taxes, numérotation, conditions de paiement et tarifs habituels."],
      [vers("securite"), " : activez la double vérification et rangez vos codes de récupération hors du CRM."],
      [vers("equipe"), " : ajoutez les personnes qui doivent voir ou modifier le CRM, avec le rôle qui convient."],
      [vers("sauvegardes"), " : téléchargez une première sauvegarde, puis prenez l’habitude d’en refaire une chaque semaine."]
    ),
    admin
      ? p("Pour vous exercer d’abord, l’écran ", page("/accueil", "Accueil"), " propose ", q("Essayer avec des données d’exemple"), ". Elles se retirent en un clic avec ", q("Retirer les données d’exemple"), " et ne touchent jamais à vos vraies fiches.")
      : null,
  ];
}

function vocabulaire() {
  return [
    paires([
      ["Demande", "Un message reçu par le formulaire du site. Elle attend votre réponse."],
      ["Contact", "Une personne, avec ses coordonnées et l’historique de vos échanges."],
      ["Entreprise", "L’organisation d’un ou de plusieurs contacts : ferme, OBNL, PME…"],
      ["Affaire", "Une occasion de mandat, de la première demande jusqu’à la livraison ou à la perte. C’est ce qui se déplace dans le tableau des étapes."],
      ["Dossier de financement", "Le travail de préparation et de dépôt d’une demande d’aide auprès d’un programme : statuts, documents à obtenir, dates. Une affaire peut en avoir plusieurs."],
      ["Tâche", "Une chose à faire, avec une échéance. Certaines se créent seules quand un dossier change de statut."],
      ["File d’appels", ["Les personnes à appeler, une tâche d’appel chacune. Le poste d’appel (", page("/appels", "Appels"), ") les présente une à une, avec le script."]],
      ["Devis et facture", "Deux documents numérotés, avec les taxes calculées. Un devis accepté se transforme en facture."],
    ]),
  ];
}

function quotidien() {
  return [
    h(
      "div.replies",
      question("Comment répondre à une demande du site ?", { ouverte: true },
        p("Ouvrez la demande dans ", page("/demandes", "Demandes"), ". ", q("Répondre par courriel"), " ouvre un message prêt à envoyer dans votre logiciel de courriel. Quand il est parti, cliquez sur ", q("J’ai répondu"), " : le délai cesse de courir."),
        p("Une demande qui n’en est pas une (publicité, test) se range avec ", q("Classer"), " puis ", q("Classer comme pourriel"), ". Une demande sérieuse se transforme en contact avec ", q("Convertir en contact"), "."),
        p("Les messages types (suivi, relance, envoi d’une facture) se préparent dans ", vers("courriels"), ".")
      ),
      question("Comment ajouter un contact, une entreprise ou une affaire ?", {},
        p("Cliquez sur ", q("Nouveau"), ", en haut de l’écran. Le menu propose une tâche, un contact, une entreprise, une affaire, un dossier de financement, un rendez-vous, une facture ou un devis."),
        p("Sur la fiche d’un contact, d’une entreprise ou d’une affaire, le menu ", q("Ajouter"), " crée directement un élément déjà relié à cette fiche : c’est la façon la plus sûre de ne rien égarer."),
        p("Vous avez déjà une liste ailleurs ? ", vers("importer"), " reprend un fichier CSV (la plupart des tableurs savent l’enregistrer ainsi). Une simulation vous montre le résultat avant que la moindre fiche soit créée.")
      ),
      question("Comment suivre un dossier de financement ?", {},
        p("Ouvrez le dossier dans ", page("/dossiers", "Dossiers"), " et changez son statut à mesure qu’il avance. Les tâches prévues pour ce statut s’ajoutent seules, avec leur échéance."),
        p("Le bloc ", q("Documents à obtenir"), " est la liste des pièces à recevoir du client. ", q("Ajouter la liste habituelle"), " la remplit à partir d’un modèle ; cochez chaque document à mesure qu’il arrive."),
        p("Les dates limites de dépôt et les décisions attendues apparaissent dans le ", page("/calendrier", "Calendrier"), " et sur l’", page("/accueil", "Accueil"), ".")
      ),
      question("Comment faire un devis ou une facture ?", {},
        p("Choisissez ", q("Nouveau"), " puis ", q("Nouveau devis"), " ou ", q("Nouvelle facture"), ", ou utilisez le menu ", q("Ajouter"), " d’une fiche. Le document reste un brouillon, sans numéro, tant que vous n’avez pas ajouté vos lignes (services, honoraires) ; les taxes se calculent selon ", vers("facturation"), "."),
        p(q("Émettre la facture"), " lui attribue son numéro. Ensuite, ses lignes ne peuvent plus changer : en cas d’erreur, ", q("Annuler la facture"), " puis ", q("Dupliquer"), " pour repartir de la même base. Rien n’est envoyé au client automatiquement."),
        p(q("Envoyer par courriel"), " ouvre un message dans votre logiciel de courriel. Pour joindre le document, cliquez sur ", q("Imprimer"), " et choisissez « Enregistrer au format PDF »."),
        p("Quand le client paie, ", q("Enregistrer un paiement"), ". Si une facture est en retard, ", q("Envoyer un rappel de paiement"), " prépare le message."),
        p("Pour un devis : ", q("Marquer comme accepté"), ", puis ", q("Créer la facture"), " reporte les lignes sans les ressaisir.")
      ),
      question("Comment organiser mes tâches ?", {},
        p("L’écran ", page("/taches", "Tâches"), " range tout ce qu’il reste à faire, du plus urgent au plus lointain. Cochez une tâche pour la terminer ; cliquez dessus pour la modifier ou ouvrir la fiche à laquelle elle est liée."),
        p("Les filtres, dont ", q("Mes tâches"), ", aident à ne voir que l’essentiel. Sur l’", page("/accueil", "Accueil"), ", le bloc ", q("À faire"), " permet d’ajouter une tâche en quelques secondes.")
      ),
      question("Comment voir mes rendez-vous et mes échéances ?", {},
        p("Le ", page("/calendrier", "Calendrier"), " réunit les rendez-vous, les tâches datées, les dates limites de dépôt, les décisions attendues et les factures à échéance, en mois ou en liste. ", q("Nouveau rendez-vous"), " ajoute un rendez-vous."),
        p("Pour les voir aussi dans Google, Apple ou Outlook, activez ", vers("calendrier"), ". Le lien d’abonnement est un secret : ne le partagez pas.")
      ),
      question("J’ai supprimé une fiche par erreur : peut-on la retrouver ?", {},
        p("Oui. Une fiche supprimée va dans la ", page("/corbeille", "Corbeille"), " et y reste 30 jours. ", q("Rétablir"), " la remet en place. Juste après une suppression, un message propose aussi de l’annuler."),
        p("Passé ce délai, la fiche est effacée pour de bon. Une facture ou un devis déjà émis, lui, n’est jamais effacé automatiquement.")
      )
    ),
  ];
}

function appels() {
  return [
    p(
      "Le poste d’appel prépare vos appels et les consigne : la file des personnes à appeler, le script sous les yeux, le chronomètre et le résultat noté sur la fiche. ",
      gras("Il ne compose pas le numéro à votre place"), " : ", q("Appeler"), " ouvre l’application d’appel de votre appareil (le téléphone, ou le logiciel d’appel de votre ordinateur). Le CRM n’enregistre pas les conversations."
    ),
    h("h3", "Un appel, du début à la fin"),
    etapes(
      [gras("Remplissez la file."), " Dans ", page("/appels", "Appels"), ", ", q("Ajouter des personnes"), " choisit des contacts, des entreprises ou des demandes du site et crée une tâche d’appel pour chacun. Sur une fiche, le menu ", q("Ajouter"), " propose aussi ", q("À la file d’appels"), "."],
      [gras("Commencez."), " ", q("Commencer les appels"), " ouvre la première personne : les appels en retard d’abord, puis ceux d’aujourd’hui."],
      [gras("Appelez."), " ", q("Appeler"), " ouvre votre application d’appel et lance le chronomètre. Pas d’application d’appel sur l’ordinateur ? ", q("Copier le numéro"), ", composez-le sur votre téléphone et lancez le chrono à la main."],
      [gras("Notez."), " Ce que vous écrivez dans ", q("Notes d’appel"), " s’ajoute à l’historique de la fiche. ", q("Ajouter une tâche de suite"), " programme, par exemple, l’envoi d’une liste de programmes."],
      [gras("Choisissez le résultat."), " Un clic sur l’un des huit boutons (ou la touche 1 à 8) consigne l’appel, termine la tâche et ouvre la personne suivante."]
    ),
    p("Depuis la fiche d’un contact, d’une entreprise ou d’une demande, ", q("Appeler"), " ouvre le même écran pour cette seule personne : une fois le résultat choisi, vous revenez à la fiche."),
    h("h3", "Ce que fait chaque résultat"),
    paires(
      [
        [q("Joint"), "Vous avez parlé à la personne. L’appel est consigné et la tâche d’appel est terminée."],
        [q("Rendez-vous"), ["Vous avez fixé un rendez-vous (date, heure et type) : il s’ajoute au calendrier et à l’historique. ", q("Date à fixer plus tard"), " consigne l’appel sans rendez-vous."]],
        [q("À rappeler"), ["La personne demande qu’on la rappelle : une tâche ", q("Rappeler"), " prioritaire est créée pour la date et l’heure choisies."]],
        [h("span", q("Sans réponse"), " · ", q("Message laissé")), ["Un nouvel essai est programmé tout seul, quelques jours ouvrables plus tard, jusqu’au nombre d’essais permis (", vers("appels"), "). Après le dernier essai, la personne quitte la file."]],
        [q("Pas intéressé"), "L’appel est consigné et la tâche terminée. Rien n’est reprogrammé."],
        [q("Mauvais numéro"), "L’appel est consigné et la tâche terminée. Corrigez le numéro sur la fiche avant de réessayer."],
        [q("Ne plus appeler"), ["La personne est inscrite sur la liste interne « ne pas appeler » : elle quitte la file et ne peut plus y être ajoutée. Pour la retirer de la liste, décochez ", q("Ne pas appeler"), " dans ", q("Modifier"), " sur sa fiche."]],
      ],
      { larges: true }
    ),
    h("h3", "Le script"),
    p("Le script est le texte à lire à voix haute : ouverture, questions, réponse aux objections. Les mots de la fiche (prénom, entreprise, votre nom…) s’y insèrent seuls et paraissent surlignés. Deux scripts sont fournis, l’un pour répondre à une demande du site, l’autre pour un premier contact. Dans ", vers("appels"), ", vous les modifiez, en ajoutez ou en retirez."),
    h("h3", "Heures d’appel et règles du CRTC"),
    p("Le CRM vous avertit, sans vous bloquer, quand vous appelez en dehors des heures permises pour le télémarketing (de 9 h à 21 h 30 en semaine, de 10 h à 18 h la fin de semaine). Il ne consulte pas la liste nationale de numéros exclus (LNNTE) : si vous appelez des particuliers, vérifiez-la vous-même. Ces rappels sont donnés à titre d’information et ne constituent pas un avis juridique."),
    h("h3", "Suivre vos résultats"),
    p("L’onglet ", q("Journal"), " liste les appels de la période avec leur résultat, leur durée et vos notes. ", q("Statistiques"), " montre les appels faits, les personnes jointes, les rendez-vous pris et les heures où l’on vous répond le mieux."),
    h("h3", "Si la connexion Internet saute"),
    p("Un appel terminé est d’abord gardé dans votre navigateur, puis envoyé au CRM. S’il ne peut pas partir, un avis s’affiche en haut de l’écran et le CRM réessaie tout seul : gardez la page ouverte jusqu’à ce que l’avis disparaisse. Si l’envoi échoue pour de bon, vos notes restent copiables."),
  ];
}

function raccourcis() {
  return [
    paires([
      [combo("Ctrl", "K"), ["Ouvre la recherche rapide, de n’importe où. Tapez un nom, un courriel, un numéro de facture… ou le début d’une action comme ", q("Nouveau contact"), ". Sur Mac : ", combo("⌘", "K"), "."]],
      [h("kbd", "/"), "La même chose, quand vous n’êtes pas en train d’écrire dans un champ."],
      [h("kbd", "?"), "Ouvre cette page d’aide."],
      [h("span.aide__combo", h("kbd", "↑"), h("kbd", "↓"), h("kbd", "Entrée")), "Dans la recherche : choisir un résultat, puis l’ouvrir."],
      [h("kbd", "Échap"), "Ferme la recherche, une fenêtre ou un menu ouvert. Sur l’écran d’appel, referme le panneau de rappel ou de rendez-vous."],
      [h("span.aide__combo", h("kbd", "←"), h("kbd", "→"), h("kbd", "↑"), h("kbd", "↓")), "Dans le calendrier : passer d’un jour à l’autre (la semaine précédente ou suivante avec ↑ et ↓)."],
      [h("span.aide__combo", h("kbd", "Début"), h("kbd", "Fin")), "Dans le calendrier : aller au début ou à la fin de la semaine. Page précédente et Page suivante changent de mois."],
    ]),
    h("h3", "Sur l’écran d’appel"),
    paires([
      [h("kbd", "A"), "Appeler le premier numéro de la personne."],
      [h("span.aide__combo", h("kbd", "1"), " à ", h("kbd", "8")), "Choisir le résultat de l’appel : Joint, Rendez-vous, À rappeler, Sans réponse, Message laissé, Pas intéressé, Mauvais numéro, Ne plus appeler."],
      [h("kbd", "S"), "Passer cette personne : elle revient en fin de file."],
      [h("kbd", "N"), "Écrire dans les notes d’appel."],
    ]),
  ];
}

function sauvegardes() {
  return [
    h("h3", "Chaque semaine : téléchargez une sauvegarde"),
    p("Dans ", vers("sauvegardes"), ", ", q("Télécharger une sauvegarde"), " produit un seul fichier : vos fiches, vos réglages et l’historique des notes. Les mots de passe n’en font pas partie."),
    liste(
      "Rangez ce fichier hors du CRM : disque externe, ou service infonuagique protégé par un mot de passe.",
      "Faites-en une aussi avant tout gros changement : import, nettoyage, restauration.",
      "Il contient des renseignements personnels sur vos clients. Traitez-le comme un dossier confidentiel."
    ),
    h("h3", "Copies automatiques"),
    p("Chaque jour, dès la première connexion, le CRM garde une copie complète de vos données et conserve les 14 dernières. Elles servent à revenir en arrière après une fausse manœuvre : un import raté, une suppression en série."),
    p("Ces copies sont rangées au même endroit que vos données. Elles ne remplacent donc pas le fichier que vous téléchargez vous-même."),
    h("h3", "Restaurer"),
    p(q("Restaurer une sauvegarde"), " (ou ", q("Restaurer"), " à côté d’une copie automatique) remplace toutes les données actuelles. Les comptes et les mots de passe ne changent pas."),
    p("Juste avant, le CRM garde une copie de l’état actuel (les trois dernières sont conservées). Si le résultat ne vous convient pas, restaurez cette copie pour revenir exactement où vous étiez."),
  ];
}

function accesPerdu() {
  return [
    avis({ ton: "info", titre: "Pensez-y avant d’en avoir besoin", texte: "Gardez vos codes de récupération hors du CRM et préparez la phrase secrète d’urgence décrite plus bas : ce sont les deux seules portes de secours." }),
    h("h3", "J’ai oublié mon mot de passe"),
    p("Sur l’écran de connexion, cliquez sur ", q("J’ai perdu l’accès à mon compte"), ". Entrez votre courriel, l’un de vos codes de récupération (de la forme xxxx-xxxx-xxxx) et un nouveau mot de passe d’au moins 12 caractères. Chaque code ne sert qu’une fois."),
    p("Il vous reste peu de codes ? ", vers("securite"), " puis ", q("Générer de nouveaux codes…"), " en fabrique une série neuve (les anciens cessent de fonctionner)."),
    h("h3", "J’ai perdu mon téléphone"),
    p("À l’étape du code à 6 chiffres, entrez un code de récupération à la place. Une fois connecté, reconfigurez la double vérification dans ", vers("securite"), "."),
    h("h3", "Je n’ai plus mes codes"),
    p("Demandez à une personne qui administre le CRM. Dans ", vers("equipe"), ", le menu de votre ligne propose ", q("Réinitialiser le mot de passe…"), " (elle vous remet un mot de passe temporaire, que vous changez dès la connexion) et ", q("Retirer la double vérification…"), "."),
    h("h3", "Personne d’autre ne peut m’aider"),
    p("C’est le rôle de la réinitialisation d’urgence. Sur l’écran ", q("Retrouver l’accès"), ", le lien ", q("Je n’ai plus mes codes"), " mène à ", q("Réinitialisation d’urgence"), ". Elle demande la phrase secrète que vous avez fixée dans Netlify, un courriel et un nouveau mot de passe. Le compte indiqué devient administrateur, sa double vérification est retirée et toutes ses sessions sont fermées."),
    p("Cette porte n’existe que si vous l’avez préparée à l’avance :"),
    etapes(
      ["Dans Netlify, ouvrez votre site, puis ", gras("Project configuration"), " (ou ", gras("Site configuration"), ") et ", gras("Environment variables"), "."],
      ["Ajoutez le réglage ", code("CRM_REINITIALISATION"), " avec, comme valeur, une longue phrase de votre choix (au moins 20 caractères) que personne d’autre ne connaît."],
      ["Notez cette phrase dans un endroit sûr : coffre-fort, gestionnaire de mots de passe ou papier sous clé."],
      ["Relancez la publication : un réglage ajouté dans Netlify ne s’applique qu’à la publication suivante (voir ", lien("#/aide/mises-a-jour", "Mises à jour"), ")."]
    ),
    avis({ ton: "attention", titre: "Cette phrase ouvre un accès complet", texte: "Quiconque la connaît peut s’octroyer un compte administrateur. Ne l’écrivez dans aucun courriel ni message. Vous pouvez aussi retirer le réglage de Netlify une fois votre accès rétabli, et le remettre au besoin." }),
  ];
}

function alertes() {
  return [
    h("h3", "Sans rien configurer"),
    p("Tant que le CRM est ouvert dans un onglet, il vérifie les nouvelles demandes chaque minute et affiche un message à l’écran. Si vous avez accepté les notifications du navigateur (", vers("profil"), "), un avis apparaît aussi quand l’onglet est en arrière-plan."),
    p(gras("Quand le CRM est fermé, personne n’est averti."), " Ouvrez ", page("/demandes", "Demandes"), " au moins une fois par jour ouvrable pour respecter votre délai de réponse, ou activez les alertes par courriel ci-dessous."),
    h("h3", "Recevoir un courriel à chaque demande"),
    p("Le CRM n’envoie pas de courriel par lui-même : il confie l’envoi à un service spécialisé, gratuit pour un petit volume. Deux sont pris en charge : ", externe("https://resend.com", "Resend"), " et ", externe("https://sendgrid.com", "SendGrid"), "."),
    etapes(
      ["Créez un compte chez l’un des deux, puis demandez une ", gras("clé d’API"), " : un long code secret qui permet au CRM d’envoyer des courriels en votre nom."],
      ["Le service vous demandera de confirmer votre adresse d’envoi ou votre domaine. Lisez d’abord l’avertissement plus bas."],
      [
        "Dans Netlify, ouvrez ", gras("Project configuration"), " (ou ", gras("Site configuration"), ") puis ", gras("Environment variables"), " et ajoutez ces trois réglages :",
        paires(
          [
            [code("RESEND_API_KEY"), ["La clé d’API de Resend. Si vous choisissez SendGrid, utilisez plutôt ", code("SENDGRID_API_KEY"), "."]],
            [code("NOTIF_COURRIEL"), "L’adresse qui reçoit les alertes, par exemple info@innovaffaires.com."],
            [code("NOTIF_EXPEDITEUR"), "L’adresse d’envoi, confirmée auprès du service, par exemple alertes@innovaffaires.com."],
          ],
          { larges: true }
        ),
      ],
      ["Relancez la publication : un réglage ajouté dans Netlify ne s’applique qu’à la publication suivante (voir ", lien("#/aide/mises-a-jour", "Mises à jour"), ")."],
      ["Dans ", vers("demandes"), ", cliquez sur ", q("Envoyer un courriel d’essai"), " pour vérifier que tout fonctionne."]
    ),
    p("Si l’envoi échoue, la demande est quand même enregistrée dans le CRM : l’alerte n’est jamais un obstacle pour la personne qui écrit."),
    avis({ ton: "attention", titre: "La clé d’API est un secret", texte: "Elle se colle uniquement dans Netlify. Ne l’envoyez jamais par courriel ni par message. Si elle a été exposée, supprimez-la chez le service et créez-en une nouvelle." }),
    avis({ ton: "attention", titre: "Attention aux réglages de votre domaine", texte: "Resend et SendGrid demandent d’ajouter quelques enregistrements DNS à votre domaine. Ajoutez seulement ceux qu’ils indiquent, sans modifier ni supprimer ceux qui font fonctionner votre courriel actuel (MX, SPF, DKIM, DMARC). En cas de doute, demandez à la personne qui gère votre domaine avant de valider." }),
  ];
}

function misesAJour() {
  return [
    p("Le CRM voyage avec votre site dans un seul fichier, ", code("paquet.tgz"), ", rangé dans votre espace privé sur GitHub. Vos données sont rangées à part, dans le stockage de Netlify : installer une nouvelle version ne les efface pas."),
    h("h3", "Installer une nouvelle version"),
    etapes(
      ["Vous recevez un nouveau fichier ", code("paquet.tgz"), "."],
      ["Sur github.com, ouvrez votre espace ", code("innovaffaires-crm"), ", puis cliquez sur ", gras("Add file"), " et ", gras("Upload files"), "."],
      ["Déposez le nouveau ", code("paquet.tgz"), " : il remplace l’ancien. Laissez les autres fichiers tels quels."],
      ["Cliquez sur ", gras("Commit changes"), ". Netlify republie le site et le CRM tout seul en une à trois minutes ; suivez-le dans ", gras("Deploys"), "."]
    ),
    liste(
      "Le site public et le CRM voyagent ensemble dans ce fichier : une mise à jour remplace les deux.",
      ["Après chaque publication, ouvrez ", vers("apropos"), " : la vérification doit afficher « Tout fonctionne »."],
      ["Un réglage modifié dans Netlify (clé, variable) ne s’applique qu’à la publication suivante : dans ", gras("Deploys"), ", cliquez sur ", gras("Trigger deploy"), " puis sur ", gras("Deploy project"), "."],
      "Si le CRM était resté ouvert pendant la mise à jour, rechargez la page pour obtenir la nouvelle version."
    ),
  ];
}

function viePrivee() {
  return [
    p("Les fiches de vos contacts contiennent des renseignements personnels : la Loi 25 s’applique."),
    liste(
      [vers("confidentialite"), " règle la durée de conservation des demandes du site et permet de les purger."],
      ["Sur la fiche d’un contact, ", q("Télécharger ses renseignements (Loi 25)"), " répond à une demande d’accès. ", q("Anonymiser (Loi 25)"), " retire son nom, ses coordonnées et ses notes, masque son nom dans les demandes, tâches, affaires et notes liées, et garde les montants et les étapes pour vos rapports."],
      ["Chaque appel consigné (résultat, durée, notes) s’ajoute à l’historique de la fiche et suit les mêmes règles que le reste : accès, téléchargement des renseignements, anonymisation. Une personne qui demande de ne plus être appelée est inscrite sur la liste interne « ne pas appeler » (voir ", lien("#/aide/appels", "Appels"), ")."],
      ["Le ", vers("journal", "journal d’activité"), " garde la trace de qui a fait quoi, et quand."],
      "Les données sont hébergées chez Netlify, aux États-Unis : votre politique de confidentialité doit le mentionner.",
      "Les sauvegardes téléchargées contiennent ces mêmes renseignements : rangez-les en lieu sûr."
    ),
  ];
}

const SECTIONS_AIDE = [
  { id: "demarrage", titre: "Pour commencer", chapeau: "Le CRM réunit au même endroit les personnes avec qui vous travaillez, ce qui est en cours avec chacune et ce qu’il vous reste à faire.", rendre: demarrage },
  { id: "vocabulaire", titre: "Les mots du CRM", chapeau: "Quelques mots reviennent partout. Les voici, dans l’ordre où on les rencontre.", rendre: vocabulaire },
  { id: "quotidien", titre: "Au quotidien", chapeau: "Les gestes de tous les jours, un par un. Cliquez sur une question pour lire la réponse.", rendre: quotidien },
  { id: "appels", titre: "Appels", chapeau: "Appelez vos contacts une personne à la fois, avec le script sous les yeux et le résultat noté sur la fiche.", rendre: appels },
  { id: "raccourcis", titre: "Raccourcis clavier", chapeau: "Pour aller plus vite, sans la souris.", rendre: raccourcis },
  { id: "sauvegardes", titre: "Sauvegardes", chapeau: "Les copies automatiques protègent d’une erreur ; un fichier téléchargé protège de tout le reste.", rendre: sauvegardes },
  { id: "acces-perdu", titre: "Accès perdu", chapeau: "Selon ce qui manque, il existe une solution. Elle est décrite ici, du plus simple au plus radical.", rendre: accesPerdu },
  { id: "alertes", titre: "Alertes par courriel", chapeau: "Par défaut, le CRM ne vous écrit pas. Voici comment être averti d’une nouvelle demande.", rendre: alertes },
  { id: "mises-a-jour", titre: "Mises à jour", chapeau: "Comment installer une nouvelle version sans perdre une seule fiche.", rendre: misesAJour },
  { id: "vie-privee", titre: "Vie privée (Loi 25)", chapeau: "Ce que le CRM fait pour la protection des renseignements de vos clients, et ce qui reste à votre charge.", rendre: viePrivee },
];

/** Espaces insécables avant « : ; ! ? » », après « et entre un nombre et son unité : aucune ligne ne commence par un « ? ». */
function typographie(racine) {
  const marcheur = document.createTreeWalker(racine, NodeFilter.SHOW_TEXT);
  for (let n = marcheur.nextNode(); n; n = marcheur.nextNode()) {
    if (n.parentElement?.closest("code, kbd")) continue;
    n.nodeValue = n.nodeValue
      .replace(/ ([:;!?»])/g, `${NBSP}$1`)
      .replace(/(«) /g, `$1${NBSP}`)
      .replace(/(\d) (?=\p{L})/gu, `$1${NBSP}`)
      .replace(/\b(Loi) (\d)/g, `$1${NBSP}$2`);
  }
  return racine;
}

// ----- Page --------------------------------------------------------------------------------------------------------
export default async function vueAide(ctx) {
  const demandee = ctx.params?.section || null;

  const sections = SECTIONS_AIDE.map((s) => {
    const tete = h("h2.aide__titre", { id: `aide-${s.id}-titre`, tabindex: "-1" }, s.titre);
    const noeud = h(
      "section.aide__section",
      { id: `aide-${s.id}`, "aria-labelledby": `aide-${s.id}-titre` },
      tete,
      h("p.aide__chapeau", s.chapeau),
      h("div.aide__corps", s.rendre())
    );
    typographie(noeud);
    return { ...s, tete, noeud };
  });
  const parId = new Map(sections.map((s) => [s.id, s]));

  const liens = sections.map((s) => ({
    id: s.id,
    a: h("a.aide__lien", { href: `#/aide/${s.id}`, onclick: (e) => { e.preventDefault(); aller(s.id); } }, s.titre),
  }));
  const sommaire = h("nav.aide__sommaire", { "aria-label": "Sur cette page" }, h("p.aide__sommaire-titre", "Sur cette page"), h("ul", liens.map((l) => h("li", l.a))));

  function marquer(id) {
    for (const l of liens) {
      if (l.id === id) l.a.setAttribute("aria-current", "location");
      else l.a.removeAttribute("aria-current");
    }
  }

  /** Va à une section : l'adresse est mise à jour sans recharger l'écran ni empiler l'historique. */
  function aller(id, { adresse = true } = {}) {
    const s = parId.get(id);
    if (!s) return;
    if (adresse) history.replaceState(null, "", `#/aide/${id}`);
    s.noeud.scrollIntoView({ block: "start", behavior: "instant" });
    s.tete.focus({ preventScroll: true });
    marquer(id);
  }

  // Le sommaire suit la lecture : la section en cours est celle dont le haut vient de passer sous la barre.
  let planifie = false;
  function suivre() {
    planifie = false;
    let courant = sections[0];
    for (const s of sections) if (s.noeud.getBoundingClientRect().top <= 140) courant = s;
    if (innerHeight + scrollY >= document.documentElement.scrollHeight - 4) courant = sections[sections.length - 1];
    marquer(courant.id);
  }
  const surDefilement = () => {
    if (planifie) return;
    planifie = true;
    requestAnimationFrame(suivre);
  };
  addEventListener("scroll", surDefilement, { passive: true });

  marquer(demandee && parId.has(demandee) ? demandee : sections[0].id);
  // La page n'est pas encore dans le document, et l'écran remonte en haut juste après : on attend l'image suivante.
  if (demandee && parId.has(demandee)) requestAnimationFrame(() => aller(demandee, { adresse: false }));

  const pied = h("p.aide__pied.muet", "Le guide de mise en ligne remis avec le CRM reprend les étapes d’installation et de mise à jour, pas à pas.");

  return {
    titre: "Aide",
    noeud: h(
      "div",
      enTete({ titre: "Aide", sous: "Un guide court, avec les mots exacts des écrans du CRM." }),
      h("div.aide", sommaire, h("div.aide__contenu", sections.map((s) => s.noeud), pied))
    ),
    detruire: () => removeEventListener("scroll", surDefilement),
  };
}
