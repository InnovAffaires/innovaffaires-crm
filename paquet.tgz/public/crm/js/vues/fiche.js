// =============================================================================
// Squelette des pages de fiche (contact, entreprise, affaire, dossier, facture) :
// un en-tête, deux colonnes de blocs et une mise à jour par morceaux. Un bloc
// n'est redessiné que si les données dont il dépend ont changé ; l'historique
// (et sa zone de saisie) n'est jamais recréé pendant que l'on écrit.
// Contient aussi les pièces communes : lignes de fiches liées, tâches, notes.
// =============================================================================
import { h, remplir, paragraphes, idUnique } from "../noyau/dom.js";
import { icone } from "../noyau/icones.js";
import { etat, fiche as ficheDe, libelleFiche, nomUtilisateur, nomFiche, maintenant } from "../noyau/etat.js";
import { restaurerFiche, modifierFiche, tenter } from "../noyau/ecriture.js";
import { synchroniser } from "../noyau/synchro.js";
import { argent, dateCourte, ilYa, nomComplet, normaliser, telephone as fmtTel } from "../commun/format.js";
import { ENTITES, SERVICES } from "../commun/schema.js";
import { lienFiche } from "../noyau/routeur.js";
import { partiesLocales } from "../commun/dates.js";
import { btn, panneau, listeDef, etatVide, pastille, tampon, chargement } from "../ui/composants.js";
import { ouvrirDialogue } from "../ui/dialogue.js";
import { ajoutRapide, ligneTache, ordreTaches } from "../ui/taches.js";
import { pastilleEtape, pastilleStatutDossier, pastilleEtatDocument, totauxDe, libelleOption, dateSansAnneeCourante, lienCourriel, lienTelephone } from "./aides.js";

// ----- Conservation de la saisie pendant un redessin ---------------------------------------------------------------
function capturerSaisies(racine) {
  const actif = document.activeElement;
  const sortie = [];
  for (const el of racine.querySelectorAll("[data-focus-id]")) {
    const e = { id: el.dataset.focusId, valeur: "value" in el ? el.value : null, focus: el === actif, debut: null, fin: null };
    try {
      e.debut = el.selectionStart;
      e.fin = el.selectionEnd;
    } catch {
      /* pas de sélection pour ce type de champ */
    }
    sortie.push(e);
  }
  return sortie;
}
function restaurerSaisies(racine, saisies) {
  for (const s of saisies) {
    const el = racine.querySelector(`[data-focus-id="${CSS.escape(s.id)}"]`);
    if (!el) continue;
    if (s.valeur !== null && "value" in el && el.value !== s.valeur) el.value = s.valeur;
    if (s.focus) {
      el.focus({ preventScroll: true });
      try {
        if (s.debut !== null) el.setSelectionRange(s.debut, s.fin);
      } catch {
        /* ignoré */
      }
    }
  }
}

/**
 * creerVueFiche({ entite, liste, entete, blocs, titre })
 *   liste  : { href, libelle } — lien de retour quand la fiche n'existe plus
 *   entete : { depend: [...], dessiner(f) → Node }
 *   blocs  : [{ id, colonne: "principal" | "lateral", ordre (écran étroit), depend: [...], dessiner(f) → Node | null }]
 *            ou, pour un bloc qui ne doit jamais être recréé : { …, creer(f) → { noeud, miseAJour?(changes, f), vide?() → bool, detruire?() } }
 *            (`vide()` vrai : le bloc est caché, sans laisser de trou dans la page)
 */
export function creerVueFiche(def) {
  return async function vueFiche(ctx) {
    const id = ctx.params.id;
    const zoneEntete = h("div.fiche-page__entete");
    const principal = h("div.fiche__principal");
    const lateral = h("aside.fiche__lateral", { "aria-label": def.ariaLateral || "Renseignements" });
    const corps = h("div.fiche", principal, lateral);
    const absent = h("div.fiche-page__absent", { hidden: true });
    const racine = h("div.fiche-page", zoneEntete, corps, absent);

    const blocs = def.blocs.map((b) => {
      const noeud = h("div.fiche__bloc", { dataset: { bloc: b.id }, css: { "--ordre": b.ordre ?? 0 } });
      (b.colonne === "lateral" ? lateral : principal).append(noeud);
      return { ...b, noeud, instance: null };
    });

    let cleFiche = "";
    let absence = ""; // "", "absent" ou "corbeille" : ce que l'écran montre à la place de la fiche

    function dessinerEntete(f) {
      const saisies = capturerSaisies(zoneEntete);
      remplir(zoneEntete, def.entete.dessiner(f));
      restaurerSaisies(zoneEntete, saisies);
    }
    const masquerSiVide = (b) => {
      if (b.instance?.vide) b.noeud.hidden = !!b.instance.vide();
    };
    function dessinerBloc(b, f) {
      if (b.creer) {
        if (!b.instance) {
          b.instance = b.creer(f);
          b.noeud.replaceChildren(b.instance.noeud);
        }
        masquerSiVide(b);
        return;
      }
      const saisies = capturerSaisies(b.noeud);
      const contenu = b.dessiner(f);
      b.noeud.hidden = !contenu;
      if (contenu) b.noeud.replaceChildren(contenu);
      else b.noeud.replaceChildren();
      restaurerSaisies(b.noeud, saisies);
    }
    const toutDessiner = (f) => {
      dessinerEntete(f);
      for (const b of blocs) dessinerBloc(b, f);
    };

    function montrerAbsence(f) {
      absence = f?.supprime ? "corbeille" : "absent";
      corps.hidden = true;
      zoneEntete.hidden = true;
      absent.hidden = false;
      const dansCorbeille = f?.supprime;
      remplir(
        absent,
        dansCorbeille ? h("a.retour", { href: def.liste.href }, icone("retour", "ic--p"), def.liste.libelle) : null,
        etatVide({
          icone: dansCorbeille ? "corbeille" : "recherche",
          titre: dansCorbeille ? "Cette fiche est dans la corbeille" : "Cette fiche n’existe pas ou plus",
          texte: dansCorbeille ? "Vous pouvez la rétablir : elle reprendra sa place avec tout son historique." : "Elle a peut-être été supprimée, ou l’adresse est périmée.",
          action: dansCorbeille
            ? etat.droits.ecrire
              ? btn("Rétablir cette fiche", { ton: "primaire", icone: "annuler", onclick: () => tenter(() => restaurerFiche(def.entite, id), { succes: "Fiche rétablie." }) })
              : null
            : btn(`Retour aux ${def.liste.libelle.toLowerCase()}`, { href: def.liste.href }),
        })
      );
    }
    function montrerFiche(f) {
      absence = "";
      corps.hidden = false;
      zoneEntete.hidden = false;
      absent.hidden = true;
      remplir(absent);
      toutDessiner(f);
    }

    const titrer = (f) => {
      document.title = `${libelleFiche(def.entite, f)} — CRM InnovAffaires`;
    };
    let detruite = false;
    const f0 = ficheDe(def.entite, id);
    if (f0 && !f0.supprime) {
      cleFiche = `${f0.v}|${f0.maj}`;
      montrerFiche(f0);
    } else if (f0) montrerAbsence(f0);
    else {
      // Inconnue ici : elle vient peut-être d'être créée ailleurs (autre poste, formulaire du site). On demande au serveur avant de conclure.
      absence = "chargement";
      corps.hidden = true;
      zoneEntete.hidden = true;
      absent.hidden = false;
      remplir(absent, chargement());
      synchroniser()
        .catch(() => {})
        .finally(() => {
          if (detruite || absence !== "chargement") return;
          const f = ficheDe(def.entite, id);
          if (f && !f.supprime) {
            cleFiche = `${f.v}|${f.maj}`;
            montrerFiche(f);
            titrer(f);
          } else montrerAbsence(f);
        });
    }

    return {
      titre: f0 && !f0.supprime ? libelleFiche(def.entite, f0) : f0 ? "Fiche dans la corbeille" : "Fiche",
      noeud: racine,
      miseAJour(changes) {
        const f = ficheDe(def.entite, id);
        if (!f && absence === "chargement") return true; // la vérification auprès du serveur est en cours
        if (!f || f.supprime) {
          if (absence !== (f?.supprime ? "corbeille" : "absent")) montrerAbsence(f);
          return true;
        }
        if (absence) {
          cleFiche = `${f.v}|${f.maj}`;
          montrerFiche(f);
          titrer(f);
          return true;
        }
        const cle = `${f.v}|${f.maj}`;
        const modifiee = cle !== cleFiche;
        cleFiche = cle;
        const touche = (dep = []) => modifiee || dep.some((d) => changes.has(d)) || changes.has("session");
        if (touche(def.entete.depend)) dessinerEntete(f);
        if (modifiee) titrer(f);
        for (const b of blocs) {
          if (b.creer) {
            b.instance?.miseAJour?.(changes, f);
            masquerSiVide(b);
          } else if (touche(b.depend)) dessinerBloc(b, f);
        }
        return true;
      },
      detruire() {
        detruite = true;
        for (const b of blocs) b.instance?.detruire?.();
      },
    };
  };
}

// ----- Marques d'en-tête ----------------------------------------------------------------------------------------------------------
/** Tampons et pastilles à placer à côté du titre : état de la fiche (`etats`), archivée, anonymisée, donnée d'exemple. */
export function marquesFiche(f, { archive = false, anonymise = false, etats = [] } = {}) {
  const m = [...etats];
  if (anonymise) m.push(tampon("Anonymisé", "neutre"));
  else if (archive) m.push(tampon("Archivé", "neutre"));
  if (f.exemple) m.push(pastille("Donnée d’exemple", "neutre"));
  return m.length ? h("span.fiche__marques", m) : null;
}

// ----- Client -----------------------------------------------------------------------------------------------------------------------------
/**
 * panneauClient(f, extra) — l'entreprise et le contact rattachés à une affaire, un dossier ou une facture,
 * avec de quoi les joindre. `extra` : lignes [libellé, valeur] ajoutées en bas (ex. l'affaire d'origine).
 * Retourne null quand il n'y a rien à montrer.
 */
export function panneauClient(f, extra = []) {
  const ent = f.entreprise_id ? ficheDe("entreprises", f.entreprise_id) : null;
  const con = f.contact_id ? ficheDe("contacts", f.contact_id) : null;
  const entOk = ent && !ent.supprime;
  const conOk = con && !con.supprime;
  const def = listeDef([
    ["Entreprise", entOk ? h("a.lien-fiche", { href: lienFiche("entreprises", ent.id) }, ent.nom) : null],
    ["Contact", conOk ? h("a.lien-fiche", { href: lienFiche("contacts", con.id) }, nomComplet(con) || con.courriel) : null],
    ["Fonction", conOk ? con.titre || null : null],
    ["Courriel", conOk && con.courriel ? lienCourriel(con.courriel) : null],
    ["Téléphone", conOk && (con.telephone || con.mobile) ? lienTelephone(con.telephone || con.mobile) : null],
    ...extra,
  ]);
  return def.children.length ? panneau({ titre: "Client" }, def) : null;
}

// ----- Listes de fiches liées -------------------------------------------------------------------------------------------------
/** ligneLiee({ href, titre, sous, marque, fin }) — une ligne de registre qui mène à une autre fiche. */
export function ligneLiee({ href, titre, sous = null, marque = null, fin = null, ton = null }) {
  return h(
    "li",
    h(
      "a.ligne.ligne--liee",
      { href },
      h("span.ligne__texte", h("span.ligne__titre", titre), sous ? h("span.ligne__sous", sous) : null),
      marque || fin ? h("span.ligne__fin.ligne__fin--pile", fin ? h("span.ligne__montant", { class: ton ? `ligne__montant--${ton}` : "" }, fin) : null, marque) : null
    )
  );
}

/** panneauLie({ titre, compteur, lignes, vide, actions, sous, pied }) — un panneau-registre de fiches liées. */
export function panneauLie({ titre, compteur = null, lignes, vide = "Aucun élément.", actions = null, sous = null, pied = null }) {
  const noeud = panneau({ titre, sous, compteur: compteur ?? (lignes.length || null), actions, classe: "panneau--liste" }, lignes.length ? h("ul.registre-liste", lignes) : h("p.liste-vide", vide));
  if (pied) noeud.append(pied);
  return noeud;
}

// ----- Lignes types : une fiche liée, vue depuis une autre ---------------------------------------------------------------
export function ligneContact(c) {
  return ligneLiee({
    href: lienFiche("contacts", c.id), titre: nomComplet(c) || c.courriel || "Contact sans nom",
    sous: [c.titre, c.courriel].filter(Boolean).join(" — ") || null, fin: c.telephone || c.mobile ? fmtTel(c.telephone || c.mobile) : null,
  });
}

export function ligneAffaire(o, { client = false } = {}) {
  return ligneLiee({
    href: lienFiche("opportunites", o.id), titre: o.titre,
    sous: [libelleOption(SERVICES, o.service), o.date_fermeture_prevue ? `fermeture prévue le ${dateSansAnneeCourante(o.date_fermeture_prevue)}` : null, client ? nomFiche("entreprises", o.entreprise_id) : null].filter(Boolean).join(" — ") || null,
    marque: pastilleEtape(o.etape), fin: o.valeur ? argent(o.valeur) : null,
  });
}

export function ligneDossier(d, { client = false } = {}) {
  const depot = d.date_limite && !d.date_depot ? `dépôt avant le ${dateSansAnneeCourante(d.date_limite)}` : d.date_depot ? `déposé le ${dateSansAnneeCourante(d.date_depot)}` : null;
  return ligneLiee({
    href: lienFiche("dossiers", d.id), titre: d.titre,
    sous: [d.programme && !normaliser(d.titre).includes(normaliser(d.programme).slice(0, 10)) ? d.programme : null, depot, client ? nomFiche("entreprises", d.entreprise_id) : null].filter(Boolean).join(" — ") || null,
    marque: pastilleStatutDossier(d.statut), fin: d.montant_demande ? argent(d.montant_demande) : null,
  });
}

export function ligneFacture(f, { client = false } = {}) {
  const total = totauxDe(f).total;
  return ligneLiee({
    href: lienFiche("factures", f.id), titre: [libelleFiche("factures", f), f.objet].filter(Boolean).join(" — "),
    sous: [f.date_emission ? `${f.type === "devis" ? "émis" : "émise"} le ${dateSansAnneeCourante(f.date_emission)}` : "Brouillon", client ? nomFiche("entreprises", f.entreprise_id) : null].filter(Boolean).join(" — "),
    marque: pastilleEtatDocument(f), fin: argent(total),
  });
}

// ----- Tâches liées ---------------------------------------------------------------------------------------------------------------
const TACHES_VISIBLES = 6;
const depliees = new Set(); // panneaux dont la suite de tâches est ouverte : l'état survit aux redessins

/**
 * panneauTaches({ taches, lieType, lieId, valeurs, placeholder, focusId, estDirecte })
 *   taches     : toutes les tâches à présenter (à faire et terminées)
 *   estDirecte : (t) => bool — la tâche est liée à la fiche elle-même (son lien n'est alors pas répété)
 */
export function panneauTaches({ taches, lieType, lieId, valeurs = {}, titre = "À faire", placeholder = "Nouvelle tâche…", focusId = "fiche-ajout", estDirecte = () => true }) {
  const ouvertes = taches.filter((t) => t.statut !== "fait").sort(ordreTaches);
  const faites = taches.filter((t) => t.statut === "fait").sort((a, b) => String(b.terminee_le || "").localeCompare(String(a.terminee_le || "")));
  const lignes = (liste) => liste.map((t) => ligneTache(t, { lien: !estDirecte(t) }));
  const contenu = [];
  if (!ouvertes.length) contenu.push(h("p.liste-vide", "Aucune tâche à faire."));
  else {
    contenu.push(h("ul.taches", lignes(ouvertes.slice(0, TACHES_VISIBLES))));
    if (ouvertes.length > TACHES_VISIBLES) {
      const cle = `${lieType}:${lieId}`;
      const reste = ouvertes.length - TACHES_VISIBLES;
      const suite = h("details.taches-faites.taches-suite", h("summary", `${reste} autre${reste > 1 ? "s" : ""} tâche${reste > 1 ? "s" : ""} à faire`), h("ul.taches", lignes(ouvertes.slice(TACHES_VISIBLES))));
      suite.open = depliees.has(cle);
      suite.addEventListener("toggle", () => (suite.open ? depliees.add(cle) : depliees.delete(cle)));
      contenu.push(suite);
    }
  }
  if (faites.length) contenu.push(h("details.taches-faites", h("summary", `Tâches terminées (${faites.length})`), h("ul.taches", lignes(faites.slice(0, 15)))));
  const noeud = panneau({ titre, compteur: ouvertes.length || null, classe: "panneau--liste" }, contenu);
  const ajout = ajoutRapide({ lieType, lieId, valeurs, placeholder, focusId, echeance: "semaine" });
  if (ajout) noeud.append(h("div.panneau__pied", ajout));
  return noeud;
}

// ----- Notes ----------------------------------------------------------------------------------------------------------------------------
/** Fenêtre de modification des seules notes d'une fiche. */
export function modifierNotes(entite, f, { titre = "Notes" } = {}) {
  const courante = () => ficheDe(entite, f.id) || f;
  ouvrirDialogue({
    titre, taille: "moyen",
    contenu: (ctx) => {
      const idZone = idUnique("notes-fiche");
      const zone = h("textarea.saisie.saisie--long", { id: idZone, rows: 10, maxlength: 5000 });
      zone.value = courante().notes || "";
      const initial = zone.value;
      zone.addEventListener("input", () => ctx.modifie(zone.value !== initial));
      const annuler = btn("Annuler", { onclick: () => ctx.fermer(undefined) });
      const ok = btn("Enregistrer", { ton: "primaire", onclick: enregistrer });
      ctx.definirPied(annuler, ok);
      async function enregistrer() {
        const texte = zone.value.trim();
        if (texte === (courante().notes || "").trim()) return ctx.fermer(undefined);
        ctx.occupe(true);
        const r = await tenter(() => modifierFiche(entite, courante(), { notes: texte || null }), { succes: "Notes enregistrées.", entite });
        ctx.occupe(false);
        if (r) {
          ctx.modifie(false);
          ctx.fermer(r.fiche);
        }
      }
      return h("div.champ", h("label.sr-only", { for: idZone }, titre), zone);
    },
  });
}

export function panneauNotes(entite, f, { titre = "Notes", vide = "Aucune note. Ajoutez ici ce qu’il faut garder en tête." } = {}) {
  const peutEcrire = etat.droits.ecrire;
  const actions = peutEcrire ? btn(f.notes ? "Modifier" : "Ajouter", { petit: true, ton: "discret", icone: "modifier", onclick: () => modifierNotes(entite, f, { titre }) }) : null;
  return panneau({ titre, actions }, f.notes ? h("div.notes-fiche", paragraphes(f.notes)) : h("p.muet", vide));
}

// ----- Pied de fiche ---------------------------------------------------------------------------------------------------------
export function piedFiche(entite, f) {
  const e = ENTITES[entite]?.genre === "f" ? "e" : "";
  const cree = Date.parse(f.cree);
  const maj = Date.parse(f.maj);
  const par = f.par && f.par !== "formulaire" ? nomUtilisateur(f.par) : "";
  const parMaj = f.maj_par && f.maj_par !== "formulaire" ? nomUtilisateur(f.maj_par) : "";
  const bouts = [];
  if (Number.isFinite(cree)) bouts.push(`Créé${e} le ${dateCourte(partiesLocales(cree).date)}${par ? ` par ${par}` : ""}`);
  if (Number.isFinite(maj) && maj - cree > 60_000) bouts.push(`modifié${e} ${ilYa(maj, maintenant())}${parMaj ? ` par ${parMaj}` : ""}`);
  return h("p.fiche__pied", `${bouts.join(", ")}.`);
}
