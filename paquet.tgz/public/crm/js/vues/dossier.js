// =============================================================================
// Fiche d'un dossier de financement : l'avancement (statuts cliquables), les
// montants, les documents à obtenir, les tâches, les factures liées et
// l'historique, avec les dates, la demande et le client à côté.
// =============================================================================
import { h } from "../noyau/dom.js";
import { icone } from "../noyau/icones.js";
import { etat, actives, liees, fiche, nomUtilisateur, statutDossierDe } from "../noyau/etat.js";
import { lienFiche, naviguer } from "../noyau/routeur.js";
import { modifierFiche, supprimerAvecAnnulation, tenter } from "../noyau/ecriture.js";
import { aujourdhui, differenceJours } from "../commun/dates.js";
import { nouvelId } from "../commun/ids.js";
import { PALIERS, TYPES_AIDE } from "../commun/schema.js";
import { argent, argentEntier, dateLongue, echeanceRelative, nomComplet, normaliser, pluriel, pourcent, tronquer } from "../commun/format.js";
import { btn, champTexte, enTete, menuActions, panneau, listeDef, avis, tampon } from "../ui/composants.js";
import { journal } from "../ui/journal.js";
import { frise } from "../ui/frise.js";
import { ouvrirDialogue } from "../ui/dialogue.js";
import { toast } from "../ui/toast.js";
import { libelleOption, noeudEcheance, dateSansAnneeCourante, lienSite } from "./aides.js";
import { nouvelleFiche, modifierLaFiche, DOCUMENTS_HABITUELS } from "./formulaires.js";
import { changerStatutDossier } from "./etapes.js";
import { creerVueFiche, marquesFiche, panneauClient, panneauTaches, panneauNotes, piedFiche, panneauLie, ligneFacture } from "./fiche.js";

export const depend = ["dossiers", "entreprises", "contacts", "opportunites", "factures", "taches", "evenements", "equipe", "config"];

const TON_FRISE = { "en-cours": "ouverte", accepte: "gagnee", termine: "gagnee", refuse: "perdue" };
const TON_TAMPON = { accepte: "ok", termine: "neutre", refuse: "erreur" };

/** Le dossier n'a pas encore été déposé : sa date limite compte. */
const avantDepot = (d) => statutDossierDe(d.statut)?.type === "en-cours" && !d.date_depot;
/** Le dossier est déposé et attend la réponse de l'organisme. */
const enAnalyse = (d) => statutDossierDe(d.statut)?.type === "en-cours" && !!d.date_depot;

// ----- En-tête -----------------------------------------------------------------------------------------------------------------------------------------
function menuAjouter(d) {
  const liens = { ...(d.entreprise_id ? { entreprise_id: d.entreprise_id } : {}), ...(d.contact_id ? { contact_id: d.contact_id } : {}) };
  const rattache = { dossier_id: d.id, ...(d.opportunite_id ? { opportunite_id: d.opportunite_id } : {}) };
  const aller = (idFocus) => document.querySelector(`[data-focus-id="${idFocus}"]`)?.focus();
  return menuActions({
    libelle: "Ajouter", icone: "plus", ton: "primaire", aria: "Ajouter une tâche, un document à obtenir, un rendez-vous ou une facture à ce dossier",
    elements: [
      { libelle: "Tâche", icone: "taches", onclick: () => aller("dossier-ajout") },
      { libelle: "Document à obtenir", icone: "document", onclick: () => aller("dossier-doc") },
      { libelle: "Rendez-vous", icone: "calendrier", onclick: () => nouvelleFiche("evenements", { lie_type: "dossiers", lie_id: d.id }) },
      "separateur",
      { libelle: "Facture", icone: "factures", onclick: () => nouvelleFiche("factures", { type: "facture", ...liens, ...rattache, objet: d.titre }) },
      { libelle: "Devis", icone: "document", onclick: () => nouvelleFiche("factures", { type: "devis", ...liens, ...rattache, objet: d.titre }) },
    ],
  });
}

function enteteDossier(d) {
  const statut = statutDossierDe(d.statut);
  const ent = d.entreprise_id ? fiche("entreprises", d.entreprise_id) : null;
  const con = d.contact_id ? fiche("contacts", d.contact_id) : null;
  const sous = [];
  if (ent && !ent.supprime) sous.push(h("a.lien-fiche", { href: lienFiche("entreprises", ent.id) }, ent.nom));
  if (ent && !ent.supprime && con && !con.supprime) sous.push(" — ");
  if (con && !con.supprime) sous.push(h("a.lien-fiche", { href: lienFiche("contacts", con.id) }, nomComplet(con) || con.courriel));
  const actions = [];
  if (etat.droits.ecrire) {
    actions.push(menuAjouter(d));
    actions.push(btn("Modifier", { icone: "modifier", onclick: () => modifierLaFiche("dossiers", fiche("dossiers", d.id) || d) }));
    actions.push(
      menuActions({
        aria: "Plus d’actions sur ce dossier",
        elements: [{ libelle: "Mettre à la corbeille", icone: "corbeille", danger: true, onclick: () => supprimerAvecAnnulation("dossiers", d.id, { apres: () => naviguer("/dossiers") }) }],
      })
    );
  }
  return enTete({
    retour: { href: "#/dossiers", libelle: "Dossiers de financement" },
    titre: d.titre,
    apres: marquesFiche(d, { etats: statut && statut.type !== "en-cours" ? [tampon(statut.nom, TON_TAMPON[statut.type])] : [] }),
    sous: sous.length ? sous : null,
    actions,
  });
}

// ----- Avancement ------------------------------------------------------------------------------------------------------------------------------------
function blocAvancement(d) {
  const peutEcrire = etat.droits.ecrire;
  const depuis = d.statut_depuis ? Math.max(0, differenceJours(d.statut_depuis, aujourdhui())) : null;
  const sous = depuis === null ? null : depuis === 0 ? "Passé à ce statut aujourd’hui" : `À ce statut depuis ${pluriel(depuis, "jour", "jours")}`;
  return panneau(
    { titre: "Avancement", sous },
    frise({
      etapes: etat.config.statuts_dossier.map((s) => ({ id: s.id, nom: s.nom, ton: TON_FRISE[s.type] || "ouverte" })), courant: d.statut, ecrire: peutEcrire,
      surChoix: (s) => changerStatutDossier(d.id, s.id), libelleChemin: "Statuts du dossier", libelleIssues: "Refus", titreBouton: (s) => `Passer le dossier à « ${s.nom} »`,
    }),
    peutEcrire ? h("p.frise__aide.muet.petit", "Cliquez sur un statut pour y passer le dossier. Les tâches prévues pour ce statut s’ajoutent à votre liste.") : null
  );
}

/** Date limite proche ou dépassée, tant que le dossier n'est pas déposé. */
function avisDepot(d) {
  if (!d.date_limite || !avantDepot(d)) return null;
  const n = differenceJours(aujourdhui(), d.date_limite);
  if (n > 7) return null;
  const manquants = (d.documents || []).filter((x) => !x.recu).length;
  const docs = manquants ? ` ${manquants > 1 ? `${manquants} documents manquent encore` : "Un document manque encore"}.` : "";
  return avis({
    ton: n < 0 ? "erreur" : "attention",
    titre: n < 0 ? "La date limite de dépôt est dépassée" : n === 0 ? "Date limite de dépôt : aujourd’hui" : `Date limite de dépôt : ${echeanceRelative(d.date_limite)}`,
    texte: `${dateLongue(d.date_limite)}.${docs}`,
  });
}

function avisRefus(d) {
  if (statutDossierDe(d.statut)?.type !== "refuse") return null;
  const peutEcrire = etat.droits.ecrire;
  return avis({
    ton: "erreur", titre: "Dossier refusé",
    texte: d.raison_refus ? h("span.avis__motifs", `Motifs : ${d.raison_refus}`) : "Aucun motif n’a été consigné.",
    actions: peutEcrire ? btn(d.raison_refus ? "Modifier les motifs" : "Ajouter les motifs", { petit: true, icone: "modifier", onclick: () => modifierLaFiche("dossiers", fiche("dossiers", d.id) || d) }) : null,
  });
}

// ----- Montants ----------------------------------------------------------------------------------------------------------------------------------------
function blocMontants(d) {
  const demande = +d.montant_demande || 0;
  const cout = +d.cout_projet || 0;
  const obtenu = +d.montant_obtenu || 0;
  if (!demande && !cout && !obtenu) return null;
  const statut = statutDossierDe(d.statut);
  const item = (titre, valeur, precision) => h("div.fiche-chiffres__item", h("dt", titre), h("dd", valeur, precision ? h("small", precision) : null));
  const attente = statut?.type === "refuse" ? "Dossier refusé" : avantDepot(d) ? "Pas encore déposé" : d.date_decision_prevue ? `Décision prévue le ${dateSansAnneeCourante(d.date_decision_prevue)}` : "En attente de décision";
  const taux = cout ? ((obtenu || demande) / cout) * 100 : null;
  return h(
    "dl.fiche-chiffres",
    item("Montant demandé", demande ? argent(demande) : "—", demande ? null : "Non précisé"),
    item("Coût du projet", cout ? argentEntier(cout) : "—", cout ? (demande && cout > demande ? `Part du client\u00a0: ${argentEntier(cout - demande)}` : null) : "Non précisé"),
    item("Montant accordé", obtenu ? argent(obtenu) : "—", obtenu ? (demande ? `${pourcent((obtenu / demande) * 100)} du montant demandé` : null) : attente),
    item("Taux d’aide", taux === null ? "—" : pourcent(taux), taux === null ? "Coût du projet non précisé" : `${obtenu ? "accordé" : "demandé"}, du coût du projet`)
  );
}

// ----- Documents à obtenir ---------------------------------------------------------------------------------------------------------------------
// Les écritures du tableau passent l'une après l'autre : cocher deux cases coup sur coup
// ne doit jamais envoyer deux fois la même version de la fiche.
const enCours = new Map();
function enfiler(id, tache) {
  const courant = (enCours.get(id) || Promise.resolve()).then(tache, tache);
  const trace = courant.catch(() => {});
  enCours.set(id, trace);
  trace.then(() => {
    if (enCours.get(id) === trace) enCours.delete(id);
  });
  return courant;
}

/** Réécrit la liste des documents : `transformer` reçoit une copie de la liste à jour et retourne la nouvelle liste (ou null pour ne rien faire). */
function ecrireDocuments(id, transformer, { succes = null } = {}) {
  return enfiler(id, async () => {
    const d = fiche("dossiers", id);
    if (!d || d.supprime) return null;
    const apres = transformer((d.documents || []).map((x) => ({ ...x })));
    if (!apres) return null;
    return tenter(() => modifierFiche("dossiers", d, { documents: apres }), { entite: "dossiers", succes });
  });
}

function basculerDocument(id, idDoc, recu) {
  return ecrireDocuments(id, (docs) =>
    docs.map((x) => {
      if (x.id !== idDoc) return x;
      const { date_recu: _ancienne, ...reste } = x;
      return recu ? { ...reste, recu: true, date_recu: aujourdhui() } : { ...reste, recu: false };
    })
  );
}

function ajouterHabituels(id) {
  return ecrireDocuments(
    id,
    (docs) => {
      const connus = new Set(docs.map((x) => normaliser(x.nom)));
      const nouveaux = DOCUMENTS_HABITUELS.filter((nom) => !connus.has(normaliser(nom))).map((nom) => ({ id: nouvelId(), nom, recu: false }));
      return nouveaux.length ? [...docs, ...nouveaux] : null;
    },
    { succes: "Les documents habituels ont été ajoutés." }
  );
}

function modifierDocument(id, idDoc) {
  const x0 = (fiche("dossiers", id)?.documents || []).find((x) => x.id === idDoc);
  if (!x0) return;
  ouvrirDialogue({
    titre: "Document à obtenir", taille: "petit",
    contenu: (ctx) => {
      const nom = champTexte({ libelle: "Document", valeur: x0.nom, maxlength: 200 });
      const note = champTexte({ libelle: "Note", valeur: x0.note || "", maxlength: 300, requis: false, aide: "Par exemple : « demandé au comptable le 12 octobre »." });
      const enregistrer = () => {
        if (!nom.lire().trim()) {
          nom.erreur("Donnez un nom au document.");
          nom.focus();
          return;
        }
        ctx.fermer({ nom: nom.lire().trim(), note: note.lire().trim() });
      };
      const retirer = btn("Retirer de la liste", { ton: "danger", classe: "pousse", onclick: () => ctx.fermer("retirer") });
      ctx.definirPied(retirer, btn("Annuler", { onclick: () => ctx.fermer(null) }), btn("Enregistrer", { ton: "primaire", onclick: enregistrer }));
      return h("form.formulaire", { novalidate: true, onsubmit: (e) => (e.preventDefault(), enregistrer()) }, h("div.grille.grille--1", nom.noeud, note.noeud));
    },
  }).promesse.then((v) => {
    if (!v) return;
    if (v === "retirer") {
      const copie = { ...x0 };
      ecrireDocuments(id, (docs) => docs.filter((x) => x.id !== idDoc)).then((r) => {
        if (!r) return;
        toast(`« ${tronquer(x0.nom, 40)} » a été retiré de la liste.`, {
          ton: "info", duree: 9000,
          action: { libelle: "Annuler", onclick: () => ecrireDocuments(id, (docs) => (docs.some((x) => x.id === idDoc) ? null : [...docs, copie])) },
        });
      });
      return;
    }
    ecrireDocuments(id, (docs) =>
      docs.map((x) => {
        if (x.id !== idDoc) return x;
        const { note: _ancienne, ...reste } = x;
        return { ...reste, nom: v.nom, ...(v.note ? { note: v.note } : {}) };
      })
    );
  });
}

function ligneDocument(d, x) {
  const peutEcrire = etat.droits.ecrire;
  const coche = h("input", { type: "checkbox", checked: !!x.recu, disabled: !peutEcrire, "aria-label": `${x.recu ? "Marquer comme non reçu" : "Marquer comme reçu"} : ${x.nom}`, "data-focus-id": `doc-${x.id}` });
  coche.addEventListener("change", () => basculerDocument(d.id, x.id, coche.checked));
  return h(
    "li.tache.doc",
    { class: { "tache--faite": !!x.recu } },
    h("label.case.tache__case", coche, h("span.case__boite", { "aria-hidden": "true" }, icone("coche", "ic--p"))),
    h(
      "div.tache__corps",
      peutEcrire ? h("button.tache__titre", { type: "button", title: "Modifier ou retirer ce document", onclick: () => modifierDocument(d.id, x.id) }, x.nom) : h("span.tache__titre", x.nom),
      x.note ? h("div.tache__meta", h("span", x.note)) : null
    ),
    h("div.tache__fin", x.recu && x.date_recu ? h("small.muet", `reçu le ${dateSansAnneeCourante(x.date_recu)}`) : null)
  );
}

function blocDocuments(d) {
  const docs = d.documents || [];
  const recus = docs.filter((x) => x.recu).length;
  const peutEcrire = etat.droits.ecrire;
  const manquantsHabituels = DOCUMENTS_HABITUELS.some((nom) => !docs.some((x) => normaliser(x.nom) === normaliser(nom)));
  const menu =
    peutEcrire && docs.length && manquantsHabituels
      ? menuActions({ aria: "Plus d’actions sur les documents", elements: [{ libelle: "Ajouter les documents habituels", icone: "plus", onclick: () => ajouterHabituels(d.id) }] })
      : null;
  const noeud = panneau({ titre: "Documents à obtenir", compteur: docs.length ? `${recus} sur ${docs.length} reçus` : null, actions: menu, classe: "panneau--liste" });
  const corps = noeud.querySelector(".panneau__corps");
  if (docs.length) {
    corps.append(
      h("div.docs__barre", h("progress.docs-avancement", { max: docs.length, value: recus, "aria-label": "Documents reçus", class: { "docs-avancement--complet": recus === docs.length } })),
      h("ul.taches", docs.map((x) => ligneDocument(d, x)))
    );
  } else {
    corps.append(
      h(
        "div.docs__vide",
        h("p.liste-vide", "Aucun document à obtenir pour l’instant."),
        peutEcrire ? btn("Ajouter la liste habituelle", { petit: true, icone: "plus", onclick: () => ajouterHabituels(d.id) }) : null
      )
    );
  }
  if (peutEcrire) {
    const saisie = h("input.saisie", { type: "text", maxlength: 200, placeholder: "Nouveau document à obtenir…", autocomplete: "off", "aria-label": "Nouveau document à obtenir", "data-focus-id": "dossier-doc" });
    const ajouter = () => {
      const nom = saisie.value.trim();
      if (!nom) return;
      saisie.value = "";
      ecrireDocuments(d.id, (liste) => [...liste, { id: nouvelId(), nom, recu: false }]);
    };
    saisie.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        ajouter();
      }
    });
    noeud.append(h("div.panneau__pied", h("div.docs__ajout", saisie, btn("Ajouter", { icone: "plus", ton: "primaire", onclick: ajouter }))));
  }
  return noeud;
}

// ----- Tâches, factures, historique -----------------------------------------------------------------------------------------------------------
const tachesDuDossier = (d) => actives("taches").filter((t) => t.lie_type === "dossiers" && t.lie_id === d.id);

function blocFactures(d) {
  const lignes = liees("factures", "dossier_id", d.id).slice().sort((a, b) => String(b.date_emission || "9999").localeCompare(String(a.date_emission || "9999")));
  return lignes.length ? panneauLie({ titre: "Factures et devis", lignes: lignes.map((x) => ligneFacture(x)) }) : null;
}

function blocHistorique(d0) {
  let entreprise = null;
  let j = null;
  const conteneur = h("div");
  function monter(d) {
    entreprise = d.entreprise_id || null;
    j = journal({ lieType: "dossiers", lieId: d.id, lie2: entreprise ? { type: "entreprises", id: entreprise } : null, aide: "Notes, appels, courriels et rencontres liés à ce dossier, et les changements de statut." });
    conteneur.replaceChildren(j.noeud);
  }
  monter(d0);
  return {
    noeud: conteneur,
    miseAJour(changes, d) {
      if ((d.entreprise_id || null) !== entreprise) monter(d);
      else if (changes.has("factures")) j.recharger();
    },
  };
}

// ----- Colonne de droite ---------------------------------------------------------------------------------------------------------------------------
function blocDates(d) {
  const def = listeDef([
    ["Date limite de dépôt", d.date_limite ? (avantDepot(d) ? noeudEcheance(d.date_limite) : dateSansAnneeCourante(d.date_limite)) : null],
    ["Déposé le", d.date_depot ? dateSansAnneeCourante(d.date_depot) : null],
    ["Décision prévue", d.date_decision_prevue ? (enAnalyse(d) ? noeudEcheance(d.date_decision_prevue) : dateSansAnneeCourante(d.date_decision_prevue)) : null],
    ["Décision reçue le", d.date_decision ? dateSansAnneeCourante(d.date_decision) : null],
  ]);
  return panneau({ titre: "Dates" }, def.children.length ? def : h("p.muet", "Aucune date. Utilisez « Modifier » pour préciser la date limite de dépôt."));
}

function blocDemande(d) {
  return panneau(
    { titre: "Demande" },
    listeDef([
      ["Programme", d.programme || null],
      ["Organisme", d.organisme || null],
      ["Palier", libelleOption(PALIERS, d.palier) || null],
      ["Type d’aide", libelleOption(TYPES_AIDE, d.type_aide) || null],
      ["N° de dossier", d.numero_dossier || null],
      ["Portail", d.lien_portail ? lienSite(d.lien_portail) : null],
    ])
  );
}

function blocClient(d) {
  const o = d.opportunite_id ? fiche("opportunites", d.opportunite_id) : null;
  const extra = o && !o.supprime ? [["Affaire", h("a.lien-fiche", { href: lienFiche("opportunites", o.id) }, o.titre)]] : [];
  return panneauClient(d, extra);
}

export default creerVueFiche({
  entite: "dossiers",
  liste: { href: "#/dossiers", libelle: "Dossiers de financement" },
  entete: { depend: ["dossiers", "entreprises", "contacts", "config"], dessiner: enteteDossier },
  blocs: [
    { id: "avancement", colonne: "principal", ordre: 0, depend: ["dossiers", "config"], dessiner: blocAvancement },
    { id: "echeance", colonne: "principal", ordre: 1, depend: ["dossiers", "config"], dessiner: avisDepot },
    { id: "refus", colonne: "principal", ordre: 2, depend: ["dossiers", "config"], dessiner: avisRefus },
    { id: "montants", colonne: "principal", ordre: 3, depend: ["dossiers", "config"], dessiner: blocMontants },
    { id: "documents", colonne: "principal", ordre: 4, depend: ["dossiers"], dessiner: blocDocuments },
    {
      id: "taches", colonne: "principal", ordre: 5, depend: ["taches"],
      dessiner: (d) => panneauTaches({ taches: tachesDuDossier(d), lieType: "dossiers", lieId: d.id, placeholder: "Nouvelle tâche pour ce dossier…", focusId: "dossier-ajout" }),
    },
    { id: "dates", colonne: "lateral", ordre: 6, depend: ["dossiers", "config"], dessiner: blocDates },
    { id: "demande", colonne: "lateral", ordre: 7, depend: ["dossiers"], dessiner: blocDemande },
    { id: "client", colonne: "lateral", ordre: 8, depend: ["dossiers", "entreprises", "contacts", "opportunites"], dessiner: blocClient },
    { id: "factures", colonne: "principal", ordre: 9, depend: ["factures"], dessiner: blocFactures },
    { id: "historique", colonne: "principal", ordre: 10, creer: blocHistorique },
    {
      id: "suivi", colonne: "lateral", ordre: 11, depend: ["dossiers", "equipe"],
      dessiner: (d) => {
        const def = listeDef([["Responsable", nomUtilisateur(d.responsable_id) || null]]);
        return def.children.length ? panneau({ titre: "Suivi" }, def) : null;
      },
    },
    { id: "notes", colonne: "lateral", ordre: 12, depend: ["dossiers"], dessiner: (d) => panneauNotes("dossiers", d) },
    { id: "pied", colonne: "lateral", ordre: 13, depend: ["dossiers", "equipe"], dessiner: (d) => piedFiche("dossiers", d) },
  ],
});
