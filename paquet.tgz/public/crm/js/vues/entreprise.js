// =============================================================================
// Fiche d'une entreprise : chiffres clés, contacts, tâches, affaires, dossiers,
// factures et historique, avec les renseignements de l'entreprise à côté.
// =============================================================================
import { h } from "../noyau/dom.js";
import { etat, actives, liees, nomUtilisateur, sourceDe, etapeDe, statutDossierDe, fiche } from "../noyau/etat.js";
import { naviguer } from "../noyau/routeur.js";
import { modifierFiche, supprimerAvecAnnulation, tenter } from "../noyau/ecriture.js";
import { SECTEURS, REGIONS, FORMES_JURIDIQUES } from "../commun/schema.js";
import { argent, argentEntier, nombre, pluriel, nomComplet } from "../commun/format.js";
import { btn, avatar, enTete, menuActions, panneau, listeDef } from "../ui/composants.js";
import { journal } from "../ui/journal.js";
import { lienTelephone, lienSite, puces, libelleOption, soldeDu, etatDocument } from "./aides.js";
import { nouvelleFiche, modifierLaFiche } from "./formulaires.js";
import { creerVueFiche, marquesFiche, panneauLie, panneauTaches, panneauNotes, piedFiche, ligneContact, ligneAffaire, ligneDossier, ligneFacture } from "./fiche.js";

export const depend = ["entreprises", "contacts", "opportunites", "dossiers", "factures", "taches", "evenements", "equipe", "config"];

const nomDe = (f) => f.nom || "Entreprise sans nom";

// ----- Actions -----------------------------------------------------------------------------------------------------------------------------------------
async function archiver(f, archive) {
  await tenter(() => modifierFiche("entreprises", fiche("entreprises", f.id) || f, { archive }), {
    succes: archive ? "Entreprise archivée : elle n’apparaît plus dans la liste." : "Entreprise rétablie dans la liste.", entite: "entreprises",
  });
}

function menuAjouter(f) {
  const liees_ = { entreprise_id: f.id };
  return menuActions({
    libelle: "Ajouter", icone: "plus", ton: "primaire", aria: "Ajouter un contact, une tâche, une affaire, un dossier ou une facture pour cette entreprise",
    elements: [
      { libelle: "Contact", icone: "contacts", onclick: () => nouvelleFiche("contacts", liees_, { naviguer: false }) },
      { libelle: "Tâche", icone: "taches", onclick: () => document.querySelector('[data-focus-id="entreprise-ajout"]')?.focus() },
      { libelle: "Rendez-vous", icone: "calendrier", onclick: () => nouvelleFiche("evenements", { lie_type: "entreprises", lie_id: f.id }) },
      "separateur",
      { libelle: "Affaire", icone: "affaires", onclick: () => nouvelleFiche("opportunites", liees_) },
      { libelle: "Dossier de financement", icone: "dossiers", onclick: () => nouvelleFiche("dossiers", liees_) },
      { libelle: "Facture", icone: "factures", onclick: () => nouvelleFiche("factures", { type: "facture", ...liees_ }) },
      { libelle: "Devis", icone: "document", onclick: () => nouvelleFiche("factures", { type: "devis", ...liees_ }) },
    ],
  });
}

function menuPlus(f) {
  return menuActions({
    aria: "Plus d’actions sur cette entreprise",
    elements: [
      { libelle: f.archive ? "Rétablir dans la liste" : "Archiver", icone: "archiver", onclick: () => archiver(f, !f.archive) },
      "separateur",
      { libelle: "Mettre à la corbeille", icone: "corbeille", danger: true, onclick: () => supprimerAvecAnnulation("entreprises", f.id, { apres: () => naviguer("/entreprises") }) },
    ],
  });
}

// ----- En-tête -----------------------------------------------------------------------------------------------------------------------------------------
function enteteEntreprise(f) {
  const peutEcrire = etat.droits.ecrire;
  const sous = [libelleOption(SECTEURS, f.secteur), f.ville].filter(Boolean).join(", ");
  const actions = [];
  if (f.telephone) actions.push(btn("Appeler", { icone: "appel", href: `tel:${String(f.telephone).replace(/[^\d+]/g, "")}` }));
  if (f.site_web) {
    const site = btn("Site Web", { icone: "externe", href: f.site_web });
    site.target = "_blank";
    site.rel = "noopener noreferrer";
    actions.push(site);
  }
  if (peutEcrire) {
    actions.push(menuAjouter(f));
    actions.push(btn("Modifier", { icone: "modifier", onclick: () => modifierLaFiche("entreprises", fiche("entreprises", f.id) || f) }));
    actions.push(menuPlus(f));
  }
  return enTete({
    retour: { href: "#/entreprises", libelle: "Entreprises" },
    avatar: avatar(nomDe(f), { taille: "l" }),
    titre: nomDe(f),
    apres: marquesFiche(f, { archive: f.archive }),
    sous: sous || null,
    actions,
  });
}

// ----- Chiffres clés ----------------------------------------------------------------------------------------------------------------------
function chiffresCles(f) {
  const affaires = liees("opportunites", "entreprise_id", f.id);
  const dossiers = liees("dossiers", "entreprise_id", f.id);
  const factures = liees("factures", "entreprise_id", f.id);
  if (!affaires.length && !dossiers.length && !factures.length) return null;

  const ouvertes = affaires.filter((o) => etapeDe(o.etape)?.type === "ouverte");
  const honoraires = ouvertes.reduce((n, o) => n + (+o.valeur || 0), 0);
  const enCours = dossiers.filter((d) => {
    const s = statutDossierDe(d.statut);
    return !s || s.type === "en-cours";
  });
  const demande = enCours.reduce((n, d) => n + (+d.montant_demande || 0), 0);
  const accordes = dossiers.filter((d) => +d.montant_obtenu > 0);
  const obtenu = accordes.reduce((n, d) => n + (+d.montant_obtenu || 0), 0);
  const aPayer = factures.filter((x) => soldeDu(x) > 0);
  const solde = aPayer.reduce((n, x) => n + soldeDu(x), 0);
  const enRetard = aPayer.filter((x) => etatDocument(x).cle === "en_retard");

  const item = (titre, valeur, precision, { alerte = false } = {}) =>
    h("div.fiche-chiffres__item", { class: alerte ? "fiche-chiffres__item--alerte" : "" }, h("dt", titre), h("dd", valeur, precision ? h("small", precision) : null));

  return h(
    "dl.fiche-chiffres",
    item("Affaires en cours", nombre(ouvertes.length), honoraires ? `${argentEntier(honoraires)} d’honoraires en vue` : ouvertes.length ? "Honoraires non estimés" : "Aucune affaire ouverte"),
    item("Dossiers en cours", nombre(enCours.length), demande ? `${argentEntier(demande)} demandés` : enCours.length ? "Montants non précisés" : "Aucun dossier en cours"),
    item("Aide obtenue", obtenu ? argentEntier(obtenu) : "—", accordes.length ? pluriel(accordes.length, "dossier accordé", "dossiers accordés") : "Aucune aide accordée"),
    item("À encaisser", solde ? argent(solde) : "—", enRetard.length ? `${pluriel(enRetard.length, "facture en retard", "factures en retard")}` : aPayer.length ? pluriel(aPayer.length, "facture à payer", "factures à payer") : "Rien à encaisser", { alerte: enRetard.length > 0 })
  );
}

// ----- Blocs --------------------------------------------------------------------------------------------------------------------------------------------
function tachesDeLEntreprise(f) {
  const ids = new Map(
    ["opportunites", "dossiers", "factures"].map((entite) => [entite, new Set(liees(entite, "entreprise_id", f.id).map((x) => x.id))])
  );
  return actives("taches").filter((t) => (t.lie_type === "entreprises" && t.lie_id === f.id) || ids.get(t.lie_type)?.has(t.lie_id));
}

const parOuverture = (a, b) => {
  const oa = etapeDe(a.etape)?.type === "ouverte" ? 0 : 1;
  const ob = etapeDe(b.etape)?.type === "ouverte" ? 0 : 1;
  return oa - ob || String(b.maj || "").localeCompare(String(a.maj || ""));
};

function blocHistorique(f) {
  const j = journal({ lieType: "entreprises", lieId: f.id, aide: "Notes, appels, courriels et rencontres liés à cette entreprise et à ses contacts, du plus récent au plus ancien." });
  return {
    noeud: j.noeud,
    miseAJour(changes) {
      if (["opportunites", "dossiers", "factures", "contacts"].some((c) => changes.has(c))) j.recharger();
    },
  };
}

const ligneRenseignement = (f) =>
  listeDef([
    ["NEQ", f.neq || null],
    ["Secteur", libelleOption(SECTEURS, f.secteur) || null],
    ["Forme juridique", libelleOption(FORMES_JURIDIQUES, f.forme) || null],
    ["Employés", f.employes !== undefined && f.employes !== null ? nombre(f.employes) : null],
    ["Fondée en", f.annee_fondation || null],
    ["Chiffre d’affaires", f.chiffre_affaires ? argentEntier(f.chiffre_affaires) : null],
    ["Téléphone", f.telephone ? lienTelephone(f.telephone) : null],
    ["Site Web", f.site_web ? lienSite(f.site_web) : null],
    ["Adresse", [f.adresse, [f.ville, f.code_postal].filter(Boolean).join(" ")].filter(Boolean).join(", ") || null],
    ["Région", libelleOption(REGIONS, f.region) || null],
  ]);

export default creerVueFiche({
  entite: "entreprises",
  liste: { href: "#/entreprises", libelle: "Entreprises" },
  entete: { depend: ["entreprises"], dessiner: enteteEntreprise },
  blocs: [
    { id: "chiffres", colonne: "principal", ordre: 0, depend: ["opportunites", "dossiers", "factures", "config"], dessiner: chiffresCles },
    {
      id: "renseignements", colonne: "lateral", ordre: 1, depend: ["entreprises"],
      dessiner: (f) => {
        const def = ligneRenseignement(f);
        return panneau({ titre: "Renseignements" }, def.children.length ? def : h("p.muet", "Aucun renseignement. Utilisez « Modifier » pour compléter la fiche."));
      },
    },
    {
      id: "contacts", colonne: "principal", ordre: 2, depend: ["contacts"],
      dessiner: (f) => {
        const contacts = liees("contacts", "entreprise_id", f.id)
          .filter((c) => !c.archive && !c.anonymise)
          .sort((a, b) => nomComplet(a).localeCompare(nomComplet(b), "fr", { sensitivity: "base" }));
        const actions = etat.droits.ecrire
          ? btn("Nouveau contact", { petit: true, ton: "discret", icone: "plus", onclick: () => nouvelleFiche("contacts", { entreprise_id: f.id }, { naviguer: false }) })
          : null;
        return panneauLie({ titre: "Contacts", lignes: contacts.map(ligneContact), vide: "Aucun contact pour cette entreprise.", actions });
      },
    },
    {
      id: "taches", colonne: "principal", ordre: 3, depend: ["taches", "opportunites", "dossiers", "factures"],
      dessiner: (f) =>
        panneauTaches({
          taches: tachesDeLEntreprise(f), lieType: "entreprises", lieId: f.id, placeholder: `Nouvelle tâche pour ${f.nom || "cette entreprise"}…`, focusId: "entreprise-ajout",
          estDirecte: (t) => t.lie_type === "entreprises" && t.lie_id === f.id,
        }),
    },
    {
      id: "affaires", colonne: "principal", ordre: 4, depend: ["opportunites", "config"],
      dessiner: (f) => {
        const lignes = liees("opportunites", "entreprise_id", f.id).slice().sort(parOuverture);
        return lignes.length ? panneauLie({ titre: "Affaires", lignes: lignes.map((o) => ligneAffaire(o)) }) : null;
      },
    },
    {
      id: "dossiers", colonne: "principal", ordre: 5, depend: ["dossiers", "config"],
      dessiner: (f) => {
        const lignes = liees("dossiers", "entreprise_id", f.id).slice().sort((a, b) => String(b.maj || "").localeCompare(String(a.maj || "")));
        return lignes.length ? panneauLie({ titre: "Dossiers de financement", lignes: lignes.map((d) => ligneDossier(d)) }) : null;
      },
    },
    {
      id: "factures", colonne: "principal", ordre: 6, depend: ["factures"],
      dessiner: (f) => {
        const lignes = liees("factures", "entreprise_id", f.id).slice().sort((a, b) => String(b.date_emission || "9999").localeCompare(String(a.date_emission || "9999")));
        return lignes.length ? panneauLie({ titre: "Factures et devis", lignes: lignes.map((x) => ligneFacture(x)) }) : null;
      },
    },
    { id: "historique", colonne: "principal", ordre: 7, creer: blocHistorique },
    {
      id: "suivi", colonne: "lateral", ordre: 8, depend: ["entreprises", "equipe", "config"],
      dessiner: (f) => {
        const def = listeDef([
          ["Responsable", nomUtilisateur(f.responsable_id) || null],
          ["Provenance", sourceDe(f.source) || null],
          ["Étiquettes", f.etiquettes?.length ? puces(f.etiquettes) : null],
        ]);
        return def.children.length ? panneau({ titre: "Suivi" }, def) : null;
      },
    },
    { id: "notes", colonne: "lateral", ordre: 9, depend: ["entreprises"], dessiner: (f) => panneauNotes("entreprises", f) },
    { id: "pied", colonne: "lateral", ordre: 10, depend: ["entreprises", "equipe"], dessiner: (f) => piedFiche("entreprises", f) },
  ],
});
