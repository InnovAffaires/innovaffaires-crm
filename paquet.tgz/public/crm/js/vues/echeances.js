// =============================================================================
// Les éléments datés du CRM : dates limites de dépôt, décisions attendues,
// factures à échéance, rendez-vous et tâches datées. Une seule définition,
// partagée par l'Accueil (la règle des échéances) et le Calendrier.
//
// Chaque élément : { id, type, date, heure, titre, detail, href, entite, ficheId }
//   type  : "depot" | "decision" | "facture" | "rdv" | "tache"
//   date  : « AAAA-MM-JJ » (heure de Toronto) ; heure : « HH:MM » ou ""
// =============================================================================
import { actives, nomFiche, statutDossierDe } from "../noyau/etat.js";
import { lienFiche } from "../noyau/routeur.js";
import { partiesLocales } from "../commun/dates.js";
import { argent } from "../commun/format.js";
import { soldeDu } from "./aides.js";

/** Dates limites de dépôt et décisions attendues des dossiers encore en traitement. */
export function echeancesDossiers() {
  const sortie = [];
  for (const d of actives("dossiers")) {
    if (statutDossierDe(d.statut)?.type !== "en-cours") continue;
    const client = nomFiche("entreprises", d.entreprise_id);
    const base = { heure: "", titre: d.titre, detail: client, href: lienFiche("dossiers", d.id), entite: "dossiers", ficheId: d.id };
    if (d.date_limite && !d.date_depot) sortie.push({ ...base, id: `depot-${d.id}`, type: "depot", date: d.date_limite });
    if (d.date_decision_prevue && d.date_depot && !d.date_decision) sortie.push({ ...base, id: `decision-${d.id}`, type: "decision", date: d.date_decision_prevue });
  }
  return sortie;
}

/** Factures (pas les devis) dont il reste un solde à encaisser, à leur date d'échéance. */
export function echeancesFactures() {
  const sortie = [];
  for (const f of actives("factures")) {
    if (f.type !== "facture" || !f.date_echeance) continue;
    const solde = soldeDu(f);
    if (solde <= 0) continue;
    sortie.push({
      id: `facture-${f.id}`, type: "facture", date: f.date_echeance, heure: "", titre: `${f.numero || "Facture"} — ${nomFiche("entreprises", f.entreprise_id)}`,
      detail: argent(solde), href: lienFiche("factures", f.id), entite: "factures", ficheId: f.id,
    });
  }
  return sortie;
}

/** Rendez-vous, au jour (et à l'heure) de leur début. Un rendez-vous sur plusieurs jours figure à son premier jour. */
export function rendezVous() {
  const sortie = [];
  for (const ev of actives("evenements")) {
    const ms = Date.parse(ev.debut);
    if (Number.isNaN(ms)) continue;
    const debut = partiesLocales(ms);
    const fin = ev.fin && !Number.isNaN(Date.parse(ev.fin)) ? partiesLocales(Date.parse(ev.fin)) : null;
    sortie.push({
      id: `rdv-${ev.id}`, type: "rdv", date: debut.date, heure: ev.journee_entiere ? "" : debut.heure, heureFin: !ev.journee_entiere && fin && fin.date === debut.date ? fin.heure : "",
      jusquau: fin && fin.date > debut.date ? fin.date : "", titre: ev.titre, detail: ev.lieu || "",
      href: `#/calendrier?date=${debut.date}&evenement=${encodeURIComponent(ev.id)}`, entite: "evenements", ficheId: ev.id,
    });
  }
  return sortie;
}

/** Tâches à faire qui ont une échéance. */
export function tachesDatees() {
  const sortie = [];
  for (const t of actives("taches")) {
    if (!t.echeance || t.statut === "fait") continue;
    sortie.push({ id: `tache-${t.id}`, type: "tache", date: t.echeance, heure: t.heure || "", titre: t.titre, detail: "", href: "", entite: "taches", ficheId: t.id });
  }
  return sortie;
}
