// =============================================================================
// Petites fonctions d'affichage partagées par les écrans : états, échéances,
// liens de courriel et de téléphone, étiquettes.
// =============================================================================
import { h } from "../noyau/dom.js";
import { icone } from "../noyau/icones.js";
import { aujourdhui, differenceJours, echeanceOuvrable, heuresOuvrablesEcoulees, partiesLocales } from "../commun/dates.js";
import { dateCourte, dateLongue, jourMois, echeanceRelative, telephone as fmtTel, argent, tronquer, ilYa, heure } from "../commun/format.js";
import { etatFacture, calculerTotaux } from "../commun/calculs.js";
import { STATUTS_FACTURE, STATUTS_DEVIS } from "../commun/schema.js";
import { etat, maintenant, statutDossierDe, etapeDe, fiche, libelleFiche } from "../noyau/etat.js";
import { lienFiche } from "../noyau/routeur.js";
import { pastille } from "../ui/composants.js";

// ----- Factures et devis -----------------------------------------------------------------------------------------
const TONS_FACTURE = { brouillon: "neutre", envoyee: "info", partielle: "attention", payee: "ok", en_retard: "erreur", annulee: "neutre" };
const TONS_DEVIS = { brouillon: "neutre", envoyee: "info", acceptee: "ok", refusee: "erreur", expiree: "attention" };

/** { cle, libelle, ton } : l'état d'affichage d'une facture ou d'un devis. */
export function etatDocument(f, ref = aujourdhui()) {
  const cle = etatFacture(f, ref);
  if (f.type === "devis") return { cle, libelle: STATUTS_DEVIS.find((s) => s.id === cle)?.libelle || cle, ton: TONS_DEVIS[cle] || "neutre" };
  return { cle, libelle: STATUTS_FACTURE.find((s) => s.id === cle)?.libelle || cle, ton: TONS_FACTURE[cle] || "neutre" };
}
export const pastilleEtatDocument = (f) => {
  const e = etatDocument(f);
  return pastille(e.libelle, e.ton);
};
export const totauxDe = (f) => f.totaux || calculerTotaux(f.lignes || [], f.taux, f.paiements || []);

/** Solde restant à payer d'une facture émise (0 pour un devis, un brouillon ou une facture annulée). */
export function soldeDu(f) {
  if (f.type === "devis" || f.statut === "brouillon" || f.statut === "annulee") return 0;
  return Math.max(0, totauxDe(f).solde);
}

// ----- Dossiers et affaires ----------------------------------------------------------------------------------------
const TONS_STATUT_DOSSIER = { "en-cours": "info", accepte: "ok", refuse: "erreur", termine: "neutre" };
export function pastilleStatutDossier(id) {
  const s = statutDossierDe(id);
  return pastille(s?.nom || id || "—", TONS_STATUT_DOSSIER[s?.type] || "neutre");
}
const TONS_ETAPE = { ouverte: "info", gagnee: "ok", perdue: "erreur" };
export function pastilleEtape(id) {
  const e = etapeDe(id);
  return pastille(e?.nom || id || "—", TONS_ETAPE[e?.type] || "neutre");
}

// ----- Dates et échéances ---------------------------------------------------------------------------------------------
/** Ton d'une échéance : erreur (dépassée), attention (≤ 3 jours), neutre. `fait` neutralise (tâche faite). */
export function tonEcheance(date, { fait = false, ref = aujourdhui() } = {}) {
  if (!date || fait) return "neutre";
  const n = differenceJours(ref, date);
  if (n < 0) return "erreur";
  if (n <= 3) return "attention";
  return "neutre";
}

/** « 12 oct. » pour l'année en cours, « 12 oct. 2027 » sinon. */
export function dateSansAnneeCourante(date, ref = aujourdhui()) {
  if (!date) return "";
  return String(date).slice(0, 4) === ref.slice(0, 4) ? jourMois(date) : dateCourte(date);
}

/** Date courte suivie d'un repère relatif (« dans 3 jours »), colorée selon l'urgence. */
export function noeudEcheance(date, { fait = false } = {}) {
  if (!date) return h("span.muet", "—");
  const ton = tonEcheance(date, { fait });
  return h("span.echeance", { class: `echeance--${ton}` }, h("span.echeance__date", dateSansAnneeCourante(date)), fait ? null : h("small.echeance__rel", echeanceRelative(date)));
}

// ----- Coordonnées -----------------------------------------------------------------------------------------------------------
export function lienCourriel(adresse) {
  if (!adresse) return h("span.muet", "—");
  // Une coupure possible après l'arobase évite de casser l'adresse au milieu d'un mot dans une colonne étroite.
  const [local, ...domaine] = String(adresse).split("@");
  const texte = domaine.length ? [`${local}@`, h("wbr"), domaine.join("@")] : adresse;
  return h("a.lien-discret", { href: `mailto:${adresse}` }, texte);
}
export function lienTelephone(tel) {
  if (!tel) return h("span.muet", "—");
  const chiffres = String(tel).replace(/[^\d+]/g, "");
  return h("a.lien-discret.tel", { href: `tel:${chiffres}` }, fmtTel(tel));
}
export function lienSite(url) {
  if (!url) return h("span.muet", "—");
  let texte = url;
  try {
    texte = new URL(url).hostname.replace(/^www\./, "");
  } catch {
    /* adresse brute */
  }
  return h("a.lien-discret", { href: url, target: "_blank", rel: "noopener noreferrer" }, texte, icone("externe", "ic--p"));
}

export function puces(liste = []) {
  if (!liste?.length) return h("span.muet", "—");
  return h("span.etiquettes", liste.map((e) => h("span.etiquette", e)));
}

export const montant = (n) => (n === undefined || n === null || n === "" ? h("span.muet", "—") : argent(n));

/** Libellé d'une option d'une liste fixe. */
export const libelleOption = (liste, id) => liste.find((o) => o.id === id)?.libelle || id || "";

// ----- Liens entre fiches ---------------------------------------------------------------------------------------------------------
export const ICONE_ENTITE = {
  contacts: "contacts", entreprises: "entreprises", opportunites: "affaires", dossiers: "dossiers", factures: "factures", demandes: "demandes",
  taches: "taches", evenements: "calendrier",
};

/** « lundi 12 octobre 2026, à 14 h 30 » à partir d'un instant (ms). */
export const dateHeure = (ms) => (Number.isFinite(ms) ? `${dateLongue(partiesLocales(ms).date)}, à ${heure(ms)}` : "");

/** « 14:30 » → « 14 h 30 ». */
export const heureTexte = (hhmm) => (/^\d{2}:\d{2}$/.test(hhmm || "") ? `${+hhmm.slice(0, 2)} h ${hhmm.slice(3)}` : "");

/** Lien (avec icône) vers la fiche désignée par lie_type / lie_id ; null si la fiche n'existe pas. */
export function lienLie(lieType, lieId, { court = false } = {}) {
  const f = fiche(lieType, lieId);
  if (!f) return null;
  const nom = tronquer(libelleFiche(lieType, f), court ? 28 : 46);
  if (f.supprime) return h("span.lien-lie.lien-perdu", icone(ICONE_ENTITE[lieType] || "lien", "ic--p"), h("span", `${nom} (corbeille)`));
  return h("a.lien-lie", { href: lienFiche(lieType, lieId) }, icone(ICONE_ENTITE[lieType] || "lien", "ic--p"), h("span", nom));
}

// ----- Délai de réponse promis aux demandes du site -----------------------------------------------------------------------
const HEURES_ALERTE = 8; // une réponse due dans moins de 8 heures ouvrables passe en « attention »

/** Instant (ms) où la réponse à une demande est due, selon le délai promis (en heures ouvrables). */
export function echeanceReponse(d) {
  return echeanceOuvrable(Date.parse(d.recu), etat.config.delai_reponse_heures ?? 48, etat.config.jours_feries_supplementaires || []);
}

/**
 * { ton, texte, court, enRetard, due } du délai de réponse promis ; null si la demande a déjà reçu une réponse.
 *   texte : phrase complète (« Réponse en retard : due il y a 5 jours »)   court : pour une pastille (« Due il y a 5 jours »)
 */
export function delaiReponse(d, maint = maintenant()) {
  if (d.reponse_le) return null;
  const due = echeanceReponse(d);
  const quand = ilYa(due, maint);
  if (due < maint) return { ton: "erreur", texte: `Réponse en retard : due ${quand}`, court: `Due ${quand}`, enRetard: true, due };
  const restantes = heuresOuvrablesEcoulees(maint, due, etat.config.jours_feries_supplementaires || []);
  return { ton: restantes <= HEURES_ALERTE ? "attention" : "neutre", texte: `Réponse due ${quand}`, court: `Due ${quand}`, enRetard: false, due };
}
