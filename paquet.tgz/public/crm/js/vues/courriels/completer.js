// =============================================================================
// Courriels → Fiches à compléter : des contacts du CRM dont une signature (ou un échange) donne un renseignement qui manque.
// On coche ce qu'on veut ajouter ; rien de ce qui est déjà écrit dans la fiche n'est remplacé.
// =============================================================================
import { h, remplir } from "../../noyau/dom.js";
import { ErreurApi } from "../../noyau/api.js";
import { naviguer, lienFiche } from "../../noyau/routeur.js";
import { pluriel } from "../../commun/format.js";
import { completerFiches, ecarterPropositions } from "../../noyau/classement.js";
import { btn, panneau, avis, etatVide } from "../../ui/composants.js";
import { toast, toastErreur } from "../../ui/toast.js";
import { confirmer } from "../../ui/dialogue.js";
import { caseACocher, libelleChamp, ORDRE_CHAMPS, noteEntreprise, texteEchanges, bilanResultats } from "./commun.js";

const valeurAffichee = (champ, v) => (champ === "entreprise" ? v.nom : v);

/** Ce qu'on demande au serveur d'écrire pour un champ proposé. */
function valeurAEnvoyer(champ, v) {
  if (champ !== "entreprise") return v;
  return v.existante && v.id ? { id: v.id } : { nom: v.nom };
}

export function monterCompleter(P) {
  const m = P.memoire;
  const vue = P.vue;
  const toutes = vue.completer || [];
  if (!m.has("decoches")) m.set("decoches", new Map());
  const decoches = m.get("decoches"); // adresse → ensemble des champs que la personne a décochés
  const presentes = new Set(toutes.map((c) => c.adresse));
  for (const a of [...decoches.keys()]) if (!presentes.has(a)) decoches.delete(a);

  const racine = h("div.pile");
  let occupe = false;

  const champsCoches = (c) => Object.keys(c.champs).filter((k) => !decoches.get(c.adresse)?.has(k));
  const demande = (c) => ({ adresse: c.adresse, champs: Object.fromEntries(champsCoches(c).map((k) => [k, valeurAEnvoyer(k, c.champs[k])])) });

  function occuper(v) {
    occupe = v;
    racine.toggleAttribute("aria-busy", v);
    for (const b of racine.querySelectorAll("button, input")) {
      if (v) {
        if (!b.disabled) {
          b.disabled = true;
          b.dataset.occupe = "1";
        }
      } else if (b.dataset.occupe) {
        b.disabled = false;
        delete b.dataset.occupe;
      }
    }
  }

  async function completer(lignes) {
    const demandes = lignes.filter((c) => champsCoches(c).length).map(demande);
    if (occupe || !demandes.length) return;
    occuper(true);
    try {
      const { resultats, erreur } = await completerFiches(demandes);
      const bilan = bilanResultats(resultats, { verbe: "complement" });
      const morceaux = [];
      if (bilan.faits) morceaux.push(`${pluriel(bilan.faits, "fiche complétée", "fiches complétées")}.`);
      morceaux.push(...bilan.messages);
      if (erreur) morceaux.push(erreur.message);
      const options = { ton: erreur ? "info" : "ok", duree: 9000 };
      if (bilan.faits) options.action = { libelle: "Voir les ajouts", onclick: () => naviguer("/courriels/ajouts") };
      toast(morceaux.join(" ") || "Rien n’a été complété.", options);
    } catch (e) {
      if (!(e instanceof ErreurApi)) throw e;
      toastErreur(e);
    } finally {
      occuper(false);
      P.actualiser();
    }
  }

  async function ecarter(adresses) {
    if (occupe || !adresses.length) return;
    occuper(true);
    try {
      const n = await ecarterPropositions("completer", adresses);
      toast(`${pluriel(n, "proposition écartée", "propositions écartées")}.`, { ton: "info" });
    } catch (e) {
      if (!(e instanceof ErreurApi)) throw e;
      toastErreur(e);
    } finally {
      occuper(false);
      P.actualiser();
    }
  }

  function ligne(c) {
    const boutonCompleter = btn("Compléter la fiche", { ton: "primaire", petit: true, icone: "coche", aria: `Compléter la fiche de ${c.contact.nom}`, onclick: () => completer([c]) });
    const majBouton = () => {
      boutonCompleter.disabled = occupe || !champsCoches(c).length;
    };
    const cles = ORDRE_CHAMPS.filter((k) => k in c.champs);
    const champs = cles.map((k) => {
      const v = c.champs[k];
      const case_ = caseACocher({
        libelle: `Ajouter le champ ${libelleChamp(k)} à la fiche de ${c.contact.nom}`, texte: libelleChamp(k), focusId: `champ:${c.adresse}:${k}`,
        coche: !decoches.get(c.adresse)?.has(k),
        surChangement: (coche) => {
          const s = decoches.get(c.adresse) || new Set();
          if (coche) s.delete(k);
          else s.add(k);
          if (s.size) decoches.set(c.adresse, s);
          else decoches.delete(c.adresse);
          majBouton();
        },
      });
      return h("li.prop__champ", case_.noeud, h("span.prop__valeur", valeurAffichee(k, v), k === "entreprise" ? h("small.muet", ` (${noteEntreprise(v)})`) : null));
    });
    majBouton();
    return h(
      "li.prop.prop--completer",
      h(
        "div.prop__texte",
        h("p.prop__nom", h("a.lien-fiche", { href: lienFiche("contacts", c.contact.id) }, c.contact.nom), h("span.prop__courriel.muet", c.adresse)),
        h("ul.prop__champs", champs),
        h("p.prop__echanges.muet.petit", texteEchanges(c), c.objet ? ` — « ${c.objet} »` : "")
      ),
      h("div.prop__actions", boutonCompleter, btn("Écarter", { petit: true, ton: "discret", icone: "cacher", titre: `Ne plus proposer de compléter la fiche de ${c.contact.nom}`, aria: `Écarter : ne plus proposer de compléter la fiche de ${c.contact.nom}`, onclick: () => ecarter([c.adresse]) }))
    );
  }

  if (!toutes.length) {
    racine.append(
      etatVide({
        icone: "liste-verif",
        titre: vue.analyse ? "L’analyse est en cours" : "Aucune fiche à compléter",
        texte: vue.analyse
          ? "Les renseignements trouvés apparaîtront ici dès que possible."
          : "Quand une signature donne un téléphone, une fonction ou une entreprise qui manque à un de vos contacts, la proposition apparaît ici.",
      })
    );
    return { noeud: racine };
  }

  remplir(
    racine,
    vue.completer_total > toutes.length
      ? avis({ ton: "info", texte: `Les ${toutes.length} premières fiches sur ${vue.completer_total} sont affichées. Traitez celles-ci pour voir les suivantes.` })
      : null,
    panneau(
      {
        titre: "Fiches à compléter", compteur: String(vue.completer_total ?? toutes.length), classe: "panneau--liste",
        sous: "Seuls les champs vides sont proposés. Décochez ce que vous ne voulez pas ajouter.",
        actions: btn(`Compléter les ${toutes.length > 1 ? `${toutes.length} fiches` : "fiche"}`, {
          icone: "coche",
          onclick: async () => {
            const ok = await confirmer({
              titre: "Compléter toutes ces fiches ?",
              message: `Les renseignements cochés seront ajoutés à ${pluriel(toutes.length, "fiche", "fiches")}. Rien de ce qui est déjà écrit ne sera remplacé, et vous pourrez annuler chaque ajout pendant 14 jours.`,
              libelleConfirmer: "Compléter",
            });
            if (ok) await completer(toutes);
          },
        }),
      },
      h("ul.prop-liste", toutes.map(ligne))
    )
  );
  return { noeud: racine };
}
