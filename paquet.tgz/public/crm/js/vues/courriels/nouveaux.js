// =============================================================================
// Courriels → Nouvelles personnes : les correspondants qui ne sont pas encore dans le CRM.
// On peut ajouter chaque personne (telle quelle ou corrigée), en ajouter plusieurs d'un coup, ou l'écarter pour de bon.
// =============================================================================
import { h, remplir } from "../../noyau/dom.js";
import { ErreurApi } from "../../noyau/api.js";
import { naviguer } from "../../noyau/routeur.js";
import { pluriel } from "../../commun/format.js";
import { ajouterContacts, ecarterPropositions } from "../../noyau/classement.js";
import { btn, panneau, pastille, avis, etatVide } from "../../ui/composants.js";
import { toast, toastErreur } from "../../ui/toast.js";
import { caseACocher, nomPersonne, texteEchanges, noteEntreprise, entreprisePourAjout, bilanResultats } from "./commun.js";
import { dialogueAjout } from "./modifier.js";

/** La demande d'ajout d'une proposition, sans correction : le serveur complète avec ce qu'il a repéré. */
function chargeAjout(p) {
  const c = { adresse: p.adresse };
  const entreprise = entreprisePourAjout(p.entreprise);
  if (entreprise) c.entreprise = entreprise;
  return c;
}

export function monterNouveaux(P) {
  const m = P.memoire;
  const vue = P.vue;
  const tous = vue.nouveaux || [];
  const recommandees = tous.filter((p) => p.recommande);
  if (!m.has("sel_nouveaux")) m.set("sel_nouveaux", new Set());
  const sel = m.get("sel_nouveaux");
  const existantes = new Set(tous.map((p) => p.adresse));
  for (const a of [...sel]) if (!existantes.has(a)) sel.delete(a);

  // Sans choix de la personne : les recommandées d'abord, s'il y a de quoi trier.
  const choix = m.get("filtre_nouveaux") || "auto";
  const peutFiltrer = recommandees.length > 0 && recommandees.length < tous.length;
  const filtre = !peutFiltrer ? "toutes" : choix === "auto" ? "recommandees" : choix;
  const visibles = filtre === "recommandees" ? recommandees : tous;

  const racine = h("div.pile");
  let occupe = false;

  /** Bloque les boutons pendant un appel au serveur (la page est redessinée ensuite). */
  function occuper(v) {
    occupe = v;
    racine.toggleAttribute("aria-busy", v);
    for (const b of racine.querySelectorAll("button, input")) {
      if (v) {
        if (!b.disabled) {
          b.disabled = true;
          b.dataset.occupe = "1";
        }
      } else if (b.dataset.occupe) {
        b.disabled = false;
        delete b.dataset.occupe;
      }
    }
  }

  async function ajouter(charges, adresses) {
    if (occupe || !charges.length) return;
    occuper(true);
    try {
      const { resultats, erreur } = await ajouterContacts(charges);
      const bilan = bilanResultats(resultats, { verbe: "ajout" });
      for (const a of adresses) sel.delete(a);
      const morceaux = [];
      if (bilan.faits) morceaux.push(`${pluriel(bilan.faits, "personne ajoutée", "personnes ajoutées")} à vos contacts.`);
      morceaux.push(...bilan.messages);
      if (erreur) morceaux.push(erreur.message);
      if (bilan.faits) toast(morceaux.join(" "), { ton: erreur ? "info" : "ok", duree: 9000, action: { libelle: "Voir les ajouts", onclick: () => naviguer("/courriels/ajouts") } });
      else toast(morceaux.join(" ") || "Rien n’a été ajouté.", { ton: erreur || bilan.messages.length ? "info" : "ok" });
    } catch (e) {
      if (!(e instanceof ErreurApi)) throw e;
      toastErreur(e);
    } finally {
      occuper(false);
      P.actualiser();
    }
  }

  async function ecarter(adresses) {
    if (occupe || !adresses.length) return;
    occuper(true);
    try {
      const n = await ecarterPropositions("nouveaux", adresses);
      for (const a of adresses) sel.delete(a);
      toast(`${pluriel(n, "personne écartée", "personnes écartées")} : ${n > 1 ? "elles ne seront plus proposées" : "elle ne sera plus proposée"}. Vous pouvez les reproposer dans « Réglages ».`, { ton: "info", duree: 8000 });
    } catch (e) {
      if (!(e instanceof ErreurApi)) throw e;
      toastErreur(e);
    } finally {
      occuper(false);
      P.actualiser();
    }
  }

  async function modifierPuisAjouter(p) {
    const charge = await dialogueAjout(p);
    if (charge) await ajouter([charge], [p.adresse]);
  }

  // ----- Barre d'actions groupées ----------------------------------------------------------------------------------------------
  const compte = h("span.prop-barre__compte", { role: "status" });
  const boutonAjouter = btn("Ajouter la sélection", { ton: "primaire", icone: "ajout-utilisateur", onclick: () => ajouterSelection() });
  const boutonEcarter = btn("Écarter la sélection", { icone: "cacher", onclick: () => ecarter([...sel]) });
  const toutes = caseACocher({
    libelle: "Sélectionner toutes les personnes affichées", texte: "Tout sélectionner", focusId: "tout",
    coche: false,
    surChangement: (v) => {
      for (const p of visibles) {
        if (v) sel.add(p.adresse);
        else sel.delete(p.adresse);
      }
      for (const cb of racine.querySelectorAll("input[data-case-ligne]")) cb.checked = v;
      majBarre();
    },
  });

  function ajouterSelection() {
    const choisies = visibles.filter((p) => sel.has(p.adresse));
    return ajouter(choisies.map(chargeAjout), choisies.map((p) => p.adresse));
  }

  function majBarre() {
    const n = visibles.filter((p) => sel.has(p.adresse)).length;
    compte.textContent = n ? pluriel(n, "personne sélectionnée", "personnes sélectionnées") : "";
    boutonAjouter.querySelector("span").textContent = n > 1 ? `Ajouter la sélection (${n})` : "Ajouter la sélection";
    boutonAjouter.disabled = occupe || !n;
    boutonEcarter.disabled = occupe || !n;
    toutes.cb.checked = n > 0 && n === visibles.length;
    toutes.cb.indeterminate = n > 0 && n < visibles.length;
  }

  const segments = peutFiltrer
      ? h(
          "div.segments",
          { role: "group", "aria-label": "Personnes à afficher" },
          [["recommandees", `Recommandées (${recommandees.length})`], ["toutes", `Toutes (${tous.length})`]].map(([id, libelle]) =>
            h("button.segments__bouton", {
              type: "button", "aria-pressed": String(filtre === id),
              onclick: () => {
                m.set("filtre_nouveaux", id);
                P.actualiser();
              },
            }, libelle)
          )
        )
      : null;

  // ----- Les lignes -----------------------------------------------------------------------------------------------------------------
  function ligne(p) {
    const nom = nomPersonne(p) || p.adresse;
    const case_ = caseACocher({
      libelle: `Sélectionner ${nom}`, coche: sel.has(p.adresse), focusId: `sel:${p.adresse}`,
      surChangement: (v) => {
        if (v) sel.add(p.adresse);
        else sel.delete(p.adresse);
        majBarre();
      },
    });
    case_.cb.dataset.caseLigne = "1";

    const coordonnees = [h("span.prop__courriel", p.adresse)];
    if (p.titre) coordonnees.push(h("span", p.titre, p.titre_sur ? null : h("small.muet", " (à vérifier)")));
    if (p.entreprise) coordonnees.push(h("span", p.entreprise.nom, h("small.muet", ` (${noteEntreprise(p.entreprise)})`)));
    if (p.telephone) coordonnees.push(h("span", p.telephone));
    if (p.mobile) coordonnees.push(h("span", `${p.mobile} `, h("small.muet", "(cellulaire)")));

    return h(
      "li.prop",
      case_.noeud,
      h(
        "div.prop__texte",
        h("p.prop__nom", h("strong", nom), p.incertain ? pastille("Nom à vérifier", "attention") : null, p.generique ? pastille("Adresse générale", "neutre") : null),
        h("p.prop__coord", coordonnees),
        h("p.prop__echanges.muet.petit", texteEchanges(p), p.objet ? ` — « ${p.objet} »` : "")
      ),
      h(
        "div.prop__actions",
        btn("Ajouter", { ton: "primaire", petit: true, icone: "ajout-utilisateur", titre: `Ajouter ${nom} à vos contacts`, onclick: () => ajouter([chargeAjout(p)], [p.adresse]) }),
        btn("Modifier…", { petit: true, icone: "modifier", titre: `Corriger les renseignements de ${nom} avant de l’ajouter`, onclick: () => modifierPuisAjouter(p) }),
        btn("Écarter", { petit: true, ton: "discret", icone: "cacher", titre: `Ne plus proposer ${nom}`, onclick: () => ecarter([p.adresse]) })
      )
    );
  }

  // ----- Assemblage -----------------------------------------------------------------------------------------------------------------
  if (!tous.length) {
    const enCours = !!vue.analyse;
    racine.append(
      etatVide({
        icone: "contacts",
        titre: enCours ? "L’analyse est en cours" : vue.derniere ? "Aucune nouvelle personne à ajouter" : "Pas encore d’analyse terminée",
        texte: enCours
          ? "Les personnes trouvées apparaîtront ici dès que possible."
          : vue.derniere
            ? `Les personnes avec qui vous échangez sont déjà dans votre CRM${vue.ignores ? `, ou ont été écartées (${vue.ignores})` : ""}. Les nouveaux correspondants apparaîtront ici après la prochaine analyse.`
            : "Cliquez sur « Analyser maintenant » pour lire votre boîte Gmail.",
      })
    );
    return { noeud: racine };
  }

  remplir(
    racine,
    vue.nouveaux_total > tous.length
      ? avis({ ton: "info", texte: `Les ${tous.length} premières propositions sur ${vue.nouveaux_total} sont affichées. Ajoutez ou écartez celles-ci pour voir les suivantes.` })
      : null,
    panneau(
      {
        titre: "Nouvelles personnes", compteur: String(vue.nouveaux_total ?? tous.length), classe: "panneau--liste",
        sous: "Des gens avec qui vous échangez et qui ne sont pas encore dans le CRM. Rien n’est ajouté avant votre clic.",
        actions: segments,
      },
      h("div.prop-barre", toutes.noeud, compte, h("div.prop-barre__actions", boutonAjouter, boutonEcarter)),
      h("ul.prop-liste", visibles.map(ligne))
    )
  );
  majBarre();
  return { noeud: racine };
}
