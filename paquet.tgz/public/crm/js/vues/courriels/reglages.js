// =============================================================================
// Courriels → Réglages : mode (je vérifie / automatique), période lue, nouvelle lecture, et arrêt complet avec effacement.
// =============================================================================
import { h, idUnique } from "../../noyau/dom.js";
import { icone } from "../../noyau/icones.js";
import { ErreurApi } from "../../noyau/api.js";
import { naviguer } from "../../noyau/routeur.js";
import { dateCourte, pluriel } from "../../commun/format.js";
import { PERIODES, libellePeriode, reglagesClassement, reanalyserClassement, desactiverClassement, lancerAnalyse } from "../../noyau/classement.js";
import { btn, panneau, listeDef } from "../../ui/composants.js";
import { confirmer } from "../../ui/dialogue.js";
import { toast, toastErreur } from "../../ui/toast.js";
import { quand } from "./commun.js";

const MODES = [
  ["revue", "Je vérifie chaque proposition", "Recommandé. Le CRM vous propose des personnes à ajouter et des fiches à compléter ; rien n’est modifié avant votre clic."],
  [
    "auto", "Automatique, pour les cas les plus sûrs",
    "Après chaque analyse, le CRM ajoute lui-même les personnes avec qui vous échangez dans les deux sens (prénom et nom certains) et complète les téléphones manquants. Au plus 25 changements par analyse, tous annulables pendant 14 jours. Le reste vous est proposé comme d’habitude.",
  ],
];

export function monterReglages(P) {
  const vue = P.vue;
  const racine = h("div.pile.pile--l");
  let occupe = false;

  /** Exécute une action, affiche l'erreur éventuelle et redessine la page. */
  async function agir(action) {
    if (occupe) return;
    occupe = true;
    racine.setAttribute("aria-busy", "true");
    try {
      await action();
    } catch (e) {
      if (!(e instanceof ErreurApi)) throw e;
      toastErreur(e);
    } finally {
      occupe = false;
      P.actualiser();
    }
  }

  // ----- Mode ---------------------------------------------------------------------------------------------------------------------
  async function changerMode(mode) {
    if (mode === vue.mode) return;
    if (mode === "auto") {
      const ok = await confirmer({
        titre: "Passer en mode automatique ?",
        message: "Le CRM ajoutera lui-même des contacts à partir de vos courriels, sans vous demander. Seuls les cas très sûrs sont traités (échange dans les deux sens, prénom et nom certains), au plus 25 changements par analyse.",
        detail: h("p.muet", "Vous pourrez annuler chaque ajout pendant 14 jours (onglet « Derniers ajouts ») et revenir au mode « je vérifie » à tout moment."),
        libelleConfirmer: "Passer en automatique",
      });
      if (!ok) {
        P.actualiser();
        return;
      }
    }
    await agir(async () => {
      await reglagesClassement({ mode, ...(mode === "auto" ? { confirmer: true } : {}) });
      toast(mode === "auto" ? "Mode automatique activé : le CRM traitera seul les cas très sûrs." : "Retour au mode « je vérifie » : rien ne sera ajouté sans votre clic.", { ton: "info", duree: 6000 });
    });
  }

  const nomMode = idUnique("mode");
  const choixMode = h(
    "fieldset.choix-groupe",
    h("legend.sr-only", "Ce que le CRM fait de ce qu’il trouve"),
    MODES.map(([valeur, titre, texte]) => {
      const radio = h("input", { type: "radio", name: nomMode, value: valeur, dataset: { focusId: `mode:${valeur}` }, onchange: () => changerMode(valeur) });
      radio.checked = vue.mode === valeur;
      return h("label.choix", radio, h("span.choix__pastille", { "aria-hidden": "true" }), h("span.choix__texte", h("strong", titre), h("small", texte)));
    })
  );

  // ----- Période -------------------------------------------------------------------------------------------------------------------
  const select = h("select", { id: "cl-reglage-periode", "aria-describedby": "cl-reglage-periode-aide" }, PERIODES.map(([jours, libelle]) => h("option", { value: String(jours) }, libelle)));
  select.value = String(vue.fenetre_jours);
  select.addEventListener("change", () => {
    const jours = Number(select.value);
    const allonge = jours > vue.fenetre_jours;
    agir(async () => {
      await reglagesClassement({ fenetre_jours: jours });
      toast(allonge ? `Période allongée : ${libellePeriode(jours)}. Les courriels plus anciens vont être lus.` : `Période réduite : ${libellePeriode(jours)}.`, { ton: "info" });
      if (allonge) lancerAnalyse({ manuel: true }).catch(() => {});
    });
  });

  // ----- Nouvelle lecture ---------------------------------------------------------------------------------------------------
  async function toutRelire() {
    const ok = await confirmer({
      titre: "Relire tous vos courriels ?",
      message: `Le CRM relira tous les courriels de la période choisie (${libellePeriode(vue.fenetre_jours)}). Les propositions seront recalculées ; ce qui est déjà dans votre CRM ne change pas.`,
      libelleConfirmer: "Tout relire",
    });
    if (!ok) return;
    await agir(async () => {
      await reanalyserClassement();
      lancerAnalyse({ manuel: true }).catch(() => {});
      toast("Nouvelle lecture lancée.", { ton: "info" });
    });
  }

  async function reproposer() {
    const ok = await confirmer({
      titre: "Proposer de nouveau les personnes écartées ?",
      message: `${pluriel(vue.ignores, "personne écartée sera proposée", "personnes écartées seront proposées")} de nouveau après une nouvelle lecture de vos courriels.`,
      libelleConfirmer: "Les proposer de nouveau",
    });
    if (!ok) return;
    await agir(async () => {
      await reanalyserClassement({ ignores: true });
      lancerAnalyse({ manuel: true }).catch(() => {});
      toast("Nouvelle lecture lancée : les personnes écartées seront reproposées.", { ton: "info" });
    });
  }

  // ----- Arrêt complet ----------------------------------------------------------------------------------------------------------
  async function desactiver() {
    const ok = await confirmer({
      titre: "Désactiver l’analyse de vos courriels ?",
      message: "Le CRM arrête de lire votre boîte Gmail et efface tout ce qu’il avait retenu : propositions, personnes écartées, liste des derniers ajouts.",
      detail: h("p.muet", "Les fiches déjà ajoutées à votre CRM restent en place. Vous pourrez réactiver l’analyse quand vous voudrez."),
      libelleConfirmer: "Désactiver et effacer", danger: true,
    });
    if (!ok) return;
    await agir(async () => {
      await desactiverClassement();
      toast("Analyse désactivée. Ce que le CRM avait retenu est effacé.", { ton: "ok" });
      naviguer("/courriels", { remplacer: true });
    });
  }

  // ----- Assemblage ------------------------------------------------------------------------------------------------------------
  const derniere = vue.derniere;
  const couvert = vue.couvert;
  racine.append(
    panneau({ titre: "Que fait le CRM de ce qu’il trouve ?", niveau: 3 }, choixMode),
    panneau(
      { titre: "Période lue", niveau: 3, sous: "Les courriels plus anciens ne sont pas lus." },
      h(
        "div.champ",
        h("label.champ__etiquette", { for: "cl-reglage-periode" }, "Courriels des"),
        h("div.saisie-select.saisie-select--etroit", select, icone("bas", "ic--p")),
        h("p.champ__aide", { id: "cl-reglage-periode-aide" }, "Allonger la période relit les courriels plus anciens ; la raccourcir retire les propositions qui en dépendent.")
      )
    ),
    panneau(
      { titre: "Analyse", niveau: 3 },
      h(
        "div.pile",
        listeDef([
          ["Boîte Gmail", vue.compte || null],
          ["Dernière analyse", derniere ? `${quand(derniere.fin)} (${pluriel(derniere.examines, "courriel examiné", "courriels examinés")})` : "Aucune analyse terminée"],
          ["Courriels lus", couvert ? `du ${dateCourte(couvert.de.slice(0, 10))} au ${dateCourte(couvert.a.slice(0, 10))}` : null],
          ["Personnes écartées", vue.ignores ? pluriel(vue.ignores, "personne", "personnes") : null],
        ]),
        h(
          "div.actions-ligne",
          btn("Tout relire depuis le début…", { icone: "rafraichir", onclick: toutRelire }),
          vue.ignores ? btn("Reproposer les personnes écartées…", { icone: "voir", onclick: reproposer }) : null
        )
      )
    ),
    panneau(
      { titre: "Vos données", niveau: 3 },
      h(
        "div.pile",
        h("p", "Pour chaque personne repérée, le CRM retient son nom, son adresse, son téléphone, sa fonction et son entreprise (quand ils figurent dans sa signature), l’objet de votre dernier échange et le nombre de courriels échangés. Il ne copie aucun message."),
        h("p.muet", "Ces renseignements servent uniquement à vous faire des propositions. Ils sont effacés quand vous désactivez l’analyse ou déconnectez votre compte Google. Les fiches créées portent l’étiquette « Depuis Gmail »."),
        h("div.actions-ligne", btn("Désactiver l’analyse et effacer ce qui a été retenu…", { ton: "danger", onclick: desactiver }))
      )
    )
  );
  return { noeud: racine };
}
