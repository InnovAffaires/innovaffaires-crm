// =============================================================================
// Courriels → Réglages : mode (je vérifie / automatique), période lue, suivi des courriels (tâches, affaires, dossiers),
// nouvelle lecture, et arrêt complet avec effacement.
// =============================================================================
import { h, idUnique } from "../../noyau/dom.js";
import { icone } from "../../noyau/icones.js";
import { ErreurApi } from "../../noyau/api.js";
import { naviguer } from "../../noyau/routeur.js";
import { dateCourte, pluriel } from "../../commun/format.js";
import {
  PERIODES, libellePeriode, reglagesClassement, reanalyserClassement, desactiverClassement, lancerAnalyse,
  activerSuivi, desactiverSuivi, reglerSuivi, oublierChoixSuivi,
} from "../../noyau/classement.js";
import { btn, panneau, listeDef } from "../../ui/composants.js";
import { confirmer } from "../../ui/dialogue.js";
import { creerChamp, etiquettesConnues } from "../../ui/formulaire.js";
import { toast, toastErreur } from "../../ui/toast.js";
import { quand, caseACocher } from "./commun.js";

const MODES = [
  ["revue", "Je vérifie chaque proposition", "Recommandé. Le CRM vous propose des personnes à ajouter et des fiches à compléter ; rien n’est modifié avant votre clic."],
  [
    "auto", "Automatique, pour les cas les plus sûrs",
    "Après chaque analyse, le CRM ajoute lui-même les personnes avec qui vous échangez dans les deux sens (prénom et nom certains) et complète les téléphones manquants. Au plus 25 changements par analyse, tous annulables pendant 14 jours. Le reste vous est proposé comme d’habitude.",
  ],
];

const MODES_TACHES = [
  ["revue", "Je vérifie chaque tâche", "Recommandé. Le CRM vous propose les tâches à créer et à terminer ; rien n’est modifié avant votre clic."],
  [
    "auto", "Automatique, pour les cas les plus sûrs",
    "Après chaque analyse, le CRM crée lui-même les tâches « Répondre à… » et « Relancer… » les plus sûres et termine celles qui sont clairement réglées (votre réponse est adressée à la personne, ou c’est elle qui a répondu). Au plus 25 changements par analyse, tous annulables pendant 14 jours.",
  ],
];
const MODES_AFFAIRES = [
  ["non", "Ne pas proposer d’affaires", "Le CRM ne repère pas les échanges avec de futurs clients."],
  ["revue", "Je vérifie chaque affaire", "Recommandé. Le CRM vous propose les affaires à créer ; rien n’est créé avant votre clic."],
  [
    "auto", "Automatique, pour les affaires recommandées",
    "Le CRM crée lui-même les affaires dont l’échange est clair (vous avez écrit en premier et la personne a répondu, ou l’échange est nourri). Au plus 25 changements par analyse, tous annulables pendant 14 jours.",
  ],
];
const MODES_DOSSIERS = [
  ["non", "Ne pas proposer de dossiers", "Le CRM ne repère pas les échanges avec les organismes."],
  ["revue", "Je vérifie chaque dossier", "Le CRM vous propose les dossiers à créer. Un dossier demande une entreprise cliente et un programme : il n’est jamais créé automatiquement."],
];
const DELAIS_RELANCE = [3, 5, 7, 10, 14];

export function monterReglages(P) {
  const vue = P.vue;
  const racine = h("div.pile.pile--l");
  let occupe = false;

  /** Exécute une action, affiche l'erreur éventuelle et redessine la page. */
  async function agir(action) {
    if (occupe) return;
    occupe = true;
    racine.setAttribute("aria-busy", "true");
    try {
      await action();
    } catch (e) {
      if (!(e instanceof ErreurApi)) throw e;
      toastErreur(e);
    } finally {
      occupe = false;
      P.actualiser();
    }
  }

  // ----- Mode ---------------------------------------------------------------------------------------------------------------------
  async function changerMode(mode) {
    if (mode === vue.mode) return;
    if (mode === "auto") {
      const ok = await confirmer({
        titre: "Passer en mode automatique ?",
        message: "Le CRM ajoutera lui-même des contacts à partir de vos courriels, sans vous demander. Seuls les cas très sûrs sont traités (échange dans les deux sens, prénom et nom certains), au plus 25 changements par analyse.",
        detail: h("p.muet", "Vous pourrez annuler chaque ajout pendant 14 jours (onglet « Derniers ajouts ») et revenir au mode « je vérifie » à tout moment."),
        libelleConfirmer: "Passer en automatique",
      });
      if (!ok) {
        P.actualiser();
        return;
      }
    }
    await agir(async () => {
      await reglagesClassement({ mode, ...(mode === "auto" ? { confirmer: true } : {}) });
      toast(mode === "auto" ? "Mode automatique activé : le CRM traitera seul les cas très sûrs." : "Retour au mode « je vérifie » : rien ne sera ajouté sans votre clic.", { ton: "info", duree: 6000 });
    });
  }

  const nomMode = idUnique("mode");
  const choixMode = h(
    "fieldset.choix-groupe",
    h("legend.sr-only", "Ce que le CRM fait de ce qu’il trouve"),
    MODES.map(([valeur, titre, texte]) => {
      const radio = h("input", { type: "radio", name: nomMode, value: valeur, dataset: { focusId: `mode:${valeur}` }, onchange: () => changerMode(valeur) });
      radio.checked = vue.mode === valeur;
      return h("label.choix", radio, h("span.choix__pastille", { "aria-hidden": "true" }), h("span.choix__texte", h("strong", titre), h("small", texte)));
    })
  );

  // ----- Période -------------------------------------------------------------------------------------------------------------------
  const select = h("select", { id: "cl-reglage-periode", "aria-describedby": "cl-reglage-periode-aide" }, PERIODES.map(([jours, libelle]) => h("option", { value: String(jours) }, libelle)));
  select.value = String(vue.fenetre_jours);
  select.addEventListener("change", () => {
    const jours = Number(select.value);
    const allonge = jours > vue.fenetre_jours;
    agir(async () => {
      await reglagesClassement({ fenetre_jours: jours });
      toast(allonge ? `Période allongée : ${libellePeriode(jours)}. Les courriels plus anciens vont être lus.` : `Période réduite : ${libellePeriode(jours)}.`, { ton: "info" });
      if (allonge) lancerAnalyse({ manuel: true }).catch(() => {});
    });
  });

  // ----- Nouvelle lecture ---------------------------------------------------------------------------------------------------
  async function toutRelire() {
    const ok = await confirmer({
      titre: "Relire tous vos courriels ?",
      message: `Le CRM relira tous les courriels de la période choisie (${libellePeriode(vue.fenetre_jours)}). Les propositions seront recalculées ; ce qui est déjà dans votre CRM ne change pas.`,
      libelleConfirmer: "Tout relire",
    });
    if (!ok) return;
    await agir(async () => {
      await reanalyserClassement();
      lancerAnalyse({ manuel: true }).catch(() => {});
      toast("Nouvelle lecture lancée.", { ton: "info" });
    });
  }

  async function reproposer() {
    const ok = await confirmer({
      titre: "Proposer de nouveau les personnes écartées ?",
      message: `${pluriel(vue.ignores, "personne écartée sera proposée", "personnes écartées seront proposées")} de nouveau après une nouvelle lecture de vos courriels.`,
      libelleConfirmer: "Les proposer de nouveau",
    });
    if (!ok) return;
    await agir(async () => {
      await reanalyserClassement({ ignores: true });
      lancerAnalyse({ manuel: true }).catch(() => {});
      toast("Nouvelle lecture lancée : les personnes écartées seront reproposées.", { ton: "info" });
    });
  }

  // ----- Arrêt complet ----------------------------------------------------------------------------------------------------------
  async function desactiver() {
    const ok = await confirmer({
      titre: "Désactiver l’analyse de vos courriels ?",
      message: "Le CRM arrête de lire votre boîte Gmail et efface tout ce qu’il avait retenu : propositions, choix que vous avez faits, liste des derniers changements et, si le suivi était activé, la mémoire des conversations.",
      detail: h("p.muet", "Les fiches déjà ajoutées, ainsi que les tâches, affaires et dossiers déjà créés, restent en place. Vous pourrez réactiver l’analyse quand vous voudrez."),
      libelleConfirmer: "Désactiver et effacer", danger: true,
    });
    if (!ok) return;
    await agir(async () => {
      await desactiverClassement();
      toast("Analyse désactivée. Ce que le CRM avait retenu est effacé.", { ton: "ok" });
      naviguer("/courriels", { remplacer: true });
    });
  }

  // ----- Suivi des courriels ------------------------------------------------------------------------------------------------
  const sv = vue.suivi;
  const r = sv?.reglages || {};
  const changer = (suivi, message = "Réglage enregistré.", apres = null) =>
    agir(async () => {
      await reglerSuivi(suivi);
      apres?.();
      if (message) toast(message, { ton: "info", duree: 5000 });
    });

  async function activerLeSuivi() {
    const ok = await confirmer({
      titre: "Activer le suivi des courriels ?",
      message: "Le CRM relira votre boîte Gmail et retiendra, pour chaque conversation récente, son objet, ses dates, qui a écrit en dernier et les adresses des participants. Il ne copie jamais le texte des messages. Il vous proposera ensuite des tâches, des affaires et des dossiers.",
      detail: h("p.muet", "Rien n’est créé sans votre clic. Vous pourrez désactiver le suivi en tout temps : la mémoire des conversations est alors effacée."),
      libelleConfirmer: "Activer le suivi",
    });
    if (!ok) return;
    await agir(async () => {
      await activerSuivi();
      lancerAnalyse({ manuel: true }).catch(() => {});
      toast("Suivi activé. Le CRM relit votre boîte pour préparer ses propositions.", { ton: "ok", duree: 8000 });
    });
  }

  async function desactiverLeSuivi() {
    const ok = await confirmer({
      titre: "Désactiver le suivi des courriels ?",
      message: "Le CRM cesse de proposer des tâches, des affaires et des dossiers, et efface la mémoire des conversations (objets, dates et adresses).",
      detail: h("p.muet", "Les tâches, affaires et dossiers déjà créés restent en place. L’analyse des courriels (nouvelles personnes, fiches à compléter) continue. Vous pourrez réactiver le suivi quand vous voudrez."),
      libelleConfirmer: "Désactiver le suivi", danger: true,
    });
    if (!ok) return;
    await agir(async () => {
      await desactiverSuivi();
      toast("Suivi désactivé. La mémoire des conversations est effacée.", { ton: "ok" });
    });
  }

  /** Passer en automatique demande une confirmation : le CRM modifiera alors des fiches sans attendre un clic. */
  async function changerModeAutomatique(cle, mode, { titre, message }) {
    if (mode === r[cle]) return;
    if (mode === "auto") {
      const ok = await confirmer({
        titre, message,
        detail: h("p.muet", "Chaque changement apparaît dans l’onglet « Derniers changements » et peut être annulé pendant 14 jours. Vous pourrez revenir au mode « je vérifie » à tout moment."),
        libelleConfirmer: "Passer en automatique",
      });
      if (!ok) {
        P.actualiser();
        return;
      }
    }
    await agir(async () => {
      await reglerSuivi({ [cle]: mode }, { confirmer: mode === "auto" });
      toast(mode === "auto" ? "Mode automatique activé : le CRM traitera seul les cas très sûrs." : "Retour au mode « je vérifie » : rien ne sera créé sans votre clic.", { ton: "info", duree: 6000 });
    });
  }

  /** Un groupe de choix exclusifs (boutons radio), avec leur explication. */
  function groupeChoix({ legende, choix, valeur, surChoix, prefixe }) {
    const nom = idUnique("sv");
    return h(
      "fieldset.choix-groupe",
      h("legend.reglage-suivi__titre", legende),
      choix.map(([v, titre, texte]) => {
        const radio = h("input", { type: "radio", name: nom, value: v, dataset: { focusId: `${prefixe}:${v}` }, onchange: () => surChoix(v) });
        radio.checked = valeur === v;
        return h("label.choix", radio, h("span.choix__pastille", { "aria-hidden": "true" }), h("span.choix__texte", h("strong", titre), h("small", texte)));
      })
    );
  }

  async function oublierLesChoix() {
    const ok = await confirmer({
      titre: "Oublier vos choix ?",
      message: "Le CRM pourra de nouveau vous proposer ce que vous avez écarté, ainsi que les personnes pour lesquelles vous aviez demandé de ne plus rien proposer.",
      libelleConfirmer: "Oublier mes choix",
    });
    if (!ok) return;
    await agir(async () => {
      const rep = await oublierChoixSuivi();
      toast(rep.oublies ? "Choix oubliés : les propositions écartées peuvent revenir." : "Aucun choix à oublier.", { ton: "ok" });
    });
  }

  function panneauSuivi() {
    if (!sv?.actif) {
      return panneau(
        { titre: "Suivi des courriels", niveau: 3, sous: "Des tâches, des affaires et des dossiers proposés à partir de vos échanges." },
        h(
          "div.pile",
          h("p", "Le CRM repère les courriels qui attendent votre réponse et les envois restés sans suite, les échanges sérieux avec de futurs clients et les échanges avec les organismes financeurs. Il vous propose des tâches (« Répondre à… », « Relancer… »), des affaires et des dossiers de financement."),
          h("p.muet", "Pour cela, il retient pour chaque conversation récente son objet, ses dates, qui a écrit en dernier et les adresses des participants. Il ne copie jamais le texte des messages."),
          h("div.actions-ligne", btn("Activer le suivi des courriels…", { ton: "primaire", icone: "etincelle", onclick: activerLeSuivi }))
        )
      );
    }

    const repondre = caseACocher({
      libelle: "Réponses à donner : un courriel reçu qui attend votre réponse", texte: "Réponses à donner : un courriel reçu qui attend votre réponse", coche: r.repondre, focusId: "sv-repondre",
      surChangement: (v) => changer({ repondre: v }),
    });
    const relancer = caseACocher({
      libelle: "Relances : un courriel envoyé resté sans réponse", texte: "Relances : un courriel envoyé resté sans réponse", coche: r.relancer, focusId: "sv-relancer",
      surChangement: (v) => changer({ relancer: v }),
    });
    const delai = h("select", { id: "sv-relance", "aria-describedby": "sv-relance-aide" }, DELAIS_RELANCE.map((j) => h("option", { value: String(j) }, `${j} jours`)));
    delai.value = String(r.relance_jours);
    delai.addEventListener("change", () => changer({ relance_jours: Number(delai.value) }));
    delai.dataset.focusId = "sv-relance";

    // Ce qui a été ajouté mais pas encore enregistré survit à un redessin de la page (une analyse qui se termine, par exemple).
    const exclues = creerChamp("exclues", { type: "multi", libelle: "Étiquettes à exclure des affaires" }, P.memoire.get("sv_exclues") || r.exclues || [], {
      aide: "Les personnes qui portent l’une de ces étiquettes ne donnent jamais lieu à une proposition d’affaire. Sont déjà exclues d’office : fournisseur, partenaire, comptable, avocat, banque, collègue, équipe, pigiste, personnel, famille, ami et les organismes financeurs.",
      suggestions: etiquettesConnues, placeholder: "Ajouter une étiquette…",
    });
    exclues.noeud.addEventListener("change", () => P.memoire.set("sv_exclues", exclues.lire()));
    const enregistrerExclues = () => {
      const liste = exclues.lire();
      if (liste.length > 20) {
        exclues.erreur("Vingt étiquettes au plus.");
        return;
      }
      return changer({ exclues: liste }, "Étiquettes enregistrées.", () => P.memoire.delete("sv_exclues"));
    };

    const choisies = (sv.ecartees || 0) + (sv.personnes || 0);
    return panneau(
      { titre: "Suivi des courriels", niveau: 3, sous: "Des tâches, des affaires et des dossiers proposés à partir de vos échanges Gmail." },
      h(
        "div.reglage-suivi",
        groupeChoix({
          legende: "Tâches", choix: MODES_TACHES, valeur: r.taches, prefixe: "sv-taches",
          surChoix: (mode) => changerModeAutomatique("taches", mode, {
            titre: "Créer et terminer les tâches automatiquement ?",
            message: "Après chaque analyse, le CRM créera lui-même les tâches « Répondre à… » et « Relancer… » les plus sûres et terminera celles qui sont clairement réglées : votre réponse est adressée à la personne, ou c’est elle qui a répondu. Un courriel transféré à un tiers ou la réponse d’une collègue restent à vérifier. Au plus 25 changements par analyse.",
          }),
        }),
        h(
          "div.pile",
          h("p.reglage-suivi__titre", "Ce que le CRM surveille pour les tâches"),
          repondre.noeud,
          relancer.noeud,
          h(
            "div.champ",
            h("label.champ__etiquette", { for: "sv-relance" }, "Proposer une relance après"),
            h("div.saisie-select.saisie-select--etroit", delai, icone("bas", "ic--p")),
            h("p.champ__aide", { id: "sv-relance-aide" }, "Un envoi resté sans réponse est proposé pour une relance après ce délai, et jusqu’à 45 jours.")
          )
        ),
        groupeChoix({
          legende: "Affaires", choix: MODES_AFFAIRES, valeur: r.affaires, prefixe: "sv-affaires",
          surChoix: (mode) => changerModeAutomatique("affaires", mode, {
            titre: "Créer les affaires automatiquement ?",
            message: "Après chaque analyse, le CRM créera lui-même les affaires recommandées : un échange clair avec un futur client qui n’a ni affaire récente ni dossier en cours. Au plus 25 changements par analyse.",
          }),
        }),
        h("div.pile", exclues.noeud, h("div.actions-ligne", btn("Enregistrer les étiquettes", { icone: "coche", onclick: enregistrerExclues }))),
        groupeChoix({ legende: "Dossiers de financement", choix: MODES_DOSSIERS, valeur: r.dossiers, prefixe: "sv-dossiers", surChoix: (mode) => changer({ dossiers: mode }) }),
        h(
          "div.pile",
          h("p.reglage-suivi__titre", "Vos choix"),
          listeDef([
            ["Propositions écartées", sv.ecartees ? pluriel(sv.ecartees, "proposition", "propositions") : null],
            ["Personnes qu’on ne suit plus", sv.personnes ? pluriel(sv.personnes, "personne", "personnes") : null],
          ]),
          choisies
            ? h("div.actions-ligne", btn("Oublier mes choix…", { icone: "annuler", onclick: oublierLesChoix }))
            : h("p.muet.petit", "Vous n’avez rien écarté pour l’instant. Les propositions écartées et les personnes que vous demandez de ne plus suivre apparaîtront ici.")
        ),
        h("div.actions-ligne", btn("Désactiver le suivi des courriels…", { ton: "danger", onclick: desactiverLeSuivi }))
      )
    );
  }

  // ----- Assemblage ------------------------------------------------------------------------------------------------------------
  const derniere = vue.derniere;
  const couvert = vue.couvert;
  racine.append(
    panneau({ titre: "Que fait le CRM de ce qu’il trouve ?", niveau: 3 }, choixMode),
    panneau(
      { titre: "Période lue", niveau: 3, sous: "Les courriels plus anciens ne sont pas lus." },
      h(
        "div.champ",
        h("label.champ__etiquette", { for: "cl-reglage-periode" }, "Courriels des"),
        h("div.saisie-select.saisie-select--etroit", select, icone("bas", "ic--p")),
        h("p.champ__aide", { id: "cl-reglage-periode-aide" }, "Allonger la période relit les courriels plus anciens ; la raccourcir retire les propositions qui en dépendent.")
      )
    ),
    panneauSuivi(),
    panneau(
      { titre: "Analyse", niveau: 3 },
      h(
        "div.pile",
        listeDef([
          ["Boîte Gmail", vue.compte || null],
          ["Dernière analyse", derniere ? `${quand(derniere.fin)} (${pluriel(derniere.examines, "courriel examiné", "courriels examinés")})` : "Aucune analyse terminée"],
          ["Courriels lus", couvert ? `du ${dateCourte(couvert.de.slice(0, 10))} au ${dateCourte(couvert.a.slice(0, 10))}` : null],
          ["Personnes écartées", vue.ignores ? pluriel(vue.ignores, "personne", "personnes") : null],
        ]),
        h(
          "div.actions-ligne",
          btn("Tout relire depuis le début…", { icone: "rafraichir", onclick: toutRelire }),
          vue.ignores ? btn("Reproposer les personnes écartées…", { icone: "voir", onclick: reproposer }) : null
        )
      )
    ),
    panneau(
      { titre: "Vos données", niveau: 3 },
      h(
        "div.pile",
        h("p", "Pour chaque personne repérée, le CRM retient son nom, son adresse, son téléphone, sa fonction et son entreprise (quand ils figurent dans sa signature), l’objet de votre dernier échange et le nombre de courriels échangés. Il ne copie aucun message."),
        h("p", sv?.actif ? "Avec le suivi, le CRM retient aussi, pour chaque conversation récente, son objet, ses dates, qui a écrit en dernier et les adresses des participants. Jamais le texte des messages." : "Si vous activez le suivi, le CRM retiendra aussi, pour chaque conversation récente, son objet, ses dates, qui a écrit en dernier et les adresses des participants. Jamais le texte des messages."),
        h("p.muet", "Ces renseignements servent uniquement à vous faire des propositions. Ils sont effacés quand vous désactivez l’analyse (ou le suivi, pour ce qui le concerne) ou déconnectez votre compte Google. Les fiches créées portent l’étiquette « Depuis Gmail »."),
        h("div.actions-ligne", btn("Désactiver l’analyse et effacer ce qui a été retenu…", { ton: "danger", onclick: desactiver }))
      )
    )
  );
  return { noeud: racine };
}
