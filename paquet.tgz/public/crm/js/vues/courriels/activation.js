// =============================================================================
// Courriels — avant l'activation : ce que fait la fonction, ce qu'elle ne fait pas, et le bouton pour l'activer.
// Si Google n'est pas prêt, la page dit ce qu'il reste à faire plutôt que d'offrir un bouton qui échouerait.
// =============================================================================
import { h } from "../../noyau/dom.js";
import { icone } from "../../noyau/icones.js";
import { ErreurApi } from "../../noyau/api.js";
import { compteGoogle, signalerErreurGoogle } from "../../noyau/google.js";
import { activerClassement, activerSuivi, lancerAnalyse, PERIODES } from "../../noyau/classement.js";
import { btn, panneau } from "../../ui/composants.js";
import { toast, toastErreur } from "../../ui/toast.js";
import { caseACocher } from "./commun.js";

/** Google n'est pas prêt (ou le compte est en lecture seule) : on explique, avec le bouton qui mène à la bonne page. */
export function panneauBloque(raison) {
  return panneau(
    { titre: raison.titre, classe: "panneau--accent", niveau: 2 },
    h(
      "div.pile",
      h("p", raison.texte),
      raison.chemin ? h("div.actions-ligne", btn(raison.libelleAction, { ton: "primaire", icone: "lien", href: `#${raison.chemin}` })) : null
    )
  );
}

const liste = (icone_, textes) => h("ul.argu", textes.map((t) => h("li.argu__ligne", icone(icone_, "ic--p"), h("span", t))));

/** La page d'accueil de la fonction. `surActive()` est appelé quand l'activation a réussi. */
export function panneauActivation({ vue, surActive }) {
  const compte = compteGoogle();
  const select = h("select", { id: "cl-periode", "aria-describedby": "cl-periode-aide" }, PERIODES.map(([jours, libelle]) => h("option", { value: String(jours) }, libelle)));
  select.value = String(vue.fenetre_jours || 90);

  const suivi = caseACocher({
    libelle: "Activer aussi le suivi des courriels", focusId: "activer-suivi", coche: false,
    texte: "Activer aussi le suivi des courriels : tâches (« Répondre à… », « Relancer… »), affaires et dossiers proposés à partir de vos échanges",
  });

  const bouton = btn("Activer l’analyse de mes courriels", {
    ton: "primaire", icone: "etincelle",
    onclick: async () => {
      bouton.disabled = true;
      bouton.setAttribute("aria-busy", "true");
      try {
        await activerClassement({ fenetre_jours: Number(select.value) });
        if (suivi.cb.checked) {
          try {
            await activerSuivi();
          } catch (e) {
            // L'analyse est activée ; seul le suivi a échoué : on le dit, la personne pourra le réessayer dans « Réglages ».
            if (!(e instanceof ErreurApi)) throw e;
            toast(`L’analyse est activée, mais le suivi ne l’a pas été : ${e.message} Vous pourrez le réessayer dans « Réglages ».`, { ton: "info", duree: 12000 });
          }
        }
        // La première analyse démarre tout de suite : la page montre l'avancement.
        lancerAnalyse({ manuel: true }).catch(() => {});
        surActive();
      } catch (e) {
        if (!(e instanceof ErreurApi)) throw e;
        signalerErreurGoogle(e); // la connexion a peut-être changé depuis l'ouverture : la page se met à jour
        toastErreur(e);
        bouton.disabled = false;
        bouton.removeAttribute("aria-busy");
      }
    },
  });

  return panneau(
    { titre: "Laissez le CRM repérer vos contacts dans Gmail", sous: compte ? `Boîte analysée : ${compte}` : null, classe: "panneau--accent", niveau: 2 },
    h(
      "div.pile.pile--l.activation",
      h("p", "Le CRM parcourt les courriels que vous avez reçus et envoyés, repère les personnes avec qui vous échangez et vous les propose comme contacts, avec leur entreprise, leur fonction et leur téléphone lorsque ces renseignements figurent dans leur signature."),
      h(
        "section.activation__bloc",
        h("h3", "Ce que vous obtenez"),
        liste("coche", [
          "Les nouvelles personnes de vos échanges, à ajouter en un clic (ou à corriger avant de les ajouter).",
          "Les fiches incomplètes de votre CRM, complétées avec ce que disent les signatures. Rien de ce qui est déjà écrit n’est remplacé.",
          "Un bouton « Annuler » sur chaque ajout, pendant 14 jours.",
          "En option, le suivi des courriels : des tâches à créer (réponses à donner, relances), des affaires et des dossiers de financement.",
        ])
      ),
      h(
        "section.activation__bloc",
        h("h3", "Ce que le CRM fait de vos courriels"),
        liste("bouclier", [
          "Il ne copie pas vos messages. Il garde seulement ce qu’il a repéré (nom, adresse, téléphone, fonction, entreprise) et l’objet du dernier échange, pour vous aider à reconnaître la personne.",
          "Si vous activez aussi le suivi, il retient en plus, pour chaque conversation récente, l’objet, les dates et les adresses des participants. Jamais le texte des messages.",
          "Les infolettres, promotions, messages automatiques, pourriels et courriels de vos collègues sont ignorés.",
          "Rien n’est ajouté sans votre accord. Vous pourrez choisir plus tard le mode automatique, limité aux cas les plus sûrs.",
          "Les personnes qui demandent à être oubliées (Loi 25) ne sont jamais reproposées.",
          "Vous pouvez tout arrêter et tout effacer en un clic, dans l’onglet « Réglages ».",
        ])
      ),
      h(
        "div.activation__action",
        h(
          "div.champ",
          h("label.champ__etiquette", { for: "cl-periode" }, "Période à analyser"),
          h("div.saisie-select", select, icone("bas", "ic--p")),
          h("p.champ__aide", { id: "cl-periode-aide" }, "La première analyse peut durer quelques minutes ; vous pouvez continuer à travailler pendant ce temps.")
        ),
        suivi.noeud,
        h("div.actions-ligne", bouton)
      ),
      h("p.muet.petit", "Les fiches ajoutées portent l’étiquette « Depuis Gmail » et n’ont aucun consentement aux communications commerciales.")
    )
  );
}
