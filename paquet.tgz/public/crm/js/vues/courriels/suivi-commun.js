// =============================================================================
// Courriels → Suivi : pièces communes aux onglets Tâches, Affaires et Dossiers.
//   • le « registre » : les propositions d'une sorte, avec cases à cocher, barre d'actions groupées et choix « Recommandées | Toutes » ;
//   • le bilan, en phrases, de ce que le serveur a fait ;
//   • le lien vers la conversation dans Gmail, le menu « Ne plus suivre cette personne » et l'invitation à activer le suivi.
// Aucun texte de courriel n'est affiché : seulement des objets de conversation, des noms et des dates.
// =============================================================================
import { h } from "../../noyau/dom.js";
import { icone } from "../../noyau/icones.js";
import { ErreurApi } from "../../noyau/api.js";
import { naviguer } from "../../noyau/routeur.js";
import { compteGoogle } from "../../noyau/google.js";
import { pluriel } from "../../commun/format.js";
import { activerSuivi, ecarterSuivi, lancerAnalyse } from "../../noyau/classement.js";
import { btn, panneau, avis, menuActions } from "../../ui/composants.js";
import { toast, toastErreur } from "../../ui/toast.js";
import { confirmer } from "../../ui/dialogue.js";
import { caseACocher } from "./commun.js";

/** L'adresse d'une conversation dans Gmail (elle s'ouvre avec le bon compte, dans un nouvel onglet). */
export function lienFilGmail(filId) {
  const compte = compteGoogle();
  return `https://mail.google.com/mail/${compte ? `?authuser=${encodeURIComponent(compte)}` : ""}#all/${encodeURIComponent(filId)}`;
}

/** Le bouton « Voir le courriel » : ouvre la conversation dans Gmail pour vérifier avant d'agir. */
export function boutonCourriel(filId, nom) {
  return btn("Voir le courriel", {
    petit: true, icone: "externe", href: lienFilGmail(filId), externe: true,
    titre: "Ouvrir la conversation dans Gmail (nouvel onglet)", aria: `Voir dans Gmail la conversation avec ${nom || "cette personne"} (s’ouvre dans un nouvel onglet)`,
  });
}

/** Un lien vers une conversation, avec son objet (« Question sur le programme ») ou, à défaut, un libellé neutre. */
export function lienConversation(filId, objet) {
  return h("a.lien-discret", { href: lienFilGmail(filId), target: "_blank", rel: "noopener noreferrer" }, objet ? `« ${objet} »` : "(sans objet)", icone("externe", "ic--p"));
}

/** Ouvre la fiche d'une tâche pour la lire ou la modifier. */
export async function ouvrirTache(id) {
  const m = await import("../formulaires.js");
  m.modifierLaFiche("taches", id);
}

/** Bloque (ou débloque) les boutons et cases d'une zone pendant un appel au serveur. */
export function occuper(zone, v) {
  zone.toggleAttribute("aria-busy", v);
  for (const b of zone.querySelectorAll("button, input")) {
    if (v) {
      if (!b.disabled) {
        b.disabled = true;
        b.dataset.occupe = "1";
      }
    } else if (b.dataset.occupe) {
      b.disabled = false;
      delete b.dataset.occupe;
    }
  }
}

// ----- Bilan ---------------------------------------------------------------------------------------------------------------
const NOMS = { tache: ["tâche", "tâches"], fermer: ["tâche", "tâches"], affaire: ["affaire", "affaires"], dossier: ["dossier", "dossiers"] };

/** Ce que le serveur a répondu à une demande, en une phrase par sorte de résultat : { faits, messages }. */
export function bilanSuivi(resultats, genre) {
  const [un, plusieurs] = NOMS[genre];
  const de = (statut) => resultats.filter((r) => r.statut === statut);
  const messages = [];
  const deja = de("deja");
  const disparues = de("introuvable");
  const refusees = de("refuse");
  if (deja.length) {
    messages.push(
      genre === "fermer"
        ? `${pluriel(deja.length, "tâche était déjà terminée ou n’existe plus", "tâches étaient déjà terminées ou n’existent plus")}.`
        : `${pluriel(deja.length, `${un} existait déjà`, `${plusieurs} existaient déjà`)}.`
    );
  }
  if (disparues.length) messages.push(`${pluriel(disparues.length, "proposition n’existe plus", "propositions n’existent plus")} : la liste a été mise à jour.`);
  if (refusees.length) {
    const raison = refusees[0].message || "données invalides";
    messages.push(refusees.length === 1 ? `Refusé par le CRM : ${raison}` : `${pluriel(refusees.length, "proposition refusée", "propositions refusées")} par le CRM (par exemple : ${raison})`);
  }
  return { faits: de("cree").length + de("termine").length, messages };
}

/**
 * Affiche le résultat d'une demande d'application sous forme de message.
 * `texteFaits(n, sortie)` : la phrase de ce qui a réussi ; `action` : { libelle, onclick } (ou une fonction de la sortie qui la retourne)
 * offerte quand quelque chose a réussi.
 */
export function annoncerResultat(sortie, genre, { texteFaits, action = null }) {
  const bilan = bilanSuivi(sortie.resultats, genre);
  const morceaux = [];
  if (bilan.faits) morceaux.push(texteFaits(bilan.faits, sortie));
  morceaux.push(...bilan.messages);
  if (sortie.erreur) morceaux.push(sortie.erreur.message);
  const offerte = bilan.faits ? (typeof action === "function" ? action(sortie) : action) : null;
  toast(morceaux.join(" ") || "Rien n’a été modifié.", { ton: bilan.faits && !sortie.erreur ? "ok" : "info", duree: bilan.faits ? 9000 : null, action: offerte });
  return bilan;
}

// ----- Le registre ---------------------------------------------------------------------------------------------------------
/**
 * Les propositions d'une sorte : cases à cocher, barre d'actions groupées, choix « Recommandées | Toutes » et une ligne par proposition.
 *   P          : la page (P.memoire garde la sélection d'un redessin à l'autre, P.actualiser() redessine)
 *   cle        : nom de cette liste (sélection, filtre, identifiants de focus)
 *   elements   : les propositions du serveur ; total : leur nombre réel s'il dépasse ce qui est affiché
 *   id(e)      : la clé d'une proposition ;  recommande(e) : vrai pour une proposition « sûre » (offre le choix Recommandées | Toutes)
 *   etiquette(e) : texte lu par les lecteurs d'écran pour la case de la ligne
 *   ligne(e, ctx) : retourne le <li> ; ctx = { case_, agir, ecarter, menuPersonne }
 *   groupees   : [{ libelle, icone, ton?, executer(choisies) }] — actions de la barre (l'écartement est toujours offert)
 *   ecarter    : { libelleGroupe, libelleUn, message(n) } — vocabulaire de l'écartement (« Écarter » ou « Garder ouverte »)
 *   entete     : { titre, sous }
 */
export function registre({ P, cle, elements, total = null, id, recommande = null, etiquette, ligne, groupees = [], ecarter, entete }) {
  const m = P.memoire;
  const cleSel = `sel_${cle}`;
  if (!m.has(cleSel)) m.set(cleSel, new Set());
  const sel = m.get(cleSel);
  const existants = new Set(elements.map(id));
  for (const k of [...sel]) if (!existants.has(k)) sel.delete(k);

  // Sans choix de la personne : les recommandées d'abord, s'il y a de quoi trier.
  const recs = recommande ? elements.filter(recommande) : [];
  const peutFiltrer = recs.length > 0 && recs.length < elements.length;
  const choix = m.get(`filtre_${cle}`) || "auto";
  const filtre = !peutFiltrer ? "toutes" : choix === "auto" ? "recommandees" : choix;
  const visibles = filtre === "recommandees" ? recs : elements;

  const racine = h("div.pile");
  let occupe = false;

  /** Exécute une action pendant que les boutons sont bloqués, affiche l'erreur éventuelle et redessine la page. */
  async function agir(action, retirer = []) {
    if (occupe) return;
    occupe = true;
    occuper(racine, true);
    try {
      await action();
      for (const k of retirer) sel.delete(k);
    } catch (e) {
      if (!(e instanceof ErreurApi)) throw e;
      toastErreur(e);
    } finally {
      occupe = false;
      occuper(racine, false);
      P.actualiser();
    }
  }

  const ecarterCles = (cles, libelleMessage) =>
    agir(async () => {
      const r = await ecarterSuivi({ cles });
      toast(libelleMessage(r.ignores), { ton: "info", duree: 8000 });
    }, cles);

  async function plusSuivre(contact) {
    const ok = await confirmer({
      titre: `Ne plus rien proposer pour ${contact.nom} ?`,
      message: "Le CRM ne proposera plus de tâches, d’affaires ni de dossiers à propos des courriels échangés avec cette personne. Sa fiche et vos courriels ne changent pas.",
      detail: h("p.muet", "Vous pourrez annuler ce choix à tout moment dans « Réglages » (bouton « Oublier mes choix »)."),
      libelleConfirmer: "Ne plus rien proposer",
    });
    if (!ok) return;
    await agir(async () => {
      await ecarterSuivi({ personnes: [contact.id] });
      toast(`Le CRM ne proposera plus rien à propos de ${contact.nom}.`, { ton: "info", duree: 8000 });
    });
  }

  /** Le menu « Plus d'actions » d'une ligne qui concerne une personne. */
  const menuPersonne = (contact) =>
    contact
      ? menuActions({
          // Placé par rapport à la fenêtre : les boutons d'une ligne sont alignés à gauche, un menu aligné sur leur bord droit sortirait de l'écran.
          aria: `Plus d’actions pour ${contact.nom}`, fixe: true, aligne: "gauche",
          elements: [
            { libelle: `Voir la fiche de ${contact.nom}`, icone: "utilisateur", onclick: () => naviguer(`/contacts/${encodeURIComponent(contact.id)}`) },
            "separateur",
            { libelle: `Ne plus rien proposer pour ${contact.nom}`, icone: "bloquer", onclick: () => plusSuivre(contact) },
          ],
        })
      : null;

  // ----- Barre d'actions groupées ----------------------------------------------------------------------------------------------
  const compte = h("span.prop-barre__compte", { role: "status" });
  const boutons = groupees.map((g) => ({ g, bouton: btn(g.libelle, { ton: g.ton || "primaire", icone: g.icone, onclick: () => lancer(g) }) }));
  const boutonEcarter = btn(ecarter.libelleGroupe, { icone: "cacher", onclick: () => ecarterCles(choisies().map(id), ecarter.message) });
  const choisies = () => visibles.filter((e) => sel.has(id(e)));
  const toutes = caseACocher({
    libelle: "Sélectionner toutes les propositions affichées", texte: "Tout sélectionner", focusId: `tout:${cle}`,
    surChangement: (v) => {
      for (const e of visibles) {
        if (v) sel.add(id(e));
        else sel.delete(id(e));
      }
      for (const cb of racine.querySelectorAll("input[data-case-ligne]")) cb.checked = v;
      majBarre();
    },
  });

  function lancer(g) {
    const elles = choisies();
    return agir(() => g.executer(elles), elles.map(id));
  }

  function majBarre() {
    const n = choisies().length;
    compte.textContent = n ? pluriel(n, "proposition sélectionnée", "propositions sélectionnées") : "";
    for (const { g, bouton } of boutons) {
      bouton.querySelector("span").textContent = n > 1 ? `${g.libelle} (${n})` : g.libelle;
      bouton.disabled = occupe || !n;
    }
    boutonEcarter.querySelector("span").textContent = n > 1 ? `${ecarter.libelleGroupe} (${n})` : ecarter.libelleGroupe;
    boutonEcarter.disabled = occupe || !n;
    toutes.cb.checked = n > 0 && n === visibles.length;
    toutes.cb.indeterminate = n > 0 && n < visibles.length;
  }

  const segments = peutFiltrer
    ? h(
        "div.segments",
        { role: "group", "aria-label": "Propositions à afficher" },
        [["recommandees", `Recommandées (${recs.length})`], ["toutes", `Toutes (${elements.length})`]].map(([idChoix, libelle]) =>
          h("button.segments__bouton", {
            type: "button", "aria-pressed": String(filtre === idChoix),
            onclick: () => {
              m.set(`filtre_${cle}`, idChoix);
              P.actualiser();
            },
          }, libelle)
        )
      )
    : null;

  // ----- Les lignes ---------------------------------------------------------------------------------------------------------------
  function uneLigne(e) {
    const k = id(e);
    const case_ = caseACocher({
      libelle: etiquette(e), coche: sel.has(k), focusId: `sel:${cle}:${k}`,
      surChangement: (v) => {
        if (v) sel.add(k);
        else sel.delete(k);
        majBarre();
      },
    });
    case_.cb.dataset.caseLigne = "1";
    return ligne(e, { case_, agir, menuPersonne, ecarter: () => ecarterCles([k], (n) => ecarter.message(n)) });
  }

  if ((total ?? elements.length) > elements.length) {
    racine.append(avis({ ton: "info", texte: `Les ${elements.length} premières propositions sur ${total} sont affichées. Traitez celles-ci pour voir les suivantes.` }));
  }
  racine.append(
    panneau(
      { titre: entete.titre, compteur: String(total ?? elements.length), classe: "panneau--liste", sous: entete.sous, actions: segments },
      h("div.prop-barre", toutes.noeud, compte, h("div.prop-barre__actions", boutons.map((x) => x.bouton), boutonEcarter)),
      h("ul.prop-liste", visibles.map(uneLigne))
    )
  );
  majBarre();
  return { noeud: racine };
}

/** Une ligne de proposition : la case, le texte (plusieurs lignes) et les boutons. */
export function ligneProposition({ case_, texte, actions, classe = "" }) {
  return h("li.prop.prop--suivi", { class: classe }, case_.noeud, h("div.prop__texte", texte), h("div.prop__actions", actions));
}

// ----- Bandeaux et invitation --------------------------------------------------------------------------------------------------
/** Le suivi vient d'être allumé : tant que la première lecture n'est pas finie, il n'y a rien à proposer. */
export function bandeauPreparation() {
  return avis({
    ton: "info", titre: "Le suivi se prépare",
    texte: "Le CRM relit votre boîte Gmail une première fois pour le suivi. Les propositions apparaîtront à la fin de cette lecture ; vous pouvez continuer à travailler.",
  });
}

const liste = (nomIcone, textes) => h("ul.argu", textes.map((t) => h("li.argu__ligne", icone(nomIcone, "ic--p"), h("span", t))));

/**
 * Ce que le suivi des courriels apporte, ce qu'il retient, et le bouton pour l'allumer.
 * `surActive()` est appelé quand l'activation a réussi.
 */
export function panneauInvitationSuivi({ vue, surActive }) {
  const jours = vue.suivi?.reglages?.relance_jours ?? 7;
  const bouton = btn("Activer le suivi des courriels", {
    ton: "primaire", icone: "etincelle",
    onclick: async () => {
      bouton.disabled = true;
      bouton.setAttribute("aria-busy", "true");
      try {
        await activerSuivi();
        // La première lecture avec le suivi démarre tout de suite : la page montre l'avancement.
        lancerAnalyse({ manuel: true }).catch(() => {});
        toast("Suivi activé. Le CRM relit votre boîte pour préparer ses propositions.", { ton: "ok", duree: 8000 });
        surActive();
      } catch (e) {
        if (!(e instanceof ErreurApi)) throw e;
        toastErreur(e);
        bouton.disabled = false;
        bouton.removeAttribute("aria-busy");
      }
    },
  });
  return panneau(
    { titre: "Laissez le CRM suivre vos courriels", sous: vue.compte ? `Boîte analysée : ${vue.compte}` : null, classe: "panneau--accent", niveau: 2 },
    h(
      "div.pile.pile--l.activation",
      h("p", "Le CRM peut proposer des tâches, des affaires et des dossiers à partir de vos échanges Gmail, pour que rien ne reste sans réponse et que vos fiches reflètent ce qui se passe vraiment."),
      h(
        "section.activation__bloc",
        h("h3", "Ce que vous obtenez"),
        liste("coche", [
          `Des tâches à créer : « Répondre à… » quand un courriel attend votre réponse, « Relancer… » quand un envoi reste sans réponse depuis ${jours} jours.`,
          "Des tâches à terminer : dès que vous avez répondu, ou que la personne l’a fait, le CRM vous propose de fermer la tâche.",
          "Des affaires à ouvrir quand un échange sérieux s’engage avec un client potentiel.",
          "Des dossiers de financement à ouvrir quand un organisme public ou un financeur vous écrit.",
        ])
      ),
      h(
        "section.activation__bloc",
        h("h3", "Ce que le CRM retient"),
        liste("bouclier", [
          "Pour chaque conversation : l’objet, les dates, qui a écrit en dernier et les adresses des participants. Jamais le texte des messages.",
          "Rien n’est créé sans votre clic. Vous pourrez ensuite choisir le mode automatique, limité aux cas les plus sûrs, dans « Réglages ».",
          "Vous pouvez tout arrêter en tout temps : la mémoire des conversations est alors effacée (les tâches, affaires et dossiers déjà créés restent).",
        ])
      ),
      h("div.activation__action", h("p.champ__aide", "La première lecture peut durer quelques minutes ; vous pouvez continuer à travailler pendant ce temps."), h("div.actions-ligne", bouton))
    )
  );
}
