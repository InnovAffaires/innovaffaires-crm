// =============================================================================
// Courriels → Derniers changements : ce que la fonction a ajouté, complété, créé ou terminé depuis 14 jours, avec « Annuler ».
// Personnes ajoutées, fiches complétées, et (avec le suivi) tâches, affaires et dossiers créés, tâches terminées.
// =============================================================================
import { h } from "../../noyau/dom.js";
import { ErreurApi } from "../../noyau/api.js";
import { lienFiche } from "../../noyau/routeur.js";
import { defaire } from "../../noyau/classement.js";
import { btn, panneau, tampon, etatVide } from "../../ui/composants.js";
import { toast, toastErreur } from "../../ui/toast.js";
import { confirmer } from "../../ui/dialogue.js";
import { libelleChamp, quand } from "./commun.js";
import { ouvrirTache } from "./suivi-commun.js";

const champsDe = (r) => [...new Set((r.champs || []).map(libelleChamp))].join(", ");

const RAISONS_FERMETURE = {
  vous_avez_repondu: "vous avez répondu au courriel",
  ils_ont_repondu: "la personne a répondu",
  vous_avez_relance: "vous avez relancé la personne",
  vous_avez_ecrit: "vous avez écrit dans la conversation",
  autre_a_repondu: "quelqu’un d’autre a répondu dans la conversation",
};

/** Ce qui s'est passé, en une courte phrase. */
function quoi(r) {
  switch (r.type) {
    case "ajout": return "Fiche créée à partir de vos courriels";
    case "tache": return "Tâche créée à partir de vos courriels";
    case "tache_fermee": return `Tâche terminée (${RAISONS_FERMETURE[r.raison] || "elle semblait réglée"})`;
    case "affaire": return "Affaire créée à partir de vos courriels";
    case "dossier": return "Dossier créé à partir de vos courriels";
    default: return `Complétée : ${champsDe(r) || "renseignements ajoutés"}`;
  }
}

/** Le nom de la chose (avec un lien vers sa fiche quand elle en a une). */
function noeudNom(r) {
  if (r.annule && r.type === "tache") return h("span", r.nom);
  switch (r.type) {
    case "tache":
    case "tache_fermee":
      return h("button.lien-bouton", { type: "button", title: "Ouvrir cette tâche", onclick: () => ouvrirTache(r.ref) }, r.nom);
    case "affaire":
      return h("a.lien-fiche", { href: lienFiche("opportunites", r.ref) }, r.nom);
    case "dossier":
      return h("a.lien-fiche", { href: lienFiche("dossiers", r.ref) }, r.nom);
    default:
      return h("a.lien-fiche", { href: lienFiche("contacts", r.contact_id) }, r.nom);
  }
}

/** Les mots de la confirmation, du bouton et du message de fin pour chaque sorte de changement. */
const ANNULATION = {
  ajout: {
    titre: "Annuler cet ajout ?", ok: "Oui, annuler l’ajout", titreBouton: (r) => `Annuler l’ajout de ${r.nom}`,
    message: (r) => `La fiche de ${r.nom} sera placée dans la corbeille ; vous pourrez la restaurer pendant 30 jours. Cette personne ne sera pas proposée de nouveau.`,
    fait: (r) => `Ajout annulé : la fiche de ${r.nom} est dans la corbeille.`,
  },
  completion: {
    titre: "Annuler ce complément ?", ok: "Oui, annuler le complément", titreBouton: (r) => `Annuler le complément de la fiche de ${r.nom}`,
    message: (r) => `Les renseignements ajoutés à la fiche de ${r.nom} (${champsDe(r) || "champs complétés"}) seront retirés, et le CRM ne proposera plus de compléter cette fiche (vous pourrez le réactiver dans « Réglages »).`,
    fait: (r) => `Complément annulé pour ${r.nom}. Le CRM ne proposera plus de compléter cette fiche.`,
  },
  tache: {
    titre: "Annuler cette tâche ?", ok: "Oui, annuler la tâche", titreBouton: (r) => `Annuler la tâche « ${r.nom} »`,
    message: (r) => `La tâche « ${r.nom} » sera placée dans la corbeille ; vous pourrez la restaurer pendant 30 jours. Le CRM ne la proposera plus.`,
    fait: () => "Tâche annulée : elle est dans la corbeille. Le CRM ne la proposera plus.",
  },
  tache_fermee: {
    titre: "Rouvrir cette tâche ?", ok: "Oui, rouvrir la tâche", titreBouton: (r) => `Rouvrir la tâche « ${r.nom} »`,
    message: (r) => `La tâche « ${r.nom} » sera de nouveau « à faire ». Le CRM ne proposera plus de la terminer.`,
    fait: () => "Tâche rouverte. Le CRM ne proposera plus de la terminer.",
  },
  affaire: {
    titre: "Annuler cette affaire ?", ok: "Oui, annuler l’affaire", titreBouton: (r) => `Annuler l’affaire « ${r.nom} »`,
    message: (r) => `L’affaire « ${r.nom} » sera placée dans la corbeille ; vous pourrez la restaurer pendant 30 jours. Le CRM ne la proposera plus.`,
    fait: () => "Affaire annulée : elle est dans la corbeille. Le CRM ne la proposera plus.",
  },
  dossier: {
    titre: "Annuler ce dossier ?", ok: "Oui, annuler le dossier", titreBouton: (r) => `Annuler le dossier « ${r.nom} »`,
    message: (r) => `Le dossier « ${r.nom} » sera placé dans la corbeille, avec les tâches de départ que le CRM y a ajoutées si vous n’y avez pas touché${r.entreprise_creee ? ", et l’entreprise créée avec lui si elle n’est utilisée nulle part ailleurs" : ""}. Le CRM ne le proposera plus.`,
    fait: () => "Dossier annulé : il est dans la corbeille. Le CRM ne le proposera plus.",
  },
};

export function monterAjouts(P) {
  const recents = P.vue.recents || [];
  const racine = h("div.pile");
  let occupe = false;

  async function annuler(r) {
    const mots = ANNULATION[r.type] || ANNULATION.completion;
    if (occupe) return;
    const ok = await confirmer({ titre: mots.titre, message: mots.message(r), libelleConfirmer: mots.ok, libelleAnnuler: "Non, la garder" });
    if (!ok) return;
    occupe = true;
    racine.setAttribute("aria-busy", "true");
    try {
      const rep = await defaire(r.id);
      toast(rep.deja ? "Rien à défaire : cette opération était déjà annulée ou la fiche n’existe plus." : mots.fait(r), { ton: "ok" });
    } catch (e) {
      if (!(e instanceof ErreurApi)) throw e;
      if (e.code === "modifiee") toast(e.message, { ton: "info", duree: 10000 });
      else toastErreur(e);
    } finally {
      occupe = false;
      P.actualiser();
    }
  }

  function ligne(r) {
    const mots = ANNULATION[r.type] || ANNULATION.completion;
    return h(
      "li.prop.prop--ajout",
      h(
        "div.prop__texte",
        h("p.prop__nom", noeudNom(r), r.annule ? tampon("Annulé", "neutre") : null),
        h("p.prop__coord", h("span", quoi(r)), h("span", r.auto ? "Fait automatiquement" : "Fait par vous"), h("span", quand(r.t)))
      ),
      h(
        "div.prop__actions",
        r.annule
          ? h("span.muet.petit", `Annulé ${quand(r.annule_le)}`)
          : btn(r.type === "tache_fermee" ? "Rouvrir" : "Annuler", { petit: true, icone: "annuler", titre: mots.titreBouton(r), aria: mots.titreBouton(r), onclick: () => annuler(r) })
      )
    );
  }

  if (!recents.length) {
    racine.append(
      etatVide({
        icone: "historique", titre: "Aucun changement récent",
        texte: "Les personnes ajoutées, les fiches complétées et, avec le suivi, les tâches, affaires et dossiers créés ou terminés à partir de vos courriels apparaissent ici pendant 14 jours, avec un bouton pour annuler.",
      })
    );
    return { noeud: racine };
  }
  racine.append(
    panneau(
      { titre: "Derniers changements", compteur: String(recents.length), classe: "panneau--liste", sous: "Annulez un changement tant que la fiche n’a pas été modifiée depuis : elle retourne à la corbeille (ou la tâche se rouvre)." },
      h("ul.prop-liste", recents.map(ligne))
    )
  );
  return { noeud: racine };
}
