// =============================================================================
// Courriels → Derniers ajouts : ce que la fonction a ajouté ou complété depuis 14 jours, avec « Annuler ».
// =============================================================================
import { h } from "../../noyau/dom.js";
import { ErreurApi } from "../../noyau/api.js";
import { lienFiche } from "../../noyau/routeur.js";
import { defaire } from "../../noyau/classement.js";
import { btn, panneau, tampon, etatVide } from "../../ui/composants.js";
import { toast, toastErreur } from "../../ui/toast.js";
import { confirmer } from "../../ui/dialogue.js";
import { libelleChamp, quand } from "./commun.js";

const champsDe = (r) => [...new Set((r.champs || []).map(libelleChamp))].join(", ");

export function monterAjouts(P) {
  const recents = P.vue.recents || [];
  const racine = h("div.pile");
  let occupe = false;

  async function annuler(r) {
    if (occupe) return;
    const ajout = r.type === "ajout";
    const ok = await confirmer({
      titre: ajout ? "Annuler cet ajout ?" : "Annuler ce complément ?",
      message: ajout
        ? `La fiche de ${r.nom} sera placée dans la corbeille ; vous pourrez la restaurer pendant 30 jours. Cette personne ne sera pas proposée de nouveau.`
        : `Les renseignements ajoutés à la fiche de ${r.nom} (${champsDe(r) || "champs complétés"}) seront retirés, et le CRM ne proposera plus de compléter cette fiche (vous pourrez le réactiver dans « Réglages »).`,
      libelleConfirmer: ajout ? "Oui, annuler l’ajout" : "Oui, annuler le complément", libelleAnnuler: "Non, la garder",
    });
    if (!ok) return;
    occupe = true;
    racine.setAttribute("aria-busy", "true");
    try {
      const rep = await defaire(r.id);
      toast(
        rep.deja
          ? "Rien à défaire : cette opération était déjà annulée ou la fiche n’existe plus."
          : ajout ? `Ajout annulé : la fiche de ${r.nom} est dans la corbeille.` : `Complément annulé pour ${r.nom}. Le CRM ne proposera plus de compléter cette fiche.`,
        { ton: "ok" }
      );
    } catch (e) {
      if (!(e instanceof ErreurApi)) throw e;
      if (e.code === "modifiee") toast(e.message, { ton: "info", duree: 10000 });
      else toastErreur(e);
    } finally {
      occupe = false;
      P.actualiser();
    }
  }

  function ligne(r) {
    const quoi = r.type === "ajout" ? "Fiche créée à partir de vos courriels" : `Complétée : ${champsDe(r) || "renseignements ajoutés"}`;
    return h(
      "li.prop.prop--ajout",
      h(
        "div.prop__texte",
        h("p.prop__nom", h("a.lien-fiche", { href: lienFiche("contacts", r.contact_id) }, r.nom), r.annule ? tampon("Annulé", "neutre") : null),
        h("p.prop__coord", h("span", quoi), h("span", r.auto ? "Fait automatiquement" : "Fait par vous"), h("span", quand(r.t)))
      ),
      h(
        "div.prop__actions",
        r.annule
          ? h("span.muet.petit", `Annulé ${quand(r.annule_le)}`)
          : btn("Annuler", { petit: true, icone: "annuler", titre: r.type === "ajout" ? `Annuler l’ajout de ${r.nom}` : `Annuler le complément de la fiche de ${r.nom}`, onclick: () => annuler(r) })
      )
    );
  }

  if (!recents.length) {
    racine.append(
      etatVide({
        icone: "historique", titre: "Aucun ajout récent",
        texte: "Les personnes ajoutées et les fiches complétées à partir de vos courriels apparaissent ici pendant 14 jours, avec un bouton pour annuler.",
      })
    );
    return { noeud: racine };
  }
  racine.append(
    panneau(
      { titre: "Derniers ajouts", compteur: String(recents.length), classe: "panneau--liste", sous: "Annulez un ajout tant que la fiche n’a pas été modifiée depuis : elle retourne à la corbeille." },
      h("ul.prop-liste", recents.map(ligne))
    )
  );
  return { noeud: racine };
}
