// =============================================================================
// Courriels — pièces communes aux onglets : libellés, cases à cocher, bloc d'avancement de l'analyse,
// et lecture des résultats d'ajout ou de complément renvoyés par le serveur.
// =============================================================================
import { h } from "../../noyau/dom.js";
import { icone } from "../../noyau/icones.js";
import { maintenant, actives } from "../../noyau/etat.js";
import { ilYa, pluriel, normaliser } from "../../commun/format.js";
import { surAnalyse, etatAnalyse } from "../../noyau/classement.js";

export const ms = (iso) => {
  const t = Date.parse(iso || "");
  return Number.isFinite(t) ? t : 0;
};
/** « il y a 3 jours » à partir d'un instant ISO du serveur (vide si l'instant est inconnu). */
export const quand = (iso) => (ms(iso) ? ilYa(ms(iso), maintenant()) : "");

export const nomPersonne = (p) => [p.prenom, p.nom].filter(Boolean).join(" ").trim();

/** Le nom des champs d'une fiche de contact, tels que la personne les lit dans le CRM. */
export const LIBELLES_CHAMPS = {
  prenom: "Prénom", nom: "Nom", telephone: "Téléphone", mobile: "Cellulaire", titre: "Fonction", entreprise: "Entreprise", entreprise_id: "Entreprise",
};
export const libelleChamp = (cle) => LIBELLES_CHAMPS[cle] || cle;
/** L'ordre dans lequel les champs proposés sont présentés. */
export const ORDRE_CHAMPS = ["prenom", "nom", "titre", "entreprise", "telephone", "mobile"];

/** « Courriels : 3 reçus, 1 envoyé — dernier échange il y a 3 jours ». */
export function texteEchanges(p) {
  const morceaux = [];
  const compte = (n, plus, un, plusieurs) => `${n}${plus ? "+" : ""} ${n > 1 || plus ? plusieurs : un}`;
  if (p.recus) morceaux.push(compte(p.recus, p.plus_r, "reçu", "reçus"));
  if (p.envoyes) morceaux.push(compte(p.envoyes, p.plus_e, "envoyé", "envoyés"));
  const dernier = quand(p.dernier);
  return `Courriels : ${morceaux.join(", ") || "aucun"}${dernier ? ` · dernier échange ${dernier}` : ""}`;
}

/**
 * Une case à cocher. `libelle` : ce que lisent les lecteurs d'écran ; `texte` : ce qui s'affiche à côté (rien si omis).
 * `focusId` permet de remettre le focus sur la même case quand la page se redessine.
 */
export function caseACocher({ libelle, texte = null, coche = false, desactive = false, surChangement, classe = "", focusId = null }) {
  const cb = h("input", { type: "checkbox", disabled: desactive, "aria-label": libelle, dataset: focusId ? { focusId } : null, onchange: () => surChangement?.(cb.checked) });
  cb.checked = coche;
  const noeud = h("label.case", { class: classe }, cb, h("span.case__boite", { "aria-hidden": "true" }, icone("coche", "ic--p")), texte ? h("span", texte) : null);
  return { noeud, cb };
}

/** L'état d'une entreprise proposée, en deux mots : « déjà au CRM », « sera créée » ou « à confirmer ». */
export function noteEntreprise(e) {
  if (!e) return "";
  if (e.existante) return "déjà au CRM";
  return e.sure ? "sera créée" : "à confirmer";
}

const FORMES = /\b(inc|incorporee|ltee|ltd|limitee|limited|corp|corporation|enr|enregistree|senc|sencrl|llc|cie|co)\b/g;
/** Clé approximative pour reconnaître une entreprise déjà au CRM d'après son nom (le serveur fait la vraie comparaison). */
export const cleNomEntreprise = (nom) => normaliser(nom).replace(FORMES, " ").replace(/[^a-z0-9]+/g, "");

export function entrepriseConnue(nom) {
  const cle = cleNomEntreprise(nom);
  if (cle.length < 3) return null;
  return actives("entreprises").find((e) => cleNomEntreprise(e.nom) === cle) || null;
}

/** Le travail demandé au serveur pour l'entreprise d'une proposition, sans rien créer d'incertain. */
export function entreprisePourAjout(e) {
  if (!e) return undefined;
  if (e.existante && e.id) return { id: e.id };
  if (e.sure && e.nom) return { nom: e.nom };
  return undefined;
}

/** Ce que le serveur a répondu à une demande d'ajout ou de complément, en une phrase par sorte de résultat. */
export function bilanResultats(resultats, { verbe }) {
  const compte = (statut) => resultats.filter((r) => r.statut === statut);
  const faits = compte(verbe === "ajout" ? "ajoute" : "complete");
  const sortie = { faits: faits.length, messages: [] };
  const deja = compte("deja");
  const rien = compte("rien");
  const exclus = compte("exclu");
  const disparus = compte("introuvable");
  const refuses = compte("refuse");
  if (deja.length) sortie.messages.push(`${pluriel(deja.length, "personne était déjà dans le CRM", "personnes étaient déjà dans le CRM")}.`);
  if (rien.length) sortie.messages.push(`${pluriel(rien.length, "fiche n’avait rien à compléter", "fiches n’avaient rien à compléter")} (déjà remplie${rien.length > 1 ? "s" : ""}).`);
  if (exclus.length) sortie.messages.push(`${pluriel(exclus.length, "personne n’a pas été ajoutée", "personnes n’ont pas été ajoutées")} : elle${exclus.length > 1 ? "s ont" : " a"} demandé de ne plus figurer dans le CRM.`);
  if (disparus.length) sortie.messages.push(`${pluriel(disparus.length, "proposition n’existe plus", "propositions n’existent plus")} : la liste a été mise à jour.`);
  if (refuses.length) sortie.messages.push(refuses.length === 1 ? `Refusé par le CRM : ${refuses[0].message || "données invalides"}` : `${pluriel(refuses.length, "fiche refusée", "fiches refusées")} par le CRM (données invalides).`);
  return sortie;
}

// ----- Avancement de l'analyse --------------------------------------------------------------------------------------------
/**
 * Le bloc qui montre l'analyse en cours (barre, nombre de courriels examinés, pause demandée par Google).
 * Il se met à jour tout seul, sans redessiner la page ; `detruire()` le détache de l'analyse.
 */
export function blocAvancement() {
  const titre = h("p.analyse__titre");
  const detail = h("p.analyse__detail.muet.petit");
  const barre = h("span.progres__barre");
  const piste = h("div.progres", { "aria-hidden": "true" }, barre);
  const noeud = h("div.analyse", { hidden: true }, h("div.analyse__tete", icone("rafraichir", "ic--p analyse__icone"), titre), piste, detail);
  let dernierTitre = "";

  function maj(e) {
    noeud.hidden = !e.enCours;
    if (!e.enCours) {
      dernierTitre = "";
      return;
    }
    let t;
    let d = "";
    let part = null;
    if (e.pause) {
      t = "Google demande de patienter un instant";
      d = "L’analyse reprendra toute seule. Vous pouvez continuer à travailler.";
    } else {
      const p = e.progres;
      const examines = p?.examines || 0;
      t = p?.finalisation ? "Dernières vérifications…" : "Analyse de vos courriels en cours…";
      d = examines ? `${pluriel(examines, "courriel examiné", "courriels examinés")}${p.estime > examines ? ` sur environ ${p.estime.toLocaleString("fr-CA")}` : ""}. Vous pouvez continuer à travailler.` : "Lecture de votre boîte Gmail…";
      if (p?.finalisation) part = 0.98;
      else if (p?.estime > 0) part = Math.min(0.97, examines / p.estime);
    }
    if (t !== dernierTitre) {
      dernierTitre = t;
      titre.textContent = t;
      // Le titre est annoncé aux lecteurs d'écran quand il change ; le décompte, lui, ne l'est pas à chaque lot.
      titre.setAttribute("role", "status");
    }
    detail.textContent = d;
    piste.classList.toggle("progres--indetermine", part === null);
    if (part === null) barre.style.removeProperty("--p");
    else barre.style.setProperty("--p", String(part));
  }
  maj(etatAnalyse());
  const desabonner = surAnalyse(maj);
  return { noeud, detruire: desabonner };
}
