// =============================================================================
// Courriels → Tâches : les tâches que le CRM propose de créer (réponses à donner, relances) et celles qu'il propose de terminer
// parce que vous avez répondu, ou que la personne l'a fait. Rien n'est créé ni terminé avant votre clic (sauf en mode automatique).
// =============================================================================
import { h } from "../../noyau/dom.js";
import { naviguer } from "../../noyau/routeur.js";
import { pluriel } from "../../commun/format.js";
import { appliquerSuivi } from "../../noyau/classement.js";
import { btn, etatVide, pastille, avis } from "../../ui/composants.js";
import { noeudEcheance, lienLie } from "../aides.js";
import { quand } from "./commun.js";
import { registre, ligneProposition, boutonCourriel, annoncerResultat, ouvrirTache } from "./suivi-commun.js";

/** « il y a 2 jours » précédé d'une espace, ou rien si l'instant est inconnu. */
const depuis = (iso) => {
  const q = quand(iso);
  return q ? ` ${q}` : "";
};

/** Pourquoi la tâche semble réglée ; `q` : « il y a 2 jours » précédé d'une espace (ou rien), placé là où la phrase se lit le mieux. */
const RAISONS = {
  vous_avez_repondu: (q) => `Vous avez répondu à ce courriel${q}`,
  ils_ont_repondu: (q) => `La personne a répondu à votre envoi${q}`,
  vous_avez_relance: (q) => `Vous avez relancé la personne${q}`,
  // Ce qui s'est passé dans la conversation ne concerne pas sûrement la personne visée : à vous de juger.
  vous_avez_ecrit: (q) => `Vous avez écrit dans cette conversation${q}, mais pas à cette personne`,
  autre_a_repondu: (q) => `Quelqu’un d’autre a répondu dans cette conversation${q}`,
};

/** La fiche à laquelle la tâche sera reliée : un lien si elle est connue de cet écran, sinon son nom. */
function noeudLien(lien) {
  if (!lien) return null;
  return lienLie(lien.type, lien.id, { court: true }) || h("span", lien.libelle || "");
}

export function monterTaches(P) {
  const s = P.vue.suivi;
  const taches = s.taches || [];
  const fermer = s.fermer || [];
  const totaux = s.totaux || {};
  const racine = h("div.pile");

  // ----- Tâches à créer ----------------------------------------------------------------------------------------------------------
  const creer = (elles) => appliquerSuivi(elles.map((p) => ({ genre: "tache", cle: p.cle }))).then((sortie) =>
    annoncerResultat(sortie, "tache", {
      texteFaits: (n) => `${pluriel(n, "tâche créée", "tâches créées")}.`,
      action: { libelle: "Voir mes tâches", onclick: () => naviguer("/taches") },
    })
  );

  function ligneACreer(p, ctx) {
    const nom = p.contact?.nom || "cette personne";
    const lien = noeudLien(p.lien);
    return ligneProposition({
      case_: ctx.case_,
      texte: [
        h(
          "p.prop__nom", h("strong", p.titre), pastille(p.sorte === "repondre" ? "Réponse à donner" : "Relance", "info"),
          p.sure ? null : pastille("À vérifier", "attention"),
          p.priorite === "haute" ? pastille("Priorité haute", "attention", { icone: "drapeau" }) : null
        ),
        h(
          "p.prop__coord",
          h("span", p.sorte === "repondre" ? `Courriel reçu${depuis(p.quand)}, sans réponse de votre part` : `Votre envoi${depuis(p.quand)} est resté sans réponse`),
          h("span", "Échéance : ", noeudEcheance(p.echeance)),
          lien ? h("span", "Lié à : ", lien) : null
        ),
      ],
      actions: [
        btn("Créer la tâche", { ton: "primaire", petit: true, icone: "liste-verif", aria: `Créer la tâche « ${p.titre} »`, onclick: () => ctx.agir(() => creer([p])) }),
        boutonCourriel(p.fil, nom),
        btn("Écarter", { petit: true, ton: "discret", icone: "cacher", titre: `Ne plus proposer cette tâche (${nom})`, aria: `Écarter la tâche « ${p.titre} »`, onclick: ctx.ecarter }),
        ctx.menuPersonne(p.contact),
      ],
    });
  }

  // ----- Tâches à terminer ---------------------------------------------------------------------------------------------------------
  const terminer = (elles) => appliquerSuivi(elles.map((p) => ({ genre: "fermer", cle: p.cle }))).then((sortie) =>
    annoncerResultat(sortie, "fermer", {
      texteFaits: (n) => `${pluriel(n, "tâche terminée", "tâches terminées")}. Vous pouvez annuler dans « Derniers changements ».`,
      action: { libelle: "Voir les changements", onclick: () => naviguer("/courriels/ajouts") },
    })
  );

  function ligneATerminer(p, ctx) {
    const nom = p.contact?.nom || "cette personne";
    return ligneProposition({
      case_: ctx.case_,
      texte: [
        h("p.prop__nom", h("button.lien-bouton", { type: "button", title: "Ouvrir cette tâche", onclick: () => ouvrirTache(p.tache.id) }, p.tache.titre), p.sure ? null : pastille("À vérifier", "attention")),
        h("p.prop__coord", h("span", (RAISONS[p.raison] || ((q) => `Cette tâche semble réglée${q}`))(depuis(p.quand)))),
      ],
      actions: [
        btn("Terminer la tâche", { ton: "primaire", petit: true, icone: "coche", aria: `Terminer la tâche « ${p.tache.titre} »`, onclick: () => ctx.agir(() => terminer([p])) }),
        boutonCourriel(p.fil, nom),
        btn("Garder ouverte", { petit: true, ton: "discret", icone: "cacher", titre: "Ne plus proposer de terminer cette tâche", aria: `Garder ouverte la tâche « ${p.tache.titre} »`, onclick: ctx.ecarter }),
      ],
    });
  }

  // ----- Assemblage ---------------------------------------------------------------------------------------------------------------
  const r = s.reglages || {};
  if (r.taches === "auto") {
    racine.append(avis({ ton: "info", texte: "Mode automatique : le CRM crée lui-même les tâches les plus sûres et termine celles qui sont réglées. Ci-dessous : ce qu’il vous laisse décider." }));
  }
  if (r.repondre === false && r.relancer === false) {
    racine.append(avis({ ton: "info", texte: "Les tâches « Répondre à… » et « Relancer… » sont désactivées dans l’onglet « Réglages »." }));
  }

  if (!taches.length && !fermer.length) {
    racine.append(
      etatVide({
        icone: "taches",
        titre: !s.pret ? "Pas encore de tâche à proposer" : "Aucune tâche à proposer",
        texte: !s.pret
          ? "Les tâches apparaîtront ici à la fin de la première lecture de votre boîte Gmail."
          : "Aucun courriel récent n’attend votre réponse et aucun envoi n’est resté sans suite. Les nouvelles propositions apparaîtront ici après chaque analyse.",
      })
    );
    return { noeud: racine };
  }

  if (taches.length) {
    racine.append(
      registre({
        P, cle: "taches", elements: taches, total: totaux.taches, id: (p) => p.cle, recommande: (p) => p.sure, etiquette: (p) => `Sélectionner : ${p.titre}`,
        ligne: ligneACreer,
        groupees: [{ libelle: "Créer la sélection", icone: "liste-verif", executer: creer }],
        ecarter: {
          libelleGroupe: "Écarter la sélection",
          message: (n) => `${pluriel(n, "tâche écartée", "tâches écartées")} : le CRM ne ${n > 1 ? "les proposera" : "la proposera"} plus. Pour ${n > 1 ? "les" : "la"} revoir : « Réglages », puis « Oublier mes choix ».`,
        },
        entete: { titre: "Tâches à créer", sous: "Des courriels qui attendent votre réponse et des envois restés sans réponse. Rien n’est créé avant votre clic." },
      }).noeud
    );
  }
  if (fermer.length) {
    racine.append(
      registre({
        P, cle: "fermer", elements: fermer, total: totaux.fermer, id: (p) => p.cle, recommande: (p) => p.sure, etiquette: (p) => `Sélectionner : ${p.tache.titre}`,
        ligne: ligneATerminer,
        groupees: [{ libelle: "Terminer la sélection", icone: "coche", executer: terminer }],
        ecarter: {
          libelleGroupe: "Garder ouvertes",
          message: (n) => `${pluriel(n, "tâche gardée ouverte", "tâches gardées ouvertes")} : le CRM ne proposera plus de ${n > 1 ? "les" : "la"} terminer.`,
        },
        entete: { titre: "Tâches à terminer", sous: "Ces tâches, créées à partir de vos courriels, semblent réglées : vous avez répondu, ou la personne l’a fait. « À vérifier » : la conversation a bougé, mais pas clairement entre vous et cette personne." },
      }).noeud
    );
  }
  return { noeud: racine };
}
