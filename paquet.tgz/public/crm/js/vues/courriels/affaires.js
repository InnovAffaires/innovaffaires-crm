// =============================================================================
// Courriels → Affaires : les échanges sérieux avec un client potentiel (dans les deux sens, jamais avec un organisme financeur ni
// une adresse générale) qui n'ont pas encore d'affaire au CRM. Rien n'est créé avant votre clic (sauf en mode automatique,
// pour les propositions « recommandées »).
// =============================================================================
import { h } from "../../noyau/dom.js";
import { naviguer, lienFiche } from "../../noyau/routeur.js";
import { pluriel, argentEntier } from "../../commun/format.js";
import { SERVICES } from "../../commun/schema.js";
import { appliquerSuivi } from "../../noyau/classement.js";
import { btn, etatVide, pastille, avis, listeDef } from "../../ui/composants.js";
import { creerChamp } from "../../ui/formulaire.js";
import { ouvrirDialogue } from "../../ui/dialogue.js";
import { quand, texteEchanges } from "./commun.js";
import { registre, ligneProposition, boutonCourriel, annoncerResultat } from "./suivi-commun.js";

const libelleService = (id) => SERVICES.find((s) => s.id === id)?.libelle || "";

/** Retourne (par une promesse) le titre choisi, ou undefined si la personne abandonne. */
function dialogueAffaire(p) {
  return ouvrirDialogue({
    titre: "Créer l’affaire",
    description: "Corrigez au besoin le titre, puis créez l’affaire. Vous pourrez tout modifier ensuite dans sa fiche.",
    taille: "moyen",
    contenu: (ctx) => {
      const titre = creerChamp("titre", { type: "texte", libelle: "Titre de l’affaire", max: 160, requis: true }, p.titre, {});
      const creer = () => {
        const t = titre.lire().trim();
        if (!t) {
          titre.erreur("Donnez un titre à l’affaire.");
          titre.focus();
          return;
        }
        ctx.fermer(t);
      };
      ctx.definirPied(btn("Annuler", { onclick: () => ctx.fermer(undefined) }), btn("Créer l’affaire", { ton: "primaire", icone: "affaires", onclick: creer }));
      return h(
        "form.pile",
        { onsubmit: (ev) => (ev.preventDefault(), creer()), novalidate: true },
        listeDef(
          [
            ["Personne", p.contact?.nom], ["Entreprise", p.entreprise?.nom], ["Service probable", libelleService(p.service)],
            ["Honoraires prévus", p.valeur > 0 ? argentEntier(p.valeur) : null],
          ],
          { classe: "def--serre" }
        ),
        titre.noeud
      );
    },
  }).promesse;
}

export function monterAffaires(P) {
  const s = P.vue.suivi;
  const affaires = s.affaires || [];
  const racine = h("div.pile");

  const creer = (elles, titres = {}) =>
    appliquerSuivi(elles.map((p) => ({ genre: "affaire", cle: p.cle, ...(titres[p.cle] ? { titre: titres[p.cle] } : {}) }))).then((sortie) =>
      annoncerResultat(sortie, "affaire", {
        texteFaits: (n) => `${pluriel(n, "affaire créée", "affaires créées")}, à la première étape de votre pipeline.`,
        action: (r) => {
          const faites = r.resultats.filter((x) => x.statut === "cree");
          return faites.length === 1 && faites[0].id
            ? { libelle: "Voir l’affaire", onclick: () => naviguer(`/affaires/${encodeURIComponent(faites[0].id)}`) }
            : { libelle: "Voir les affaires", onclick: () => naviguer("/affaires") };
        },
      })
    );

  async function modifierPuisCreer(p, ctx) {
    const titre = await dialogueAffaire(p);
    if (titre) await ctx.agir(() => creer([p], { [p.cle]: titre }));
  }

  function ligne(p, ctx) {
    const nom = p.contact?.nom || "cette personne";
    return ligneProposition({
      case_: ctx.case_,
      texte: [
        h(
          "p.prop__nom", h("strong", p.titre), p.recommande ? pastille("Recommandée", "ok") : pastille("À vérifier", "attention"),
          libelleService(p.service) ? pastille(libelleService(p.service), "neutre") : null
        ),
        h(
          "p.prop__coord",
          p.contact ? h("span", "Contact : ", h("a.lien-fiche", { href: lienFiche("contacts", p.contact.id) }, p.contact.nom)) : null,
          p.entreprise ? h("span", "Entreprise : ", h("a.lien-fiche", { href: lienFiche("entreprises", p.entreprise.id) }, p.entreprise.nom)) : null,
          h("span", p.ouvert_par === "moi" ? "Vous avez écrit en premier" : "La personne a écrit en premier")
        ),
        h("p.prop__echanges.muet.petit", `${texteEchanges({ recus: p.recus, envoyes: p.envoyes, dernier: p.quand })}${quand(p.debut) ? ` — premier échange ${quand(p.debut)}` : ""}`),
      ],
      actions: [
        btn("Créer l’affaire", { ton: "primaire", petit: true, icone: "affaires", aria: `Créer l’affaire « ${p.titre} »`, onclick: () => ctx.agir(() => creer([p])) }),
        btn("Modifier…", { petit: true, icone: "modifier", titre: `Corriger le titre de l’affaire avant de la créer (${nom})`, aria: `Modifier le titre de l’affaire « ${p.titre} » avant de la créer`, onclick: () => modifierPuisCreer(p, ctx) }),
        boutonCourriel(p.fil, nom),
        btn("Écarter", { petit: true, ton: "discret", icone: "cacher", titre: `Ne plus proposer cette affaire (${nom})`, aria: `Écarter l’affaire « ${p.titre} »`, onclick: ctx.ecarter }),
        ctx.menuPersonne(p.contact),
      ],
    });
  }

  const r = s.reglages || {};
  if (r.affaires === "auto") {
    racine.append(avis({ ton: "info", texte: "Mode automatique : le CRM crée lui-même les affaires « recommandées ». Ci-dessous : celles qu’il vous laisse vérifier." }));
  }
  if (r.affaires === "non") {
    racine.append(
      etatVide({
        icone: "affaires", titre: "Les propositions d’affaires sont désactivées",
        texte: "Vous pouvez les réactiver dans l’onglet « Réglages ».",
        action: btn("Ouvrir les réglages", { ton: "primaire", href: "#/courriels/reglages" }),
      })
    );
    return { noeud: racine };
  }
  if (!affaires.length) {
    racine.append(
      etatVide({
        icone: "affaires",
        titre: !s.pret ? "Pas encore d’affaire à proposer" : "Aucune affaire à proposer",
        texte: !s.pret
          ? "Les affaires apparaîtront ici à la fin de la première lecture de votre boîte Gmail."
          : "Une affaire est proposée quand un échange sérieux (dans les deux sens) s’engage avec quelqu’un qui n’a ni affaire récente ni dossier en cours. Les nouvelles propositions apparaîtront ici après chaque analyse.",
      })
    );
    return { noeud: racine };
  }
  racine.append(
    registre({
      P, cle: "affaires", elements: affaires, total: s.totaux?.affaires, id: (p) => p.cle, recommande: (p) => p.recommande,
      etiquette: (p) => `Sélectionner : ${p.titre}`, ligne,
      groupees: [{ libelle: "Créer la sélection", icone: "affaires", executer: (elles) => creer(elles) }],
      ecarter: {
        libelleGroupe: "Écarter la sélection",
        message: (n) => `${pluriel(n, "affaire écartée", "affaires écartées")} : le CRM ne ${n > 1 ? "les proposera" : "la proposera"} plus. Pour ${n > 1 ? "les" : "la"} revoir : « Réglages », puis « Oublier mes choix ».`,
      },
      entete: { titre: "Affaires à créer", sous: "Des échanges sérieux avec de futurs clients. « Recommandée » : vous avez écrit en premier et la personne a répondu, ou l’échange est nourri." },
    }).noeud
  );
  return { noeud: racine };
}
