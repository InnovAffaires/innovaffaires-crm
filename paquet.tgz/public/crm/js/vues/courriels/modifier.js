// =============================================================================
// Courriels — la fenêtre « Modifier avant d'ajouter » : on corrige ce qui a été repéré, puis on ajoute la personne.
// =============================================================================
import { h, idUnique } from "../../noyau/dom.js";
import { actives } from "../../noyau/etat.js";
import { btn, listeDef } from "../../ui/composants.js";
import { creerChamp } from "../../ui/formulaire.js";
import { ouvrirDialogue } from "../../ui/dialogue.js";
import { entrepriseConnue } from "./commun.js";

/**
 * Retourne (par une promesse) la demande d'ajout corrigée, ou undefined si la personne abandonne.
 * Le nom d'entreprise saisi est relié à l'entreprise du CRM qui porte le même nom, sinon une nouvelle fiche est créée.
 */
export function dialogueAjout(p) {
  return ouvrirDialogue({
    titre: "Ajouter à vos contacts",
    description: "Corrigez au besoin ce que le CRM a repéré, puis ajoutez la personne.",
    taille: "moyen",
    contenu: (ctx) => {
      const prenom = creerChamp("prenom", { type: "texte", libelle: "Prénom", max: 80 }, p.prenom || "", {});
      const nom = creerChamp("nom", { type: "texte", libelle: "Nom", max: 80 }, p.nom || "", {});
      const titre = creerChamp("titre", { type: "texte", libelle: "Fonction", max: 120 }, p.titre || "", {});
      const telephone = creerChamp("telephone", { type: "tel", libelle: "Téléphone", max: 40 }, p.telephone || "", {});
      const mobile = creerChamp("mobile", { type: "tel", libelle: "Cellulaire", max: 40 }, p.mobile || "", {});
      const entreprise = creerChamp("entreprise", { type: "texte", libelle: "Entreprise", max: 160 }, p.entreprise?.nom || "", {});

      // Les entreprises du CRM sont proposées pendant la saisie.
      const idListe = idUnique("entreprises");
      entreprise.controle.setAttribute("list", idListe);
      const suggestions = h("datalist", { id: idListe }, actives("entreprises").filter((e) => !e.archive).slice(0, 500).map((e) => h("option", { value: e.nom })));
      const indice = h("p.champ__aide", { role: "status" });
      const majIndice = () => {
        const texte = entreprise.lire().trim();
        if (!texte) indice.textContent = "Laissez vide pour ne relier aucune entreprise.";
        else if (entrepriseConnue(texte)) indice.textContent = "Cette entreprise est déjà au CRM : la fiche y sera reliée.";
        else indice.textContent = "Nouvelle entreprise : elle sera créée avec la fiche.";
      };
      entreprise.controle.addEventListener("input", majIndice);
      majIndice();

      const ajouter = () => {
        const charge = {
          adresse: p.adresse, prenom: prenom.lire().trim(), nom: nom.lire().trim(), titre: titre.lire().trim(),
          telephone: telephone.lire().trim(), mobile: mobile.lire().trim(),
        };
        const texte = entreprise.lire().trim();
        if (texte) charge.entreprise = p.entreprise?.existante && p.entreprise.id && texte === p.entreprise.nom ? { id: p.entreprise.id } : { nom: texte };
        ctx.fermer(charge);
      };
      ctx.definirPied(btn("Annuler", { onclick: () => ctx.fermer(undefined) }), btn("Ajouter la personne", { ton: "primaire", icone: "ajout-utilisateur", onclick: ajouter }));

      return h(
        "form.pile",
        { onsubmit: (ev) => (ev.preventDefault(), ajouter()), novalidate: true },
        listeDef([["Courriel", p.adresse]], { classe: "def--serre" }),
        h("div.grille.grille--2", prenom.noeud, nom.noeud),
        titre.noeud,
        h("div.grille.grille--2", telephone.noeud, mobile.noeud),
        h("div.pile.pile--xs", entreprise.noeud, indice, suggestions)
      );
    },
  }).promesse;
}
