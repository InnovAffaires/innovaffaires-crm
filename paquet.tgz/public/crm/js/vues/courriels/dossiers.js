// =============================================================================
// Courriels → Dossiers : les échanges avec un organisme public ou un financeur qui n'ont pas encore de dossier de financement
// au CRM. Un dossier demande une entreprise cliente et un programme : la fenêtre « Créer le dossier » les confirme.
// Les dossiers ne sont jamais créés automatiquement.
// =============================================================================
import { h, idUnique } from "../../noyau/dom.js";
import { naviguer, lienFiche } from "../../noyau/routeur.js";
import { actives } from "../../noyau/etat.js";
import { pluriel } from "../../commun/format.js";
import { appliquerSuivi } from "../../noyau/classement.js";
import { btn, etatVide, pastille, avis } from "../../ui/composants.js";
import { creerChamp } from "../../ui/formulaire.js";
import { ouvrirDialogue } from "../../ui/dialogue.js";
import { quand, entrepriseConnue } from "./commun.js";
import { registre, ligneProposition, boutonCourriel, lienConversation, annoncerResultat } from "./suivi-commun.js";

const MAX_CONVERSATIONS_AFFICHEES = 3;

/**
 * Retourne (par une promesse) ce que la personne a confirmé — { entreprise, programme, organisme, titre? } — ou undefined si elle abandonne.
 * Le nom d'entreprise saisi est relié à l'entreprise du CRM qui porte le même nom, sinon une nouvelle fiche est créée avec le dossier.
 */
function dialogueDossier(p) {
  return ouvrirDialogue({
    titre: "Créer le dossier de financement",
    description: "Confirmez l’entreprise cliente et le programme visé. Vous pourrez compléter le reste dans la fiche du dossier.",
    taille: "moyen",
    contenu: (ctx) => {
      const entreprise = creerChamp("entreprise", { type: "texte", libelle: "Entreprise cliente", max: 160, requis: true }, p.entreprise?.nom || "", {});
      const programme = creerChamp("programme", { type: "texte", libelle: "Programme visé", max: 200, requis: true }, p.programme || "", {});
      const organisme = creerChamp("organisme", { type: "texte", libelle: "Organisme", max: 200 }, p.organisme || "", {});
      const titre = creerChamp("titre", { type: "texte", libelle: "Titre du dossier", max: 200 }, "", {
        placeholder: "Par défaut : nom de l’entreprise — programme",
      });

      // Les entreprises du CRM sont proposées pendant la saisie.
      const idListe = idUnique("entreprises");
      entreprise.controle.setAttribute("list", idListe);
      const suggestions = h("datalist", { id: idListe }, actives("entreprises").filter((e) => !e.archive).slice(0, 500).map((e) => h("option", { value: e.nom })));
      const indice = h("p.champ__aide", { role: "status" });
      const majIndice = () => {
        const texte = entreprise.lire().trim();
        if (!texte) indice.textContent = "Choisissez l’entreprise qui demande cette aide (pas l’organisme).";
        else if (entrepriseConnue(texte)) indice.textContent = "Cette entreprise est déjà au CRM : le dossier y sera relié.";
        else indice.textContent = "Nouvelle entreprise : elle sera créée avec le dossier.";
      };
      entreprise.controle.addEventListener("input", majIndice);
      majIndice();

      const creer = () => {
        const nomEntreprise = entreprise.lire().trim();
        const prog = programme.lire().trim();
        let premier = null;
        if (!nomEntreprise) {
          entreprise.erreur("Choisissez l’entreprise cliente de ce dossier.");
          premier = entreprise;
        }
        if (!prog) {
          programme.erreur("Indiquez le programme visé.");
          premier = premier || programme;
        }
        if (premier) {
          premier.focus();
          return;
        }
        const connue = entrepriseConnue(nomEntreprise);
        const charge = {
          entreprise: p.entreprise && nomEntreprise === p.entreprise.nom ? { id: p.entreprise.id } : connue ? { id: connue.id } : { nom: nomEntreprise },
          programme: prog, organisme: organisme.lire().trim(),
        };
        const t = titre.lire().trim();
        if (t) charge.titre = t;
        ctx.fermer(charge);
      };
      ctx.definirPied(btn("Annuler", { onclick: () => ctx.fermer(undefined) }), btn("Créer le dossier", { ton: "primaire", icone: "dossier-plus", onclick: creer }));

      return h(
        "form.pile",
        { onsubmit: (ev) => (ev.preventDefault(), creer()), novalidate: true },
        h("div.pile.pile--xs", entreprise.noeud, indice, suggestions),
        programme.noeud,
        organisme.noeud,
        titre.noeud
      );
    },
  }).promesse;
}

export function monterDossiers(P) {
  const s = P.vue.suivi;
  const dossiers = s.dossiers || [];
  const racine = h("div.pile");

  const creer = (p, charge) =>
    appliquerSuivi([{ genre: "dossier", cle: p.cle, ...charge }]).then((sortie) =>
      annoncerResultat(sortie, "dossier", {
        texteFaits: (n, r) => {
          const taches = r.resultats.reduce((somme, x) => somme + (x.taches || 0), 0);
          const creee = r.resultats.some((x) => x.entreprise_creee);
          return `${pluriel(n, "dossier créé", "dossiers créés")}${creee ? " (l’entreprise a été ajoutée au CRM)" : ""}.${taches ? ` ${pluriel(taches, "tâche de départ a été ajoutée", "tâches de départ ont été ajoutées")}.` : ""}`;
        },
        action: (r) => {
          const id = r.resultats.find((x) => x.statut === "cree")?.id;
          return id ? { libelle: "Voir le dossier", onclick: () => naviguer(`/dossiers/${encodeURIComponent(id)}`) } : null;
        },
      })
    );

  async function confirmerPuisCreer(p, ctx) {
    const charge = await dialogueDossier(p);
    if (charge) await ctx.agir(() => creer(p, charge));
  }

  /** Les conversations avec l'organisme : leur objet ouvre la conversation dans Gmail. */
  function conversations(p) {
    const montrees = (p.fils || []).slice(0, MAX_CONVERSATIONS_AFFICHEES);
    const autres = (p.autres || 0) + 1 - montrees.length;
    return h(
      "p.prop__echanges.muet.petit",
      "Conversations : ",
      montrees.map((f, i) => [i ? " ; " : null, lienConversation(f.id, f.objet), quand(f.quand) ? ` (${quand(f.quand)})` : ""]),
      autres > 0 ? ` et ${pluriel(autres, "autre", "autres")}` : ""
    );
  }

  function ligne(p, ctx) {
    const connue = p.entreprise && actives("entreprises").some((e) => e.id === p.entreprise.id);
    return ligneProposition({
      case_: ctx.case_,
      texte: [
        h("p.prop__nom", h("strong", p.titre), p.entreprise ? pastille("Entreprise reconnue", "ok") : pastille("Entreprise à choisir", "attention")),
        h(
          "p.prop__coord",
          p.organisme ? h("span", "Organisme : ", p.organisme) : null,
          p.entreprise ? h("span", "Entreprise : ", connue ? h("a.lien-fiche", { href: lienFiche("entreprises", p.entreprise.id) }, p.entreprise.nom) : p.entreprise.nom) : null,
          p.contacts?.length ? h("span", "Avec : ", p.contacts.map((k) => k.nom).join(", ")) : null
        ),
        conversations(p),
      ],
      actions: [
        btn("Créer le dossier…", { ton: "primaire", petit: true, icone: "dossier-plus", titre: `Confirmer l’entreprise et le programme, puis créer le dossier « ${p.titre} »`, aria: `Créer le dossier « ${p.titre} » (l’entreprise et le programme seront à confirmer)`, onclick: () => confirmerPuisCreer(p, ctx) }),
        boutonCourriel(p.fil, p.organisme),
        btn("Écarter", { petit: true, ton: "discret", icone: "cacher", titre: `Ne plus proposer ce dossier (${p.organisme || "organisme"})`, aria: `Écarter le dossier « ${p.titre} »`, onclick: ctx.ecarter }),
      ],
    });
  }

  if (s.reglages?.dossiers === "non") {
    racine.append(
      etatVide({
        icone: "dossiers", titre: "Les propositions de dossiers sont désactivées",
        texte: "Vous pouvez les réactiver dans l’onglet « Réglages ».",
        action: btn("Ouvrir les réglages", { ton: "primaire", href: "#/courriels/reglages" }),
      })
    );
    return { noeud: racine };
  }
  if (!dossiers.length) {
    racine.append(
      etatVide({
        icone: "dossiers",
        titre: !s.pret ? "Pas encore de dossier à proposer" : "Aucun dossier à proposer",
        texte: !s.pret
          ? "Les dossiers apparaîtront ici à la fin de la première lecture de votre boîte Gmail."
          : "Un dossier est proposé quand vous échangez, dans les deux sens, avec un organisme public ou un financeur sans qu’il y ait déjà un dossier au CRM. Les nouvelles propositions apparaîtront ici après chaque analyse.",
      })
    );
    return { noeud: racine };
  }
  racine.append(
    avis({ ton: "info", texte: "Les dossiers de financement ne sont jamais créés automatiquement : il faut confirmer l’entreprise cliente et le programme." }),
    registre({
      P, cle: "dossiers", elements: dossiers, total: s.totaux?.dossiers, id: (p) => p.cle, etiquette: (p) => `Sélectionner : ${p.titre}`, ligne,
      ecarter: {
        libelleGroupe: "Écarter la sélection",
        message: (n) => `${pluriel(n, "dossier écarté", "dossiers écartés")} : le CRM ne ${n > 1 ? "les proposera" : "le proposera"} plus. Pour ${n > 1 ? "les" : "le"} revoir : « Réglages », puis « Oublier mes choix ».`,
      },
      entete: { titre: "Dossiers à créer", sous: "Des échanges avec des organismes qui n’ont pas encore de dossier au CRM. Rien n’est créé avant votre confirmation." },
    }).noeud
  );
  return { noeud: racine };
}
