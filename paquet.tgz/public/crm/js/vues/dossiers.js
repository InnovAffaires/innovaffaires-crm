// Liste des dossiers de financement.
import { h } from "../noyau/dom.js";
import { etat, nomFiche, nomUtilisateur, statutDossierDe } from "../noyau/etat.js";
import { PALIERS } from "../commun/schema.js";
import { argent, dateCourte } from "../commun/format.js";
import { ajouterJours } from "../commun/dates.js";
import { lienFiche } from "../noyau/routeur.js";
import { creerVueListe } from "./liste.js";
import { pastilleStatutDossier, noeudEcheance, libelleOption } from "./aides.js";

export const depend = ["dossiers", "entreprises", "equipe", "config"];

const PHASES = [
  { id: "en-cours", libelle: "En préparation ou en analyse" },
  { id: "accepte", libelle: "Acceptés (suivi)" },
  { id: "termine", libelle: "Terminés" },
  { id: "refuse", libelle: "Refusés" },
];
const type = (d) => statutDossierDe(d.statut)?.type;
const AVANT_DEPOT = new Set(["collecte", "redaction", "revision", "prete"]);

export default creerVueListe({
  entite: "dossiers",
  titre: "Dossiers de financement",
  sous: () => "Chaque demande de subvention, de prêt ou de crédit d’impôt que vous préparez pour un client.",
  nouveau: { libelle: "Nouveau dossier" },
  placeholder: "Rechercher un dossier, un programme, un organisme, un client…",
  triDefaut: { col: "echeance", dir: "asc" },
  href: (d) => lienFiche("dossiers", d.id),
  vide: { icone: "dossiers", titre: "Aucun dossier de financement", texte: "Créez un dossier pour suivre une demande : documents à obtenir, tâches automatiques à chaque étape, date limite et décision de l’organisme." },
  filtres: [
    { id: "phase", libelle: "Situation", tout: "Toutes les situations", options: () => PHASES, test: (d, v) => type(d) === v },
    { id: "statut", libelle: "Statut", tout: "Tous les statuts", options: () => (etat.config?.statuts_dossier || []).map((s) => ({ id: s.id, libelle: s.nom })), test: (d, v) => d.statut === v },
    { id: "palier", libelle: "Palier", tout: "Tous les paliers", options: () => PALIERS, test: (d, v) => d.palier === v },
    {
      id: "echeance", libelle: "Date limite", tout: "Toutes les dates limites",
      options: () => [{ id: "retard", libelle: "Dépassée" }, { id: "7", libelle: "Dans 7 jours ou moins" }, { id: "30", libelle: "Dans 30 jours ou moins" }, { id: "sans", libelle: "Sans date limite" }],
      test: (d, v, auj) => {
        const avant = AVANT_DEPOT.has(d.statut) || (type(d) === "en-cours" && !d.date_depot);
        if (v === "sans") return !d.date_limite;
        if (!d.date_limite || !avant) return false;
        if (v === "retard") return d.date_limite < auj;
        return d.date_limite >= auj && d.date_limite <= ajouterJours(auj, Number(v));
      },
    },
    { id: "responsable", libelle: "Responsable", tout: "Tous responsables", options: () => etat.equipe.map((u) => ({ id: u.id, libelle: u.nom })), test: (d, v) => d.responsable_id === v },
  ],
  colonnes: [
    { id: "titre", titre: "Dossier", classe: "cellule-titre", valeur: (d) => d.titre, rendu: (d) => h("div.identite__texte", h("a", { href: lienFiche("dossiers", d.id) }, d.titre), h("small.muet", nomFiche("entreprises", d.entreprise_id))) },
    { id: "programme", titre: "Programme", valeur: (d) => d.programme, rendu: (d) => h("div.identite__texte", d.programme || "—", d.organisme ? h("small.muet", d.organisme) : null), mobile: "cache" },
    { id: "statut", titre: "Statut", valeur: (d) => (etat.config?.statuts_dossier || []).findIndex((s) => s.id === d.statut), rendu: (d) => pastilleStatutDossier(d.statut) },
    {
      id: "echeance", titre: "Date limite", valeur: (d) => d.date_limite || "",
      rendu: (d) => (AVANT_DEPOT.has(d.statut) || (type(d) === "en-cours" && !d.date_depot) ? noeudEcheance(d.date_limite) : d.date_depot ? h("span.muet", `Déposé le ${dateCourte(d.date_depot)}`) : h("span.muet", "—")),
    },
    { id: "montant", titre: "Montant demandé", classe: "num", valeur: (d) => d.montant_demande, rendu: (d) => (d.montant_demande ? argent(d.montant_demande) : h("span.muet", "—")) },
    { id: "palier", titre: "Palier", valeur: (d) => libelleOption(PALIERS, d.palier), rendu: (d) => libelleOption(PALIERS, d.palier) || h("span.muet", "—"), mobile: "cache" },
  ],
  exporter: {
    nom: "dossiers-innovaffaires",
    colonnes: [
      { titre: "Dossier", valeur: (d) => d.titre }, { titre: "Client", valeur: (d) => nomFiche("entreprises", d.entreprise_id) }, { titre: "Programme", valeur: (d) => d.programme },
      { titre: "Organisme", valeur: (d) => d.organisme }, { titre: "Palier", valeur: (d) => libelleOption(PALIERS, d.palier) }, { titre: "Statut", valeur: (d) => statutDossierDe(d.statut)?.nom || d.statut },
      { titre: "Date limite", valeur: (d) => d.date_limite }, { titre: "Déposé le", valeur: (d) => d.date_depot }, { titre: "Montant demandé", valeur: (d) => d.montant_demande },
      { titre: "Montant accordé", valeur: (d) => d.montant_obtenu }, { titre: "Numéro de dossier", valeur: (d) => d.numero_dossier }, { titre: "Responsable", valeur: (d) => nomUtilisateur(d.responsable_id) },
    ],
  },
});
