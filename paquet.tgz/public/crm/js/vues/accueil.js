// =============================================================================
// Accueil : ce qui demande de l'attention aujourd'hui, et ce qui s'en vient.
//   · la règle des échéances (six semaines)
//   · les demandes du site à traiter, avec le délai de réponse promis
//   · les tâches en retard, du jour et de la semaine (avec ajout rapide)
//   · le pipeline, les factures, l'activité récente
// Chaque section se redessine seule quand les données changent : l'ajout rapide
// d'une tâche n'est jamais effacé pendant la saisie.
// =============================================================================
import { h, remplir, idUnique } from "../noyau/dom.js";
import { etat, actives, maintenant, nomFiche, etapeDe } from "../noyau/etat.js";
import { lire, envoyer } from "../noyau/api.js";
import { synchroniser } from "../noyau/synchro.js";
import { tenter } from "../noyau/ecriture.js";
import { lienFiche } from "../noyau/routeur.js";
import { NOMS_ENTITES } from "../commun/schema.js";
import { aujourdhui, ajouterJours, partiesLocales } from "../commun/dates.js";
import { argent, argentCompact, dateLongue, ilYa, nombre, pluriel, tronquer, echeanceRelative } from "../commun/format.js";
import { valeurPonderee } from "../commun/calculs.js";
import { btn, avatar, pastille, avis, etatVide } from "../ui/composants.js";
import { confirmer } from "../ui/dialogue.js";
import { regleEcheances } from "../ui/regle.js";
import { ajoutRapide, listeTaches, regrouperTaches, mesTachesOuvertes, GROUPES_TACHES } from "../ui/taches.js";
import { ligneActivite } from "../ui/journal.js";
import { etatDocument, soldeDu, delaiReponse, heureTexte } from "./aides.js";
import { echeancesDossiers, echeancesFactures, rendezVous } from "./echeances.js";

export const depend = ["demandes", "taches", "dossiers", "factures", "opportunites", "evenements", "contacts", "entreprises", "config", "session"];

const JOURS_REGLE = 42;

const auj = () => aujourdhui(maintenant());
const majuscule = (s) => s.charAt(0).toUpperCase() + s.slice(1);
const prenom = () => String(etat.utilisateur?.nom || "").trim().split(/\s+/)[0] || "";

// ----- Données de la règle ---------------------------------------------------------------------------------------------------------------
function donneesRegle() {
  const jour = auj();
  const limite = ajouterJours(jour, JOURS_REGLE); // exclu
  const elements = [];
  const retards = [];
  const classer = (e) => (e.date < jour ? retards : e.date < limite ? elements : []).push(e);

  echeancesDossiers().forEach(classer);
  echeancesFactures().forEach(classer);
  for (const e of rendezVous()) {
    if (e.date >= jour && e.date < limite) elements.push({ ...e, heure: e.heure ? heureTexte(e.heure) : "" });
  }
  return { elements, retards };
}

// ----- Demandes ---------------------------------------------------------------------------------------------------------------------------------
function demandesATraiter() {
  return actives("demandes")
    .filter((d) => d.statut === "nouveau" || d.statut === "en-cours")
    .sort((a, b) => String(a.recu || "").localeCompare(String(b.recu || "")));
}
function ligneDemande(d) {
  const delai = delaiReponse(d);
  return h(
    "li",
    h(
      "a.ligne.ligne--haute",
      { href: `#/demandes/${encodeURIComponent(d.id)}` },
      avatar(d.nom),
      h(
        "span.ligne__texte",
        h("span.ligne__tete", h("span.ligne__titre", d.nom || d.courriel), h("span.ligne__fin", delai ? pastille(delai.court, delai.ton, { icone: delai.enRetard ? "alerte" : "horloge" }) : pastille("Répondu", "ok"))),
        h("span.ligne__sous.ligne__sous--libre", [d.organisation, `reçue ${ilYa(Date.parse(d.recu))}`].filter(Boolean).join(" — ")),
        h("span.ligne__extrait", tronquer(d.projet, 140))
      )
    )
  );
}

// ----- Pipeline ---------------------------------------------------------------------------------------------------------------------------
function resumePipeline() {
  const etapes = (etat.config.etapes || []).filter((e) => e.type === "ouverte");
  const ouvertes = actives("opportunites").filter((o) => etapeDe(o.etape)?.type === "ouverte");
  const lignes = etapes.map((e) => {
    const items = ouvertes.filter((o) => o.etape === e.id);
    return { etape: e, n: items.length, valeur: items.reduce((s, o) => s + (+o.valeur || 0), 0), pondere: items.reduce((s, o) => s + valeurPonderee(o), 0) };
  });
  return {
    lignes,
    n: ouvertes.length,
    valeur: lignes.reduce((s, l) => s + l.valeur, 0),
    pondere: lignes.reduce((s, l) => s + l.pondere, 0),
    max: Math.max(1, ...lignes.map((l) => l.valeur)),
  };
}

// ----- Factures ----------------------------------------------------------------------------------------------------------------------------
function resumeFactures() {
  const jour = auj();
  const mois = jour.slice(0, 7);
  let aEncaisser = 0;
  let enRetard = 0;
  let nRetard = 0;
  let encaisse = 0;
  let brouillons = 0;
  let devis = 0;
  const retardees = [];
  for (const f of actives("factures")) {
    const e = etatDocument(f, jour).cle;
    if (f.type === "devis") {
      if (e === "envoyee") devis++;
      continue;
    }
    if (e === "brouillon") brouillons++;
    if (e !== "annulee" && e !== "brouillon") {
      for (const p of f.paiements || []) if (String(p.date).startsWith(mois)) encaisse += +p.montant || 0;
    }
    if (e === "envoyee" || e === "partielle" || e === "en_retard") {
      const s = soldeDu(f);
      aEncaisser += s;
      if (e === "en_retard") {
        enRetard += s;
        nRetard++;
        retardees.push(f);
      }
    }
  }
  retardees.sort((a, b) => String(a.date_echeance).localeCompare(String(b.date_echeance)));
  return { aEncaisser, enRetard, nRetard, encaisse, brouillons, devis, retardees, mois };
}

// ----- Écran -----------------------------------------------------------------------------------------------------------------------------------
export default async function accueil() {
  const peutEcrire = etat.droits.ecrire;
  const estAdmin = etat.droits.administrer;
  const sections = [];
  let regleCourante = null;

  // En-tête et phrase de synthèse
  const titre = h("h1");
  const dateEl = h("p.page-tete__sous");
  const synthese = h("p.accueil__synthese");
  const entete = h("header.page-tete.accueil__tete", h("div", titre, dateEl, synthese));

  function majEntete() {
    const { heure: hh } = partiesLocales(maintenant());
    titre.textContent = `${+hh.slice(0, 2) >= 18 ? "Bonsoir" : "Bonjour"}${prenom() ? `, ${prenom()}` : ""}`;
    dateEl.textContent = majuscule(dateLongue(auj()));
    const phrases = [];
    const dem = demandesATraiter().filter((d) => !d.reponse_le);
    const enRetardDem = dem.filter((d) => delaiReponse(d)?.enRetard).length;
    if (dem.length) phrases.push(`${pluriel(dem.length, "demande attend", "demandes attendent")} une réponse${enRetardDem ? `, dont ${enRetardDem} en retard` : ""}.`);
    const g = regrouperTaches(mesTachesOuvertes(actives("taches")), auj());
    if (g.retard.length) phrases.push(`${pluriel(g.retard.length, "tâche est", "tâches sont")} en retard.`);
    else if (g.aujourdhui.length) phrases.push(`${pluriel(g.aujourdhui.length, "tâche est", "tâches sont")} prévue${g.aujourdhui.length > 1 ? "s" : ""} aujourd’hui.`);
    const { elements } = donneesRegle();
    const prochainDepot = elements.filter((e) => e.type === "depot").sort((a, b) => a.date.localeCompare(b.date))[0];
    if (prochainDepot) phrases.push(`Prochain dépôt : ${echeanceRelative(prochainDepot.date, auj())}.`);
    synthese.textContent = phrases.length ? phrases.join(" ") : "Rien d’urgent pour l’instant.";
  }

  // Bandeau : données d'exemple ou bienvenue
  const zoneBandeau = h("div.accueil__bandeau");
  const aDesExemples = () => NOMS_ENTITES.some((n) => etat.collections[n].some((f) => f.exemple && !f.supprime));
  const base = () => !NOMS_ENTITES.some((n) => etat.collections[n].some((f) => !f.supprime));

  async function retirerExemples() {
    const ok = await confirmer({
      titre: "Retirer les données d’exemple ?",
      message: "Toutes les fiches d’exemple (contacts, entreprises, affaires, dossiers, factures, demandes…) seront supprimées définitivement. Vos propres fiches ne sont pas touchées.",
      libelleConfirmer: "Retirer les exemples", danger: true,
    });
    if (!ok) return;
    const r = await tenter(() => envoyer("/admin/exemples", { action: "retirer" }), { succes: "Données d’exemple retirées." });
    if (r) await synchroniser({ complet: true }).catch(() => {});
  }
  async function chargerExemples() {
    const r = await tenter(() => envoyer("/admin/exemples", { action: "charger" }), { succes: "Données d’exemple ajoutées. Vous pouvez les retirer à tout moment." });
    if (r) await synchroniser({ complet: true }).catch(() => {});
  }

  function majBandeau() {
    if (base()) {
      remplir(
        zoneBandeau,
        h(
          "section.bienvenue",
          { "aria-labelledby": "bienvenue-titre" },
          h("h2", { id: "bienvenue-titre" }, "Bienvenue dans votre CRM"),
          h("p", "Voici comment démarrer. Chaque étape prend quelques minutes, et vous pouvez les faire dans l’ordre qui vous convient."),
          h(
            "ol.bienvenue__etapes",
            estAdmin ? h("li", h("a", { href: "#/parametres/entreprise" }, "Vérifier les coordonnées de l’entreprise et les paramètres de facturation"), h("small.muet", "Elles apparaissent sur vos factures et devis.")) : null,
            estAdmin ? h("li", h("a", { href: "#/parametres/profil" }, "Activer l’authentification à deux facteurs"), h("small.muet", "Une protection supplémentaire pour votre compte, fortement recommandée.")) : null,
            peutEcrire ? h("li", h("a", { href: "#/contacts" }, "Ajouter votre premier contact ou importer vos contacts existants"), h("small.muet", "L’importation accepte un fichier CSV (Excel).")) : null,
            h("li", h("a", { href: "#/demandes" }, "Surveiller les demandes du site Web"), h("small.muet", "Chaque message envoyé par le formulaire du site arrive ici, avec un délai de réponse à respecter."))
          ),
          estAdmin ? h("div.bienvenue__actions", btn("Essayer avec des données d’exemple", { icone: "etincelle", onclick: chargerExemples }), h("small.muet", "Fictives, et retirables d’un clic.")) : null
        )
      );
    } else if (aDesExemples()) {
      remplir(
        zoneBandeau,
        avis({
          ton: "info", titre: "Vous consultez des données d’exemple",
          texte: "Les fiches fictives portent la mention « (exemple) » ou une adresse en @exemple.test. Retirez-les avant de saisir vos vraies données.",
          actions: estAdmin ? btn("Retirer les données d’exemple", { petit: true, onclick: retirerExemples }) : null,
        })
      );
    } else remplir(zoneBandeau);
  }

  // Règle des échéances
  const zoneRegle = h("section.panneau.panneau--regle", { "aria-labelledby": "regle-titre" });
  function majRegle() {
    regleCourante?.detruire();
    const { elements, retards } = donneesRegle();
    regleCourante = regleEcheances({ elements, retards, jours: JOURS_REGLE, auj: auj(), vide: "Aucune échéance prévue d’ici six semaines : ni dépôt, ni facture à échéance, ni rendez-vous." });
    remplir(
      zoneRegle,
      h("header.panneau__tete", h("div.panneau__titres", h("h2", { id: "regle-titre" }, "Échéances des six prochaines semaines"), h("p.panneau__sous", "Dépôts de dossiers, décisions attendues, factures à échéance et rendez-vous.")), h("div.panneau__actions", btn("Calendrier", { petit: true, icone: "calendrier", href: "#/calendrier" }))),
      regleCourante.noeud
    );
  }

  // Sections
  function section(opts) {
    const idT = idUnique("acc");
    const compteur = h("span.panneau__compteur", { hidden: true });
    const corps = h("div.panneau__corps");
    const noeud = h(
      "section.panneau",
      { class: opts.classe, "aria-labelledby": idT, dataset: { bloc: opts.bloc } },
      h("header.panneau__tete", h("div.panneau__titres", h("h2", { id: idT }, opts.titre, compteur), opts.sous ? h("p.panneau__sous", opts.sous) : null), opts.actions ? h("div.panneau__actions", opts.actions) : null),
      corps,
      opts.pied || null
    );
    const s = {
      noeud,
      maj() {
        const r = opts.rendre();
        compteur.hidden = r.compteur === undefined || r.compteur === null;
        compteur.textContent = r.compteur ?? "";
        corps.classList.toggle("panneau__corps--liste", !!r.liste);
        remplir(corps, r.corps);
      },
    };
    sections.push(s);
    return s;
  }

  const sDemandes = section({
    bloc: "demandes", titre: "Demandes à traiter", classe: "panneau--liste panneau--accent", actions: btn("Toutes les demandes", { petit: true, href: "#/demandes" }),
    rendre() {
      const liste = demandesATraiter();
      if (!liste.length) {
        return { corps: etatVide({ icone: "courriel-ok", titre: "Aucune demande en attente", texte: "Les messages envoyés par le formulaire de votre site arriveront ici." }) };
      }
      const visibles = liste.slice(0, 5);
      return {
        compteur: liste.length, liste: true,
        corps: [h("ul.registre-liste", visibles.map(ligneDemande)), liste.length > visibles.length ? h("p.panneau__suite", h("a", { href: "#/demandes" }, `Voir les ${liste.length - visibles.length} autres demandes`)) : null],
      };
    },
  });

  const formTache = ajoutRapide({ placeholder: "Nouvelle tâche…", focusId: "accueil-ajout" });
  const sTaches = section({
    bloc: "taches", titre: "À faire", actions: btn("Toutes les tâches", { petit: true, href: "#/taches" }),
    pied: formTache ? h("div.panneau__pied", formTache) : null,
    rendre() {
      const g = regrouperTaches(mesTachesOuvertes(actives("taches")), auj());
      const montrer = ["retard", "aujourdhui", "semaine"];
      const total = montrer.reduce((n, k) => n + g[k].length, 0);
      const plusTard = g.plusTard.length + g.sansDate.length;
      if (!total) {
        return {
          liste: true,
          corps: etatVide({
            icone: "ok", titre: "Rien d’urgent", texte: plusTard ? `${pluriel(plusTard, "tâche attend", "tâches attendent")} plus tard ou sans échéance.` : "Aucune tâche à faire pour l’instant.",
            action: plusTard ? btn("Voir les tâches", { href: "#/taches" }) : null,
          }),
        };
      }
      let reste = 10;
      const blocs = [];
      for (const k of montrer) {
        if (!g[k].length || reste <= 0) continue;
        const vues = g[k].slice(0, reste);
        reste -= vues.length;
        const def = GROUPES_TACHES.find((x) => x.id === k);
        blocs.push(h("section.groupe-taches", h("h3.groupe-taches__titre", { class: `groupe-taches__titre--${def.ton}` }, def.titre, h("span.panneau__compteur", String(g[k].length))), listeTaches(vues)));
      }
      const affichees = 10 - reste;
      if (total > affichees) blocs.push(h("p.panneau__suite", h("a", { href: "#/taches" }, `Voir les ${total - affichees} autres tâches`)));
      return { compteur: total, liste: true, corps: blocs };
    },
  });

  const sPipeline = section({
    bloc: "pipeline", titre: "Affaires en cours", actions: btn("Ouvrir le pipeline", { petit: true, href: "#/affaires" }),
    rendre() {
      const p = resumePipeline();
      if (!p.n) {
        return { corps: etatVide({ icone: "affaires", titre: "Aucune affaire ouverte", texte: "Une affaire suit un mandat potentiel, de la première demande jusqu’à la signature.", action: peutEcrire ? btn("Nouvelle affaire", { icone: "plus", onclick: async () => (await import("./formulaires.js")).nouvelleFiche("opportunites") }) : null }) };
      }
      return {
        compteur: p.n,
        corps: [
          h(
            "ul.pipeline",
            p.lignes.map((l) =>
              h(
                "li.pipeline__etape",
                { class: { "pipeline__etape--vide": !l.n } },
                h("a.pipeline__nom", { href: "#/affaires" }, l.etape.nom, h("span.pipeline__n", String(l.n))),
                h("span.pipeline__barre", { css: { "--part": (l.valeur / p.max).toFixed(3) }, "aria-hidden": "true" }),
                h("span.pipeline__valeur", l.n ? argentCompact(l.valeur) : "—")
              )
            )
          ),
          h(
            "dl.pipeline__totaux",
            h("div", h("dt", "Honoraires estimés"), h("dd", argent(p.valeur))),
            h("div", h("dt", "Pondérés par la probabilité"), h("dd", argent(p.pondere)))
          ),
        ],
      };
    },
  });

  const sFactures = section({
    bloc: "factures", titre: "Facturation", actions: btn("Toutes les factures", { petit: true, href: "#/factures" }),
    rendre() {
      const r = resumeFactures();
      const toutVide = !actives("factures").length;
      if (toutVide) {
        return { corps: etatVide({ icone: "factures", titre: "Aucune facture", texte: "Créez un devis ou une facture : les montants, les taxes et les numéros sont calculés pour vous.", action: peutEcrire ? btn("Nouvelle facture", { icone: "plus", onclick: async () => (await import("./formulaires.js")).nouvelleFiche("factures", { type: "facture" }) }) : null }) };
      }
      const moisTexte = new Intl.DateTimeFormat("fr-CA", { month: "long", timeZone: "UTC" }).format(new Date(`${r.mois}-01T00:00:00Z`));
      return {
        corps: [
          h(
            "dl.registre-chiffres",
            h("div.registre-chiffres__ligne.registre-chiffres__ligne--principale", h("dt", "À encaisser"), h("dd", argent(r.aEncaisser))),
            r.nRetard ? h("div.registre-chiffres__ligne.registre-chiffres__ligne--alerte", h("dt", `dont en retard (${r.nRetard})`), h("dd", argent(r.enRetard))) : null,
            h("div.registre-chiffres__ligne", h("dt", `Encaissé en ${moisTexte}`), h("dd", argent(r.encaisse))),
            r.brouillons ? h("div.registre-chiffres__ligne", h("dt", "Brouillons à émettre"), h("dd", nombre(r.brouillons))) : null,
            r.devis ? h("div.registre-chiffres__ligne", h("dt", "Devis en attente de réponse"), h("dd", nombre(r.devis))) : null
          ),
          r.retardees.length
            ? h(
                "ul.retards-factures",
                r.retardees.slice(0, 3).map((f) =>
                  h(
                    "li",
                    h("a", { href: lienFiche("factures", f.id) }, h("strong", f.numero || "Facture"), h("span", nomFiche("entreprises", f.entreprise_id)), h("span.muet", `échéance ${echeanceRelative(f.date_echeance, auj())}`), h("span.retards-factures__montant", argent(soldeDu(f))))
                  )
                )
              )
            : null,
        ],
      };
    },
  });

  // Activité récente (chargée à part : elle n'est pas dans la synchronisation)
  const corpsActivite = h("div.panneau__corps.panneau__corps--liste", h("p.liste-vide", "Chargement…"));
  const sectionActivite = h(
    "section.panneau.panneau--liste",
    { "aria-labelledby": "acc-activite", dataset: { bloc: "activite" } },
    h("header.panneau__tete", h("div.panneau__titres", h("h2", { id: "acc-activite" }, "Activité récente"))),
    corpsActivite
  );
  let dernierChargement = 0;
  let chargementEnCours = false;
  async function chargerActivite(force = false) {
    if (chargementEnCours || (!force && Date.now() - dernierChargement < 20_000)) return;
    chargementEnCours = true;
    try {
      const rep = await lire("/activites/recentes");
      dernierChargement = Date.now();
      const liste = (rep.activites || []).slice(0, 8);
      remplir(
        corpsActivite,
        liste.length
          ? h("ul.journal.journal--accueil", liste.map((a) => ligneActivite(a, { contexte: true })))
          : etatVide({ icone: "activite", titre: "Pas encore d’activité", texte: "Les notes, appels, courriels et changements d’étape apparaîtront ici." })
      );
    } catch {
      remplir(corpsActivite, h("p.liste-vide", "L’activité récente n’a pas pu être chargée."));
    } finally {
      chargementEnCours = false;
    }
  }

  // Assemblage
  const noeud = h(
    "div.accueil",
    entete,
    zoneBandeau,
    zoneRegle,
    h("div.accueil__colonnes", h("div.accueil__col", sDemandes.noeud, sPipeline.noeud, sectionActivite), h("div.accueil__col", sTaches.noeud, sFactures.noeud))
  );

  function majTout() {
    majEntete();
    majBandeau();
    majRegle();
    for (const s of sections) s.maj();
  }
  majTout();
  chargerActivite(true);

  const minuteur = setInterval(() => {
    if (document.visibilityState === "visible") majTout();
  }, 60_000);

  return {
    titre: "Accueil",
    noeud,
    miseAJour(changes) {
      majTout();
      if ([...changes].some((c) => c !== "config" && c !== "session")) chargerActivite();
      return true;
    },
    detruire() {
      clearInterval(minuteur);
      regleCourante?.detruire();
    },
  };
}
