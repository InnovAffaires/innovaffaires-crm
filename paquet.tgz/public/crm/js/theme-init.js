// Appliqué avant l'affichage pour éviter un éclair de thème. Aucun accès réseau.
(function () {
  try {
    var t = localStorage.getItem("crm.theme");
    if (t === "clair" || t === "sombre") document.documentElement.setAttribute("data-theme", t);
    var d = localStorage.getItem("crm.densite");
    if (d === "compacte") document.documentElement.setAttribute("data-densite", d);
  } catch (e) {
    /* stockage indisponible : thème automatique */
  }
})();
