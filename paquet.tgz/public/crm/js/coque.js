// =============================================================================
// La « coque » : rail d'onglets, barre du haut, zone de page et affichage des
// écrans selon l'adresse. Les écrans eux-mêmes sont chargés à la demande.
// =============================================================================
import { h, remplir, annoncer } from "./noyau/dom.js";
import { icone } from "./noyau/icones.js";
import { etat, abonner, actives, maintenant } from "./noyau/etat.js";
import { definirRoutes, lireAdresse, resoudre, naviguer, demarrerRouteur } from "./noyau/routeur.js";
import { aujourdhui } from "./commun/dates.js";
import { fileDAppels } from "./noyau/acces-appels.js";
import { menuActions, avatar, logo, etatVide, btn } from "./ui/composants.js";
import { ouvrirDialogue } from "./ui/dialogue.js";
import { ouvrirRecherche } from "./ui/recherche.js";
import { toast } from "./ui/toast.js";
import { appliquerTheme, lireTheme, libelleTheme } from "./noyau/theme.js";
import { modifier as modifierApi } from "./noyau/api.js";
import { surEtatReseau, estEnLigne } from "./noyau/synchro.js";
import { propositionsEnAttente } from "./noyau/classement.js";

export const NAV = [
  { id: "accueil", libelle: "Accueil", icone: "accueil", chemin: "/accueil", mobile: true },
  { id: "demandes", libelle: "Demandes", icone: "demandes", chemin: "/demandes", mobile: true, compteur: "demandes" },
  { id: "contacts", libelle: "Contacts", icone: "contacts", chemin: "/contacts", mobile: true },
  { id: "entreprises", libelle: "Entreprises", icone: "entreprises", chemin: "/entreprises" },
  { id: "affaires", libelle: "Affaires", icone: "affaires", chemin: "/affaires" },
  { id: "dossiers", libelle: "Dossiers", icone: "dossiers", chemin: "/dossiers" },
  { id: "taches", libelle: "Tâches", icone: "taches", chemin: "/taches", mobile: true, compteur: "taches" },
  { id: "appels", libelle: "Appels", icone: "casque", chemin: "/appels", mobile: true, compteur: "appels" },
  { id: "courriels", libelle: "Courriels", icone: "courriel", chemin: "/courriels", compteur: "courriels", ecriture: true },
  { id: "calendrier", libelle: "Calendrier", icone: "calendrier", chemin: "/calendrier" },
  { id: "factures", libelle: "Factures", icone: "factures", chemin: "/factures" },
  "separateur",
  { id: "rapports", libelle: "Rapports", icone: "rapports", chemin: "/rapports" },
  { id: "corbeille", libelle: "Corbeille", icone: "corbeille", chemin: "/corbeille" },
  { id: "parametres", libelle: "Paramètres", icone: "parametres", chemin: "/parametres" },
  { id: "aide", libelle: "Aide", icone: "aide", chemin: "/aide" },
];

export const ROUTES = [
  { motif: "/", redirige: () => `/${etat.utilisateur?.preferences?.vue_initiale || "accueil"}` },
  { motif: "/accueil", nav: "accueil", vue: () => import("./vues/accueil.js") },
  { motif: "/demandes", nav: "demandes", vue: () => import("./vues/demandes.js"), cle: "demandes" },
  { motif: "/demandes/:id", nav: "demandes", vue: () => import("./vues/demandes.js"), cle: "demandes" },
  { motif: "/contacts", nav: "contacts", vue: () => import("./vues/contacts.js") },
  { motif: "/contacts/:id", nav: "contacts", vue: () => import("./vues/contact.js") },
  { motif: "/entreprises", nav: "entreprises", vue: () => import("./vues/entreprises.js") },
  { motif: "/entreprises/:id", nav: "entreprises", vue: () => import("./vues/entreprise.js") },
  { motif: "/affaires", nav: "affaires", vue: () => import("./vues/affaires.js") },
  { motif: "/affaires/:id", nav: "affaires", vue: () => import("./vues/affaire.js") },
  { motif: "/dossiers", nav: "dossiers", vue: () => import("./vues/dossiers.js") },
  { motif: "/dossiers/:id", nav: "dossiers", vue: () => import("./vues/dossier.js") },
  { motif: "/taches", nav: "taches", vue: () => import("./vues/taches.js") },
  { motif: "/appels", nav: "appels", vue: () => import("./vues/appels.js"), cle: "appels" },
  { motif: "/appels/:section", nav: "appels", vue: () => import("./vues/appels.js"), cle: "appels" },
  { motif: "/courriels", nav: "courriels", vue: () => import("./vues/courriels.js"), cle: "courriels" },
  { motif: "/courriels/:section", nav: "courriels", vue: () => import("./vues/courriels.js"), cle: "courriels" },
  { motif: "/calendrier", nav: "calendrier", vue: () => import("./vues/calendrier.js") },
  { motif: "/factures", nav: "factures", vue: () => import("./vues/factures.js") },
  { motif: "/factures/:id", nav: "factures", vue: () => import("./vues/facture.js") },
  { motif: "/rapports", nav: "rapports", vue: () => import("./vues/rapports.js") },
  { motif: "/corbeille", nav: "corbeille", vue: () => import("./vues/corbeille.js") },
  { motif: "/parametres", nav: "parametres", vue: () => import("./vues/parametres.js"), cle: "parametres" },
  { motif: "/parametres/:section", nav: "parametres", vue: () => import("./vues/parametres.js"), cle: "parametres" },
  { motif: "/aide", nav: "aide", vue: () => import("./vues/aide.js") },
  { motif: "/aide/:section", nav: "aide", vue: () => import("./vues/aide.js") },
];

// ----- Actions de création (menu « Nouveau » et recherche rapide) ------------------------------------------------
async function formulaires() {
  return import("./vues/formulaires.js");
}
export function actionsCreation() {
  if (!etat.droits.ecrire) return [];
  return [
    { libelle: "Nouvelle tâche", icone: "taches", executer: async () => (await formulaires()).nouvelleFiche("taches") },
    { libelle: "Nouveau contact", icone: "contacts", executer: async () => (await formulaires()).nouvelleFiche("contacts") },
    { libelle: "Nouvelle entreprise", icone: "entreprises", executer: async () => (await formulaires()).nouvelleFiche("entreprises") },
    { libelle: "Nouvelle affaire", icone: "affaires", executer: async () => (await formulaires()).nouvelleFiche("opportunites") },
    { libelle: "Nouveau dossier de financement", icone: "dossiers", executer: async () => (await formulaires()).nouvelleFiche("dossiers") },
    { libelle: "Nouveau rendez-vous", icone: "calendrier", executer: async () => (await formulaires()).nouvelleFiche("evenements") },
    { libelle: "Nouvelle facture", icone: "factures", executer: async () => (await formulaires()).nouvelleFiche("factures", { type: "facture" }) },
    { libelle: "Nouveau devis", icone: "document", executer: async () => (await formulaires()).nouvelleFiche("factures", { type: "devis" }) },
  ];
}

/** Les sections qui modifient des fiches ne sont pas offertes aux comptes en lecture seule. */
const visible = (n) => n !== "separateur" && !(n.ecriture && !etat.droits.ecrire);

// ----- Compteurs -------------------------------------------------------------------------------------------------------------
export function compteursNav() {
  const aujourd = aujourdhui(maintenant());
  const nouvelles = actives("demandes").filter((d) => d.statut === "nouveau").length;
  const moi = etat.utilisateur?.id;
  const ouvertes = actives("taches").filter((t) => t.statut !== "fait" && (!t.responsable_id || t.responsable_id === moi));
  const enRetard = ouvertes.filter((t) => t.echeance && t.echeance < aujourd).length;
  const duJour = ouvertes.filter((t) => t.echeance === aujourd).length;
  // Appels : les personnes à appeler maintenant (en retard, d'aujourd'hui, ou dont le rappel est arrivé).
  const aAppeler = fileDAppels({ portee: "jour" }).items.filter((it) => it.groupe <= 1);
  const appelsEnRetard = aAppeler.filter((it) => it.tache.echeance < aujourd).length;
  return {
    demandes: { n: nouvelles, alerte: false },
    taches: enRetard ? { n: enRetard, alerte: true } : { n: duJour, alerte: false },
    appels: { n: aAppeler.length, alerte: appelsEnRetard > 0 },
    courriels: { n: propositionsEnAttente(), alerte: false },
  };
}

// ----- Construction ------------------------------------------------------------------------------------------------------------
let elementsNav = new Map();
let elementsCompteur = new Map();
let zonePage = null;
let bandeauReseau = null;
let desabonnerProfil = null;

function itemNav(it) {
  const a = h("a.onglet", { href: `#${it.chemin}`, class: { "onglet--secondaire": !it.mobile }, "data-nav": it.id, title: it.libelle }, icone(it.icone), h("span.onglet__texte", it.libelle));
  if (it.compteur) {
    const c = h("span.compteur", { hidden: true });
    elementsCompteur.set(it.compteur, c);
    a.append(c);
  }
  elementsNav.set(it.id, a);
  return h("li", { class: { "onglet--secondaire": !it.mobile } }, a);
}

function ouvrirPlus() {
  ouvrirDialogue({
    titre: "Toutes les sections", taille: "petit", classe: "dialogue--plus",
    contenu: (ctx) =>
      h("ul.plus-liste", NAV.filter(visible).map((n) =>
        h("li", h("a.plus-liste__lien", { href: `#${n.chemin}`, onclick: () => ctx.fermer() }, icone(n.icone), h("span", n.libelle)))
      )),
  });
}

function menuUtilisateur({ surDeconnexion, haut = false, mobile = false }) {
  const u = etat.utilisateur;
  const contenu = mobile
    ? [avatar(u.nom, { taille: "s" })]
    : [avatar(u.nom, { taille: "m" }), h("span", h("strong", u.nom), h("small", { class: "" }, { admin: "Administrateur", standard: "Utilisateur", lecture: "Lecture seule" }[u.role] || ""))];
  return menuActions({
    contenu, aria: `Menu de ${u.nom}`, classeBouton: mobile ? "btn-icone btn-icone--avatar" : "rail__utilisateur", haut, aligne: mobile ? "droite" : "gauche",
    elements: () => [
      { libelle: "Mon profil et ma sécurité", icone: "utilisateur", onclick: () => naviguer("/parametres/profil") },
      { libelle: `Apparence : ${libelleTheme[lireTheme()]}`, icone: lireTheme() === "sombre" ? "lune" : "soleil", onclick: changerTheme },
      { libelle: "Aide et raccourcis", icone: "aide", onclick: () => naviguer("/aide") },
      "separateur",
      { libelle: "Se déconnecter", icone: "deconnexion", onclick: surDeconnexion },
    ],
  });
}

async function changerTheme() {
  const ordre = ["auto", "clair", "sombre"];
  const suivant = ordre[(ordre.indexOf(lireTheme()) + 1) % ordre.length];
  appliquerTheme(suivant);
  toast(`Apparence : ${libelleTheme[suivant].toLowerCase()}`, { ton: "info", duree: 2200 });
  try {
    await modifierApi("/moi", { preferences: { ...(etat.utilisateur.preferences || {}), theme: suivant } });
    etat.utilisateur.preferences = { ...(etat.utilisateur.preferences || {}), theme: suivant };
  } catch {
    /* la préférence reste gardée dans ce navigateur */
  }
}

export function monterCoque({ surDeconnexion }) {
  elementsNav = new Map();
  elementsCompteur = new Map();
  const listePrincipale = h("ul.rail__liste");
  const listeSecondaire = h("ul.rail__liste.rail__liste--secondaire");
  let secondaire = false;
  for (const it of NAV) {
    if (it === "separateur") {
      secondaire = true;
      continue;
    }
    if (!visible(it)) continue;
    (secondaire ? listeSecondaire : listePrincipale).append(itemNav(it));
  }
  listePrincipale.append(h("li.onglet--plus-item", h("button.onglet.onglet--plus", { type: "button", onclick: ouvrirPlus, "aria-haspopup": "dialog" }, icone("options"), h("span.onglet__texte", "Plus"))));

  const railBas = h("div.rail__bas", menuUtilisateur({ surDeconnexion, haut: true }));
  const barreMobile = h("div.barre__mobile", menuUtilisateur({ surDeconnexion, mobile: true }));
  // Le nom affiché suit les changements du profil (Paramètres → Profil).
  desabonnerProfil?.();
  desabonnerProfil = abonner((changes) => {
    if (!changes.has("session") || !etat.utilisateur) return;
    railBas.replaceChildren(menuUtilisateur({ surDeconnexion, haut: true }));
    barreMobile.replaceChildren(menuUtilisateur({ surDeconnexion, mobile: true }));
  });
  const rail = h(
    "nav.rail",
    { "aria-label": "Navigation principale" },
    h(
      "div.rail__defile",
      h("a.rail__marque", { href: "#/accueil", "aria-label": "InnovAffaires — Accueil" }, logo(), h("span", "InnovAffaires", h("small", "Gestion de la clientèle"))),
      listePrincipale,
      h("hr.rail__sep"),
      listeSecondaire
    ),
    railBas
  );

  const ouvrirNouveau = menuActions({
    libelle: "Nouveau", icone: "plus", ton: "primaire", aria: "Créer une nouvelle fiche",
    elements: () => actionsCreation().map((a) => ({ libelle: a.libelle, icone: a.icone, onclick: a.executer })),
  });
  const barre = h(
    "header.barre",
    h("button.barre__recherche", { type: "button", onclick: ouvrirLaRecherche, "aria-label": "Rechercher (Ctrl+K)" }, icone("recherche"), h("span", "Rechercher…"), h("kbd", "Ctrl K")),
    h("div.barre__actions", etat.droits.ecrire ? ouvrirNouveau : null, barreMobile)
  );
  bandeauReseau = h("div.bandeau-reseau", { role: "status", hidden: estEnLigne() }, icone("alerte"), h("span", "Connexion perdue. Les modifications reprendront dès que la connexion reviendra."));
  zonePage = h("main.page#contenu", { tabindex: "-1" });
  const principal = h("div.principal", barre, bandeauReseau, zonePage);
  remplir(document.getElementById("racine"), h("div.coque", rail, principal));
  surEtatReseau((enLigne) => {
    bandeauReseau.hidden = enLigne;
    if (enLigne) toast("Connexion rétablie.", { ton: "info", duree: 2500 });
  });
  majCompteurs();
  return { zonePage };
}

function libelleCompteur(cle, v) {
  const n = v?.n || 0;
  if (cle === "demandes") return `${n} nouvelle(s) demande(s)`;
  if (cle === "appels") return v?.alerte ? `${n} personne(s) à appeler, dont des appels en retard` : `${n} personne(s) à appeler`;
  if (cle === "courriels") return `${n} proposition(s) à vérifier à partir de vos courriels`;
  return v?.alerte ? `${n} tâche(s) en retard` : `${n} tâche(s) pour aujourd’hui`;
}

export function majCompteurs() {
  const c = compteursNav();
  for (const [cle, el] of elementsCompteur) {
    const v = c[cle];
    el.hidden = !v || v.n <= 0;
    el.textContent = v ? (v.n > 99 ? "99+" : String(v.n)) : "";
    el.classList.toggle("compteur--alerte", !!v?.alerte);
    el.setAttribute("aria-label", libelleCompteur(cle, v));
  }
  const nouvelles = c.demandes.n;
  const base = document.title.replace(/^\(\d+\)\s*/, "");
  document.title = nouvelles ? `(${nouvelles}) ${base}` : base;
}

export function ouvrirLaRecherche() {
  ouvrirRecherche({
    pages: NAV.filter(visible).map((n) => ({ libelle: n.libelle, icone: n.icone, chemin: n.chemin })),
    actions: actionsCreation(),
  });
}

// ----- Affichage des écrans ---------------------------------------------------------------------------------------------------------
let vueCourante = null; // { route, params, ctx, resultat, module }
let jeton = 0;
const memoires = new Map();
let abonnement = null;
let planifRendu = null;

function marquerNav(id) {
  for (const [cle, a] of elementsNav) {
    if (cle === id) a.setAttribute("aria-current", "page");
    else a.removeAttribute("aria-current");
  }
}

function pageErreur(e, ref) {
  return h(
    "div.page-erreur",
    etatVide({
      icone: "alerte", titre: "Cet écran n’a pas pu s’afficher",
      texte: `Une erreur inattendue est survenue (référence ${ref}). Vos données ne sont pas touchées. Rechargez la page ; si le problème revient, notez cette référence.`,
      action: btn("Recharger la page", { ton: "primaire", onclick: () => location.reload() }),
    })
  );
}

function pageIntrouvable() {
  return { titre: "Page introuvable", noeud: h("div", etatVide({ icone: "recherche", titre: "Cette page n’existe pas", texte: "L’adresse est peut-être périmée ou la fiche a été supprimée.", action: btn("Retour à l’accueil", { ton: "primaire", href: "#/accueil" }) })) };
}

function etatFocus() {
  const el = document.activeElement;
  if (!el || !zonePage.contains(el)) return null;
  const id = el.dataset?.focusId;
  if (!id) return null;
  let debut = null;
  let fin = null;
  try {
    debut = el.selectionStart;
    fin = el.selectionEnd;
  } catch {
    /* champ sans sélection */
  }
  return { id, debut, fin };
}
function restaurerFocus(f) {
  if (!f) return;
  const el = zonePage.querySelector(`[data-focus-id="${CSS.escape(f.id)}"]`);
  if (!el) return;
  el.focus({ preventScroll: true });
  try {
    if (f.debut !== null && f.debut !== undefined) el.setSelectionRange(f.debut, f.fin);
  } catch {
    /* ignoré */
  }
}

async function construire({ route, params, requete, chemin }, { garderScroll = false, focus = false } = {}) {
  const mon = ++jeton;
  let resultat;
  let module;
  try {
    module = vueCourante?.route === route && vueCourante.module ? vueCourante.module : await route.vue();
    if (mon !== jeton) return;
    const cleMemoire = route.cle || route.motif;
    if (!memoires.has(cleMemoire)) memoires.set(cleMemoire, new Map());
    const ctx = {
      params, requete, chemin, route,
      memoire: memoires.get(cleMemoire),
      rafraichir: () => rafraichirVue(),
      naviguer,
    };
    resultat = await module.default(ctx);
    if (mon !== jeton) return;
    vueCourante?.resultat?.detruire?.();
    vueCourante = { route, params, requete, chemin, ctx, resultat, module };
  } catch (e) {
    if (mon !== jeton) return;
    const ref = Math.random().toString(16).slice(2, 8);
    console.error(`[écran ${ref}]`, e);
    vueCourante?.resultat?.detruire?.();
    vueCourante = null;
    resultat = { titre: "Erreur", noeud: pageErreur(e, ref) };
  }
  const y = scrollY;
  const f = garderScroll ? etatFocus() : null;
  remplir(zonePage, resultat.noeud);
  document.title = `${resultat.titre ? `${resultat.titre} — ` : ""}CRM InnovAffaires`;
  majCompteurs();
  if (garderScroll) {
    scrollTo({ top: y, behavior: "instant" });
    restaurerFocus(f);
  } else {
    scrollTo({ top: 0, behavior: "instant" });
    if (focus) {
      const titre = zonePage.querySelector("h1");
      if (titre) {
        titre.setAttribute("tabindex", "-1");
        titre.focus({ preventScroll: true });
      } else zonePage.focus({ preventScroll: true });
      annoncer(resultat.titre || "Page");
    }
  }
}

export async function afficherRoute({ premiere = false } = {}) {
  const { chemin, requete } = lireAdresse();
  const { route, params } = resoudre(chemin);
  if (route?.redirige) {
    naviguer(typeof route.redirige === "function" ? route.redirige() : route.redirige, { remplacer: true });
    return;
  }
  if (!route) {
    marquerNav(null);
    vueCourante?.resultat?.detruire?.();
    vueCourante = null;
    const r = pageIntrouvable();
    remplir(zonePage, r.noeud);
    document.title = "Page introuvable — CRM InnovAffaires";
    return;
  }
  marquerNav(route.nav);
  await construire({ route, params, requete, chemin }, { garderScroll: false, focus: !premiere });
}

async function rafraichirVue() {
  if (!vueCourante) return;
  const { route, params, requete, chemin } = vueCourante;
  await construire({ route, params, requete, chemin }, { garderScroll: true });
}

export function demarrerAffichage() {
  definirRoutes(ROUTES);
  abonnement?.();
  abonnement = abonner((changes) => {
    majCompteurs();
    if (!vueCourante) return;
    const mod = vueCourante.module;
    // Les propositions tirées des courriels n'intéressent que l'écran « Courriels » (qui le déclare dans `depend`).
    const utile = [...changes].filter((c) => c !== "session" && c !== "equipe" && (c !== "classement" || mod.depend?.includes("classement")));
    if (!utile.length) return;
    if (mod.depend && !utile.some((c) => mod.depend.includes(c))) return;
    if (vueCourante.resultat?.miseAJour?.(new Set(utile)) === true) return;
    clearTimeout(planifRendu);
    planifRendu = setTimeout(rafraichirVue, 60);
  });
  demarrerRouteur(() => afficherRoute({ premiere: !vueCourante }));
}

export function arreterAffichage() {
  abonnement?.();
  abonnement = null;
  desabonnerProfil?.();
  desabonnerProfil = null;
  vueCourante?.resultat?.detruire?.();
  vueCourante = null;
  jeton++;
}
