// =============================================================================
// Démarrage du CRM : état du site (activé ou non), session, chargement des
// données, puis affichage de la coque. Tout le reste est chargé à la demande.
// =============================================================================
import { h, remplir } from "./noyau/dom.js";
import { installerIcones } from "./noyau/icones.js";
import { appliquerTheme, appliquerDensite } from "./noyau/theme.js";
import { publicGet, lire, envoyer, surSessionExpiree, ErreurApi } from "./noyau/api.js";
import { etat, appliquerSession, viderSession } from "./noyau/etat.js";
import { synchroniser, chargerEquipe, demarrerSynchro, arreterSynchro, surNouvellesDemandes } from "./noyau/synchro.js";
import { demarrerSynchroAgenda, arreterSynchroAgenda, aReconnecter, fonctionsAttendues } from "./noyau/google.js";
import { demarrerClassementAuto, arreterClassementAuto, oublierClassement, surFinAnalyse } from "./noyau/classement.js";
import { naviguer } from "./noyau/routeur.js";
import { montrerConnexion, montrerActivation, montrerChangementMotDePasse, montrerConfiguration2fa } from "./vues/acces.js";
import { monterCoque, demarrerAffichage, arreterAffichage, ouvrirLaRecherche } from "./coque.js";
import { avis, btn, logo } from "./ui/composants.js";
import { toast } from "./ui/toast.js";

let desabonnerNouvelles = null;
let desabonnerClassement = null;
let ouverturEnCours = false;

// ----- Écran d'erreur de démarrage ------------------------------------------------------------------
function montrerErreurDemarrage(e) {
  const message = e instanceof ErreurApi ? e.message : "Une erreur inattendue est survenue au démarrage.";
  console.error("[démarrage]", e);
  document.title = "Démarrage impossible — CRM InnovAffaires";
  remplir(
    document.getElementById("racine"),
    h(
      "main.accueil-acces#contenu",
      h(
        "div.feuille-acces",
        h("div.feuille-acces__marque", logo(), h("span", "InnovAffaires")),
        h("h1", { tabindex: "-1" }, "Le CRM ne démarre pas"),
        avis({ ton: "erreur", texte: message }),
        h("div.actions", btn("Réessayer", { ton: "primaire", onclick: () => location.reload() })),
        e instanceof ErreurApi && e.estReseau
          ? null
          : h("p.petit", "Si le problème persiste, ouvrez l’adresse /api/sante de votre site : elle indique ce qui ne fonctionne pas.")
      )
    )
  );
}

// ----- Session -------------------------------------------------------------------------------------------
function appliquerPreferences(prefs = {}) {
  if (prefs.theme) appliquerTheme(prefs.theme);
  appliquerDensite(prefs.densite === "compacte" ? "compacte" : "confortable");
}

/** Charge la session puis affiche l'écran qui convient. */
async function ouvrirSession(rep) {
  if (ouverturEnCours) return;
  ouverturEnCours = true;
  try {
    arreterAffichage();
    arreterSynchro();
    arreterSynchroAgenda();
    arreterClassementAuto();
    desabonnerNouvelles?.();
    desabonnerClassement?.();
    appliquerSession(rep);
    appliquerPreferences(rep.utilisateur.preferences);
    if (rep.utilisateur.doit_changer_mdp) {
      montrerChangementMotDePasse({ utilisateur: rep.utilisateur, surSucces: relancer });
      return;
    }
    if (rep.mfa_a_configurer) {
      montrerConfiguration2fa({ utilisateur: rep.utilisateur, surSucces: relancer });
      return;
    }
    await synchroniser({ complet: true });
    await chargerEquipe();
    monterCoque({ surDeconnexion: deconnecter });
    demarrerAffichage();
    demarrerSynchro();
    demarrerSynchroAgenda();
    demarrerClassementAuto();
    desabonnerNouvelles = surNouvellesDemandes(annoncerNouvellesDemandes);
    desabonnerClassement = surFinAnalyse(annoncerClassement);
    if (aReconnecter() && Object.values(fonctionsAttendues()).some(Boolean)) {
      toast("Votre connexion à Google a expiré : Gmail et Agenda sont en pause.", {
        ton: "info", duree: 15000, action: { libelle: "Reconnecter", onclick: () => naviguer("/parametres/google") },
      });
    }
  } catch (e) {
    if (e instanceof ErreurApi && e.statut === 401) retourConnexion();
    else montrerErreurDemarrage(e);
  } finally {
    ouverturEnCours = false;
  }
}

async function relancer() {
  try {
    const rep = await lire("/session", { sansExpiration: true });
    await ouvrirSession(rep);
  } catch (e) {
    if (e instanceof ErreurApi && e.statut === 401) retourConnexion();
    else montrerErreurDemarrage(e);
  }
}

function arreterTout() {
  arreterAffichage();
  arreterSynchro();
  arreterSynchroAgenda();
  oublierClassement();
  desabonnerNouvelles?.();
  desabonnerNouvelles = null;
  desabonnerClassement?.();
  desabonnerClassement = null;
  viderSession();
}

function retourConnexion(message = null) {
  arreterTout();
  montrerConnexion({ surSucces: relancer, message });
}

async function deconnecter() {
  try {
    await envoyer("/deconnexion", {});
  } catch {
    /* la session est de toute façon abandonnée localement */
  }
  arreterTout();
  history.replaceState(null, "", location.pathname + location.search);
  montrerConnexion({ surSucces: relancer, message: "Vous êtes déconnecté." });
}

// ----- Nouvelles demandes du site -------------------------------------------------------------------------
function annoncerNouvellesDemandes(liste) {
  const n = liste.length;
  const un = liste[0];
  const texte = n === 1 ? `Nouvelle demande de ${un.nom || un.courriel || "un visiteur"}.` : `${n} nouvelles demandes du site.`;
  toast(texte, { ton: "info", duree: 12000, action: { libelle: "Voir", onclick: () => naviguer(n === 1 ? `/demandes/${encodeURIComponent(un.id)}` : "/demandes") } });
  try {
    if (document.visibilityState === "hidden" && etat.utilisateur?.preferences?.notifications !== false && "Notification" in window && Notification.permission === "granted") {
      const notif = new Notification("InnovAffaires", { body: texte, tag: "demandes", icon: "assets/favicon.svg" });
      notif.onclick = () => {
        focus();
        naviguer(n === 1 ? `/demandes/${encodeURIComponent(un.id)}` : "/demandes");
        notif.close();
      };
    }
  } catch {
    /* notifications indisponibles */
  }
}

// ----- Remplissage du CRM à partir des courriels (mode automatique) ---------------------------------------------
function annoncerClassement({ automatiques }) {
  if (!automatiques) return;
  const texte = automatiques === 1 ? "1 fiche ajoutée ou complétée automatiquement à partir de vos courriels." : `${automatiques} fiches ajoutées ou complétées automatiquement à partir de vos courriels.`;
  toast(texte, { ton: "info", duree: 12000, action: { libelle: "Voir", onclick: () => naviguer("/courriels/ajouts") } });
}

// ----- Raccourcis clavier -----------------------------------------------------------------------------------
function enSaisie(el) {
  if (!(el instanceof HTMLElement)) return false;
  return el.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(el.tagName);
}
function raccourcis(e) {
  if (!etat.utilisateur || !etat.pret) return;
  if (document.querySelector("dialog[open]")) return;
  if ((e.ctrlKey || e.metaKey) && !e.altKey && !e.shiftKey && e.key.toLowerCase() === "k") {
    e.preventDefault();
    ouvrirLaRecherche();
  } else if (!e.ctrlKey && !e.metaKey && !e.altKey && !enSaisie(e.target)) {
    if (e.key === "/") {
      e.preventDefault();
      ouvrirLaRecherche();
    } else if (e.key === "?") {
      e.preventDefault();
      naviguer("/aide");
    }
  }
}

// ----- Démarrage ---------------------------------------------------------------------------------------------
async function demarrer() {
  installerIcones();
  window.__apresConnexion = relancer;
  surSessionExpiree(() => {
    if (!etat.utilisateur) return;
    retourConnexion("Votre session a expiré. Reconnectez-vous pour continuer.");
  });
  addEventListener("keydown", raccourcis);
  addEventListener("unhandledrejection", (e) => {
    if (e.reason instanceof ErreurApi) {
      e.preventDefault();
      toast(e.reason.message, { ton: "erreur" });
    }
  });

  let e;
  try {
    e = await publicGet("/etat");
  } catch (err) {
    montrerErreurDemarrage(err);
    return;
  }
  if (!e.active) {
    montrerActivation({ surSucces: relancer });
    return;
  }
  try {
    const rep = await lire("/session", { sansExpiration: true });
    await ouvrirSession(rep);
  } catch (err) {
    if (err instanceof ErreurApi && err.statut === 401) montrerConnexion({ surSucces: relancer });
    else montrerErreurDemarrage(err);
  }
}

demarrer();
