// Préférences d'affichage gardées dans ce navigateur (jamais de données du CRM) :
// vue choisie, colonnes repliées… Le stockage peut être indisponible : on ignore alors l'erreur.
export function lirePref(cle, defaut = null) {
  try {
    const brut = localStorage.getItem(`crm.${cle}`);
    return brut === null ? defaut : JSON.parse(brut);
  } catch {
    return defaut;
  }
}

export function ecrirePref(cle, valeur) {
  try {
    if (valeur === null || valeur === undefined) localStorage.removeItem(`crm.${cle}`);
    else localStorage.setItem(`crm.${cle}`, JSON.stringify(valeur));
  } catch {
    /* stockage indisponible */
  }
}
