// =============================================================================
// Appels à l'API du CRM (/api/*). Un seul point de passage : jeton CSRF,
// erreurs normalisées en français, détection de session expirée.
// =============================================================================

export class ErreurApi extends Error {
  constructor(message, { statut = 0, code = "", champs = null, actuelle = null, details = null, reessayerS = 0, ref = "" } = {}) {
    super(message);
    this.name = "ErreurApi";
    this.statut = statut;
    this.code = code;
    this.champs = champs;
    this.actuelle = actuelle;
    this.details = details;
    this.reessayerS = reessayerS;
    this.ref = ref;
  }
  get estConflit() {
    return this.statut === 409 && this.code === "conflit";
  }
  get estReseau() {
    return this.code === "reseau";
  }
}

const jeton = { csrf: "" };
const ecouteurs = new Set();

export const definirCsrf = (v) => {
  jeton.csrf = v || "";
};
/** Appelé quand le serveur répond que la session n'est plus valide. */
export function surSessionExpiree(fn) {
  ecouteurs.add(fn);
  return () => ecouteurs.delete(fn);
}

async function lireReponse(rep) {
  const type = rep.headers.get("content-type") || "";
  if (type.includes("application/json")) {
    try {
      return await rep.json();
    } catch {
      return undefined; // corps tronqué (page quittée, connexion coupée) : à distinguer d'une réponse sans corps
    }
  }
  return null;
}

function erreurDepuis(rep, corps) {
  if (corps && typeof corps === "object" && corps.erreur) {
    return new ErreurApi(corps.erreur, {
      statut: rep.status, code: corps.code || "", champs: corps.champs || null, actuelle: corps.actuelle || null,
      details: corps.details || null, reessayerS: corps.reessayerS || 0, ref: corps.ref || "",
    });
  }
  const messages = {
    400: "La requête n’a pas pu être comprise.", 401: "Votre session a expiré. Reconnectez-vous.", 403: "Cette action n’est pas permise.",
    404: "Élément introuvable.", 413: "Le fichier ou le texte est trop volumineux.", 429: "Trop de demandes. Patientez un instant.",
    500: "Une erreur est survenue sur le serveur. Réessayez.", 502: "Le serveur ne répond pas pour l’instant. Réessayez dans un moment.",
    503: "Le service est momentanément indisponible. Réessayez dans un moment.", 504: "Le serveur met trop de temps à répondre. Réessayez.",
  };
  return new ErreurApi(messages[rep.status] || `Erreur inattendue (${rep.status}).`, { statut: rep.status });
}

/**
 * Appelle l'API. `corps` est sérialisé en JSON. Retourne le JSON de la réponse.
 * Options : { signal, sansExpiration: true } (pour ne pas déclencher l'écran de connexion).
 */
export async function appeler(methode, chemin, corps, { signal, sansExpiration = false } = {}) {
  const entetes = { accept: "application/json" };
  const init = { method: methode, headers: entetes, credentials: "same-origin", cache: "no-store", signal };
  if (corps !== undefined) {
    entetes["content-type"] = "application/json";
    init.body = JSON.stringify(corps);
  }
  if (methode !== "GET" && jeton.csrf) entetes["x-csrf-token"] = jeton.csrf;
  let rep;
  try {
    rep = await fetch(`/api${chemin}`, init);
  } catch (e) {
    if (e?.name === "AbortError") throw e;
    throw new ErreurApi("Connexion impossible. Vérifiez votre accès Internet, puis réessayez.", { code: "reseau" });
  }
  const donnees = await lireReponse(rep);
  if (rep.ok) {
    if (donnees === undefined) throw new ErreurApi("La réponse du serveur est incomplète. Réessayez.", { code: "reseau" });
    return donnees ?? {};
  }
  const err = erreurDepuis(rep, donnees);
  if (rep.status === 401 && err.code === "non_authentifie" && !sansExpiration) for (const f of ecouteurs) f();
  throw err;
}

export const lire = (chemin, o) => appeler("GET", chemin, undefined, o);
export const envoyer = (chemin, corps = {}, o) => appeler("POST", chemin, corps, o);
export const modifier = (chemin, corps = {}, o) => appeler("PATCH", chemin, corps, o);
export const supprimer = (chemin, o) => appeler("DELETE", chemin, undefined, o);

/** Télécharge un fichier produit par le serveur (sauvegarde, export). */
export async function telechargerFichier(chemin) {
  let rep;
  try {
    rep = await fetch(`/api${chemin}`, { credentials: "same-origin", cache: "no-store" });
  } catch {
    throw new ErreurApi("Connexion impossible. Vérifiez votre accès Internet, puis réessayez.", { code: "reseau" });
  }
  if (!rep.ok) throw erreurDepuis(rep, await lireReponse(rep));
  const dispo = rep.headers.get("content-disposition") || "";
  const m = /filename="([^"]+)"/.exec(dispo);
  return { blob: await rep.blob(), nom: m ? m[1] : "fichier.json" };
}

/** Appels sans session : formulaire de connexion, activation… (ne déclenchent jamais « session expirée »). */
export const publicPost = (chemin, corps) => appeler("POST", chemin, corps, { sansExpiration: true });
export const publicGet = (chemin) => appeler("GET", chemin, undefined, { sansExpiration: true });
