// =============================================================================
// Routeur par fragment d'adresse (#/contacts/abc). Aucune configuration de
// serveur n'est nécessaire et le rechargement de la page garde l'écran.
// =============================================================================

let table = [];
let rappel = null;

/** liste : [{ motif: "/contacts/:id", ...infos }] — les paramètres sont lus dans l'adresse. */
export function definirRoutes(liste) {
  table = liste.map((r) => {
    const noms = [];
    const re = new RegExp("^" + r.motif.replace(/:(\w+)/g, (_, n) => (noms.push(n), "([^/]+)")) + "/?$");
    return { ...r, re, noms };
  });
}

export function lireAdresse() {
  const brut = (location.hash || "").replace(/^#/, "") || "/";
  const [chemin, requete = ""] = brut.split("?");
  return { chemin: chemin.startsWith("/") ? chemin : `/${chemin}`, requete: new URLSearchParams(requete) };
}

export function resoudre(chemin = lireAdresse().chemin) {
  for (const r of table) {
    const m = r.re.exec(chemin);
    if (!m) continue;
    const params = {};
    r.noms.forEach((n, i) => {
      try {
        params[n] = decodeURIComponent(m[i + 1]);
      } catch {
        params[n] = m[i + 1];
      }
    });
    return { route: r, params };
  }
  return { route: null, params: {} };
}

export function naviguer(chemin, { remplacer = false } = {}) {
  const cible = `#${chemin}`;
  if (location.hash === cible) {
    rappel?.();
    return;
  }
  if (remplacer) location.replace(cible);
  else location.hash = chemin;
}

/** Adresse à placer dans un href. */
export const lien = (chemin) => `#${chemin}`;
export function lienFiche(entite, id) {
  return `#/${{ opportunites: "affaires" }[entite] || entite}/${encodeURIComponent(id)}`;
}
export const cheminFiche = (entite, id) => `/${{ opportunites: "affaires" }[entite] || entite}/${encodeURIComponent(id)}`;

export function demarrerRouteur(onChange) {
  rappel = onChange;
  addEventListener("hashchange", onChange);
  onChange();
}

/** Met à jour la partie « requête » de l'adresse sans recharger l'écran. */
export function majRequete(params, { chemin = lireAdresse().chemin } = {}) {
  const q = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) if (v !== undefined && v !== null && v !== "") q.set(k, v);
  const s = q.toString();
  history.replaceState(null, "", `#${chemin}${s ? `?${s}` : ""}`);
}
