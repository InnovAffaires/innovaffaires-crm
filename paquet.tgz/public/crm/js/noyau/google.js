// =============================================================================
// Gmail et Google Agenda côté écran : état de la connexion de la personne (reçu avec la session),
// actualisation, connexion, et synchronisation des rendez-vous avec Google Agenda.
// Rien n'est demandé à Google tant que la personne n'a pas connecté son compte.
// =============================================================================
import { etat, notifier, abonner, fiche, liees } from "./etat.js";
import { lire, envoyer, ErreurApi } from "./api.js";
import { adresseValide } from "../commun/adresses.js";
import { pluriel } from "../commun/format.js";

const INTERVALLE_MS = 15 * 60_000;
const DELAI_INITIAL_MS = 4_000;

export const FONCTIONS_LIBELLES = {
  gmail_envoi: "Envoyer des courriels avec Gmail",
  gmail_echanges: "Voir les courriels échangés",
  agenda: "Synchroniser avec Google Agenda",
};

export const googleVide = () => ({
  configure: false,
  fonctions: { gmail_envoi: false, gmail_echanges: false, agenda: false },
  moi: { connecte: false },
});

/** État de Google tel que la session l'a décrit (jamais null). */
export const google = () => etat.google || googleVide();
const aucune = { gmail_envoi: false, gmail_echanges: false, agenda: false };
/** Les fonctions réellement utilisables par la personne connectée (configurées, autorisées, connexion valide, droit d'écrire). */
export const fonctionsGoogle = () => {
  const moi = google().moi;
  // Les rôles en lecture seule ne se servent ni de Gmail ni de l'agenda (le serveur les refuserait de toute façon).
  return etat.droits?.ecrire && moi?.connecte && moi.etat === "ok" ? moi.actives || aucune : aucune;
};
export const peutEnvoyerGmail = () => !!fonctionsGoogle().gmail_envoi;
export const peutVoirEchanges = () => !!fonctionsGoogle().gmail_echanges;
export const agendaActif = () => !!fonctionsGoogle().agenda;
/**
 * Les fonctions qui marcheraient si la connexion était encore valide. Elles servent à proposer de la renouveler
 * (au lieu de faire disparaître sans explication les panneaux qui en dépendent).
 */
export const fonctionsAttendues = () => {
  const g = google();
  const moi = g.moi;
  if (!etat.droits?.ecrire || !moi?.connecte || moi.etat !== "a_reconnecter") return aucune;
  const acc = moi.accordees || {};
  const prefs = moi.prefs || {};
  return {
    gmail_envoi: !!(g.fonctions?.gmail_envoi && acc.gmail_envoi),
    gmail_echanges: !!(g.fonctions?.gmail_echanges && acc.gmail_echanges && prefs.echanges !== false),
    agenda: !!(g.fonctions?.agenda && acc.agenda && prefs.agenda !== false),
  };
};
/** Adresse Gmail utilisée pour l'envoi (celle du compte Google connecté). */
export const compteGoogle = () => google().moi?.courriel || "";
/** La connexion existe mais Google ne la reconnaît plus. */
export const aReconnecter = () => !!google().moi?.connecte && google().moi.etat === "a_reconnecter";

export function definirEtatGoogle(e) {
  etat.google = e && typeof e === "object" ? e : null;
  notifier("google");
}

/** Relit l'état auprès du serveur (après une connexion, un changement de préférences, une synchronisation). */
export async function rafraichirGoogle() {
  const e = await lire("/google/etat");
  definirEtatGoogle(e);
  return e;
}

/** Réponses du serveur qui disent que la connexion à Google n'est plus ce que l'écran croyait. */
const CODES_CONNEXION_CHANGEE = new Set(["google_a_reconnecter", "google_non_connecte", "google_non_configure", "google_portee", "google_fonction_desactivee", "google_preference"]);
let relecture = null;

/**
 * À appeler quand une demande liée à Google échoue : si l'erreur montre que la connexion a changé depuis l'ouverture
 * de la session (jeton refusé, accès retiré chez Google…), l'état est relu pour que les boutons et les panneaux suivent.
 * Plusieurs panneaux qui échouent en même temps ne provoquent qu'une seule relecture.
 */
export function signalerErreurGoogle(e) {
  if (!(e instanceof ErreurApi) || !CODES_CONNEXION_CHANGEE.has(e.code) || relecture) return;
  relecture = rafraichirGoogle()
    .catch(() => {})
    .finally(() => {
      relecture = null;
    });
}

/** Envoie la personne chez Google pour autoriser le CRM ; elle revient sur Paramètres → Google. */
export async function connecterGoogle() {
  const r = await envoyer("/google/connexion", {});
  if (typeof r.url !== "string" || !/^https?:\/\//.test(r.url)) throw new ErreurApi("Google n’a pas répondu comme prévu. Réessayez.", { code: "google" });
  location.assign(r.url);
}

// ----- Synchronisation de l'agenda ------------------------------------------------------------------------------------
let enCours = null;
let minuterie = null;
let delaiInitial = null;
let dernier = 0;
let ecouteurVisibilite = null;

/**
 * Compare les rendez-vous du CRM à ceux de Google Agenda et corrige les écarts, par paquets, jusqu'à ce que tout soit à jour.
 * Retourne { pousses, retires, erreurs, restants, derniere_erreur, erreur? } ou null si l'agenda n'est pas actif.
 */
export function synchroniserAgenda() {
  if (enCours) return enCours;
  if (!agendaActif()) return Promise.resolve(null);
  enCours = (async () => {
    const bilan = { pousses: 0, retires: 0, erreurs: 0, restants: 0, derniere_erreur: null };
    try {
      for (let i = 0; i < 20; i++) {
        const r = await envoyer("/agenda/synchro", {});
        if (!r.actif) break;
        bilan.pousses += r.pousses || 0;
        bilan.retires += r.retires || 0;
        bilan.erreurs += r.erreurs || 0;
        bilan.restants = r.restants || 0;
        if (r.derniere_erreur) bilan.derniere_erreur = r.derniere_erreur;
        // On s'arrête dès qu'un paquet échoue ou ne change plus rien : jamais de boucle sans fin.
        if (r.erreurs > 0 || !r.restants || (r.pousses || 0) + (r.retires || 0) === 0) break;
      }
      dernier = Date.now();
      await rafraichirGoogle().catch(() => {});
    } catch (e) {
      if (!(e instanceof ErreurApi)) throw e;
      bilan.erreur = e;
      signalerErreurGoogle(e);
    } finally {
      enCours = null;
    }
    return bilan;
  })();
  return enCours;
}

/** « 3 rendez-vous envoyés, 1 retiré. » */
export function resumeSynchro(bilan) {
  if (!bilan) return { ton: "info", texte: "La synchronisation de l’agenda n’est pas active pour votre compte." };
  if (bilan.erreur) return { ton: "erreur", texte: bilan.erreur.message };
  if (bilan.erreurs > 0) return { ton: "attention", texte: `Synchronisation incomplète : ${bilan.derniere_erreur?.message || "Google a refusé certaines mises à jour."}` };
  if (bilan.pousses + bilan.retires === 0) return { ton: "ok", texte: "Votre Google Agenda est déjà à jour." };
  const morceaux = [];
  if (bilan.pousses) morceaux.push(`${pluriel(bilan.pousses, "rendez-vous envoyé", "rendez-vous envoyés")}`);
  if (bilan.retires) morceaux.push(`${pluriel(bilan.retires, "rendez-vous retiré", "rendez-vous retirés")}`);
  return { ton: "ok", texte: `Google Agenda mis à jour : ${morceaux.join(", ")}.` };
}

/** Lance la synchronisation de l'agenda : peu après l'ouverture, puis toutes les 15 minutes et au retour sur l'onglet. */
export function demarrerSynchroAgenda() {
  arreterSynchroAgenda();
  const tic = () => {
    if (document.visibilityState === "visible" && agendaActif()) synchroniserAgenda().catch((e) => console.warn("[agenda]", e?.message));
  };
  delaiInitial = setTimeout(tic, DELAI_INITIAL_MS);
  minuterie = setInterval(tic, INTERVALLE_MS);
  ecouteurVisibilite = () => {
    if (document.visibilityState === "visible" && Date.now() - dernier > INTERVALLE_MS / 3) tic();
  };
  document.addEventListener("visibilitychange", ecouteurVisibilite);
}

export function arreterSynchroAgenda() {
  clearTimeout(delaiInitial);
  clearInterval(minuterie);
  delaiInitial = null;
  minuterie = null;
  if (ecouteurVisibilite) document.removeEventListener("visibilitychange", ecouteurVisibilite);
  ecouteurVisibilite = null;
}

// ----- Événements de l'agenda Google (superposition dans le calendrier) ------------------------------------------------
/** Les événements de l'agenda principal sur une plage de dates (YYYY-MM-DD, 62 jours au plus). */
export async function lireEvenementsGoogle(du, au, { signal, frais = false } = {}) {
  return lire(`/agenda/evenements?du=${encodeURIComponent(du)}&au=${encodeURIComponent(au)}${frais ? "&frais=1" : ""}`, { signal });
}

const VALIDITE_AGENDA_MS = 45_000;
const memoireAgenda = new Map(); // « du|au » → { t, valeur }
// Un rendez-vous enregistré ou une connexion qui change : les plages déjà lues sont périmées.
abonner((changes) => {
  if (changes.has("evenements") || changes.has("google")) memoireAgenda.clear();
});

/**
 * Comme lireEvenementsGoogle, mais une plage lue il y a moins de 45 secondes se réutilise telle quelle (le calendrier et le
 * formulaire d'un rendez-vous demandent souvent la même). `frais` : relire sans passer par cette mémoire.
 */
export async function evenementsGoogle(du, au, { signal, frais = false } = {}) {
  const cle = `${du}|${au}`;
  const connue = memoireAgenda.get(cle);
  if (!frais && connue && Date.now() - connue.t < VALIDITE_AGENDA_MS) return connue.valeur;
  const valeur = await lireEvenementsGoogle(du, au, { signal, frais });
  memoireAgenda.set(cle, { t: Date.now(), valeur });
  if (memoireAgenda.size > 40) memoireAgenda.delete(memoireAgenda.keys().next().value);
  return valeur;
}

/**
 * Les adresses courriel de la personne concernée par une fiche. Même règle que sur le serveur (adressesDeLaFiche) :
 * contact → son adresse ; entreprise → celles de ses 5 premiers contacts ; demande → l'adresse saisie, puis celle du contact ;
 * affaire, dossier ou autre → le contact, à défaut les 3 premiers contacts de l'entreprise. Sans doublon, en minuscules.
 */
export function adressesDeFiche(entite, f) {
  if (!f) return [];
  const deContact = (id) => {
    const c = id ? fiche("contacts", id) : null;
    return c && !c.supprime && !c.anonymise ? [c.courriel] : [];
  };
  // Comme le serveur : on prend les premiers contacts de l'entreprise, puis on écarte ceux qui n'ont pas d'adresse utilisable.
  const deEntreprise = (id, max) =>
    id ? liees("contacts", "entreprise_id", id).filter((c) => !c.supprime && !c.anonymise).map((c) => c.courriel).slice(0, max) : [];
  const nettoyer = (liste) => [...new Set(liste.map(adresseValide).filter(Boolean))];
  let liste;
  if (entite === "contacts") liste = f.anonymise ? [] : [f.courriel];
  else if (entite === "entreprises") liste = deEntreprise(f.id, 5);
  else if (entite === "demandes") liste = [f.courriel, ...deContact(f.contact_id)];
  else {
    liste = deContact(f.contact_id);
    if (!nettoyer(liste).length) liste = deEntreprise(f.entreprise_id, 3);
  }
  return nettoyer(liste).slice(0, 5);
}

/**
 * L'adresse à laquelle Google enverrait l'invitation d'un rendez-vous lié à une fiche (jamais pour une entreprise entière).
 * Retourne "" s'il n'y en a pas.
 */
export function adresseInvitation(lieType, lieId) {
  if (!lieType || !lieId || lieType === "entreprises") return "";
  return adressesDeFiche(lieType, fiche(lieType, lieId))[0] || "";
}

/** Courriels échangés avec la personne d'une fiche (objet et extrait seulement). `frais` : relire chez Google sans passer par la mémoire de 60 secondes. */
export async function lireEchanges(lieType, lieId, { signal, frais = false } = {}) {
  return lire(`/gmail/echanges?lie_type=${encodeURIComponent(lieType)}&lie_id=${encodeURIComponent(lieId)}${frais ? "&frais=1" : ""}`, { signal });
}

// ----- Envoi d'un courriel ---------------------------------------------------------------------------------------------------
/**
 * Clé d'opération (24 caractères) : un même envoi ne part jamais deux fois, même si la réponse se perd en route.
 * Elle se garde pour toute la durée d'une fenêtre de rédaction et ne change que si l'on décide de renvoyer.
 */
export function nouvelleCleEnvoi() {
  const octets = crypto.getRandomValues(new Uint8Array(18));
  return btoa(String.fromCharCode(...octets)).replace(/\+/g, "-").replace(/\//g, "_");
}

/** Envoie un courriel avec le compte Gmail de la personne (voir /gmail/envoyer dans CONCEPTION.md). */
export const envoyerGmail = (charge) => envoyer("/gmail/envoyer", charge);

/** Adresse de la boîte « Envoyés » du compte Gmail connecté. */
export const lienGmailEnvoyes = () => `https://mail.google.com/mail/?authuser=${encodeURIComponent(compteGoogle())}#sent`;
