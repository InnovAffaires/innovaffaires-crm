// =============================================================================
// CSV : export (compatible Excel en français : séparateur « ; », UTF-8 avec BOM)
// et lecture (séparateur détecté automatiquement).
// =============================================================================

function cellule(v) {
  if (v === null || v === undefined) return "";
  if (typeof v === "number") return Number.isFinite(v) ? String(v).replace(".", ",") : "";
  let s = String(v);
  // Neutralise les formules (=, +, -, @) que le tableur exécuterait à l'ouverture.
  if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`;
  return /[";\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

/** colonnes : [{ titre, valeur(ligne) }] — retourne le texte du fichier. */
export function versCsv(colonnes, lignes) {
  const sortie = [colonnes.map((c) => cellule(c.titre)).join(";")];
  for (const l of lignes) sortie.push(colonnes.map((c) => cellule(c.valeur(l))).join(";"));
  return `\uFEFF${sortie.join("\r\n")}\r\n`;
}

/**
 * Lit un CSV → { entetes: string[], lignes: string[][], numeros: number[] }. Gère les guillemets et les sauts de ligne internes.
 * `numeros[i]` est la ligne du fichier (à partir de 1, titres compris) où commence `lignes[i]` : celle qu'on voit dans le tableur.
 */
export function lireCsv(texte) {
  let t = String(texte ?? "").replace(/^\uFEFF/, "");
  if (!t.trim()) return { entetes: [], lignes: [], numeros: [] };
  const premiere = t.split(/\r?\n/, 1)[0];
  const compte = (c) => (premiere.match(new RegExp(c === "\t" ? "\\t" : `\\${c}`, "g")) || []).length;
  const sep = [";", ",", "\t"].map((c) => [c, compte(c)]).sort((a, b) => b[1] - a[1])[0][0];
  const lignes = [];
  const numeros = [];
  let ligne = [];
  let champ = "";
  let guillemets = false;
  let courante = 1; // ligne du fichier où l'on se trouve
  let debut = 1; // ligne du fichier où a commencé l'enregistrement en cours
  const garder = () => {
    if (ligne.some((x) => x.trim() !== "")) {
      lignes.push(ligne);
      numeros.push(debut);
    }
  };
  for (let i = 0; i < t.length; i++) {
    const c = t[i];
    if (guillemets) {
      if (c === '"') {
        if (t[i + 1] === '"') {
          champ += '"';
          i++;
        } else guillemets = false;
      } else {
        champ += c;
        if (c === "\n" || (c === "\r" && t[i + 1] !== "\n")) courante++;
      }
    } else if (c === '"' && champ === "") guillemets = true;
    else if (c === sep) {
      ligne.push(champ);
      champ = "";
    } else if (c === "\n" || c === "\r") {
      if (c === "\r" && t[i + 1] === "\n") i++;
      ligne.push(champ);
      champ = "";
      garder();
      ligne = [];
      courante++;
      debut = courante;
    } else champ += c;
  }
  ligne.push(champ);
  garder();
  const entetes = (lignes.shift() || []).map((x) => x.trim());
  numeros.shift();
  return { entetes, lignes, numeros };
}
