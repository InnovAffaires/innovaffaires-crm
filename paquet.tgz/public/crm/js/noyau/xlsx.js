// =============================================================================
// Lecture d'un classeur Excel (.xlsx) dans le navigateur, sans bibliothèque ni envoi du fichier : un .xlsx est une
// archive ZIP de petits fichiers XML. On lit la première feuille visible — le texte des cellules (chaînes partagées,
// texte en ligne, nombres) —, sans formules ni mise en forme. Le résultat a la même forme que lireCsv().
//
// Prudence : l'archive vient de l'extérieur. Taille de l'archive, nombre d'entrées, taille décompressée (comptée à la
// lecture, pas selon ce que l'en-tête annonce), nombre de cellules et de colonnes sont plafonnés, et tout XML qui
// déclare des entités ou un DOCTYPE est refusé.
// =============================================================================

export const TAILLE_MAX_XLSX = 3_000_000;
const MAX_ENTREES = 1000;
const MAX_XML = 25_000_000;
const MAX_CELLULES = 300_000;
const MAX_COLONNES = 60;
const MAX_LIGNES = 5000;

export class ErreurXlsx extends Error {
  constructor(code, message) {
    super(message);
    this.name = "ErreurXlsx";
    this.code = code;
  }
}

const ERREURS = {
  format: "Ce fichier n’est pas un classeur Excel (.xlsx) lisible. Enregistrez-le de nouveau, ou exportez-le au format CSV.",
  ancien: "Ce fichier est dans l’ancien format Excel (.xls) que le CRM ne lit pas. Dans Excel : Fichier › Enregistrer sous › « Classeur Excel (.xlsx) » ou « CSV UTF-8 ».",
  chiffre: "Ce classeur est protégé par un mot de passe : enregistrez-en une copie sans mot de passe, puis réessayez.",
  gros: "Ce classeur est trop volumineux pour être lu ici. Enregistrez-le au format CSV, ou découpez-le en plusieurs fichiers.",
  navigateur: "Ce navigateur ne sait pas ouvrir les classeurs Excel. Enregistrez le fichier au format CSV (Fichier › Enregistrer sous › « CSV UTF-8 »).",
  vide: "Ce classeur ne contient aucune feuille avec des données.",
};
const echec = (code) => new ErreurXlsx(code, ERREURS[code]);

// ----- Archive ZIP ---------------------------------------------------------------------------------------------------------
const u16 = (v, o) => v.getUint16(o, true);
const u32 = (v, o) => v.getUint32(o, true);

/** Les quatre premiers octets d'un ArrayBuffer ou d'un Uint8Array (new Uint8Array(tableau, 0, 4) copierait tout le tableau). */
const quatrePremiers = (octets) => (octets instanceof Uint8Array ? octets : new Uint8Array(octets)).subarray(0, 4);

/** « PK\x03\x04 » : un fichier ZIP (donc, a priori, un .xlsx). */
export function ressembleAXlsx(octets) {
  const o = quatrePremiers(octets);
  return o.length === 4 && o[0] === 0x50 && o[1] === 0x4b && o[2] === 3 && o[3] === 4;
}
/** « D0 CF 11 E0 » : l'ancien format Excel (.xls), ou un classeur chiffré. */
export function ressembleAAncienExcel(octets) {
  const o = quatrePremiers(octets);
  return o.length === 4 && o[0] === 0xd0 && o[1] === 0xcf && o[2] === 0x11 && o[3] === 0xe0;
}

/** Les entrées de l'archive : Map(nom → { methode, tailleCompressee, entete }). */
function lireRepertoire(octets) {
  const v = new DataView(octets.buffer, octets.byteOffset, octets.byteLength);
  let fin = -1;
  for (let i = octets.length - 22; i >= Math.max(0, octets.length - 22 - 65_535); i--) {
    if (u32(v, i) === 0x06054b50) {
      fin = i;
      break;
    }
  }
  if (fin < 0) throw echec("format");
  const nombre = u16(v, fin + 10);
  let p = u32(v, fin + 16);
  if (nombre > MAX_ENTREES || p >= octets.length) throw echec("format");
  const entrees = new Map();
  const decodeur = new TextDecoder("utf-8");
  for (let i = 0; i < nombre; i++) {
    if (p + 46 > octets.length || u32(v, p) !== 0x02014b50) throw echec("format");
    const drapeaux = u16(v, p + 8);
    if (drapeaux & 1) throw echec("chiffre");
    const methode = u16(v, p + 10);
    const tailleCompressee = u32(v, p + 20);
    const lNom = u16(v, p + 28);
    const lExtra = u16(v, p + 30);
    const lNote = u16(v, p + 32);
    const entete = u32(v, p + 42);
    if (p + 46 + lNom > octets.length) throw echec("format");
    const nom = decodeur.decode(octets.subarray(p + 46, p + 46 + lNom));
    entrees.set(nom.replace(/\\/g, "/"), { methode, tailleCompressee, entete });
    p += 46 + lNom + lExtra + lNote;
  }
  return entrees;
}

async function decompresser(compresse) {
  if (typeof DecompressionStream !== "function") throw echec("navigateur");
  const flux = new Blob([compresse]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
  const lecteur = flux.getReader();
  const morceaux = [];
  let total = 0;
  try {
    for (;;) {
      const { done, value } = await lecteur.read();
      if (done) break;
      total += value.length;
      if (total > MAX_XML) {
        await lecteur.cancel().catch(() => {});
        throw echec("gros");
      }
      morceaux.push(value);
    }
  } catch (e) {
    if (e instanceof ErreurXlsx) throw e;
    throw echec("format");
  }
  const sortie = new Uint8Array(total);
  let o = 0;
  for (const m of morceaux) {
    sortie.set(m, o);
    o += m.length;
  }
  return sortie;
}

/** Le texte d'un fichier de l'archive, ou null s'il n'y est pas. */
async function lireEntree(octets, entrees, nom) {
  const e = entrees.get(nom);
  if (!e) return null;
  const v = new DataView(octets.buffer, octets.byteOffset, octets.byteLength);
  if (e.entete + 30 > octets.length || u32(v, e.entete) !== 0x04034b50) throw echec("format");
  const debut = e.entete + 30 + u16(v, e.entete + 26) + u16(v, e.entete + 28);
  const fin = debut + e.tailleCompressee;
  if (fin > octets.length) throw echec("format");
  const brut = octets.subarray(debut, fin);
  let contenu;
  if (e.methode === 0) contenu = brut;
  else if (e.methode === 8) contenu = await decompresser(brut);
  else throw echec("format");
  if (contenu.length > MAX_XML) throw echec("gros");
  return new TextDecoder("utf-8").decode(contenu);
}

// ----- XML ---------------------------------------------------------------------------------------------------------------------
function lireXml(texte) {
  if (/<!(DOCTYPE|ENTITY)/i.test(texte)) throw echec("format");
  const doc = new DOMParser().parseFromString(texte, "application/xml");
  if (doc.getElementsByTagName("parsererror").length) throw echec("format");
  return doc;
}
const enfants = (el, nom) => [...el.children].filter((x) => x.localName === nom);
const premier = (el, nom) => enfants(el, nom)[0] || null;

/** Les chaînes partagées du classeur (texte enrichi mis bout à bout, sans la prononciation phonétique). */
function lireChainesPartagees(texte) {
  if (!texte) return [];
  const racine = lireXml(texte).documentElement;
  return enfants(racine, "si").map((si) => {
    let s = "";
    for (const c of si.children) {
      if (c.localName === "t") s += c.textContent;
      else if (c.localName === "r") for (const t of enfants(c, "t")) s += t.textContent;
    }
    return s;
  });
}

/** « B7 » → 1 (colonne, depuis 0). */
function indexColonne(ref) {
  const m = /^([A-Z]{1,3})/.exec(ref || "");
  if (!m) return -1;
  let n = 0;
  for (const c of m[1]) n = n * 26 + (c.charCodeAt(0) - 64);
  return n - 1;
}

function lireFeuille(texte, chaines) {
  const racine = lireXml(texte).documentElement;
  const donnees = premier(racine, "sheetData");
  if (!donnees) return [];
  const lignes = [];
  let cellules = 0;
  let suivante = 0;
  for (const lg of enfants(donnees, "row")) {
    const numero = Number.parseInt(lg.getAttribute("r"), 10);
    const rang = Number.isInteger(numero) && numero > 0 ? numero : suivante + 1;
    suivante = rang;
    if (lignes.length >= MAX_LIGNES) break;
    const valeurs = [];
    let colonne = 0;
    for (const c of enfants(lg, "c")) {
      cellules += 1;
      if (cellules > MAX_CELLULES) throw echec("gros");
      const idx = indexColonne(c.getAttribute("r"));
      const i = idx >= 0 ? idx : colonne;
      colonne = i + 1;
      if (i >= MAX_COLONNES) continue;
      const type = c.getAttribute("t") || "n";
      let valeur = "";
      if (type === "inlineStr") {
        const is = premier(c, "is");
        if (is) valeur = enfants(is, "t").map((t) => t.textContent).join("") || enfants(is, "r").flatMap((r) => enfants(r, "t")).map((t) => t.textContent).join("");
      } else {
        const v = premier(c, "v");
        const brut = v ? v.textContent : "";
        if (type === "s") valeur = chaines[Number.parseInt(brut, 10)] ?? "";
        else if (type === "b") valeur = brut === "1" ? "Oui" : "Non";
        else if (type === "e") valeur = "";
        else valeur = brut;
      }
      if (valeur === "") continue;
      while (valeurs.length < i) valeurs.push("");
      valeurs[i] = valeur;
    }
    if (valeurs.some((x) => String(x).trim() !== "")) lignes.push({ rang, valeurs });
  }
  return lignes;
}

/** Chemin de la première feuille visible, d'après le classeur et ses relations. */
function cheminPremiereFeuille(classeur, relations, entrees) {
  const feuilles = premier(classeur.documentElement, "sheets");
  const cibles = new Map();
  if (relations) for (const r of relations.documentElement.children) if (r.localName === "Relationship") cibles.set(r.getAttribute("Id"), r.getAttribute("Target") || "");
  for (const f of feuilles ? enfants(feuilles, "sheet") : []) {
    const etat = f.getAttribute("state");
    if (etat === "hidden" || etat === "veryHidden") continue;
    const id = [...f.attributes].find((a) => a.localName === "id")?.value;
    let cible = id ? cibles.get(id) : "";
    if (!cible) continue;
    cible = cible.startsWith("/") ? cible.slice(1) : `xl/${cible}`;
    cible = cible.replace(/\/\.\//g, "/");
    if (entrees.has(cible)) return { chemin: cible, nom: f.getAttribute("name") || "" };
  }
  const repli = [...entrees.keys()].filter((n) => /^xl\/worksheets\/[^/]+\.xml$/i.test(n)).sort()[0];
  return repli ? { chemin: repli, nom: "" } : null;
}

/**
 * Lit un classeur .xlsx (ArrayBuffer ou Uint8Array).
 * Retourne { entetes: string[], lignes: string[][], numeros: number[], feuille } — `numeros[i]` est le numéro de la ligne de `lignes[i]`
 * dans le classeur (la première ligne non vide donne les titres).
 */
export async function lireXlsx(contenu) {
  const octets = contenu instanceof Uint8Array ? contenu : new Uint8Array(contenu);
  if (octets.length > TAILLE_MAX_XLSX) throw echec("gros");
  if (ressembleAAncienExcel(octets)) throw echec("ancien");
  if (!ressembleAXlsx(octets)) throw echec("format");
  const entrees = lireRepertoire(octets);
  if (!entrees.has("xl/workbook.xml")) throw echec("format");
  const classeur = lireXml(await lireEntree(octets, entrees, "xl/workbook.xml"));
  const relationsTexte = await lireEntree(octets, entrees, "xl/_rels/workbook.xml.rels");
  const relations = relationsTexte ? lireXml(relationsTexte) : null;
  const feuille = cheminPremiereFeuille(classeur, relations, entrees);
  if (!feuille) throw echec("vide");
  const chaines = lireChainesPartagees(await lireEntree(octets, entrees, "xl/sharedStrings.xml"));
  const lignes = lireFeuille(await lireEntree(octets, entrees, feuille.chemin), chaines);
  if (!lignes.length) throw echec("vide");
  const largeur = Math.min(MAX_COLONNES, Math.max(...lignes.map((l) => l.valeurs.length)));
  const complet = (valeurs) => Array.from({ length: largeur }, (_, i) => String(valeurs[i] ?? ""));
  const [titres, ...corps] = lignes;
  return {
    entetes: complet(titres.valeurs).map((x) => x.trim()),
    lignes: corps.map((l) => complet(l.valeurs)),
    numeros: corps.map((l) => l.rang),
    feuille: feuille.nom,
  };
}
