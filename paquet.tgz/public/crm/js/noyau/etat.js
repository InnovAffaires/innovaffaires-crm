// =============================================================================
// État de l'application : session, configuration et copie locale des fiches.
// Les écrans lisent ici ; la synchronisation (synchro.js) remplit.
// =============================================================================
import { NOMS_ENTITES, ENTITES } from "../commun/schema.js";
import { nomComplet, normaliser } from "../commun/format.js";
import { definirCsrf } from "./api.js";

export const etat = {
  pret: false,
  utilisateur: null,
  droits: { ecrire: false, administrer: false, role: "lecture" },
  config: null,
  courriel: null,
  version: "",
  mfaAConfigurer: false,
  decalageHorloge: 0,
  collections: Object.fromEntries(NOMS_ENTITES.map((n) => [n, []])),
  index: Object.fromEntries(NOMS_ENTITES.map((n) => [n, new Map()])),
  etags: {},
  equipe: [],
};

const abonnes = new Set();
/** fn(changements: Set<string>) — noms d'entités modifiées, « config » ou « equipe ». */
export function abonner(fn) {
  abonnes.add(fn);
  return () => abonnes.delete(fn);
}
let enAttente = new Set();
let planifie = false;
export function notifier(...noms) {
  for (const n of noms) enAttente.add(n);
  if (planifie) return;
  planifie = true;
  queueMicrotask(() => {
    planifie = false;
    const lot = enAttente;
    enAttente = new Set();
    for (const f of [...abonnes]) {
      try {
        f(lot);
      } catch (e) {
        console.error("[abonné]", e);
      }
    }
  });
}

/** Instant courant corrigé par l'écart avec l'horloge du serveur. */
export const maintenant = () => Date.now() + etat.decalageHorloge;

export function appliquerSession(rep) {
  etat.utilisateur = rep.utilisateur;
  etat.droits = rep.droits || etat.droits;
  etat.config = rep.config || etat.config;
  etat.courriel = rep.courriel || null;
  etat.version = rep.version || etat.version;
  etat.mfaAConfigurer = !!rep.mfa_a_configurer;
  if (rep.csrf) definirCsrf(rep.csrf);
  if (rep.maintenant) etat.decalageHorloge = rep.maintenant - Date.now();
  notifier("session", "config");
}

export function viderSession() {
  etat.pret = false;
  etat.utilisateur = null;
  etat.droits = { ecrire: false, administrer: false, role: "lecture" };
  etat.config = null;
  etat.etags = {};
  etat.equipe = [];
  for (const n of NOMS_ENTITES) {
    etat.collections[n] = [];
    etat.index[n] = new Map();
  }
  cacheActives.clear();
  cacheLiees.clear();
  definirCsrf("");
}

const cacheActives = new Map();
const cacheLiees = new Map();

function reindexer(nom) {
  const m = new Map();
  for (const f of etat.collections[nom]) m.set(f.id, f);
  etat.index[nom] = m;
  cacheActives.delete(nom);
  for (const k of [...cacheLiees.keys()]) if (k.startsWith(`${nom}|`)) cacheLiees.delete(k);
}

/** Applique la réponse de /api/synchro. Retourne l'ensemble des entités modifiées. */
export function appliquerSynchro(rep) {
  const changes = new Set();
  for (const [nom, items] of Object.entries(rep.collections || {})) {
    if (!(nom in etat.collections)) continue;
    etat.collections[nom] = items;
    reindexer(nom);
    changes.add(nom);
  }
  Object.assign(etat.etags, rep.etags || {});
  if (rep.config) {
    etat.config = rep.config;
    changes.add("config");
  }
  if (rep.maintenant) etat.decalageHorloge = rep.maintenant - Date.now();
  etat.pret = true;
  if (changes.size) notifier(...changes);
  return changes;
}

export function definirEquipe(liste) {
  etat.equipe = liste;
  notifier("equipe");
}

// ----- Lecture --------------------------------------------------------------------
export const fiche = (entite, id) => (id ? etat.index[entite]?.get(id) || null : null);

/** Fiches non supprimées (liste partagée : ne pas la modifier). */
export function actives(entite) {
  const src = etat.collections[entite];
  const c = cacheActives.get(entite);
  if (c && c.src === src) return c.val;
  const val = src.filter((f) => !f.supprime);
  cacheActives.set(entite, { src, val });
  return val;
}

export const supprimees = (entite) => etat.collections[entite].filter((f) => f.supprime);

/** Fiches actives dont `champ` vaut `id` (ex. les contacts d'une entreprise). */
export function liees(entite, champ, id) {
  if (!id) return [];
  const cle = `${entite}|${champ}`;
  const src = etat.collections[entite];
  let c = cacheLiees.get(cle);
  if (!c || c.src !== src) {
    const m = new Map();
    for (const f of src) {
      if (f.supprime || !f[champ]) continue;
      const k = f[champ];
      if (!m.has(k)) m.set(k, []);
      m.get(k).push(f);
    }
    c = { src, m };
    cacheLiees.set(cle, c);
  }
  return c.m.get(id) || [];
}

/** Mise à jour locale immédiate après un appel réussi (la synchro confirmera). */
export function mettreAJourFiche(entite, f) {
  const liste = etat.collections[entite];
  const i = liste.findIndex((x) => x.id === f.id);
  if (i >= 0) liste[i] = f;
  else liste.push(f);
  etat.collections[entite] = liste.slice();
  reindexer(entite);
  notifier(entite);
}

export function retirerFicheLocale(entite, id) {
  etat.collections[entite] = etat.collections[entite].filter((x) => x.id !== id);
  reindexer(entite);
  notifier(entite);
}

// ----- Libellés ----------------------------------------------------------------------
export function libelleFiche(entite, f) {
  if (!f) return "";
  switch (entite) {
    case "contacts":
      return nomComplet(f) || f.courriel || "Contact sans nom";
    case "entreprises":
      return f.nom || "Entreprise sans nom";
    case "factures":
      return f.numero || (f.type === "devis" ? "Devis (brouillon)" : "Facture (brouillon)");
    case "demandes":
      return f.nom || f.courriel || "Demande";
    default:
      return f.titre || f.nom || "Sans titre";
  }
}
export const nomFiche = (entite, id) => libelleFiche(entite, fiche(entite, id));

export function nomUtilisateur(id) {
  if (!id) return "";
  if (etat.utilisateur && etat.utilisateur.id === id) return etat.utilisateur.nom;
  return etat.equipe.find((u) => u.id === id)?.nom || "";
}

/** Étape de la configuration par identifiant. */
export const etapeDe = (id) => etat.config?.etapes.find((e) => e.id === id) || null;
export const statutDossierDe = (id) => etat.config?.statuts_dossier.find((e) => e.id === id) || null;
export const sourceDe = (id) => etat.config?.sources.find((e) => e.id === id)?.libelle || "";

/** Texte indexé pour la recherche d'une fiche (sans accents, minuscules). */
const cacheTexte = new WeakMap();
export function texteRecherche(entite, f) {
  let t = cacheTexte.get(f);
  if (t !== undefined) return t;
  const champs = ENTITES[entite].recherche || [];
  const parts = champs.map((c) => (Array.isArray(f[c]) ? f[c].join(" ") : f[c]));
  if (entite === "contacts") parts.push(nomComplet(f));
  if (entite === "factures") parts.push(nomFiche("entreprises", f.entreprise_id));
  if (entite === "contacts" || entite === "opportunites" || entite === "dossiers") parts.push(nomFiche("entreprises", f.entreprise_id));
  t = normaliser(parts.filter(Boolean).join(" "));
  cacheTexte.set(f, t);
  return t;
}
