// =============================================================================
// « Remplir mon CRM avec mes courriels », côté écran.
//   • Le résumé reçu avec la session (activé ou non, mode, nombre de propositions) vit dans etat.classement.
//   • Les appels au serveur (activer, régler, ajouter, compléter, écarter, annuler…) sont regroupés ici.
//   • La boucle d'analyse lit la boîte Gmail par petits lots tant qu'il reste du travail ; elle tourne
//     en arrière-plan (peu après l'ouverture, puis toutes les 15 minutes) ou à la demande, jamais deux fois en même temps.
//   • Le « suivi des courriels » (tâches à créer ou à terminer, affaires, dossiers) passe par les mêmes appels : sa vue vient
//     avec celle de l'analyse (vue.suivi) et ses actions ont leurs propres fonctions plus bas.
// Aucun texte de courriel ne passe par ici : le serveur ne renvoie que des coordonnées repérées, des objets de conversation et des compteurs.
// =============================================================================
import { etat, notifier } from "./etat.js";
import { lire, envoyer, modifier, ErreurApi } from "./api.js";
import { synchroniser } from "./synchro.js";
import { google, peutVoirEchanges, signalerErreurGoogle } from "./google.js";

const BASE = "/gmail/classer";
const INTERVALLE_MS = 15 * 60_000;
const DELAI_INITIAL_MS = 7_000;
const VALIDITE_VUE_MS = 8_000;
const MAX_LOTS = 500;
const TAILLE_PAQUET = 50; // le serveur accepte au plus 50 ajouts ou compléments par appel
const RAFRAICHIR_PENDANT_MS = 15_000;

/** Les périodes offertes, avec le texte qui les décrit. */
export const PERIODES = [
  [30, "30 derniers jours"],
  [90, "3 derniers mois"],
  [180, "6 derniers mois"],
  [365, "12 derniers mois"],
];
export const libellePeriode = (jours) => PERIODES.find(([j]) => j === jours)?.[1] || `${jours} derniers jours`;

// ----- Résumé (barre de navigation, tuiles) -----------------------------------------------------------------------
export const classementVide = () => ({ actif: false, mode: "revue", nouveaux: 0, completer: 0, en_cours: false, due: false });
/** Le résumé de la personne connectée (jamais null). */
export const classement = () => etat.classement || classementVide();
export const classementActif = () => !!etat.classement?.actif;
/** Le suivi des courriels est-il allumé ? (Le résumé ne porte `suivi` que dans ce cas.) */
export const suiviActif = () => !!etat.classement?.actif && !!etat.classement.suivi;
/** Le nombre de propositions qui attendent une réponse (personnes à ajouter, fiches à compléter, tâches, affaires et dossiers du suivi). */
export function propositionsEnAttente() {
  if (!classementActif()) return 0;
  const c = etat.classement;
  const s = c.suivi || {};
  return (c.nouveaux || 0) + (c.completer || 0) + (s.taches || 0) + (s.fermer || 0) + (s.affaires || 0) + (s.dossiers || 0);
}

function resumeDe(v) {
  if (!v?.actif) return { ...classementVide(), mode: v?.mode || "revue" };
  const t = v.suivi?.actif ? v.suivi.totaux || {} : null;
  return {
    actif: true, mode: v.mode, nouveaux: v.nouveaux_total ?? v.nouveaux?.length ?? 0, completer: v.completer_total ?? v.completer?.length ?? 0,
    en_cours: !!v.analyse, due: !!v.due,
    ...(t ? { suivi: { taches: t.taches || 0, fermer: t.fermer || 0, affaires: t.affaires || 0, dossiers: t.dossiers || 0 } } : {}),
  };
}

function definirResume(r) {
  const avant = JSON.stringify(etat.classement || null);
  etat.classement = r;
  if (JSON.stringify(r) !== avant) notifier("classement");
}

/** Pourquoi la fonction ne peut pas lire la boîte Gmail en ce moment, ou null si tout est prêt. { code, titre, texte, libelleAction?, chemin? } */
export function raisonBloquee() {
  if (!etat.droits?.ecrire) {
    return { code: "lecture", titre: "Cette fonction n’est pas offerte en lecture seule", texte: "Le remplissage du CRM à partir des courriels modifie des fiches : il faut un compte qui peut les modifier." };
  }
  const g = google();
  const aller = { libelleAction: "Ouvrir les réglages de Google", chemin: "/parametres/google" };
  if (!g.configure) {
    return {
      code: "non_configure", titre: "Google n’est pas encore configuré",
      texte: etat.droits.administrer
        ? "Faites d’abord la configuration de Google (une seule fois, environ 15 minutes) : vous pourrez ensuite connecter votre compte et activer cette fonction."
        : "Une personne qui administre le CRM doit d’abord faire la configuration de Google (une seule fois). Vous pourrez ensuite connecter votre compte ici.",
      ...aller,
    };
  }
  const moi = g.moi || {};
  if (!moi.connecte) {
    return { code: "non_connecte", titre: "Connectez votre compte Google", texte: "Cette fonction lit votre boîte Gmail. Connectez votre compte Google, puis revenez ici pour l’activer.", libelleAction: "Connecter mon compte Google", chemin: "/parametres/google" };
  }
  if (moi.etat === "a_reconnecter") {
    return { code: "a_reconnecter", titre: "Reconnexion à Google nécessaire", texte: "Google ne reconnaît plus la connexion de votre compte (mot de passe changé, accès retiré ou délai expiré). Reconnectez-vous pour reprendre là où vous étiez.", libelleAction: "Reconnecter mon compte", chemin: "/parametres/google" };
  }
  if (!g.fonctions?.gmail_echanges) {
    return { code: "fonction_off", titre: "La lecture des courriels est désactivée", texte: "La fonction « Voir les courriels échangés » n’est pas offerte à l’équipe. Une personne qui administre le CRM peut l’activer dans Paramètres → Google.", ...aller };
  }
  if (!moi.accordees?.gmail_echanges) {
    return { code: "non_accordee", titre: "Autorisation manquante chez Google", texte: "Google n’a pas accordé la lecture de vos courriels. Reconnectez votre compte et laissez toutes les cases cochées sur la page de Google.", libelleAction: "Reconnecter mon compte", chemin: "/parametres/google" };
  }
  if (moi.prefs?.echanges === false) {
    return { code: "pause", titre: "Les courriels échangés sont en pause", texte: "Vous les avez mis en pause dans Paramètres → Google. Réactivez-les pour utiliser cette fonction.", ...aller };
  }
  return null;
}

// ----- La vue complète (propositions, derniers ajouts, réglages) ------------------------------------------------
let vueMemoire = null;
let vueDepuis = 0;
let vueEnCours = null;
const ecouteursVue = new Set();

/** fn(vue) chaque fois qu'une vue plus récente est connue (lue ou renvoyée par une action). Retourne la fonction qui désabonne. */
export const surVue = (fn) => (ecouteursVue.add(fn), () => ecouteursVue.delete(fn));

/** Applique une vue reçue du serveur : elle devient la mémoire de l'écran et met le résumé à jour. */
export function appliquerVue(v) {
  vueMemoire = v;
  vueDepuis = Date.now();
  definirResume(resumeDe(v));
  for (const f of [...ecouteursVue]) {
    try {
      f(v);
    } catch (e) {
      console.error("[vue]", e);
    }
  }
  return v;
}

/** La dernière vue connue (même un peu ancienne), ou null. Sert à dessiner tout de suite pendant qu'on relit. */
export const vueConnue = () => vueMemoire;
export const vueEstFraiche = () => !!vueMemoire && Date.now() - vueDepuis < VALIDITE_VUE_MS;

/** Lit la vue auprès du serveur. `force` : ne pas se contenter de ce qui a été lu il y a quelques secondes. */
export function chargerVue({ force = false } = {}) {
  if (!force && vueEstFraiche()) return Promise.resolve(vueMemoire);
  if (!force && vueEnCours) return vueEnCours;
  const precedente = vueEnCours;
  const demande = (precedente ? precedente.catch(() => {}) : Promise.resolve()).then(async () => appliquerVue(await lire(BASE)));
  vueEnCours = demande;
  demande
    .finally(() => {
      if (vueEnCours === demande) vueEnCours = null;
    })
    .catch(() => {});
  return demande;
}

// ----- Actions -------------------------------------------------------------------------------------------------------
const retenir = async (promesse) => appliquerVue(await promesse);

/** Active l'analyse (toujours en mode « je vérifie » au départ). */
export const activerClassement = ({ fenetre_jours } = {}) => retenir(envoyer(`${BASE}/activer`, { confirmer: true, ...(fenetre_jours ? { fenetre_jours } : {}) }));
/** Désactive la fonction et efface ce que le CRM avait gardé. */
export const desactiverClassement = () => retenir(envoyer(`${BASE}/desactiver`, {}));
/** Change le mode ("revue" | "auto", avec confirmation pour "auto") et/ou la période (en jours). */
export const reglagesClassement = (changements) => retenir(modifier(`${BASE}/reglages`, changements));
/** Repart de zéro. `ignores` : oublie aussi les personnes écartées. */
export const reanalyserClassement = ({ ignores = false } = {}) => retenir(envoyer(`${BASE}/reanalyser`, { ignores }));
export const effacerClassement = () => retenir(envoyer(`${BASE}/effacer`, {}));
export const annulerOperation = (id) => envoyer(`${BASE}/annuler`, { id });
export const ignorerPropositions = (type, adresses) => envoyer(`${BASE}/ignorer`, { type, adresses });

/**
 * Envoie une liste par paquets de 50. Retourne { resultats, erreur } : si un paquet échoue, ce qui précède est tout de même rapporté.
 */
async function parPaquets(chemin, cle, liste) {
  const resultats = [];
  let erreur = null;
  for (let i = 0; i < liste.length; i += TAILLE_PAQUET) {
    try {
      const r = await envoyer(`${BASE}/${chemin}`, { [cle]: liste.slice(i, i + TAILLE_PAQUET) });
      resultats.push(...(r.resultats || []));
    } catch (e) {
      if (!(e instanceof ErreurApi)) throw e;
      erreur = e;
      break;
    }
  }
  return { resultats, erreur };
}

/** Le CRM a changé (fiches créées ou modifiées par le serveur) : on rapatrie les changements, puis on relit les propositions. */
async function apresChangement() {
  // Deux passes : une synchronisation déjà en route au moment de l'écriture peut ne pas avoir vu le changement.
  await synchroniser().catch(() => {});
  await synchroniser().catch(() => {});
  await chargerVue({ force: true }).catch(() => {});
}

/** Ajoute des personnes au CRM. `contacts` : [{ adresse, prenom?, nom?, telephone?, mobile?, titre?, entreprise?: { id } | { nom } }]. */
export async function ajouterContacts(contacts) {
  const sortie = await parPaquets("ajouter", "contacts", contacts);
  await apresChangement();
  return sortie;
}

/** Complète des fiches existantes. `completions` : [{ adresse, champs: { telephone?, mobile?, titre?, prenom?, nom?, entreprise? } }]. */
export async function completerFiches(completions) {
  const sortie = await parPaquets("completer", "completions", completions);
  await apresChangement();
  return sortie;
}

/** Écarte des propositions ("nouveaux" ou "completer") : elles ne reviendront pas. */
export async function ecarterPropositions(type, adresses) {
  const tout = [...new Set(adresses)];
  let ecartes = 0;
  for (let i = 0; i < tout.length; i += 200) {
    const r = await ignorerPropositions(type, tout.slice(i, i + 200));
    ecartes += r.ignores || 0;
  }
  await chargerVue({ force: true }).catch(() => {});
  return ecartes;
}

/** Défait un ajout ou un complément récent. */
export async function defaire(id) {
  const r = await annulerOperation(id);
  await apresChangement();
  return r;
}

// ----- Suivi des courriels ---------------------------------------------------------------------------------------------
const SUIVI = `${BASE}/suivi`;

/** Allume le suivi (toujours en mode « je vérifie ») : la mémoire des conversations se construit à la lecture suivante. */
export const activerSuivi = () => retenir(modifier(`${BASE}/reglages`, { suivi: { actif: true }, confirmer: true }));
/** Éteint le suivi et efface la mémoire des conversations. Les tâches, affaires et dossiers déjà créés restent. */
export const desactiverSuivi = () => retenir(modifier(`${BASE}/reglages`, { suivi: { actif: false } }));
/** Change des réglages du suivi (`confirmer` : pour passer une sorte en mode automatique). */
export const reglerSuivi = (suivi, { confirmer = false } = {}) => retenir(modifier(`${BASE}/reglages`, { suivi, ...(confirmer ? { confirmer: true } : {}) }));

/**
 * Crée ou termine ce que la personne a choisi. `elements` : [{ genre: "tache" | "fermer" | "affaire" | "dossier", cle, … }] — pour une
 * affaire, `titre` ; pour un dossier, `titre`, `programme`, `organisme` et `entreprise` ({ id } ou { nom }).
 * Retourne { resultats, crees, termines, erreur } : si un paquet échoue, ce qui précède est tout de même rapporté.
 */
export async function appliquerSuivi(elements) {
  const sortie = { resultats: [], crees: { taches: 0, affaires: 0, dossiers: 0 }, termines: 0, erreur: null };
  for (let i = 0; i < elements.length; i += TAILLE_PAQUET) {
    try {
      const r = await envoyer(`${SUIVI}/appliquer`, { elements: elements.slice(i, i + TAILLE_PAQUET) });
      sortie.resultats.push(...(r.resultats || []));
      for (const k of Object.keys(sortie.crees)) sortie.crees[k] += r.crees?.[k] || 0;
      sortie.termines += r.termines || 0;
    } catch (e) {
      if (!(e instanceof ErreurApi)) throw e;
      sortie.erreur = e;
      break;
    }
  }
  await apresChangement();
  return sortie;
}

/** Écarte des propositions du suivi (par leur clé) et/ou des personnes (plus aucune proposition à leur sujet). */
export async function ecarterSuivi({ cles = [], personnes = [] }) {
  const toutes = [...new Set(cles)];
  const gens = [...new Set(personnes)];
  let ignores = 0;
  let ecartees = 0;
  try {
    for (let i = 0; i < Math.max(toutes.length, 1); i += 200) {
      const lot = toutes.slice(i, i + 200);
      if (!lot.length && !(i === 0 && gens.length)) break;
      const r = await envoyer(`${SUIVI}/ignorer`, { cles: lot, personnes: i === 0 ? gens.slice(0, 100) : [] });
      ignores += r.ignores || 0;
      ecartees += r.personnes || 0;
    }
  } finally {
    await chargerVue({ force: true }).catch(() => {});
  }
  return { ignores, personnes: ecartees };
}

/** Oublie les propositions du suivi écartées et les personnes qu'on ne suit plus. */
export async function oublierChoixSuivi() {
  const r = await envoyer(`${SUIVI}/oublier-choix`, {});
  await chargerVue({ force: true }).catch(() => {});
  return r;
}

// ----- La boucle d'analyse ---------------------------------------------------------------------------------------------
const analyse = { enCours: false, manuel: false, progres: null, pause: null, erreur: null, bilan: null };
const ecouteurs = new Set();
const ecouteursFin = new Set();
let courante = null;
/** Change à chaque déconnexion : une boucle commencée avant s'arrête et ne touche plus à rien. */
let generation = 0;

export const etatAnalyse = () => ({ enCours: analyse.enCours, manuel: analyse.manuel, progres: analyse.progres, pause: analyse.pause, erreur: analyse.erreur, bilan: analyse.bilan });
/** fn(etatAnalyse()) à chaque avancement. Retourne la fonction qui désabonne. */
export const surAnalyse = (fn) => (ecouteurs.add(fn), () => ecouteurs.delete(fn));
/** fn({ automatiques, automatiques_suivi, examines, manuel }) quand une analyse se termine normalement. */
export const surFinAnalyse = (fn) => (ecouteursFin.add(fn), () => ecouteursFin.delete(fn));
export const effacerErreurAnalyse = () => {
  analyse.erreur = null;
  emettre();
};

function emettre() {
  const e = etatAnalyse();
  for (const f of [...ecouteurs]) {
    try {
      f(e);
    } catch (err) {
      console.error("[analyse]", err);
    }
  }
}

const attendre = (ms) => new Promise((r) => setTimeout(r, ms));

/** Attend jusqu'à `ms` millisecondes, en vérifiant chaque seconde qu'on ne demande pas d'arrêter. */
async function patienter(ms, g) {
  const fin = Date.now() + ms;
  while (g === generation && Date.now() < fin) await attendre(Math.min(1000, fin - Date.now()));
}

const ERREURS_PASSAGERES = new Set(["reseau"]);
const estPassagere = (e) => ERREURS_PASSAGERES.has(e.code) || e.statut === 502 || e.statut === 503 || e.statut === 504;

async function unLot(demarrer, auto, g) {
  let essais = 0;
  for (;;) {
    try {
      return await envoyer(`${BASE}/lot`, { demarrer, auto });
    } catch (e) {
      if (!(e instanceof ErreurApi) || !estPassagere(e) || ++essais > 2 || g !== generation) throw e;
      await patienter(3000 * essais, g);
    }
  }
}

async function boucle(manuel, g) {
  let occupes = 0;
  let dernierRafraichissement = Date.now();
  let demarrer = true;
  for (let i = 0; i < MAX_LOTS && g === generation; i++) {
    const r = await unLot(demarrer, !manuel, g);
    if (g !== generation) return { interrompue: true };
    demarrer = false;
    if (r.statut === "occupe") {
      // Une autre fenêtre (ou un autre appareil) est en train de lire la boîte : on attend son tour.
      if (++occupes > 15) return { occupe: true };
      await patienter(2500, g);
      continue;
    }
    occupes = 0;
    if (r.statut === "pause") {
      const s = Math.min(Math.max(Number(r.reessayerS) || 60, 5), 300);
      analyse.enCours = true;
      analyse.pause = { jusqua: Date.now() + s * 1000 };
      emettre();
      await patienter(s * 1000, g);
      if (g !== generation) return { interrompue: true };
      analyse.pause = null;
      continue;
    }
    if (r.statut === "termine") {
      // Sans « examines », rien n'était à faire (analyse récente) : ce n'est pas une analyse.
      return typeof r.examines === "number"
        ? { fait: true, examines: r.examines, automatiques: r.automatiques || 0, automatiques_suivi: r.automatiques_suivi || 0 }
        : { rien: true };
    }
    // « en_cours » : l'analyse avance.
    analyse.enCours = true;
    analyse.manuel = manuel;
    analyse.progres = r.progres || null;
    emettre();
    // Les premières personnes trouvées apparaissent pendant que l'analyse continue.
    if (Date.now() - dernierRafraichissement > RAFRAICHIR_PENDANT_MS) {
      dernierRafraichissement = Date.now();
      chargerVue({ force: true }).catch(() => {});
    }
  }
  return { interrompue: true };
}

/**
 * Lit la boîte Gmail par lots jusqu'à la fin de l'analyse (ou la reprend là où elle en était). Une seule à la fois.
 * `manuel` : demandée par la personne (démarre même si l'analyse est récente) ; sinon, c'est un passage de fond que le serveur
 * n'exécute que si une analyse est due. Retourne le bilan, ou null si la fonction n'est pas utilisable.
 */
export function lancerAnalyse({ manuel = true } = {}) {
  if (courante) {
    // Un passage de fond qui n'a encore rien trouvé à faire ne doit pas avaler une demande de la personne.
    if (manuel && !analyse.manuel && !analyse.enCours) return courante.then(() => lancerAnalyse({ manuel: true }));
    return courante;
  }
  if (!classementActif() || !peutVoirEchanges()) return Promise.resolve(null);
  const g = generation;
  analyse.enCours = manuel;
  analyse.manuel = manuel;
  analyse.erreur = null;
  analyse.pause = null;
  analyse.progres = null;
  analyse.bilan = null;
  if (manuel) emettre();
  const cetteAnalyse = (async () => {
    let bilan = null;
    try {
      bilan = await boucle(manuel, g);
    } catch (e) {
      if (g !== generation) return null;
      if (e instanceof ErreurApi) {
        analyse.erreur = e;
        signalerErreurGoogle(e);
        if (e.code === "classement_inactif") definirResume(classementVide());
      } else {
        console.error("[analyse]", e);
        analyse.erreur = new ErreurApi("Une erreur inattendue est survenue pendant l’analyse. Réessayez dans un moment.", { code: "interne" });
      }
    }
    if (g !== generation) return null;
    analyse.enCours = false;
    analyse.pause = null;
    analyse.progres = null;
    analyse.bilan = bilan;
    if (bilan?.fait || analyse.erreur || bilan?.interrompue) {
      // Fin de l'analyse : les propositions et l'état (dernière analyse, erreur éventuelle) sont relus une fois.
      await chargerVue({ force: true }).catch(() => {});
      if (bilan?.fait && (bilan.automatiques > 0 || bilan.automatiques_suivi > 0)) await synchroniser().catch(() => {});
    }
    if (g !== generation) return null;
    if (courante === cetteAnalyse) courante = null;
    emettre();
    if (bilan?.fait) {
      for (const f of [...ecouteursFin]) {
        try {
          f({ automatiques: bilan.automatiques, automatiques_suivi: bilan.automatiques_suivi, examines: bilan.examines, manuel });
        } catch (err) {
          console.error("[analyse]", err);
        }
      }
    }
    return bilan;
  })();
  courante = cetteAnalyse;
  return cetteAnalyse;
}

// ----- Passages de fond --------------------------------------------------------------------------------------------------
let minuterie = null;
let delaiInitial = null;
let ecouteurVisibilite = null;
let dernierPassage = 0;

/** Lance l'analyse de fond : peu après l'ouverture, puis toutes les 15 minutes et au retour sur l'onglet. */
export function demarrerClassementAuto() {
  arreterClassementAuto();
  const passage = () => {
    if (document.visibilityState !== "visible" || !classementActif() || !peutVoirEchanges()) return;
    if (Date.now() - dernierPassage < 60_000) return;
    dernierPassage = Date.now();
    lancerAnalyse({ manuel: false }).catch((e) => console.warn("[analyse]", e?.message));
  };
  delaiInitial = setTimeout(passage, DELAI_INITIAL_MS);
  minuterie = setInterval(passage, INTERVALLE_MS);
  ecouteurVisibilite = () => {
    if (document.visibilityState === "visible" && Date.now() - dernierPassage > INTERVALLE_MS / 3) passage();
  };
  document.addEventListener("visibilitychange", ecouteurVisibilite);
}

export function arreterClassementAuto() {
  clearTimeout(delaiInitial);
  clearInterval(minuterie);
  delaiInitial = null;
  minuterie = null;
  if (ecouteurVisibilite) document.removeEventListener("visibilitychange", ecouteurVisibilite);
  ecouteurVisibilite = null;
}

/** À la déconnexion : plus rien ne tourne et rien n'est gardé en mémoire. */
export function oublierClassement() {
  generation++;
  courante = null;
  arreterClassementAuto();
  vueMemoire = null;
  vueDepuis = 0;
  vueEnCours = null;
  analyse.enCours = false;
  analyse.progres = null;
  analyse.pause = null;
  analyse.erreur = null;
  analyse.bilan = null;
  etat.classement = null;
}
