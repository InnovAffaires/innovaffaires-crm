// Thème (clair / sombre / automatique) et densité, gardés dans ce navigateur.
const MODES = ["auto", "clair", "sombre"];

export function lireTheme() {
  try {
    const t = localStorage.getItem("crm.theme");
    return MODES.includes(t) ? t : "auto";
  } catch {
    return "auto";
  }
}

export function appliquerTheme(mode) {
  const m = MODES.includes(mode) ? mode : "auto";
  document.documentElement.setAttribute("data-theme", m);
  try {
    if (m === "auto") localStorage.removeItem("crm.theme");
    else localStorage.setItem("crm.theme", m);
  } catch {
    /* stockage indisponible */
  }
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) {
    const sombre = m === "sombre" || (m === "auto" && matchMedia("(prefers-color-scheme: dark)").matches);
    meta.setAttribute("content", sombre ? "#0b0e12" : "#3a4559");
  }
}

export function appliquerDensite(d) {
  const compacte = d === "compacte";
  if (compacte) document.documentElement.setAttribute("data-densite", "compacte");
  else document.documentElement.removeAttribute("data-densite");
  try {
    if (compacte) localStorage.setItem("crm.densite", "compacte");
    else localStorage.removeItem("crm.densite");
  } catch {
    /* stockage indisponible */
  }
}

export const libelleTheme = { auto: "Automatique", clair: "Clair", sombre: "Sombre" };
