// =============================================================================
// Écritures vers le serveur : chaque appel met aussitôt à jour la copie locale
// (l'écran réagit sans attendre la prochaine synchronisation) et traduit les
// erreurs en messages clairs.
// =============================================================================
import { envoyer, modifier, supprimer, lire, ErreurApi } from "./api.js";
import { mettreAJourFiche, retirerFicheLocale, fiche as ficheLocale, libelleFiche } from "./etat.js";
import { synchroniser } from "./synchro.js";
import { toast } from "../ui/toast.js";
import { ENTITES } from "../commun/schema.js";

const enc = encodeURIComponent;

/** Après une écriture : si le serveur a créé des tâches (changement de statut d'un dossier), on les récupère. */
function suites(rep) {
  if (rep?.effets?.taches) synchroniser().catch(() => {});
}

export async function creerFiche(entite, valeurs) {
  const rep = await envoyer(`/c/${entite}`, valeurs);
  mettreAJourFiche(entite, rep.fiche);
  suites(rep);
  return rep;
}

/** Modifie une fiche : `patch` ne contient que les champs changés (null efface). */
export async function modifierFiche(entite, f, patch) {
  const rep = await modifier(`/c/${entite}/${enc(f.id)}`, { ...patch, v: f.v });
  mettreAJourFiche(entite, rep.fiche);
  suites(rep);
  return rep;
}

export async function mettreALaCorbeille(entite, id) {
  const rep = await supprimer(`/c/${entite}/${enc(id)}`);
  mettreAJourFiche(entite, rep.fiche);
  return rep.fiche;
}

export async function restaurerFiche(entite, id) {
  const rep = await envoyer(`/c/${entite}/${enc(id)}/restaurer`, {});
  mettreAJourFiche(entite, rep.fiche);
  return rep.fiche;
}

export async function supprimerDefinitivement(entite, id) {
  await supprimer(`/c/${entite}/${enc(id)}?definitif=1`);
  retirerFicheLocale(entite, id);
}

/** Action propre à une facture (émettre, annuler, paiement…). Retourne la réponse complète. */
export async function actionFacture(id, action, corps = {}) {
  const rep = await envoyer(`/factures/${enc(id)}/${action}`, corps);
  if (rep.fiche) mettreAJourFiche("factures", rep.fiche);
  return rep;
}

export async function retirerPaiement(idFacture, idPaiement) {
  const rep = await supprimer(`/factures/${enc(idFacture)}/paiements/${enc(idPaiement)}`);
  if (rep.fiche) mettreAJourFiche("factures", rep.fiche);
  return rep;
}

export async function lireActivites(lieType, lieId, limite = 100) {
  const rep = await lire(`/activites?lie_type=${enc(lieType)}&lie_id=${enc(lieId)}&limite=${limite}`);
  return rep.activites || [];
}

/**
 * Exécute une action en gérant les erreurs : le message est affiché dans une notification,
 * et un conflit de version (fiche modifiée ailleurs) recharge la fiche locale.
 * Retourne le résultat, ou null en cas d'échec.
 */
export async function tenter(fn, { succes = null, surErreur = null, entite = null } = {}) {
  try {
    const r = await fn();
    if (succes) toast(typeof succes === "function" ? succes(r) : succes);
    return r;
  } catch (e) {
    if (!(e instanceof ErreurApi)) throw e;
    traiterErreur(e, entite);
    surErreur?.(e);
    return null;
  }
}

/** Conflit : met à jour la fiche locale avec la version du serveur et prévient. */
export function traiterErreur(e, entite = null) {
  if (e.estConflit) {
    if (entite && e.actuelle) mettreAJourFiche(entite, e.actuelle);
    toast("Cette fiche vient d’être modifiée ailleurs. Elle a été rechargée : vérifiez-la, puis refaites votre changement.", { ton: "erreur", duree: 12000 });
    return;
  }
  toast(e.message, { ton: "erreur" });
}

/** Mise à la corbeille avec annulation possible pendant quelques secondes. */
export async function supprimerAvecAnnulation(entite, id, { apres = null } = {}) {
  const f = ficheLocale(entite, id);
  const nom = f ? libelleFiche(entite, f) : "";
  const r = await tenter(() => mettreALaCorbeille(entite, id), { entite });
  if (!r) return false;
  toast(`${ENTITES[entite].libelle} ${nom ? `« ${nom} » ` : ""}placé${ENTITES[entite].genre === "f" ? "e" : ""} dans la corbeille.`, {
    ton: "info", duree: 9000,
    action: { libelle: "Annuler", onclick: () => tenter(() => restaurerFiche(entite, id), { succes: "Fiche rétablie." }) },
  });
  apres?.();
  return true;
}
