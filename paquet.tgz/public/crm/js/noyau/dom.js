// =============================================================================
// Construction d'éléments sans jamais passer par innerHTML : tout texte est
// inséré comme texte, tout lien est vérifié. Les données de la base ne peuvent
// donc pas injecter de HTML ni de script dans la page.
//
//   h("div.carte#id", { class: ["a", { b: vrai }], onclick: fn, "aria-label": "…" }, "Texte", enfant, [liste])
// =============================================================================

const ATTRIBUTS_INTERDITS = new Set(["innerhtml", "outerhtml", "srcdoc", "style"]);
const PROPRIETES = new Set(["value", "checked", "selected", "disabled", "hidden", "open", "indeterminate", "readOnly", "required", "multiple", "autofocus"]);
const ATTRIBUTS_URL = new Set(["href", "src", "action", "formaction", "poster", "data"]);
const SCHEMAS_SURS = /^(?:https?:|webcal:|mailto:|tel:|#|\/(?!\/)|\.\/|\.\.\/|[a-z0-9_\-./%?=&]+$)/i;

/** Adresse utilisable dans un lien : refuse javascript:, data:, etc. */
export function adresseSure(url) {
  const s = String(url ?? "").trim();
  if (!s) return "";
  // Retire les caractères de contrôle que certains navigateurs ignorent dans le schéma.
  const propre = s.replace(/[\u0000-\u001f\u007f\s]/g, (c) => (c === " " ? " " : ""));
  return SCHEMAS_SURS.test(propre) ? propre : "";
}

function ajouterClasses(el, v) {
  if (!v) return;
  if (typeof v === "string") {
    for (const c of v.split(/\s+/)) if (c) el.classList.add(c);
  } else if (Array.isArray(v)) {
    for (const x of v) ajouterClasses(el, x);
  } else if (typeof v === "object") {
    for (const [c, actif] of Object.entries(v)) if (actif) ajouterClasses(el, c);
  }
}

function estProps(x) {
  return x !== null && typeof x === "object" && !Array.isArray(x) && !(x instanceof Node);
}

function ajouterEnfants(parent, enfants) {
  for (const e of enfants) {
    if (e === null || e === undefined || e === false || e === true) continue;
    if (Array.isArray(e)) ajouterEnfants(parent, e);
    else if (e instanceof Node) parent.append(e);
    else parent.append(document.createTextNode(String(e)));
  }
}

export function h(sel, ...reste) {
  const m = /^([a-z][a-z0-9-]*)?((?:[.#][\w-]+)*)$/i.exec(sel);
  if (!m) throw new Error(`Sélecteur invalide : ${sel}`);
  const el = document.createElement(m[1] || "div");
  for (const part of m[2].match(/[.#][\w-]+/g) || []) {
    if (part[0] === "#") el.id = part.slice(1);
    else el.classList.add(part.slice(1));
  }
  let enfants = reste;
  if (reste.length && estProps(reste[0])) {
    const props = reste[0];
    enfants = reste.slice(1);
    for (const [k, v] of Object.entries(props)) {
      if (v === undefined || v === null || v === false) {
        if (PROPRIETES.has(k) && v === false) el[k] = false;
        continue;
      }
      if (k === "class" || k === "className") ajouterClasses(el, v);
      else if (k === "dataset") for (const [dk, dv] of Object.entries(v)) {
        if (dv !== undefined && dv !== null && dv !== false) el.dataset[dk] = String(dv);
      }
      else if (k === "css") for (const [ck, cv] of Object.entries(v)) el.style.setProperty(ck, String(cv));
      else if (k.startsWith("on") && typeof v === "function") el.addEventListener(k.slice(2).toLowerCase(), v);
      else if (k === "for") el.htmlFor = String(v);
      else if (PROPRIETES.has(k)) el[k] = v;
      else if (ATTRIBUTS_INTERDITS.has(k.toLowerCase())) throw new Error(`Attribut interdit : ${k}`);
      else if (ATTRIBUTS_URL.has(k.toLowerCase())) {
        const sure = adresseSure(v);
        el.setAttribute(k, sure || "#");
      } else el.setAttribute(k, v === true ? "" : String(v));
    }
  }
  ajouterEnfants(el, enfants);
  return el;
}

/** Fragment contenant les enfants donnés. */
export function frag(...enfants) {
  const f = document.createDocumentFragment();
  ajouterEnfants(f, enfants);
  return f;
}

export function vider(el) {
  while (el.firstChild) el.removeChild(el.firstChild);
  return el;
}

/** Remplace le contenu d'un élément. */
export function remplir(el, ...enfants) {
  vider(el);
  ajouterEnfants(el, enfants);
  return el;
}

/** Texte brut multi-ligne → fragment de paragraphes, avec liens http(s) cliquables. */
export function paragraphes(texte, { classe = "" } = {}) {
  const f = document.createDocumentFragment();
  const blocs = String(texte ?? "").replace(/\r\n?/g, "\n").split(/\n{2,}/);
  for (const bloc of blocs) {
    if (!bloc.trim()) continue;
    const p = h("p", { class: classe });
    ajouterTexteAvecLiens(p, bloc.trim());
    f.append(p);
  }
  return f;
}

const RE_LIEN = /\bhttps?:\/\/[^\s<>"')\]]+/gi;
export function ajouterTexteAvecLiens(parent, texte) {
  let dernier = 0;
  for (const m of texte.matchAll(RE_LIEN)) {
    if (m.index > dernier) parent.append(document.createTextNode(texte.slice(dernier, m.index)));
    let url = m[0];
    let fin = "";
    while (/[.,;:!?]$/.test(url)) {
      fin = url.slice(-1) + fin;
      url = url.slice(0, -1);
    }
    parent.append(h("a", { href: url, target: "_blank", rel: "noopener noreferrer" }, url));
    if (fin) parent.append(document.createTextNode(fin));
    dernier = m.index + m[0].length;
  }
  if (dernier < texte.length) parent.append(document.createTextNode(texte.slice(dernier)));
}

/** Annonce un message aux lecteurs d'écran. */
export function annoncer(message) {
  const zone = document.getElementById("annonces");
  if (!zone) return;
  zone.textContent = "";
  setTimeout(() => (zone.textContent = message), 30);
}

/** Retarde les appels rapprochés (saisie dans un champ de recherche). */
export function anti_rebond(fn, ms = 120) {
  let t;
  return (...a) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...a), ms);
  };
}

let compteurId = 0;
export const idUnique = (prefixe = "id") => `${prefixe}-${++compteurId}`;

/** Copie du texte dans le presse-papiers (avec repli pour les contextes limités). */
export async function copierTexte(texte) {
  try {
    await navigator.clipboard.writeText(texte);
    return true;
  } catch {
    const t = h("textarea", { value: texte, readOnly: true, "aria-hidden": "true", tabindex: "-1" });
    t.className = "sr-only";
    document.body.append(t);
    t.select();
    let ok = false;
    try {
      ok = document.execCommand("copy");
    } catch {
      ok = false;
    }
    t.remove();
    return ok;
  }
}

/** Téléchargement d'un contenu généré dans le navigateur. */
export function enregistrerFichier(nom, contenu, type = "application/octet-stream") {
  const blob = contenu instanceof Blob ? contenu : new Blob([contenu], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = nom;
  a.hidden = true;
  document.body.append(a);
  a.click();
  setTimeout(() => {
    a.remove();
    URL.revokeObjectURL(url);
  }, 2000);
}
