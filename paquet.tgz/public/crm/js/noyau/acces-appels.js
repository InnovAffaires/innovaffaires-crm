// =============================================================================
// Poste d'appel : relie la logique pure (commun/appels.js) aux données chargées
// dans le navigateur — la file d'attente d'aujourd'hui et la fiche d'une personne.
// =============================================================================
import { actives, fiche, liees, etat, maintenant } from "./etat.js";
import { aujourdhui } from "../commun/dates.js";
import { construireFile, itemDirect, resoudrePersonne } from "../commun/appels.js";

/** Accès aux fiches attendu par resoudrePersonne() : les fiches à la corbeille sont ignorées par la fonction elle-même. */
export function accesFiches() {
  return {
    fiche: (entite, id) => fiche(entite, id),
    contactsDe: (idEntreprise) => liees("contacts", "entreprise_id", idEntreprise),
  };
}

/** La file d'attente de l'utilisateur courant. portee : "jour" (en retard et aujourd'hui) | "tout". */
export function fileDAppels({ portee = "jour" } = {}) {
  const ms = maintenant();
  const ouvertes = actives("taches").filter((t) => t.type === "appel" && t.statut !== "fait");
  if (!ouvertes.length) return { items: [], exclus: [], resume: { total: 0, enRetard: 0, aujourdhui: 0, aVenir: 0, sansEcheance: 0, rappelsMaintenant: 0 } };
  return construireFile({ taches: ouvertes, acces: accesFiches(), auj: aujourdhui(ms), maintenantMs: ms, moiId: etat.utilisateur?.id, portee });
}

/** Un appel direct (bouton « Appeler » d'une fiche), avec les tâches d'appel encore ouvertes de la personne. */
export function appelDirect(lieType, lieId) {
  const ouvertes = actives("taches").filter((t) => t.type === "appel" && t.statut !== "fait");
  return itemDirect(lieType, lieId, accesFiches(), ouvertes);
}

/** La personne visée par une fiche (nom, numéros, drapeau « ne pas appeler »), pour les boutons des fiches. */
export const personneDe = (lieType, lieId) => resoudrePersonne(lieType, lieId, accesFiches());
