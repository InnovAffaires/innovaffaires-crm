// =============================================================================
// Synchronisation avec le serveur : chargement initial puis vérification
// régulière (seules les collections modifiées sont retransmises).
// =============================================================================
import { envoyer, lire, ErreurApi } from "./api.js";
import { etat, appliquerSynchro, definirEquipe } from "./etat.js";

const INTERVALLE_MS = 45_000;
let minuteur = null;
let enCours = null;
let enLigne = true;
const ecouteursReseau = new Set();
const ecouteursNouvelles = new Set();

export const surEtatReseau = (fn) => (ecouteursReseau.add(fn), () => ecouteursReseau.delete(fn));
export const surNouvellesDemandes = (fn) => (ecouteursNouvelles.add(fn), () => ecouteursNouvelles.delete(fn));
export const estEnLigne = () => enLigne;

function signalerReseau(ok) {
  if (ok === enLigne) return;
  enLigne = ok;
  for (const f of ecouteursReseau) f(ok);
}

/** Synchronise maintenant. Retourne l'ensemble des entités changées (vide si rien ou si hors ligne). */
export function synchroniser({ complet = false } = {}) {
  if (enCours) return enCours;
  enCours = (async () => {
    const connues = new Set(etat.collections.demandes.map((d) => d.id));
    const premiere = !etat.pret;
    try {
      const rep = await envoyer("/synchro", { etags: complet ? {} : etat.etags, complet });
      signalerReseau(true);
      const changes = appliquerSynchro(rep);
      if (!premiere && changes.has("demandes")) {
        const nouvelles = etat.collections.demandes.filter((d) => !connues.has(d.id) && d.statut === "nouveau" && !d.supprime);
        if (nouvelles.length) for (const f of ecouteursNouvelles) f(nouvelles);
      }
      return changes;
    } catch (e) {
      if (e instanceof ErreurApi && e.estReseau) {
        signalerReseau(false);
        if (premiere) throw e;
        return new Set();
      }
      throw e;
    } finally {
      enCours = null;
    }
  })();
  return enCours;
}

export async function chargerEquipe() {
  try {
    const r = await lire("/equipe");
    definirEquipe(r.utilisateurs || []);
  } catch (e) {
    if (!(e instanceof ErreurApi)) throw e;
  }
}

export function demarrerSynchro() {
  arreterSynchro();
  const tic = () => {
    if (document.visibilityState === "visible") synchroniser().catch((e) => console.warn("[synchro]", e?.message));
  };
  minuteur = setInterval(tic, INTERVALLE_MS);
  document.addEventListener("visibilitychange", tic);
  addEventListener("online", tic);
  addEventListener("focus", tic);
  demarrerSynchro._tic = tic;
}

export function arreterSynchro() {
  clearInterval(minuteur);
  minuteur = null;
  const tic = demarrerSynchro._tic;
  if (tic) {
    document.removeEventListener("visibilitychange", tic);
    removeEventListener("online", tic);
    removeEventListener("focus", tic);
    demarrerSynchro._tic = null;
  }
}

