// =============================================================================
// Listes d'appels de prospection, côté navigateur : lecture et gestion par l'API, et copie en mémoire des en-têtes de listes
// (nom, statut, compteurs) pour les écrans qui les montrent à côté de la file d'appels. Les listes ne sont pas des fiches et ne
// passent pas par la synchronisation : on les relit à la demande, et les compteurs sont recalculés par le serveur à chaque lecture.
// =============================================================================
import { lire, envoyer, modifier as modifierApi, supprimer as supprimerApi } from "./api.js";
import { etat, mettreAJourFiche, notifier } from "./etat.js";

const LOT = 200;
const M = { uid: null, listes: null, chargement: null, sequence: 0 };

function cleOperation() {
  const octets = crypto.getRandomValues(new Uint8Array(12));
  return [...octets].map((o) => o.toString(16).padStart(2, "0")).join("");
}

/** Une autre personne qui se connecte dans le même navigateur repart d'une mémoire vide. */
function surveillerSession() {
  const uid = etat.utilisateur?.id || null;
  if (M.uid !== uid) {
    M.uid = uid;
    M.listes = null;
    M.chargement = null;
    M.sequence += 1;
  }
}

/** Les en-têtes de listes déjà lus (null tant qu'ils ne l'ont pas été). */
export function listesEnMemoire() {
  surveillerSession();
  return M.listes;
}
export const listeEnMemoire = (id) => listesEnMemoire()?.find((l) => l.id === id) || null;
/** Le nom d'une liste, ou "" si elle est inconnue (supprimée, ou pas encore lue). */
export const nomDeListe = (id) => listeEnMemoire(id)?.nom || "";

/** Lit les listes avec leurs compteurs. Une seule lecture à la fois; `force` relit même si la mémoire est remplie. */
export function chargerListes({ force = false } = {}) {
  surveillerSession();
  if (M.listes && !force) return Promise.resolve(M.listes);
  if (M.chargement && !force) return M.chargement;
  const n = ++M.sequence;
  const p = lire("/appels/listes")
    .then((r) => {
      const listes = Array.isArray(r.listes) ? r.listes : [];
      if (n === M.sequence) {
        M.listes = listes;
        notifier("listes_appels");
      }
      return M.listes ?? listes;
    })
    .finally(() => {
      if (M.chargement === p) M.chargement = null;
    });
  M.chargement = p;
  return p;
}

function remplacerEnMemoire(liste) {
  if (!M.listes) return;
  const i = M.listes.findIndex((l) => l.id === liste.id);
  const suivantes = M.listes.slice();
  if (i >= 0) suivantes[i] = { ...suivantes[i], ...liste };
  else suivantes.unshift(liste);
  M.listes = suivantes;
  notifier("listes_appels");
}

/** Une liste et l'état de chacune de ses lignes : { liste, lignes: [{ t, id, etat, raison?, resultat?, appele_le?, appels?, essai? }] }. */
export async function detailListe(id) {
  const r = await lire(`/appels/listes/${encodeURIComponent(id)}`);
  remplacerEnMemoire(r.liste);
  return r;
}

/**
 * Importe une liste (ou la simule, avec `simuler: true`). `corps` : { cle, nom, description?, script_id?, fichier?, inclure_existants?, lignes }.
 * Après une importation réelle, les fiches créées sont relues par une synchronisation complète (faite par l'appelant).
 */
export async function importerListe(corps) {
  const r = await envoyer("/appels/listes/importer", corps);
  if (!corps.simuler && r.liste) {
    r.liste = { ...r.liste, compteurs: r.liste.compteurs || compteursInitiaux(r.liste.nb_lignes) };
    remplacerEnMemoire(r.liste);
  }
  return r;
}

const compteursInitiaux = (total) => ({ total, a_appeler: total, file: 0, appele: 0, exclu: 0, appeles: 0, joints: 0, rdv: 0, par_resultat: {}, exclusions: {} });

/** Modifie le nom, la description, le statut ou le script d'une liste. Retourne l'en-tête à jour. */
export async function modifierListe(id, patch, { version } = {}) {
  const r = await modifierApi(`/appels/listes/${encodeURIComponent(id)}`, { ...patch, ...(version ? { v: version } : {}) });
  remplacerEnMemoire(r.liste);
  chargerListes({ force: true }).catch(() => {});
  return r.liste;
}

/** Supprime la liste (les fiches et les appels déjà consignés restent). */
export async function supprimerListe(id) {
  await supprimerApi(`/appels/listes/${encodeURIComponent(id)}`);
  if (M.listes) {
    M.listes = M.listes.filter((l) => l.id !== id);
    notifier("listes_appels");
  }
}

/**
 * Ajoute des personnes de la liste à la file d'appels (par lots de 200). `cibles` : [{ entite, id }].
 * Retourne { creees, ignores } comme ajouterALaFile() de vues/appels/ajouter.js.
 */
export async function verserCibles(id, cibles, { echeance, heure, priorite }) {
  let creees = 0;
  const ignores = [];
  for (let i = 0; i < cibles.length; i += LOT) {
    const rep = await envoyer(`/appels/listes/${encodeURIComponent(id)}/file`, {
      cle: cleOperation(), cibles: cibles.slice(i, i + LOT), echeance, heure: heure || undefined, priorite,
    });
    for (const t of rep.taches || []) mettreAJourFiche("taches", t);
    creees += (rep.taches || []).length;
    ignores.push(...(rep.ignores || []));
  }
  chargerListes({ force: true }).catch(() => {});
  return { creees, ignores };
}

/** Les `n` prochaines personnes « à appeler » de la liste, dans l'ordre du fichier importé. */
export async function prochainesCibles(id, n) {
  const d = await detailListe(id);
  return d.lignes.filter((l) => l.etat === "a_appeler").slice(0, n).map((l) => ({ entite: l.t, id: l.id }));
}

/** Ferme les appels de la liste que personne n'a encore faits. Retourne { taches, retirees }. */
export async function retirerDeLaFile(id) {
  const r = await envoyer(`/appels/listes/${encodeURIComponent(id)}/retirer-de-la-file`, {});
  for (const t of r.taches || []) mettreAJourFiche("taches", t);
  chargerListes({ force: true }).catch(() => {});
  return r;
}

/** Les appels de la liste qui sont dans la file d'aujourd'hui, comptés d'après les tâches ouvertes (pas besoin d'aller au serveur). */
export function appelsOuvertsDeListe(id) {
  return etat.collections.taches.filter((t) => !t.supprime && t.type === "appel" && t.statut !== "fait" && t.liste_id === id && t.origine === "liste" && !(t.essai > 1)).length;
}
