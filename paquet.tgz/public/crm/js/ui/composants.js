// =============================================================================
// Petites pièces réutilisables : boutons, tampons, panneaux, menus, onglets…
// =============================================================================
import { h, idUnique } from "../noyau/dom.js";
import { icone } from "../noyau/icones.js";
import { lienFiche } from "../noyau/routeur.js";
import { fiche, libelleFiche } from "../noyau/etat.js";
import { initiales } from "../commun/format.js";

/** btn("Enregistrer", { ton: "primaire", icone: "coche", onclick }) */
export function btn(libelle, { ton = "secondaire", icone: ic = null, onclick = null, type = "button", href = null, externe = false, desactive = false, titre = null, classe = "", aria = null, petit = false, id = null } = {}) {
  const classes = ["btn", `btn--${ton}`, petit ? "btn--petit" : "", classe];
  const contenu = [ic ? icone(ic) : null, libelle ? h("span", libelle) : null];
  if (href) return h("a", { class: classes, href, title: titre, "aria-label": aria, id, target: externe ? "_blank" : null, rel: externe ? "noopener noreferrer" : null }, contenu);
  return h("button", { class: classes, type, onclick, disabled: desactive, title: titre, "aria-label": aria, id }, contenu);
}

/** Bouton réduit à une icône (le libellé reste lu par les lecteurs d'écran). */
export function btnIcone(nom, libelle, onclick, { classe = "", type = "button", desactive = false, pressed = null } = {}) {
  return h("button.btn-icone", { class: classe, type, "aria-label": libelle, title: libelle, onclick, disabled: desactive, "aria-pressed": pressed === null ? null : String(pressed) }, icone(nom));
}

/** Tampon : état définitif d'un document (Payée, Acceptée, Perdue…). ton : neutre | ok | attention | erreur */
export function tampon(texte, ton = "neutre") {
  return h("span.tampon", { class: `tampon--${ton}` }, texte);
}

/** Pastille d'état discrète (dans les tableaux). */
export function pastille(texte, ton = "neutre", { icone: ic = null } = {}) {
  return h("span.pastille", { class: `pastille--${ton}` }, ic ? icone(ic, "ic--p") : null, texte);
}

export function avatar(nom, { taille = "m" } = {}) {
  return h("span.avatar", { class: `avatar--${taille}`, "aria-hidden": "true" }, initiales(nom));
}

export function etatVide({ icone: ic = "etincelle", titre, texte = "", action = null }) {
  return h("div.vide", icone(ic, "ic--g"), h("p.vide__titre", titre), texte ? h("p.vide__texte", texte) : null, action);
}

/** panneau({ titre, sous, actions, classe, id }, ...contenu) */
export function panneau({ titre, sous = null, actions = null, classe = "", id = null, niveau = 2, compteur = null } = {}, ...contenu) {
  const idT = idUnique("pan");
  return h(
    "section.panneau",
    { class: classe, "aria-labelledby": titre ? idT : null, id },
    titre
      ? h("header.panneau__tete", h("div.panneau__titres", h(`h${niveau}`, { id: idT }, titre, compteur !== null ? h("span.panneau__compteur", compteur) : null), sous ? h("p.panneau__sous", sous) : null), actions ? h("div.panneau__actions", actions) : null)
      : null,
    h("div.panneau__corps", contenu)
  );
}

/** Liste de définitions : [["Courriel", noeud|texte], …] — les valeurs vides sont omises. */
export function listeDef(paires, { classe = "" } = {}) {
  const dl = h("dl.def", { class: classe });
  for (const [k, v] of paires) {
    if (v === null || v === undefined || v === "" || v === false) continue;
    dl.append(h("div.def__ligne", h("dt", k), h("dd", v)));
  }
  return dl;
}

/** Lien vers une fiche, avec son libellé courant. */
export function lienVers(entite, id, { texte = null, classe = "" } = {}) {
  const f = fiche(entite, id);
  if (!f) return h("span.lien-perdu", texte || "—");
  return h("a.lien-fiche", { class: classe, href: lienFiche(entite, id) }, texte || libelleFiche(entite, f));
}

// ----- Menu d'actions ------------------------------------------------------------------------------
/**
 * menuActions({ libelle, icone, elements, aria, aligne })
 *   elements : [{ libelle, icone?, onclick, danger?, desactive? } | "separateur"]
 */
export function menuActions({ libelle = "", icone: ic = "options", elements, aria = "Plus d’actions", aligne = "droite", ton = "discret", classe = "", contenu = null, classeBouton = null, haut = false, fixe = false }) {
  const idMenu = idUnique("menu");
  const bouton = h(
    "button",
    { class: classeBouton ? [classeBouton, classe] : ["btn", `btn--${ton}`, libelle ? "" : "btn--carre", classe], type: "button", "aria-haspopup": "menu", "aria-expanded": "false", "aria-controls": idMenu, "aria-label": contenu || libelle ? (contenu ? aria : null) : aria, title: libelle || contenu ? null : aria },
    contenu || [icone(ic), libelle ? h("span", libelle) : null, libelle ? icone("bas", "ic--p") : null]
  );
  const liste = h("ul.menu", { id: idMenu, role: "menu", hidden: true, class: `menu--${aligne}`, "aria-label": libelle || aria });
  const noeud = h("div.menu-conteneur", bouton, liste);
  let items = [];

  function construire() {
    liste.replaceChildren();
    items = [];
    for (const e of typeof elements === "function" ? elements() : elements) {
      if (e === "separateur") {
        liste.append(h("li.menu__sep", { role: "separator" }));
        continue;
      }
      if (!e) continue;
      const b = h("button.menu__item", { type: "button", role: "menuitem", tabindex: "-1", disabled: !!e.desactive, class: { "menu__item--danger": e.danger }, onclick: () => { fermer(); e.onclick?.(); } }, e.icone ? icone(e.icone) : null, h("span", e.libelle));
      items.push(b);
      liste.append(h("li", { role: "none" }, b));
    }
  }
  function ouvrir(focusPremier = true) {
    construire();
    liste.hidden = false;
    bouton.setAttribute("aria-expanded", "true");
    const r = bouton.getBoundingClientRect();
    const hauteur = liste.offsetHeight;
    const auDessus = haut || (r.bottom + hauteur + 8 > innerHeight && r.top > hauteur + 8);
    if (fixe) {
      // Placé par rapport à la fenêtre : un conteneur qui défile (tableau des affaires) ne le rogne pas.
      const largeur = liste.offsetWidth;
      const gauche = aligne === "gauche" ? r.left : r.right - largeur;
      liste.classList.add("menu--fixe");
      liste.style.setProperty("left", `${Math.max(8, Math.min(gauche, innerWidth - largeur - 8))}px`);
      liste.style.setProperty("top", `${auDessus ? Math.max(8, r.top - hauteur - 4) : r.bottom + 4}px`);
      addEventListener("scroll", defiler, true);
      addEventListener("resize", defiler);
    } else noeud.classList.toggle("menu-conteneur--haut", auDessus);
    if (focusPremier) items.find((i) => !i.disabled)?.focus();
    document.addEventListener("mousedown", dehors, true);
  }
  function defiler(e) {
    if (e.target instanceof Node && liste.contains(e.target)) return;
    fermer(false);
  }
  function fermer(rendreFocus = true) {
    if (liste.hidden) return;
    liste.hidden = true;
    bouton.setAttribute("aria-expanded", "false");
    document.removeEventListener("mousedown", dehors, true);
    if (fixe) {
      removeEventListener("scroll", defiler, true);
      removeEventListener("resize", defiler);
    }
    if (rendreFocus) bouton.focus();
  }
  function dehors(e) {
    if (!noeud.contains(e.target)) fermer(false);
  }
  bouton.addEventListener("click", () => (liste.hidden ? ouvrir(false) : fermer()));
  bouton.addEventListener("keydown", (e) => {
    if (e.key === "ArrowDown" || e.key === "ArrowUp") {
      e.preventDefault();
      if (liste.hidden) ouvrir(true);
      else (e.key === "ArrowDown" ? items.find((i) => !i.disabled) : [...items].reverse().find((i) => !i.disabled))?.focus();
    } else if (e.key === "Escape" && !liste.hidden) {
      // Menu ouvert à la souris : le focus est resté sur le bouton, pas dans la liste.
      e.preventDefault();
      e.stopPropagation();
      fermer();
    }
  });
  liste.addEventListener("keydown", (e) => {
    const actifs = items.filter((i) => !i.disabled);
    const i = actifs.indexOf(document.activeElement);
    if (e.key === "ArrowDown") {
      e.preventDefault();
      actifs[(i + 1) % actifs.length]?.focus();
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      actifs[(i - 1 + actifs.length) % actifs.length]?.focus();
    } else if (e.key === "Home") {
      e.preventDefault();
      actifs[0]?.focus();
    } else if (e.key === "End") {
      e.preventDefault();
      actifs.at(-1)?.focus();
    } else if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation();
      fermer();
    } else if (e.key === "Tab") {
      fermer(false);
    }
  });
  noeud.addEventListener("focusout", (e) => {
    if (!liste.hidden && e.relatedTarget && !noeud.contains(e.relatedTarget)) fermer(false);
  });
  return noeud;
}

// ----- Onglets ------------------------------------------------------------------------------------------
/** onglets({ items: [{ id, libelle, compteur? }], actif, surChoix, aria }) → <div role=tablist> */
export function onglets({ items, actif, surChoix, aria = "Sections", classe = "" }) {
  const liste = h("div.onglets", { class: classe, role: "tablist", "aria-label": aria });
  const boutons = items.map((it) =>
    h(
      "button.onglets__onglet",
      {
        type: "button", role: "tab", id: `ong-${it.id}`, "aria-selected": String(it.id === actif), tabindex: it.id === actif ? "0" : "-1",
        onclick: () => surChoix(it.id),
      },
      it.libelle,
      it.compteur !== undefined && it.compteur !== null ? h("span.onglets__compteur", String(it.compteur)) : null
    )
  );
  liste.append(...boutons);
  liste.addEventListener("keydown", (e) => {
    const i = boutons.indexOf(document.activeElement);
    if (i < 0) return;
    let n = -1;
    if (e.key === "ArrowRight") n = (i + 1) % boutons.length;
    else if (e.key === "ArrowLeft") n = (i - 1 + boutons.length) % boutons.length;
    else if (e.key === "Home") n = 0;
    else if (e.key === "End") n = boutons.length - 1;
    if (n >= 0) {
      e.preventDefault();
      boutons[n].focus();
      surChoix(items[n].id);
      setTimeout(() => document.getElementById(`ong-${items[n].id}`)?.focus(), 0);
    }
  });
  return liste;
}

/** Champ « mot de passe » avec bouton afficher/masquer. `objet` : ce que le champ contient (« le mot de passe », « le secret »…). */
export function champMotDePasse({ libelle, id = idUnique("mdp"), autocomplete = "current-password", aide = null, requis = true, nom = null, objet = "le mot de passe" }) {
  const input = h("input.saisie", { id, name: nom || id, type: "password", autocomplete, "aria-required": requis ? "true" : null, autocapitalize: "off", spellcheck: "false", maxlength: 200 });
  const idErr = `${id}-err`;
  const err = h("p.champ__erreur", { id: idErr, hidden: true });
  input.setAttribute("aria-describedby", [aide ? `${id}-aide` : null, idErr].filter(Boolean).join(" "));
  const oeil = h("button.saisie-groupe__bouton", {
    type: "button", "aria-label": `Afficher ${objet}`, "aria-pressed": "false",
    onclick: () => {
      const visible = input.type === "password";
      input.type = visible ? "text" : "password";
      oeil.setAttribute("aria-pressed", String(visible));
      oeil.setAttribute("aria-label", visible ? `Masquer ${objet}` : `Afficher ${objet}`);
      oeil.replaceChildren(icone(visible ? "cacher" : "voir"));
    },
  }, icone("voir"));
  const noeud = h("div.champ", h("label.champ__etiquette", { for: id }, libelle), h("div.saisie-groupe", input, oeil), aide ? h("p.champ__aide", { id: `${id}-aide` }, aide) : null, err);
  return {
    noeud, input,
    lire: () => input.value,
    erreur(m) {
      err.hidden = !m;
      err.textContent = m || "";
      noeud.classList.toggle("champ--erreur", !!m);
      if (m) input.setAttribute("aria-invalid", "true");
      else input.removeAttribute("aria-invalid");
    },
    focus: () => input.focus(),
  };
}

/** Champ texte simple (écrans d'accès et petits formulaires). */
export function champTexte({ libelle, id = idUnique("txt"), type = "text", autocomplete = "off", aide = null, requis = true, maxlength = 200, inputmode = null, valeur = "", placeholder = null }) {
  const input = h("input.saisie", { id, name: id, type, autocomplete, maxlength, inputmode, placeholder, "aria-required": requis ? "true" : null, autocapitalize: "off", spellcheck: "false" });
  input.value = valeur;
  const idErr = `${id}-err`;
  const err = h("p.champ__erreur", { id: idErr, hidden: true });
  input.setAttribute("aria-describedby", [aide ? `${id}-aide` : null, idErr].filter(Boolean).join(" "));
  const noeud = h("div.champ", h("label.champ__etiquette", { for: id }, libelle), input, aide ? h("p.champ__aide", { id: `${id}-aide` }, aide) : null, err);
  return {
    noeud, input,
    lire: () => input.value,
    definir: (v) => (input.value = v),
    erreur(m) {
      err.hidden = !m;
      err.textContent = m || "";
      noeud.classList.toggle("champ--erreur", !!m);
      if (m) input.setAttribute("aria-invalid", "true");
      else input.removeAttribute("aria-invalid");
    },
    focus: () => input.focus(),
  };
}

/** Bandeau d'information ou d'avertissement dans une page. */
export function avis({ ton = "info", titre = null, texte = null, actions = null, role = null }) {
  return h(
    "div.avis",
    { class: `avis--${ton}`, role: role || (ton === "erreur" ? "alert" : null) },
    icone({ info: "info", attention: "alerte", erreur: "alerte", ok: "ok" }[ton] || "info"),
    h("div.avis__texte", titre ? h("strong", titre) : null, texte ? h("p", texte) : null),
    actions ? h("div.avis__actions", actions) : null
  );
}

export const chargement = (texte = "Chargement…") => h("div.chargement", { role: "status" }, h("span.chargement__point"), h("span", texte));

/** Logo InnovAffaires (carré + coche dorée), identique à celui du site. */
export function logo({ classe = "" } = {}) {
  const NS = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(NS, "svg");
  svg.setAttribute("viewBox", "0 0 32 32");
  svg.setAttribute("aria-hidden", "true");
  svg.setAttribute("focusable", "false");
  if (classe) svg.setAttribute("class", classe);
  const carre = document.createElementNS(NS, "rect");
  for (const [k, v] of Object.entries({ x: "4", y: "8", width: "19", height: "19", rx: "2.5", fill: "none", stroke: "currentColor", "stroke-width": "2.4" })) carre.setAttribute(k, v);
  const coche = document.createElementNS(NS, "path");
  for (const [k, v] of Object.entries({ d: "M9.5 17.5l5 5.2L28.5 5.5", fill: "none", stroke: "#e3b94d", "stroke-width": "3", "stroke-linecap": "round", "stroke-linejoin": "round" })) coche.setAttribute(k, v);
  svg.append(carre, coche);
  return svg;
}

/** En-tête de page : titre, sous-titre, lien de retour, pastille ou avatar et boutons d'action. */
export function enTete({ titre, sous = null, actions = null, retour = null, apres = null, avatar: pastilleIdentite = null }) {
  const titres = h("div.page-tete__titres", h("h1", titre, apres), sous ? h("p.page-tete__sous", sous) : null);
  return h(
    "header.page-tete",
    h(
      "div.page-tete__bloc",
      retour ? h("a.retour", { href: retour.href }, icone("retour", "ic--p"), retour.libelle) : null,
      pastilleIdentite ? h("div.page-tete__identite", pastilleIdentite, titres) : titres
    ),
    actions ? h("div.page-tete__actions", actions) : null
  );
}
