// =============================================================================
// La règle des échéances : une règle graduée sur les prochaines semaines, avec
// des fanions plantés à la date de chaque dépôt, décision, échéance de facture
// et rendez-vous. Sur un écran étroit, la même liste devient une liste verticale.
//
// Les fanions sont de vrais liens ; la règle elle-même est décorative. Leur
// position est calculée après affichage (largeur réelle du texte) pour qu'ils
// ne se chevauchent jamais : on les répartit sur plusieurs voies.
// =============================================================================
import { h } from "../noyau/dom.js";
import { icone } from "../noyau/icones.js";
import { aujourdhui, ajouterJours, differenceJours, jourSemaine } from "../commun/dates.js";
import { jourMois, dateLongue, echeanceRelative } from "../commun/format.js";

export const TYPES_REGLE = {
  depot: { libelle: "Dépôt de dossier", court: "Dépôt", icone: "dossiers" },
  decision: { libelle: "Décision attendue", court: "Décision", icone: "sablier" },
  facture: { libelle: "Échéance de facture", court: "Facture", icone: "factures" },
  rdv: { libelle: "Rendez-vous", court: "Rendez-vous", icone: "rendez-vous" },
};

const LARGEUR_MIN_REGLE = 560; // en dessous, on affiche une liste verticale
const ECART = 8; // px minimum entre deux fanions d'une même voie

/**
 * regleEcheances({ elements, retards, jours, auj, vide })
 *   elements : [{ id, type, date, titre, detail?, heure?, href }] — dates dans [auj, auj + jours[
 *   retards  : mêmes objets, dates passées (affichés au-dessus, en rouge)
 * Retourne { noeud, detruire }.
 */
export function regleEcheances({ elements, retards = [], jours = 42, auj = aujourdhui(), vide = "Aucune échéance prévue pour les prochaines semaines." }) {
  const tries = elements.slice().sort((a, b) => `${a.date} ${a.heure || ""}`.localeCompare(`${b.date} ${b.heure || ""}`));

  // Fond : fins de semaine et repères du lundi.
  const fond = h("div.regle__fond", { "aria-hidden": "true" });
  const axe = h("div.regle__axe", { "aria-hidden": "true" });
  for (let j = 0; j < jours; j++) {
    const d = ajouterJours(auj, j);
    const js = jourSemaine(d);
    if (js === 0 || js === 6) fond.append(h("span.regle__weekend", { css: { "--j": j } }));
    if (js === 1 && j >= 4) axe.append(h("span.regle__semaine", { css: { "--j": j } }, jourMois(d)));
  }
  axe.append(h("span.regle__auj", "Aujourd’hui"));

  const liste = h("ol.regle__drapeaux", { "aria-label": "Échéances à venir, de la plus proche à la plus éloignée" });
  for (const e of tries) {
    const t = TYPES_REGLE[e.type] || TYPES_REGLE.rdv;
    const j = Math.max(0, Math.min(jours - 1, differenceJours(auj, e.date)));
    liste.append(
      h(
        "li.drapeau",
        { class: `drapeau--${e.type}`, css: { "--j": j, "--voie": 0 }, dataset: { j } },
        h(
          "a.drapeau__lien",
          { href: e.href, title: `${t.libelle} — ${e.titre}${e.detail ? ` (${e.detail})` : ""}` },
          icone(t.icone, "ic--p"),
          h("span.drapeau__date", jourMois(e.date)),
          h("span.drapeau__texte", e.titre),
          e.detail ? h("span.drapeau__detail", e.detail) : null,
          h("span.drapeau__rel", e.heure ? `${echeanceRelative(e.date, auj)}, ${e.heure}` : echeanceRelative(e.date, auj)),
          h("span.sr-only", ` — ${t.libelle}, ${dateLongue(e.date)}`)
        )
      )
    );
  }

  const piste = h(
    "div.regle__piste",
    { css: { "--jours": jours, "--voies": 1 } },
    fond,
    axe,
    liste,
    tries.length ? null : h("p.regle__vide", vide)
  );

  const legende = h(
    "ul.regle__legende",
    { "aria-hidden": "true" },
    Object.entries(TYPES_REGLE).map(([cle, t]) => h("li", { class: `drapeau--${cle}` }, h("span.regle__pastille"), t.court))
  );

  const bandeauRetards = retards.length
    ? h(
        "div.regle__retards",
        h("h3", icone("alerte", "ic--p"), "En retard"),
        h(
          "ul",
          retards
            .slice()
            .sort((a, b) => a.date.localeCompare(b.date))
            .map((e) => {
              const t = TYPES_REGLE[e.type] || TYPES_REGLE.rdv;
              return h(
                "li",
                h("a", { href: e.href }, h("strong", e.titre), h("span", `${t.court.toLowerCase()} : ${echeanceRelative(e.date, auj)}`), e.detail ? h("span.muet", e.detail) : null)
              );
            })
        )
      )
    : null;

  const noeud = h("div.regle", bandeauRetards, piste, h("div.regle__pied", legende));

  // ----- Placement des fanions ---------------------------------------------------------------------------------------
  let largeurPlacee = -1;
  function placer(force = false) {
    const W = piste.clientWidth;
    if (!W || (!force && W === largeurPlacee)) return;
    largeurPlacee = W;
    const etroit = W < LARGEUR_MIN_REGLE;
    noeud.classList.toggle("regle--liste", etroit);
    if (etroit) return;
    const fins = [];
    for (const li of liste.children) {
      const j = +li.dataset.j;
      const w = li.firstElementChild.offsetWidth + 6;
      const x = ((j + 0.5) / jours) * W;
      const gauche = x + w > W - 2;
      const debut = gauche ? x - w : x;
      let voie = fins.findIndex((f) => debut >= f + ECART);
      if (voie < 0) voie = fins.length;
      fins[voie] = gauche ? x : x + w;
      li.style.setProperty("--voie", String(voie));
      li.classList.toggle("drapeau--gauche", gauche);
    }
    piste.style.setProperty("--voies", String(Math.max(1, fins.length)));
  }

  const observateur = typeof ResizeObserver === "function" ? new ResizeObserver(() => placer()) : null;
  observateur?.observe(piste);
  document.fonts?.ready?.then(() => placer(true)).catch(() => {});
  requestAnimationFrame(() => placer(true));

  return {
    noeud,
    detruire() {
      observateur?.disconnect();
    },
  };
}
