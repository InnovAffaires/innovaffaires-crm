// =============================================================================
// Tâches : ligne à cocher, regroupement par échéance, ajout rapide.
// Partagé par l'accueil, l'écran des tâches et les fiches.
// =============================================================================
import { h, idUnique, annoncer } from "../noyau/dom.js";
import { icone } from "../noyau/icones.js";
import { etat, fiche, nomUtilisateur } from "../noyau/etat.js";
import { modifierFiche, creerFiche, tenter } from "../noyau/ecriture.js";
import { toast } from "./toast.js";
import { aujourdhui, ajouterJours } from "../commun/dates.js";
import { dateLongue, tronquer } from "../commun/format.js";
import { noeudEcheance, lienLie, heureTexte, dateSansAnneeCourante } from "../vues/aides.js";

export const ICONE_TACHE = { tache: "liste-verif", appel: "appel", courriel: "courriel", rendezvous: "rendez-vous", texto: "mobile" };
const LIBELLE_TYPE = { tache: "Tâche", appel: "Appel", courriel: "Courriel", rendezvous: "Rendez-vous", texto: "Texto" };
const POIDS_PRIORITE = { haute: 0, normale: 1, basse: 2 };

/** Ordre d'affichage : échéance (les plus anciennes d'abord), priorité, heure, titre. Sans échéance : à la fin. */
export function ordreTaches(a, b) {
  const ea = a.echeance || "9999-12-31";
  const eb = b.echeance || "9999-12-31";
  if (ea !== eb) return ea < eb ? -1 : 1;
  const pa = POIDS_PRIORITE[a.priorite || "normale"] ?? 1;
  const pb = POIDS_PRIORITE[b.priorite || "normale"] ?? 1;
  if (pa !== pb) return pa - pb;
  const ha = a.heure || "99:99";
  const hb = b.heure || "99:99";
  if (ha !== hb) return ha < hb ? -1 : 1;
  return String(a.titre || "").localeCompare(String(b.titre || ""), "fr-CA");
}

export const GROUPES_TACHES = [
  { id: "retard", titre: "En retard", ton: "erreur" },
  { id: "aujourdhui", titre: "Aujourd’hui", ton: "attention" },
  { id: "semaine", titre: "Dans les 7 prochains jours", ton: "neutre" },
  { id: "plusTard", titre: "Plus tard", ton: "neutre" },
  { id: "sansDate", titre: "Sans échéance", ton: "neutre" },
];

/** Répartit des tâches à faire en { retard, aujourdhui, semaine, plusTard, sansDate }, chacune triée. */
export function regrouperTaches(taches, auj = aujourdhui()) {
  const g = { retard: [], aujourdhui: [], semaine: [], plusTard: [], sansDate: [] };
  const finSemaine = ajouterJours(auj, 7);
  for (const t of taches) {
    if (!t.echeance) g.sansDate.push(t);
    else if (t.echeance < auj) g.retard.push(t);
    else if (t.echeance === auj) g.aujourdhui.push(t);
    else if (t.echeance <= finSemaine) g.semaine.push(t);
    else g.plusTard.push(t);
  }
  for (const k of Object.keys(g)) g[k].sort(ordreTaches);
  return g;
}

/** Tâches à faire qui concernent l'utilisateur (les siennes et celles qui n'ont pas de responsable). */
export function mesTachesOuvertes(taches) {
  const moi = etat.utilisateur?.id;
  return taches.filter((t) => t.statut !== "fait" && (!t.responsable_id || t.responsable_id === moi));
}

async function ouvrirEdition(id) {
  const m = await import("../vues/formulaires.js");
  m.modifierLaFiche("taches", id);
}

/**
 * ligneTache(t, { lien, responsable, quandTerminee })
 *   lien          : afficher la fiche liée (défaut : oui) ; false sur la fiche elle-même
 *   responsable   : afficher le responsable s'il n'est pas l'utilisateur courant
 *   quandTerminee : pour une tâche faite, montrer la date où elle a été terminée plutôt que son échéance
 *   lienCourt     : raccourcir le nom de la fiche liée (colonnes étroites) ; false quand la place ne manque pas
 *   echeance      : afficher la date d'échéance (false dans une liste déjà regroupée par jour)
 */
export function ligneTache(t, { lien = true, responsable = true, quandTerminee = false, lienCourt = true, echeance = true } = {}) {
  const faite = t.statut === "fait";
  const peutEcrire = etat.droits.ecrire;
  const coche = h("input", {
    type: "checkbox", checked: faite, disabled: !peutEcrire, "aria-label": `${faite ? "Rouvrir" : "Terminer"} : ${t.titre}`,
  });
  const li = h("li.tache", { class: { "tache--faite": faite }, "data-tache": t.id });

  coche.addEventListener("change", async () => {
    const termine = coche.checked;
    li.classList.toggle("tache--faite", termine);
    const courante = fiche("taches", t.id) || t;
    const r = await tenter(() => modifierFiche("taches", courante, { statut: termine ? "fait" : "a-faire" }), { entite: "taches" });
    if (!r) {
      coche.checked = !termine;
      li.classList.toggle("tache--faite", !termine);
      return;
    }
    if (termine) {
      annoncer("Tâche terminée.");
      toast(`Terminée : « ${tronquer(t.titre, 48)} ».`, {
        ton: "info", duree: 6000,
        action: { libelle: "Annuler", onclick: () => tenter(() => modifierFiche("taches", fiche("taches", t.id) || courante, { statut: "a-faire" }), { entite: "taches" }) },
      });
    }
  });

  const meta = [];
  if (t.type && t.type !== "tache") {
    meta.push(h("span.tache__type", { title: LIBELLE_TYPE[t.type] }, icone(ICONE_TACHE[t.type] || "liste-verif", "ic--p"), h("span", LIBELLE_TYPE[t.type] || t.type)));
  }
  if (t.priorite === "haute" && !faite) {
    meta.push(h("span.tache__priorite", icone("drapeau", "ic--p"), h("span", "Priorité haute")));
  }
  if (lien && t.lie_id) {
    const l = lienLie(t.lie_type, t.lie_id, { court: lienCourt });
    if (l) meta.push(l);
  }
  if (responsable && t.responsable_id && t.responsable_id !== etat.utilisateur?.id) {
    const nom = nomUtilisateur(t.responsable_id);
    if (nom) meta.push(h("span.tache__resp", icone("utilisateur", "ic--p"), h("span", nom)));
  }

  li.append(
    h("label.case.tache__case", coche, h("span.case__boite", { "aria-hidden": "true" }, icone("coche", "ic--p"))),
    h(
      "div.tache__corps",
      peutEcrire
        ? h("button.tache__titre", { type: "button", onclick: () => ouvrirEdition(t.id), title: "Modifier cette tâche" }, t.titre)
        : h("span.tache__titre", t.titre),
      meta.length ? h("div.tache__meta", meta) : null
    ),
    h(
      "div.tache__fin",
      faite && quandTerminee && t.terminee_le ? h("span.muet", `terminée le ${dateSansAnneeCourante(aujourdhui(Date.parse(t.terminee_le)))}`) : echeance ? noeudEcheance(t.echeance, { fait: faite }) : null,
      t.heure && !faite ? h("small.muet", heureTexte(t.heure)) : null
    )
  );
  return li;
}

/** Liste de tâches (ul). `vide` : texte affiché s'il n'y en a aucune. */
export function listeTaches(taches, opts = {}) {
  if (!taches.length) return opts.vide ? h("p.liste-vide", opts.vide) : null;
  return h("ul.taches", taches.map((t) => ligneTache(t, opts)));
}

// ----- Ajout rapide --------------------------------------------------------------------------------------------------------------
const ECHEANCES_RAPIDES = [
  { id: "aujourdhui", libelle: "Aujourd’hui", jours: 0 },
  { id: "demain", libelle: "Demain", jours: 1 },
  { id: "semaine", libelle: "Dans 7 jours", jours: 7 },
  { id: "aucune", libelle: "Sans échéance", jours: null },
];

/**
 * ajoutRapide({ lieType, lieId, valeurs, echeance, placeholder, focusId, surAjout })
 * Une ligne de saisie : on tape, on choisit quand, Entrée. Retourne null si l'utilisateur ne peut pas écrire.
 */
export function ajoutRapide({ lieType = null, lieId = null, valeurs = {}, echeance = "aujourdhui", placeholder = "Ajouter une tâche…", focusId = "ajout-tache", surAjout = null } = {}) {
  if (!etat.droits.ecrire) return null;
  const idChamp = idUnique("aj");
  const idQuand = idUnique("ajq");
  const champ = h("input.saisie", {
    id: idChamp, type: "text", maxlength: 300, autocomplete: "off", placeholder, "data-focus-id": focusId, enterkeyhint: "done",
  });
  const quand = h("select.saisie.saisie--filtre", { id: idQuand, "data-focus-id": `${focusId}-quand` }, ECHEANCES_RAPIDES.map((o) => h("option", { value: o.id }, o.libelle)));
  quand.value = echeance;
  const bouton = h("button.btn.btn--primaire", { type: "submit" }, icone("plus"), h("span", "Ajouter"));
  const form = h(
    "form.ajout-rapide",
    { novalidate: true },
    h("label.sr-only", { for: idChamp }, "Nouvelle tâche"),
    champ,
    h("label.sr-only", { for: idQuand }, "Échéance de la nouvelle tâche"),
    h("div.saisie-select", quand, icone("bas", "ic--p")),
    bouton
  );
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const titre = champ.value.trim();
    if (!titre) {
      champ.focus();
      return;
    }
    const choix = ECHEANCES_RAPIDES.find((o) => o.id === quand.value);
    const date = choix?.jours === null || choix === undefined ? undefined : ajouterJours(aujourdhui(), choix.jours);
    bouton.disabled = true;
    const r = await tenter(
      () => creerFiche("taches", { titre, ...(date ? { echeance: date } : {}), responsable_id: etat.utilisateur.id, ...(lieType ? { lie_type: lieType, lie_id: lieId } : {}), ...valeurs }),
      { succes: date ? `Tâche ajoutée pour le ${dateLongue(date)}.` : "Tâche ajoutée.", entite: "taches" }
    );
    bouton.disabled = false;
    if (r) {
      champ.value = "";
      surAjout?.(r.fiche);
    }
    champ.focus();
  });
  return h("div.ajout-rapide-conteneur", form);
}
