// =============================================================================
// Registre : tableau triable, qui devient une liste de fiches sur téléphone.
// =============================================================================
import { h } from "../noyau/dom.js";
import { icone } from "../noyau/icones.js";
import { naviguer } from "../noyau/routeur.js";
import { btn } from "./composants.js";

const collateur = new Intl.Collator("fr-CA", { numeric: true, sensitivity: "base" });

function comparer(a, b) {
  const va = a === undefined || a === null || a === "" ? null : a;
  const vb = b === undefined || b === null || b === "" ? null : b;
  if (va === null && vb === null) return 0;
  if (va === null) return 1;
  if (vb === null) return -1;
  if (typeof va === "number" && typeof vb === "number") return va - vb;
  return collateur.compare(String(va), String(vb));
}

/**
 * tableau({ colonnes, lignes, href, tri, surTri, libelle, limiteInitiale, vide, ligneTotal, cartes, texteLimite })
 *   texteLimite(affichees, total) : phrase du pied quand la liste est tronquée (par défaut « N fiches affichées sur M. »)
 *   colonnes : [{ id, titre, rendu(l) → Node|string, valeur?(l), classe?, etiquette?, mobile?: "cache", triable? }]
 *              classe : "num" (chiffres alignés à droite) | "cellule-titre" | "cellule-sous"
 *   href(l)  : adresse ouverte au clic sur la ligne
 *   Retourne { noeud, majLignes(lignes), lignesAffichees() }
 */
export function tableau({ colonnes, lignes, href = null, tri = null, surTri = null, libelle = "Liste", limiteInitiale = 100, vide = null, ligneTotal = null, cartes = true, texteLimite = null }) {
  let etatTri = tri ? { ...tri } : null;
  let limite = limiteInitiale;
  let donnees = lignes;
  let triees = [];

  const entetes = colonnes.map((c) => {
    const triable = c.triable ?? !!c.valeur;
    const th = h("th", { scope: "col", class: c.classe && c.classe.split(" ").filter((x) => x === "num"), "data-col": c.id });
    if (!triable) {
      th.append(c.titre);
      return { c, th };
    }
    const bouton = h("button", { type: "button", onclick: () => trier(c) }, c.titre, h("span.tri-icone", { "aria-hidden": "true" }));
    th.append(bouton);
    return { c, th, bouton };
  });
  const thead = h("thead", h("tr", entetes.map((e) => e.th)));
  const tbody = h("tbody");
  const pied = h("div.registre-pied", { hidden: true });
  const table = h("table.registre", { class: { "registre--cartes": cartes } }, h("caption", libelle), thead, tbody);
  const conteneur = h("div.registre-conteneur", table);
  const zoneVide = h("div.registre-conteneur", { hidden: true });
  const noeud = h("div.registre-bloc", conteneur, zoneVide, pied);

  function marquerTri() {
    for (const { c, th, bouton } of entetes) {
      if (!bouton) continue;
      const actif = etatTri && etatTri.col === c.id;
      if (actif) th.setAttribute("aria-sort", etatTri.dir === "asc" ? "ascending" : "descending");
      else th.removeAttribute("aria-sort");
      bouton.querySelector(".tri-icone").replaceChildren(actif ? icone(etatTri.dir === "asc" ? "haut" : "bas", "ic--p") : "");
    }
  }

  function trier(c) {
    if (etatTri && etatTri.col === c.id) etatTri = { col: c.id, dir: etatTri.dir === "asc" ? "desc" : "asc" };
    else etatTri = { col: c.id, dir: "asc" };
    surTri?.({ ...etatTri });
    dessiner();
    entetes.find((e) => e.c.id === c.id)?.bouton?.focus();
  }

  function ligne(l) {
    const tr = h("tr");
    const url = href ? href(l) : null;
    if (url) {
      tr.dataset.href = url;
      tr.addEventListener("click", (e) => {
        if (e.target.closest("a, button, input, select, label, textarea, summary")) return;
        if (getSelection()?.toString()) return;
        naviguer(url.replace(/^#/, ""));
      });
    }
    for (const c of colonnes) {
      const contenu = c.rendu(l);
      tr.append(h("td", { class: [c.classe, c.mobile === "cache" ? "cache-mobile" : ""], dataset: { etiquette: c.classe?.includes("cellule-titre") ? null : c.etiquette ?? c.titre } }, contenu));
    }
    return tr;
  }

  function dessiner() {
    const col = etatTri && colonnes.find((c) => c.id === etatTri.col);
    triees = donnees.slice();
    if (col?.valeur) {
      const f = etatTri.dir === "asc" ? 1 : -1;
      triees.sort((a, b) => {
        const va = col.valeur(a);
        const vb = col.valeur(b);
        const vide_a = va === undefined || va === null || va === "";
        const vide_b = vb === undefined || vb === null || vb === "";
        if (vide_a || vide_b) return comparer(va, vb);
        return f * comparer(va, vb);
      });
    }
    marquerTri();
    tbody.replaceChildren();
    if (!triees.length) {
      conteneur.hidden = true;
      const v = typeof vide === "function" ? vide() : vide;
      zoneVide.hidden = !v;
      zoneVide.replaceChildren(...(v ? [v] : []));
      pied.hidden = true;
      return;
    }
    conteneur.hidden = false;
    zoneVide.hidden = true;
    const visibles = triees.slice(0, limite);
    for (const l of visibles) tbody.append(ligne(l));
    if (ligneTotal) {
      const lt = ligneTotal(triees);
      if (lt) tbody.append(lt);
    }
    if (triees.length > visibles.length) {
      pied.hidden = false;
      pied.replaceChildren(
        h("span", texteLimite ? texteLimite(visibles.length, triees.length) : `${visibles.length} fiches affichées sur ${triees.length}.`),
        btn("Afficher la suite", { petit: true, onclick: () => { limite += 100; dessiner(); } })
      );
    } else pied.hidden = true;
  }

  dessiner();
  return {
    noeud,
    majLignes(nouvelles) {
      donnees = nouvelles;
      dessiner();
    },
    lignesAffichees: () => triees,
    reinitialiserLimite() {
      limite = limiteInitiale;
    },
  };
}
