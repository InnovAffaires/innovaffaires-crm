// =============================================================================
// Liste déroulante avec recherche (modèle ARIA « combobox » avec liste).
// Sert aux champs « lien » (choisir une entreprise, un contact…) et aux filtres.
// =============================================================================
import { h, idUnique } from "../noyau/dom.js";
import { icone } from "../noyau/icones.js";
import { normaliser } from "../commun/format.js";

const MAX_AFFICHES = 40;

/**
 * combobox({ options, valeur, aucun, placeholder, requis, creer, surChoix, etiquette, id })
 *   options : () => [{ id, libelle, sous?, cherche? }]   (appelée à chaque ouverture)
 *   creer   : { libelle: "Créer l’entreprise", action: async (texte) => id | null }  (facultatif)
 */
export function combobox({ options, valeur = null, aucun = "Aucun", placeholder = "Rechercher…", requis = false, creer = null, surChoix = null, id = null, etiquette = null, desactive = false }) {
  const idChamp = id || idUnique("cb");
  const idListe = `${idChamp}-liste`;
  let courant = valeur || null;
  let ouverte = false;
  let resultats = [];
  let actif = -1;
  let libelleCourant = "";

  const entree = h("input.cb__entree", {
    id: idChamp, type: "text", role: "combobox", autocomplete: "off", spellcheck: "false", placeholder,
    "aria-expanded": "false", "aria-controls": idListe, "aria-autocomplete": "list", "aria-haspopup": "listbox",
    "aria-required": requis ? "true" : null, "aria-label": etiquette, disabled: desactive,
  });
  const liste = h("ul.cb__liste", { id: idListe, role: "listbox", hidden: true, "aria-label": etiquette || "Suggestions" });
  const effacer = h("button.cb__effacer", { type: "button", tabindex: "-1", "aria-label": "Effacer le choix", hidden: true, onclick: (e) => { e.preventDefault(); choisir(null); entree.focus(); } }, icone("fermer", "ic--p"));
  const noeud = h("div.cb", entree, effacer, h("span.cb__chevron", { "aria-hidden": "true" }, icone("bas", "ic--p")), liste);

  function toutesOptions() {
    return options() || [];
  }
  function libelleDe(idv) {
    if (!idv) return "";
    return toutesOptions().find((o) => o.id === idv)?.libelle || "";
  }
  function afficherValeur() {
    libelleCourant = libelleDe(courant);
    entree.value = libelleCourant;
    effacer.hidden = !courant || requis || desactive;
  }

  function filtrer(texte) {
    const t = normaliser(texte);
    const tout = toutesOptions();
    let sortie;
    if (!t) sortie = tout;
    else {
      const debut = [];
      const dedans = [];
      for (const o of tout) {
        const l = normaliser(o.libelle);
        const c = normaliser(`${o.sous || ""} ${o.cherche || ""}`);
        if (l.startsWith(t) || l.split(/[\s'’-]+/).some((m) => m.startsWith(t))) debut.push(o);
        else if (l.includes(t) || c.includes(t)) dedans.push(o);
      }
      sortie = debut.concat(dedans);
    }
    return sortie;
  }

  function dessiner() {
    liste.replaceChildren();
    const t = entree.value === libelleCourant ? "" : entree.value;
    const tous = filtrer(t);
    resultats = [];
    if (!requis) resultats.push({ id: null, libelle: aucun, special: true });
    for (const o of tous.slice(0, MAX_AFFICHES)) resultats.push(o);
    const texteTape = entree.value.trim();
    if (creer && texteTape && texteTape !== libelleCourant && !tous.some((o) => normaliser(o.libelle) === normaliser(texteTape))) {
      resultats.push({ id: "__creer__", libelle: `${creer.libelle} « ${texteTape} »`, creer: true });
    }
    resultats.forEach((o, i) => {
      const li = h(
        "li.cb__option",
        {
          id: `${idListe}-${i}`, role: "option", "aria-selected": String(o.id === courant && !o.creer),
          class: { "cb__option--aucun": o.special, "cb__option--creer": o.creer },
          onmousedown: (e) => { e.preventDefault(); },
          onclick: () => choisir(o),
        },
        h("span.cb__option-texte", o.libelle),
        o.sous ? h("span.cb__option-sous", o.sous) : null
      );
      liste.append(li);
    });
    if (tous.length > MAX_AFFICHES) liste.append(h("li.cb__plus", { role: "presentation" }, `${tous.length - MAX_AFFICHES} autres résultats : précisez votre recherche.`));
    if (!tous.length && !creer) liste.append(h("li.cb__plus", { role: "presentation" }, "Aucun résultat."));
    actif = Math.max(0, resultats.findIndex((o) => o.id === courant));
    if (t) actif = resultats.findIndex((o) => !o.special);
    if (actif < 0) actif = 0;
    surligner();
  }

  function surligner() {
    liste.querySelectorAll("[role=option]").forEach((li, i) => li.classList.toggle("cb__option--actif", i === actif));
    const li = liste.querySelector(`#${idListe}-${actif}`);
    if (li) {
      entree.setAttribute("aria-activedescendant", li.id);
      li.scrollIntoView({ block: "nearest" });
    } else entree.removeAttribute("aria-activedescendant");
  }

  function ouvrir() {
    if (ouverte || desactive) return;
    ouverte = true;
    liste.hidden = false;
    entree.setAttribute("aria-expanded", "true");
    noeud.classList.add("cb--ouvert");
    dessiner();
  }
  function fermer({ restaurer = true } = {}) {
    if (!ouverte) return;
    ouverte = false;
    liste.hidden = true;
    entree.setAttribute("aria-expanded", "false");
    entree.removeAttribute("aria-activedescendant");
    noeud.classList.remove("cb--ouvert");
    if (restaurer) afficherValeur();
  }

  async function choisir(o) {
    if (o && o.creer) {
      const texte = entree.value.trim();
      fermer({ restaurer: false });
      entree.disabled = true;
      let nouvelId = null;
      try {
        nouvelId = await creer.action(texte);
      } finally {
        entree.disabled = desactive;
      }
      if (nouvelId) definirInterne(nouvelId, true);
      else afficherValeur();
      entree.focus();
      return;
    }
    definirInterne(o ? o.id : null, true);
    fermer({ restaurer: false });
    afficherValeur();
  }
  function definirInterne(idv, notifier) {
    courant = idv || null;
    afficherValeur();
    if (notifier) {
      noeud.dispatchEvent(new CustomEvent("change", { bubbles: true }));
      surChoix?.(courant);
    }
  }

  entree.addEventListener("focus", () => {
    entree.select();
    ouvrir();
  });
  entree.addEventListener("click", () => ouvrir());
  entree.addEventListener("input", () => {
    if (!ouverte) ouvrir();
    else dessiner();
  });
  entree.addEventListener("keydown", (e) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      if (!ouverte) ouvrir();
      else if (actif < resultats.length - 1) actif++;
      surligner();
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      if (!ouverte) ouvrir();
      else if (actif > 0) actif--;
      surligner();
    } else if (e.key === "Home" && ouverte && e.ctrlKey) {
      actif = 0;
      surligner();
    } else if (e.key === "Enter") {
      if (ouverte && resultats[actif]) {
        e.preventDefault();
        choisir(resultats[actif]);
      }
    } else if (e.key === "Escape") {
      if (ouverte) {
        e.preventDefault();
        e.stopPropagation();
        fermer();
      }
    } else if (e.key === "Tab") {
      fermer();
    }
  });
  entree.addEventListener("blur", () => {
    setTimeout(() => {
      if (!noeud.contains(document.activeElement)) fermer();
    }, 0);
  });

  afficherValeur();
  return {
    noeud,
    entree,
    lire: () => courant,
    definir(idv) {
      definirInterne(idv, false);
    },
    focus: () => entree.focus(),
    actualiser: afficherValeur,
    desactiver(v) {
      entree.disabled = !!v;
      effacer.hidden = !courant || requis || !!v;
    },
  };
}
