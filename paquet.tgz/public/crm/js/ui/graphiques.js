// =============================================================================
// Graphiques des rapports : colonnes en SVG, barres horizontales en HTML, tuiles
// de chiffres, et le cadre qui leur donne un titre, une légende et un tableau
// équivalent. Aucune bibliothèque : tout est dessiné ici, texte inséré comme
// texte (jamais en HTML) et couleurs prises dans les variables de vues.css.
//
// Règles suivies partout :
//   · une seule échelle verticale (jamais deux axes) ;
//   · barres fines (24 px au plus), bout arrondi à 4 px du côté des données, 2 px
//     d'espace entre deux éléments qui se touchent ;
//   · une légende dès qu'il y a deux séries ; le texte reste en couleur de texte,
//     la couleur de la série est portée par un petit repère à côté ;
//   · les valeurs sont toujours lisibles sans survol : étiquette sur les barres
//     horizontales, bulle (aussi au clavier) et tableau équivalent pour le reste.
// =============================================================================
import { h, remplir } from "../noyau/dom.js";
import { icone } from "../noyau/icones.js";
import { btn, panneau } from "./composants.js";

const NS = "http://www.w3.org/2000/svg";

/** Élément SVG. Les attributs vides sont ignorés ; jamais d'attribut « style » (CSP). */
function s(balise, attributs = {}, texte = null) {
  const el = document.createElementNS(NS, balise);
  for (const [cle, valeur] of Object.entries(attributs)) {
    if (valeur === null || valeur === undefined || valeur === false) continue;
    if (cle.toLowerCase() === "style") throw new Error("Attribut interdit : style");
    el.setAttribute(cle, String(valeur));
  }
  if (texte !== null) el.textContent = String(texte);
  return el;
}

// ----- Échelle verticale -----------------------------------------------------------------------------------------
/** Sommet et graduations « rondes » (1, 2, 5 × une puissance de dix), environ quatre intervalles. */
export function echelle(max, { entier = false } = {}) {
  if (!(max > 0)) return { max: 1, pas: 1, graduations: [0, 1] };
  const brut = max / 4;
  const exposant = Math.floor(Math.log10(brut));
  const f = brut / 10 ** exposant;
  const net = f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10;
  let pas = net * 10 ** exposant;
  if (entier) pas = Math.max(1, Math.ceil(pas));
  const sommet = Math.ceil(max / pas - 1e-9) * pas;
  const graduations = [];
  for (let v = 0; v <= sommet + pas / 2; v += pas) graduations.push(Math.round(v * 1e6) / 1e6);
  return { max: sommet, pas, graduations };
}

/** Colonne dont seul le bout (haut) est arrondi : le pied reste droit, collé à la ligne de base. */
function colonne(x, y, l, hauteur, rayon = 4) {
  const r = Math.max(0, Math.min(rayon, l / 2, hauteur));
  return `M${x},${y + hauteur}V${y + r}Q${x},${y} ${x + r},${y}H${x + l - r}Q${x + l},${y} ${x + l},${y + r}V${y + hauteur}Z`;
}

/** Observe la largeur d'une zone et redessine quand elle change (rien tant qu'elle est masquée). */
function suivreLargeur(zone, dessiner) {
  let derniere = 0;
  const obs = new ResizeObserver((entrees) => {
    const l = Math.floor(entrees[0].contentRect.width);
    if (l < 120 || l === derniere) return;
    derniere = l;
    dessiner(l);
  });
  obs.observe(zone);
  return () => obs.disconnect();
}

// ----- Colonnes ----------------------------------------------------------------------------------------------------
/**
 * Colonnes verticales groupées : une par catégorie (un mois, par exemple), une colonne par série.
 *   categories : [{ court, long, annee? }]   court : étiquette d'axe ; long : titre de la bulle ; annee : mention sous l'étiquette
 *   series     : [{ id, libelle, classe, valeurs }]   classe : « g-s1 », « g-s2 »…
 *   libelle    : phrase qui nomme le graphique pour les lecteurs d'écran
 * Retourne { noeud, detruire }.
 */
export function colonnes({ categories, series, entier = false, formatAxe, formatValeur, libelle }) {
  const n = categories.length;
  const ech = echelle(Math.max(0, ...series.flatMap((sr) => sr.valeurs)), { entier });

  const zone = h("div.g-zone", { tabindex: "0", role: "group", "aria-label": `${libelle}. Flèches gauche et droite pour parcourir les valeurs ; le bouton « Tableau » donne toutes les valeurs.` });
  const bulle = h("div.g-bulle", { hidden: true, "aria-hidden": "true" });
  const annonce = h("p.sr-only", { "aria-live": "polite" });
  zone.append(bulle, annonce);

  let geo = null; // géométrie du dernier dessin : gauche, largeur d'une bande, y(), largeur totale
  let actif = null; // indice de la catégorie dont la bulle est ouverte
  let surbrillance = null;

  const phrase = (i) => `${categories[i].long} : ${series.map((sr) => `${sr.libelle} ${formatValeur(sr.valeurs[i] || 0)}`).join(", ")}`;

  function montrer(i, { annoncer = false } = {}) {
    if (!geo) return;
    actif = i;
    remplir(
      bulle,
      h("p.g-bulle__titre", categories[i].long),
      series.map((sr) => h("p.g-bulle__ligne", h("span.g-cle", { class: sr.classe }), h("span.g-bulle__serie", sr.libelle), h("strong", formatValeur(sr.valeurs[i] || 0))))
    );
    bulle.hidden = false;
    const centre = geo.gauche + (i + 0.5) * geo.bande;
    const sommet = geo.y(Math.max(...series.map((sr) => sr.valeurs[i] || 0)));
    bulle.style.setProperty("left", `${Math.round(Math.max(0, Math.min(geo.largeur - bulle.offsetWidth, centre - bulle.offsetWidth / 2)))}px`);
    bulle.style.setProperty("top", `${Math.round(Math.max(2, sommet - bulle.offsetHeight - 10))}px`);
    surbrillance?.setAttribute("x", String(geo.gauche + i * geo.bande));
    surbrillance?.removeAttribute("display");
    if (annoncer) annonce.textContent = phrase(i);
  }
  function cacher() {
    actif = null;
    bulle.hidden = true;
    surbrillance?.setAttribute("display", "none");
  }
  const indexSous = (e) => {
    const svg = zone.querySelector("svg");
    if (!svg || !geo) return null;
    const x = e.clientX - svg.getBoundingClientRect().left - geo.gauche;
    if (x < 0 || x > geo.bande * n) return null;
    return Math.min(n - 1, Math.floor(x / geo.bande));
  };

  function dessiner(L) {
    const H = 248;
    const haut = 20;
    const bas = 44;
    const droite = 8;
    const hPlot = H - haut - bas;
    const textes = ech.graduations.map(formatAxe);
    const gauche = Math.ceil(Math.max(...textes.map((t) => t.length)) * 6.8) + 16;
    const lPlot = Math.max(40, L - gauche - droite);
    const bande = lPlot / n;
    const y = (v) => haut + hPlot * (1 - v / ech.max);
    geo = { gauche, bande, y, largeur: L };

    const svg = s("svg", { class: "g-svg", width: L, height: H, viewBox: `0 0 ${L} ${H}`, "aria-hidden": "true", focusable: "false" });
    ech.graduations.forEach((v, i) => {
      svg.append(s("line", { class: v === 0 ? "g-axe" : "g-grille", x1: gauche, x2: gauche + lPlot, y1: y(v), y2: y(v) }));
      svg.append(s("text", { class: "g-graduation", x: gauche - 8, y: y(v), dy: "0.32em", "text-anchor": "end" }, textes[i]));
    });
    surbrillance = s("rect", { class: "g-survol", x: gauche, y: haut, width: bande, height: hPlot, display: "none" });
    svg.append(surbrillance);

    // Colonnes : 2 px d'espace entre deux séries d'un même groupe
    const k = series.length;
    const ecart = 2;
    const largeurBarre = Math.min(24, Math.max(4, (bande * 0.72 - ecart * (k - 1)) / k));
    const largeurGroupe = k * largeurBarre + (k - 1) * ecart;
    let plusHaute = null;
    categories.forEach((_, i) => {
      let x = gauche + i * bande + (bande - largeurGroupe) / 2;
      for (const sr of series) {
        const v = sr.valeurs[i] || 0;
        if (v > 0) {
          const hauteur = Math.max(2, y(0) - y(v));
          svg.append(s("path", { class: sr.classe, d: colonne(x, y(0) - hauteur, largeurBarre, hauteur) }));
          if (!plusHaute || v > plusHaute.v) plusHaute = { v, cx: x + largeurBarre / 2, sommet: y(0) - hauteur };
        }
        x += largeurBarre + ecart;
      }
    });

    // Axe horizontal : une étiquette par colonne si la place le permet, une sur deux (ou trois…) sinon
    const pas = Math.max(1, Math.ceil(34 / bande));
    categories.forEach((c, i) => {
      if (i % pas) return;
      const cx = gauche + (i + 0.5) * bande;
      svg.append(s("text", { class: "g-etiquette", x: cx, y: haut + hPlot + 17, "text-anchor": "middle" }, c.court));
      if (c.annee) svg.append(s("text", { class: "g-etiquette g-etiquette--annee", x: cx, y: haut + hPlot + 33, "text-anchor": "middle" }, c.annee));
    });

    // Une seule valeur étiquetée en permanence : la plus haute
    if (plusHaute) {
      const texte = formatValeur(plusHaute.v);
      const demi = texte.length * 3.6;
      const x = Math.max(gauche + demi, Math.min(gauche + lPlot - demi, plusHaute.cx));
      svg.append(s("text", { class: "g-valeur", x, y: Math.max(11, plusHaute.sommet - 6), "text-anchor": "middle" }, texte));
    }

    zone.querySelector("svg")?.remove();
    zone.prepend(svg);
    if (actif !== null) montrer(actif);
  }

  zone.addEventListener("pointermove", (e) => {
    const i = indexSous(e);
    if (i === null) cacher();
    else if (i !== actif) montrer(i);
  });
  zone.addEventListener("pointerdown", (e) => {
    if (e.pointerType !== "touch") return;
    const i = indexSous(e);
    if (i === null) cacher();
    else montrer(i);
  });
  zone.addEventListener("pointerleave", (e) => {
    if (e.pointerType !== "touch") cacher();
  });
  const dehors = (e) => {
    if (e.pointerType === "touch" && !zone.contains(e.target)) cacher();
  };
  document.addEventListener("pointerdown", dehors);
  zone.addEventListener("focus", () => {
    if (zone.matches(":focus-visible")) montrer(actif ?? n - 1, { annoncer: true });
  });
  zone.addEventListener("blur", cacher);
  zone.addEventListener("keydown", (e) => {
    const courant = actif ?? n - 1;
    let i = null;
    if (e.key === "ArrowRight") i = Math.min(n - 1, courant + 1);
    else if (e.key === "ArrowLeft") i = Math.max(0, courant - 1);
    else if (e.key === "Home") i = 0;
    else if (e.key === "End") i = n - 1;
    else if (e.key === "Escape") {
      cacher();
      return;
    }
    if (i === null) return;
    e.preventDefault();
    montrer(i, { annoncer: true });
  });

  const arreter = suivreLargeur(zone, dessiner);
  return {
    noeud: zone,
    detruire: () => {
      arreter();
      document.removeEventListener("pointerdown", dehors);
    },
  };
}

// ----- Barres horizontales -----------------------------------------------------------------------------------------
/**
 * Barres horizontales (HTML) : un libellé, une barre, la valeur au bout. Chaque valeur est écrite : aucune bulle.
 *   lignes : [{ libelle, detail?, valeur, classe?, segments?: [{ valeur, classe }], texteValeur? }]
 *   La longueur suit `valeur` ; `segments` la découpe (« gagnées » et « autres », par exemple).
 */
export function barresH({ lignes, formatValeur, libelle }) {
  const max = Math.max(0, ...lignes.map((l) => l.valeur));
  return h(
    "ul.g-barres",
    { "aria-label": libelle },
    lignes.map((l) => {
      const segments = (l.segments || [{ valeur: l.valeur, classe: l.classe || "g-s1" }]).filter((sg) => sg.valeur > 0);
      return h(
        "li.g-barre",
        { class: { "g-barre--vide": !(l.valeur > 0) } },
        h("div.g-barre__libelle", h("span.g-barre__nom", l.libelle), l.detail ? h("small.g-barre__detail", l.detail) : null),
        h(
          "div.g-barre__piste",
          l.valeur > 0 ? h("div.g-barre__trait", { "aria-hidden": "true", css: { "--p": max > 0 ? (l.valeur / max).toFixed(4) : 0 } }, segments.map((sg) => h("span.g-barre__seg", { class: sg.classe, css: { "--v": sg.valeur } }))) : null,
          h("span.g-barre__valeur", l.texteValeur || formatValeur(l.valeur))
        )
      );
    })
  );
}

// ----- Légende, tuile, tableau, cadre ------------------------------------------------------------------------------
/** Légende : un petit carré de la couleur de la série, puis son nom en couleur de texte. */
export function legende(items, { libelle = "Légende" } = {}) {
  return h("ul.g-legende", { "aria-label": libelle }, items.map((it) => h("li", h("span.g-pastille", { class: it.classe }), h("span", it.libelle))));
}

/**
 * Tuile de chiffre : libellé, valeur, écart avec la période de comparaison, précisions.
 *   delta : { sens: "hausse" | "baisse" | "stable", signe, texte } ou null
 *   sous  : une phrase ou une liste de phrases
 */
export function tuile({ libelle, valeur, delta = null, sous = null, titre = null }) {
  const lignes = sous === null ? [] : Array.isArray(sous) ? sous : [sous];
  return h(
    "div.tuile",
    h("p.tuile__libelle", libelle),
    h("p.tuile__valeur", { title: titre }, valeur),
    delta
      ? h("p.tuile__delta", { class: `tuile__delta--${delta.sens}` }, delta.sens === "hausse" ? icone("haut", "ic--p") : delta.sens === "baisse" ? icone("bas", "ic--p") : null, h("strong", delta.signe), " ", h("span", delta.texte))
      : null,
    lignes.map((t) => h("p.tuile__sous", t))
  );
}

/** Tableau équivalent d'un graphique : mêmes valeurs, lisibles sans la vue ni la souris. */
export function tableauDonnees({ libelle, colonnes: noms, lignes, pied = null }) {
  return h(
    "div.g-defilant",
    h(
      "table.g-donnees",
      h("caption.sr-only", libelle),
      h("thead", h("tr", noms.map((nom, i) => h("th", { scope: "col", class: { "g-donnees__num": i > 0 } }, nom)))),
      h("tbody", lignes.map((l) => h("tr", l.map((c, i) => (i === 0 ? h("th", { scope: "row" }, c) : h("td.g-donnees__num", c)))))),
      pied ? h("tfoot", h("tr", pied.map((c, i) => (i === 0 ? h("th", { scope: "row" }, c) : h("td.g-donnees__num", c))))) : null
    )
  );
}

/**
 * Cadre d'un graphique : titre, précision, légende, puis le graphique et son tableau, qui s'échangent.
 *   graphique : { noeud, detruire? } — ignoré quand `vide` est fourni
 *   vide      : noeud affiché à la place du graphique quand il n'y a rien à montrer
 *   tableauOuvert / surBascule : mémoire du choix « Tableau » d'un dessin à l'autre
 */
export function cadre({ titre, sous = null, legende: leg = null, graphique = null, tableau = null, vide = null, tableauOuvert = false, surBascule = null, classe = "" }) {
  const avecTableau = !!tableau && !vide;
  const ouvert = avecTableau && tableauOuvert;
  const corps = h("div.g-corps", { hidden: ouvert }, vide || graphique.noeud);
  const vueTableau = avecTableau ? h("div.g-tableau", { hidden: !ouvert }, tableau) : null;
  let bouton = null;
  if (avecTableau) {
    bouton = btn("Tableau", { icone: "tableau", petit: true, ton: "discret", titre: "Voir les valeurs sous forme de tableau" });
    bouton.setAttribute("aria-pressed", String(ouvert));
    bouton.addEventListener("click", () => {
      const maintenant = bouton.getAttribute("aria-pressed") !== "true";
      bouton.setAttribute("aria-pressed", String(maintenant));
      corps.hidden = maintenant;
      vueTableau.hidden = !maintenant;
      surBascule?.(maintenant);
    });
  }
  return {
    noeud: panneau({ titre, sous, actions: bouton, niveau: 3, classe: `g-carte ${classe}`.trim() }, vide ? null : leg, corps, vueTableau),
    detruire: () => graphique?.detruire?.(),
  };
}
