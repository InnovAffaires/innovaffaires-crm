// =============================================================================
// Messages brefs en bas de l'écran (confirmations, erreurs, nouvelles demandes).
// =============================================================================
import { h } from "../noyau/dom.js";
import { icone } from "../noyau/icones.js";

const MAX = 4;

/** toast("Contact enregistré") ; toast("…", { ton: "erreur" | "info" | "ok", action: { libelle, onclick }, duree }) */
export function toast(message, { ton = "ok", action = null, duree = null } = {}) {
  const zone = document.getElementById("toasts");
  if (!zone) return () => {};
  while (zone.children.length >= MAX) zone.firstElementChild.remove();
  const delai = duree ?? (ton === "erreur" ? 9000 : action ? 8000 : 4500);
  let minuteur;
  const retirer = () => {
    clearTimeout(minuteur);
    t.classList.add("toast--sortie");
    setTimeout(() => t.remove(), 180);
  };
  const t = h(
    "div.toast",
    { class: `toast--${ton}`, role: ton === "erreur" ? "alert" : "status" },
    icone(ton === "erreur" ? "alerte" : ton === "info" ? "info" : "ok"),
    h("span.toast__texte", message),
    action ? h("button.toast__action", { type: "button", onclick: () => (action.onclick?.(), retirer()) }, action.libelle) : null,
    h("button.toast__fermer", { type: "button", "aria-label": "Fermer ce message", onclick: retirer }, icone("fermer", "ic--p"))
  );
  const armer = () => {
    clearTimeout(minuteur);
    minuteur = setTimeout(retirer, delai);
  };
  t.addEventListener("mouseenter", () => clearTimeout(minuteur));
  t.addEventListener("mouseleave", armer);
  t.addEventListener("focusin", () => clearTimeout(minuteur));
  t.addEventListener("focusout", armer);
  zone.append(t);
  armer();
  return retirer;
}

export const toastErreur = (e, repli = "Une erreur est survenue.") => toast(e?.message || repli, { ton: "erreur" });
