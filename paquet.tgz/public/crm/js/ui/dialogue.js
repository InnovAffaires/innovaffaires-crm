// =============================================================================
// Boîtes de dialogue (élément <dialog> natif : focus piégé, Échap, fond inerte).
// =============================================================================
import { h, idUnique } from "../noyau/dom.js";
import { icone } from "../noyau/icones.js";

let ouverts = 0;

/**
 * ouvrirDialogue({ titre, contenu, taille, fermable, pied })
 *   contenu : Node ou (ctx) => Node
 *   ctx     : { fermer(valeur), modifie(bool), occupe(bool), dialog, definirPied(noeuds) }
 * Retourne { promesse, fermer, dialog } ; la promesse reçoit la valeur de fermer().
 */
export function ouvrirDialogue({ titre, contenu, taille = "moyen", fermable = true, pied = null, description = "", classe = "", avantAbandon = null }) {
  const idTitre = idUnique("dlg-t");
  const idDesc = idUnique("dlg-d");
  const dialog = h("dialog", { class: ["dialogue", `dialogue--${taille}`, classe], "aria-labelledby": idTitre, "aria-describedby": description ? idDesc : null });
  const corps = h("div.dialogue__corps");
  const bas = h("div.dialogue__pied");
  const fermerBtn = fermable ? h("button.btn-icone", { type: "button", "aria-label": "Fermer", onclick: () => demanderFermeture() }, icone("fermer")) : null;
  // Attention : append(null) écrirait le mot « null » dans la fenêtre ; on n'ajoute que ce qui existe.
  dialog.append(h("div.dialogue__tete", h("h2", { id: idTitre }, titre), fermerBtn), ...(description ? [h("p.dialogue__desc", { id: idDesc }, description)] : []), corps, bas);
  const precedent = document.activeElement instanceof HTMLElement ? document.activeElement : null;
  let resolu;
  const promesse = new Promise((r) => (resolu = r));
  let valeurFinale;
  let modifie = false;
  let occupe = false;

  const ctx = {
    dialog,
    fermer(valeur) {
      valeurFinale = valeur;
      if (dialog.open) dialog.close();
      else finir();
    },
    modifie(v = true) {
      modifie = !!v;
    },
    get estModifie() {
      return modifie;
    },
    occupe(v) {
      occupe = !!v;
      dialog.toggleAttribute("aria-busy", occupe);
      for (const b of dialog.querySelectorAll("button, input, select, textarea")) {
        if (v) {
          if (!b.disabled) {
            b.disabled = true;
            b.dataset.occupe = "1";
          }
        } else if (b.dataset.occupe) {
          b.disabled = false;
          delete b.dataset.occupe;
        }
      }
    },
    definirPied(...noeuds) {
      bas.replaceChildren(...noeuds.flat().filter(Boolean));
      bas.hidden = !bas.childNodes.length;
    },
  };

  async function demanderFermeture() {
    if (occupe) return;
    if (modifie) {
      const abandonner = avantAbandon ? await avantAbandon() : await confirmer({ titre: "Abandonner les modifications ?", message: "Ce que vous avez saisi n’a pas été enregistré.", libelleConfirmer: "Abandonner", libelleAnnuler: "Continuer la saisie", danger: true });
      if (!abandonner) return;
    }
    ctx.fermer(undefined);
  }

  function finir() {
    ouverts = Math.max(0, ouverts - 1);
    if (!ouverts) document.documentElement.classList.remove("dialogue-ouvert");
    dialog.remove();
    if (precedent && document.contains(precedent)) precedent.focus({ preventScroll: true });
    resolu(valeurFinale);
  }

  dialog.addEventListener("cancel", (e) => {
    e.preventDefault();
    if (fermable) demanderFermeture();
  });
  dialog.addEventListener("close", finir);
  dialog.addEventListener("mousedown", (e) => {
    // Un clic sur le fond (hors de la feuille) ferme la fenêtre, sauf pendant une saisie.
    if (e.target === dialog && fermable && !modifie) ctx.fermer(undefined);
  });

  const noeud = typeof contenu === "function" ? contenu(ctx) : contenu;
  corps.append(noeud);
  if (pied) ctx.definirPied(pied);
  else bas.hidden = !bas.childNodes.length;
  document.body.append(dialog);
  ouverts++;
  document.documentElement.classList.add("dialogue-ouvert");
  dialog.showModal();
  const cible = dialog.querySelector("[autofocus]") || corps.querySelector("input:not([type=hidden]):not([disabled]), select, textarea") || corps.querySelector("button") || fermerBtn;
  cible?.focus({ preventScroll: true });
  return { promesse, fermer: ctx.fermer, dialog, ctx };
}

/** Confirmation. Retourne true si l'utilisateur confirme. */
export function confirmer({ titre, message, libelleConfirmer = "Confirmer", libelleAnnuler = "Annuler", danger = false, detail = null }) {
  return new Promise((resolve) => {
    const d = ouvrirDialogue({
      titre, taille: "petit", classe: "dialogue--confirmation",
      contenu: (ctx) => {
        const ok = h("button.btn", { type: "button", class: danger ? "btn--danger" : "btn--primaire", onclick: () => ctx.fermer(true) }, libelleConfirmer);
        const non = h("button.btn", { type: "button", onclick: () => ctx.fermer(false) }, libelleAnnuler);
        ctx.definirPied(non, ok);
        // Pour une action destructrice, le focus va sur « Annuler ».
        setTimeout(() => (danger ? non : ok).focus({ preventScroll: true }), 0);
        return h("div", h("p", message), detail);
      },
    });
    d.promesse.then((v) => resolve(v === true));
  });
}

/** Message d'information avec un seul bouton. */
export function informer({ titre, message, detail = null, libelle = "Fermer" }) {
  return ouvrirDialogue({
    titre, taille: "petit",
    contenu: (ctx) => {
      ctx.definirPied(h("button.btn.btn--primaire", { type: "button", onclick: () => ctx.fermer(true) }, libelle));
      return h("div", h("p", message), detail);
    },
  }).promesse;
}
