// =============================================================================
// « Courriels échangés » : les derniers courriels échangés dans Gmail avec la personne d'une fiche.
//
// Rien n'est copié dans le CRM : la liste (objet, date, court extrait) se lit en direct chez Google, avec le compte
// Gmail de la personne qui consulte la fiche. Les autres membres de l'équipe ne voient donc pas ses courriels.
// Le panneau se place dans les blocs d'une fiche : `creer: creerBlocEchanges("contacts")`.
// =============================================================================
import { h } from "../noyau/dom.js";
import { icone } from "../noyau/icones.js";
import { abonner, maintenant } from "../noyau/etat.js";
import { ErreurApi } from "../noyau/api.js";
import { naviguer } from "../noyau/routeur.js";
import { peutEnvoyerGmail, peutVoirEchanges, lireEchanges, compteGoogle, aReconnecter, fonctionsAttendues, signalerErreurGoogle, adressesDeFiche } from "../noyau/google.js";
import { ilYa, pluriel, tronquer } from "../commun/format.js";
import { nomEtAdresse, objetReponse } from "../commun/adresses.js";
import { btn, panneau, chargement, avis, pastille } from "./composants.js";
import { ouvrirCourriel, destinatairesDeFiche, variablesCourriel } from "./courriel.js";

const fmtComplet = new Intl.DateTimeFormat("fr-CA", { timeZone: "America/Toronto", dateStyle: "long", timeStyle: "short" });

/** Après un envoi, Gmail met un instant à indexer le nouveau message : on attend un peu avant de relire la liste. */
const DELAI_APRES_ENVOI_MS = 2500;
/** Une liste lue il y a moins d'une minute se réaffiche telle quelle (l'écran de la fiche se redessine souvent) ; « Actualiser » relit toujours. */
const VALIDITE_MS = 60_000;
const memoire = new Map(); // « entité:id » → { t, donnees }
// Un courriel vient de partir, ou la connexion à Google a changé : les listes déjà lues sont périmées, même si le panneau n'est plus à l'écran.
abonner((changes) => {
  if (changes.has("gmail") || changes.has("google")) memoire.clear();
});

/** Ce qui détermine les adresses lues : si cette signature change, la liste est relue (même règle que sur le serveur). */
const signatureAdresses = (entite, f) => adressesDeFiche(entite, f).join(",");

/** « "Pierre Tremblay" <pierre@x.com> » → « Pierre Tremblay » (ou l'adresse s'il n'y a pas de nom). */
const nomAffiche = (entete) => {
  const { nom, adresse } = nomEtAdresse(entete);
  return nom || adresse;
};

function ligneEchange(e, { repondre }) {
  const ms = Date.parse(e.date);
  const sortant = e.sens === "sortant";
  const qui = sortant ? `à ${tronquer(e.a.split(",").map(nomAffiche).filter(Boolean).slice(0, 2).join(", "), 70)}` : `de ${tronquer(nomAffiche(e.de), 60)}`;
  const gmail = h("a.btn.btn--discret.btn--petit", { href: e.lien, target: "_blank", rel: "noopener noreferrer" }, icone("externe"), h("span", "Ouvrir dans Gmail"));
  const actions = [];
  if (!sortant && !e.brouillon && repondre) actions.push(btn("Répondre", { petit: true, ton: "discret", icone: "annuler", onclick: () => repondre(e) }));
  actions.push(gmail);
  return h(
    "li.act.act--court.act--echange",
    { "data-echange": e.id },
    h("span.act__icone", { "aria-hidden": "true" }, icone(sortant ? "envoyer" : "courriel", "ic--p")),
    h(
      "div.act__corps",
      h("p.act__titre", h("strong", e.objet), e.brouillon ? " " : null, e.brouillon ? pastille("Brouillon", "neutre") : null),
      e.extrait ? h("div.act__texte", e.extrait) : null,
      h(
        "p.act__meta",
        h("time", { datetime: e.date || "", title: Number.isFinite(ms) ? fmtComplet.format(ms) : "" }, Number.isFinite(ms) ? ilYa(ms, maintenant()) : ""),
        h("span.act__sep", { "aria-hidden": "true" }, "·"),
        h("span", sortant ? "Envoyé" : "Reçu"),
        h("span.act__sep", { "aria-hidden": "true" }, "·"),
        h("span.echange__qui", qui)
      )
    ),
    h("div.act__actions.echange__actions", actions)
  );
}

/**
 * creerBlocEchanges(entite, { contexte, masquer }) → (f) => { noeud, miseAJour(changes, f), vide(), detruire() }
 *   contexte(f) → { lier, variables } : de quoi consigner une réponse et remplir un gabarit (par défaut : déduit de la fiche)
 *   masquer(f)  → vrai quand la fiche n'a rien à montrer (par exemple un contact anonymisé)
 * Le bloc reste vide (et caché) tant que la personne n'a pas connecté son compte Google ou si la fonction est désactivée.
 */
export function creerBlocEchanges(entite, { contexte = null, masquer = null } = {}) {
  return (f0) => {
    let f = f0;
    const racine = h("div.echanges");
    let phase = "chargement"; // chargement | ok | erreur
    let donnees = null;
    let erreur = null;
    let controleur = null;
    let sequence = 0;
    let minuterie = null;
    let signature = signatureAdresses(entite, f);
    let monte = false;
    let detruit = false;
    let vuAttache = false; // le panneau a déjà été placé dans la page : s'il en sort sans avoir été détruit, il se débranche seul
    const cle = () => `${entite}:${f.id}`;

    const peutRepondre = () => peutEnvoyerGmail();
    /**
     * Le panneau n'existe que si la lecture des courriels est permise et si la fiche a quelque chose à montrer.
     * Quand la connexion à Google doit être renouvelée, il reste là pour le dire et proposer de la renouveler.
     */
    const actif = () => (peutVoirEchanges() || (aReconnecter() && fonctionsAttendues().gmail_echanges)) && !masquer?.(f);
    /** Ce qui, dans l'état de Google, change le contenu du panneau. */
    const etatConnexion = () => (peutVoirEchanges() ? "ok" : aReconnecter() ? "a-reconnecter" : "non");
    let connexion = etatConnexion();
    function surRepondre(e) {
      const c = contexte?.(f) || null;
      const d = c ? null : destinatairesDeFiche(entite, f);
      ouvrirCourriel({
        titre: "Répondre",
        destinataire: nomEtAdresse(e.de).adresse || donnees?.adresses?.[0] || "",
        objet: objetReponse(e.objet),
        repondreA: { messageId: e.id },
        lier: c?.lier || d?.lier || { lieType: entite, lieId: f.id },
        variables: c?.variables || (d ? variablesCourriel({ contact: d.contact, entreprise: d.entreprise, dossier: d.dossier }) : variablesCourriel({})),
      });
    }

    function corps() {
      if (phase === "chargement" && !donnees) return chargement("Lecture de votre boîte Gmail…");
      if (phase === "erreur") {
        const reconnecter = ["google_a_reconnecter", "google_non_connecte", "google_portee"].includes(erreur?.code);
        const actions = reconnecter
          ? btn("Reconnecter mon compte Google", { petit: true, onclick: () => naviguer("/parametres/google") })
          : btn("Réessayer", { petit: true, icone: "rafraichir", onclick: () => charger({ frais: true }) });
        return avis({
          ton: reconnecter ? "attention" : "erreur", titre: reconnecter ? "Votre connexion à Google doit être renouvelée" : "Impossible de lire vos courriels",
          texte: erreur?.message || "Une erreur est survenue.", actions,
        });
      }
      if (donnees?.aucune_adresse) {
        return h("p.liste-vide", "Cette fiche n’a pas d’adresse courriel : ajoutez-en une à la personne concernée pour voir vos échanges avec elle.");
      }
      const liste = donnees?.echanges || [];
      if (!liste.length) {
        return h("p.liste-vide", `Aucun courriel échangé dans votre compte Gmail avec ${(donnees?.adresses || []).join(", ") || "cette personne"}.`);
      }
      return h("ul.journal", liste.map((e) => ligneEchange(e, { repondre: peutRepondre() ? surRepondre : null })));
    }

    function dessiner() {
      if (detruit) return;
      if (!actif()) {
        racine.replaceChildren();
        monte = false;
        return;
      }
      monte = true;
      const adresses = donnees?.adresses || [];
      const sous = `Vos courriels Gmail${compteGoogle() ? ` (${compteGoogle()})` : ""} avec ${adresses.length ? adresses.join(", ") : "les adresses de cette fiche"}. Lecture seule : rien n’est copié dans le CRM.`;
      const actualiser = btn("Actualiser", { petit: true, ton: "discret", icone: "rafraichir", desactive: phase === "chargement", aria: "Actualiser la liste des courriels échangés", onclick: () => charger({ frais: true }) });
      const compte = phase === "ok" && donnees?.echanges?.length ? pluriel(donnees.echanges.length, "courriel") : null;
      racine.replaceChildren(
        panneau({ titre: "Courriels échangés", sous, actions: actualiser, classe: "panneau--echanges", compteur: compte }, corps())
      );
    }

    async function charger({ frais = false } = {}) {
      if (detruit || !actif()) return;
      controleur?.abort();
      controleur = new AbortController();
      const mien = ++sequence;
      if (aReconnecter()) {
        // Inutile d'interroger le serveur : il répondrait la même chose.
        donnees = null;
        erreur = new ErreurApi("La connexion à Google n’est plus valide. Reconnectez votre compte dans Paramètres → Google.", { code: "google_a_reconnecter", statut: 409 });
        phase = "erreur";
        dessiner();
        return;
      }
      const connue = memoire.get(cle());
      if (!frais && connue && Date.now() - connue.t < VALIDITE_MS) {
        donnees = connue.donnees;
        erreur = null;
        phase = "ok";
        dessiner();
        return;
      }
      phase = "chargement";
      dessiner();
      try {
        const d = await lireEchanges(entite, f.id, { signal: controleur.signal, frais });
        if (mien !== sequence || detruit) return;
        memoire.set(cle(), { t: Date.now(), donnees: d });
        if (memoire.size > 60) memoire.delete(memoire.keys().next().value);
        donnees = d;
        erreur = null;
        phase = "ok";
      } catch (e) {
        if (e?.name === "AbortError" || mien !== sequence || detruit) return;
        if (!(e instanceof ErreurApi)) console.error("[échanges]", e);
        erreur = e instanceof ErreurApi ? e : new ErreurApi("Une erreur est survenue. Réessayez.");
        phase = "erreur";
        signalerErreurGoogle(erreur);
      }
      dessiner();
    }

    // Après un envoi (ou une déconnexion), la liste se relit d'elle-même.
    const desabonner = abonner((changes) => {
      if (detruit) return;
      // Un panneau retiré de la page sans avoir été détruit (liste de demandes, par exemple) ne travaille plus pour rien.
      if (racine.isConnected) vuAttache = true;
      else if (vuAttache) {
        detruit = true;
        controleur?.abort();
        clearTimeout(minuterie);
        desabonner();
        return;
      }
      if (changes.has("gmail") && actif()) {
        clearTimeout(minuterie);
        minuterie = setTimeout(() => charger({ frais: true }), DELAI_APRES_ENVOI_MS);
      }
    });

    if (actif()) charger();
    else dessiner();

    return {
      noeud: racine,
      vide: () => !actif(),
      miseAJour(changes, nouvelle) {
        if (detruit) return;
        f = nouvelle || f;
        const peut = actif();
        const nouvelleConnexion = etatConnexion();
        const changee = nouvelleConnexion !== connexion;
        connexion = nouvelleConnexion;
        if (peut !== monte) {
          if (peut) charger();
          else {
            controleur?.abort();
            clearTimeout(minuterie);
            dessiner();
          }
          return;
        }
        if (!peut) return;
        // La connexion a été renouvelée (ou perdue) sans que la fiche change : on relit.
        if (changee) {
          charger({ frais: true });
          return;
        }
        const sig = signatureAdresses(entite, f);
        if (sig !== signature) {
          signature = sig;
          charger();
        }
      },
      detruire() {
        detruit = true;
        controleur?.abort();
        clearTimeout(minuterie);
        desabonner();
      },
    };
  };
}
