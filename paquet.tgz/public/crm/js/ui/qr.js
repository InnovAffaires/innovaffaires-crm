// =============================================================================
// Générateur de code QR (mode octets), sans dépendance. Sert à afficher le code
// de l'application d'authentification (double vérification) : rien n'est envoyé
// à un service externe. Algorithme décrit par la norme ISO/IEC 18004.
// =============================================================================

const ECC_PAR_BLOC = {
  L: [-1, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28, 28, 28, 30, 30, 26, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
  M: [-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26, 26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28],
  Q: [-1, 13, 22, 18, 26, 18, 24, 18, 22, 20, 24, 28, 26, 24, 20, 30, 24, 28, 28, 26, 30, 28, 30, 30, 30, 30, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
  H: [-1, 17, 28, 22, 16, 22, 28, 26, 26, 24, 28, 24, 28, 22, 24, 24, 30, 28, 28, 26, 28, 30, 24, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
};
const BLOCS = {
  L: [-1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 6, 7, 8, 8, 9, 9, 10, 12, 12, 12, 13, 14, 15, 16, 17, 18, 19, 19, 20, 21, 22, 24, 25],
  M: [-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16, 17, 17, 18, 20, 21, 23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49],
  Q: [-1, 1, 1, 2, 2, 4, 4, 6, 6, 8, 8, 8, 10, 12, 16, 12, 17, 16, 18, 21, 20, 23, 23, 25, 27, 29, 34, 34, 35, 38, 40, 43, 45, 48, 51, 53, 56, 59, 62, 65, 68],
  H: [-1, 1, 1, 2, 4, 4, 4, 5, 6, 8, 8, 11, 11, 16, 16, 18, 16, 19, 21, 25, 25, 25, 34, 30, 32, 35, 37, 40, 42, 45, 48, 51, 54, 57, 60, 63, 66, 70, 74, 77, 81],
};
const BITS_FORMAT = { L: 1, M: 0, Q: 3, H: 2 };

const bit = (x, i) => ((x >>> i) & 1) !== 0;

function modulesDonnees(ver) {
  let r = (16 * ver + 128) * ver + 64;
  if (ver >= 2) {
    const n = Math.floor(ver / 7) + 2;
    r -= (25 * n - 10) * n - 55;
    if (ver >= 7) r -= 36;
  }
  return r;
}
const motsDonnees = (ver, ecc) => Math.floor(modulesDonnees(ver) / 8) - ECC_PAR_BLOC[ecc][ver] * BLOCS[ecc][ver];

function multiplierGF(x, y) {
  let z = 0;
  for (let i = 7; i >= 0; i--) {
    z = (z << 1) ^ ((z >>> 7) * 0x11d);
    z ^= ((y >>> i) & 1) * x;
  }
  return z;
}
function diviseurRS(degre) {
  const r = new Array(degre).fill(0);
  r[degre - 1] = 1;
  let racine = 1;
  for (let i = 0; i < degre; i++) {
    for (let j = 0; j < r.length; j++) {
      r[j] = multiplierGF(r[j], racine);
      if (j + 1 < r.length) r[j] ^= r[j + 1];
    }
    racine = multiplierGF(racine, 0x02);
  }
  return r;
}
function resteRS(donnees, diviseur) {
  const r = diviseur.map(() => 0);
  for (const b of donnees) {
    const facteur = b ^ r.shift();
    r.push(0);
    diviseur.forEach((coef, i) => (r[i] ^= multiplierGF(coef, facteur)));
  }
  return r;
}

/** Retourne { taille, modules[y][x] (booléens), version, masque }. */
export function creerQr(texte, { ecc = "M", versionMin = 1 } = {}) {
  const octets = Array.from(new TextEncoder().encode(String(texte)));
  // Choix de la plus petite version qui contient les données.
  let ver = versionMin;
  let bitsDonnees = 0;
  for (; ver <= 40; ver++) {
    const bitsCompte = ver < 10 ? 8 : 16;
    bitsDonnees = 4 + bitsCompte + octets.length * 8;
    if (octets.length >= 1 << bitsCompte) continue;
    if (bitsDonnees <= motsDonnees(ver, ecc) * 8) break;
  }
  if (ver > 40) throw new Error("Texte trop long pour un code QR.");

  const bits = [];
  const ajouter = (val, n) => {
    for (let i = n - 1; i >= 0; i--) bits.push((val >>> i) & 1);
  };
  ajouter(0b0100, 4);
  ajouter(octets.length, ver < 10 ? 8 : 16);
  for (const o of octets) ajouter(o, 8);
  const capaciteBits = motsDonnees(ver, ecc) * 8;
  ajouter(0, Math.min(4, capaciteBits - bits.length));
  ajouter(0, (8 - (bits.length % 8)) % 8);
  for (let pad = 0xec; bits.length < capaciteBits; pad ^= 0xec ^ 0x11) ajouter(pad, 8);
  const mots = [];
  for (let i = 0; i < bits.length; i += 8) {
    let v = 0;
    for (let j = 0; j < 8; j++) v = (v << 1) | bits[i + j];
    mots.push(v);
  }

  // Blocs + correction d'erreurs, entrelacés.
  const nbBlocs = BLOCS[ecc][ver];
  const eccLen = ECC_PAR_BLOC[ecc][ver];
  const brut = Math.floor(modulesDonnees(ver) / 8);
  const blocsCourts = nbBlocs - (brut % nbBlocs);
  const longueurCourt = Math.floor(brut / nbBlocs);
  const blocs = [];
  const div = diviseurRS(eccLen);
  for (let i = 0, k = 0; i < nbBlocs; i++) {
    const dat = mots.slice(k, k + longueurCourt - eccLen + (i < blocsCourts ? 0 : 1));
    k += dat.length;
    const e = resteRS(dat, div);
    if (i < blocsCourts) dat.push(0);
    blocs.push(dat.concat(e));
  }
  const final = [];
  for (let i = 0; i < blocs[0].length; i++) {
    blocs.forEach((b, j) => {
      if (i !== longueurCourt - eccLen || j >= blocsCourts) final.push(b[i]);
    });
  }

  // Matrice
  const taille = ver * 4 + 17;
  const modules = Array.from({ length: taille }, () => new Array(taille).fill(false));
  const fonction = Array.from({ length: taille }, () => new Array(taille).fill(false));
  const poser = (x, y, sombre) => {
    modules[y][x] = sombre;
    fonction[y][x] = true;
  };

  for (let i = 0; i < taille; i++) {
    poser(6, i, i % 2 === 0);
    poser(i, 6, i % 2 === 0);
  }
  const reperage = (cx, cy) => {
    for (let dy = -4; dy <= 4; dy++) {
      for (let dx = -4; dx <= 4; dx++) {
        const dist = Math.max(Math.abs(dx), Math.abs(dy));
        const xx = cx + dx;
        const yy = cy + dy;
        if (xx >= 0 && xx < taille && yy >= 0 && yy < taille) poser(xx, yy, dist !== 2 && dist !== 4);
      }
    }
  };
  reperage(3, 3);
  reperage(taille - 4, 3);
  reperage(3, taille - 4);
  const alignement = (cx, cy) => {
    for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) poser(cx + dx, cy + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
  };
  const positions = [];
  if (ver > 1) {
    const n = Math.floor(ver / 7) + 2;
    const pas = ver === 32 ? 26 : Math.ceil((ver * 4 + 4) / (n * 2 - 2)) * 2;
    positions.push(6);
    for (let pos = taille - 7; positions.length < n; pos -= pas) positions.splice(1, 0, pos);
  }
  positions.forEach((px, i) =>
    positions.forEach((py, j) => {
      if (!((i === 0 && j === 0) || (i === 0 && j === positions.length - 1) || (i === positions.length - 1 && j === 0))) alignement(px, py);
    })
  );

  const formats = (masque) => {
    const data = (BITS_FORMAT[ecc] << 3) | masque;
    let rem = data;
    for (let i = 0; i < 10; i++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
    const b = ((data << 10) | rem) ^ 0x5412;
    for (let i = 0; i <= 5; i++) poser(8, i, bit(b, i));
    poser(8, 7, bit(b, 6));
    poser(8, 8, bit(b, 7));
    poser(7, 8, bit(b, 8));
    for (let i = 9; i < 15; i++) poser(14 - i, 8, bit(b, i));
    for (let i = 0; i < 8; i++) poser(taille - 1 - i, 8, bit(b, i));
    for (let i = 8; i < 15; i++) poser(8, taille - 15 + i, bit(b, i));
    poser(8, taille - 8, true);
  };
  formats(0); // réserve la place
  if (ver >= 7) {
    let rem = ver;
    for (let i = 0; i < 12; i++) rem = (rem << 1) ^ ((rem >>> 11) * 0x1f25);
    const b = (ver << 12) | rem;
    for (let i = 0; i < 18; i++) {
      const a = taille - 11 + (i % 3);
      const c = Math.floor(i / 3);
      poser(a, c, bit(b, i));
      poser(c, a, bit(b, i));
    }
  }

  // Placement des mots en zigzag
  let k = 0;
  for (let droite = taille - 1; droite >= 1; droite -= 2) {
    if (droite === 6) droite = 5;
    for (let vert = 0; vert < taille; vert++) {
      for (let j = 0; j < 2; j++) {
        const x = droite - j;
        const montant = ((droite + 1) & 2) === 0;
        const y = montant ? taille - 1 - vert : vert;
        if (!fonction[y][x] && k < final.length * 8) {
          modules[y][x] = bit(final[k >>> 3], 7 - (k & 7));
          k++;
        }
      }
    }
  }

  const masquer = (m) => {
    for (let y = 0; y < taille; y++) {
      for (let x = 0; x < taille; x++) {
        let inv;
        switch (m) {
          case 0: inv = (x + y) % 2 === 0; break;
          case 1: inv = y % 2 === 0; break;
          case 2: inv = x % 3 === 0; break;
          case 3: inv = (x + y) % 3 === 0; break;
          case 4: inv = (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0; break;
          case 5: inv = ((x * y) % 2) + ((x * y) % 3) === 0; break;
          case 6: inv = (((x * y) % 2) + ((x * y) % 3)) % 2 === 0; break;
          default: inv = (((x + y) % 2) + ((x * y) % 3)) % 2 === 0;
        }
        if (!fonction[y][x] && inv) modules[y][x] = !modules[y][x];
      }
    }
  };

  const penalite = () => {
    let total = 0;
    const ajouterHistorique = (longueur, hist) => {
      if (hist[0] === 0) longueur += taille;
      hist.pop();
      hist.unshift(longueur);
    };
    const compterMotifs = (hist) => {
      const n = hist[1];
      const coeur = n > 0 && hist[2] === n && hist[3] === n * 3 && hist[4] === n && hist[5] === n;
      return (coeur && hist[0] >= n * 4 && hist[6] >= n ? 1 : 0) + (coeur && hist[6] >= n * 4 && hist[0] >= n ? 1 : 0);
    };
    const terminer = (couleur, longueur, hist) => {
      if (couleur) {
        ajouterHistorique(longueur, hist);
        longueur = 0;
      }
      longueur += taille;
      ajouterHistorique(longueur, hist);
      return compterMotifs(hist);
    };
    for (let a = 0; a < taille; a++) {
      for (const sens of [0, 1]) {
        let couleur = false;
        let run = 0;
        const hist = [0, 0, 0, 0, 0, 0, 0];
        for (let b = 0; b < taille; b++) {
          const v = sens === 0 ? modules[a][b] : modules[b][a];
          if (v === couleur) {
            run++;
            if (run === 5) total += 3;
            else if (run > 5) total++;
          } else {
            ajouterHistorique(run, hist);
            if (!couleur) total += compterMotifs(hist) * 40;
            couleur = v;
            run = 1;
          }
        }
        total += terminer(couleur, run, hist) * 40;
      }
    }
    for (let y = 0; y < taille - 1; y++) {
      for (let x = 0; x < taille - 1; x++) {
        const c = modules[y][x];
        if (c === modules[y][x + 1] && c === modules[y + 1][x] && c === modules[y + 1][x + 1]) total += 3;
      }
    }
    let sombres = 0;
    for (const ligne of modules) for (const c of ligne) if (c) sombres++;
    const tot = taille * taille;
    total += (Math.ceil(Math.abs(sombres * 20 - tot * 10) / tot) - 1) * 10;
    return total;
  };

  let meilleur = 0;
  let minPen = Infinity;
  for (let m = 0; m < 8; m++) {
    masquer(m);
    formats(m);
    const p = penalite();
    if (p < minPen) {
      minPen = p;
      meilleur = m;
    }
    masquer(m); // annule
  }
  masquer(meilleur);
  formats(meilleur);
  return { taille, modules, version: ver, masque: meilleur };
}

/** Élément <svg> du code QR (noir sur blanc, zone de silence incluse). */
export function qrSvg(texte, { pixels = 220, ecc = "M", titre = "Code QR" } = {}) {
  const { taille, modules } = creerQr(texte, { ecc });
  const marge = 4;
  const NS = "http://www.w3.org/2000/svg";
  const total = taille + marge * 2;
  const svg = document.createElementNS(NS, "svg");
  svg.setAttribute("viewBox", `0 0 ${total} ${total}`);
  svg.setAttribute("width", String(pixels));
  svg.setAttribute("height", String(pixels));
  svg.setAttribute("role", "img");
  svg.setAttribute("aria-label", titre);
  svg.setAttribute("class", "qr");
  svg.setAttribute("shape-rendering", "crispEdges");
  const fond = document.createElementNS(NS, "rect");
  fond.setAttribute("width", String(total));
  fond.setAttribute("height", String(total));
  fond.setAttribute("fill", "#ffffff");
  const chemin = document.createElementNS(NS, "path");
  let d = "";
  for (let y = 0; y < taille; y++) {
    let x = 0;
    while (x < taille) {
      if (!modules[y][x]) {
        x++;
        continue;
      }
      let fin = x;
      while (fin < taille && modules[y][fin]) fin++;
      d += `M${x + marge} ${y + marge}h${fin - x}v1h${x - fin}z`;
      x = fin;
    }
  }
  chemin.setAttribute("d", d);
  chemin.setAttribute("fill", "#000000");
  svg.append(fond, chemin);
  return svg;
}
