// =============================================================================
// Recherche rapide (Ctrl+K ou /) : trouve une fiche, une page ou une action.
// La recherche se fait dans les données déjà chargées : instantanée, sans réseau.
// =============================================================================
import { h, idUnique } from "../noyau/dom.js";
import { icone } from "../noyau/icones.js";
import { normaliser } from "../commun/format.js";
import { ENTITES } from "../commun/schema.js";
import { actives, libelleFiche, nomFiche, texteRecherche } from "../noyau/etat.js";
import { naviguer, cheminFiche } from "../noyau/routeur.js";

const ORDRE = ["demandes", "contacts", "entreprises", "opportunites", "dossiers", "factures", "taches", "evenements"];
const MAX_PAR_GROUPE = 5;

function sousTitre(entite, f) {
  switch (entite) {
    case "contacts":
      return [f.titre, nomFiche("entreprises", f.entreprise_id), f.courriel].filter(Boolean).join(" · ");
    case "entreprises":
      return [f.ville, f.secteur ? "" : ""].filter(Boolean).join(" · ");
    case "opportunites":
    case "dossiers":
      return nomFiche("entreprises", f.entreprise_id);
    case "factures":
      return [nomFiche("entreprises", f.entreprise_id), f.objet].filter(Boolean).join(" · ");
    case "demandes":
      return f.courriel;
    case "taches":
      return f.echeance ? `Échéance ${f.echeance}` : "";
    default:
      return "";
  }
}

function chercher(texte) {
  const jetons = normaliser(texte).split(/\s+/).filter(Boolean);
  if (!jetons.length) return [];
  const groupes = [];
  for (const entite of ORDRE) {
    const trouves = [];
    for (const f of actives(entite)) {
      if (entite === "contacts" && f.anonymise) continue;
      const t = texteRecherche(entite, f);
      if (!jetons.every((j) => t.includes(j))) continue;
      const lib = normaliser(libelleFiche(entite, f));
      const score = lib.startsWith(jetons[0]) ? 0 : lib.includes(jetons[0]) ? 1 : 2;
      trouves.push({ f, score, lib });
    }
    trouves.sort((a, b) => a.score - b.score || a.lib.localeCompare(b.lib, "fr-CA"));
    if (trouves.length) groupes.push({ entite, total: trouves.length, items: trouves.slice(0, MAX_PAR_GROUPE).map((x) => x.f) });
  }
  return groupes;
}

/** ouvrirRecherche({ pages: [{libelle, icone, chemin}], actions: [{libelle, icone, executer}] }) */
export function ouvrirRecherche({ pages = [], actions = [] }) {
  const precedent = document.activeElement instanceof HTMLElement ? document.activeElement : null;
  const idListe = idUnique("pal");
  const entree = h("input.palette__entree", {
    type: "text", role: "combobox", autocomplete: "off", spellcheck: "false", placeholder: "Rechercher un contact, un dossier, une facture, une page…",
    "aria-expanded": "true", "aria-controls": idListe, "aria-autocomplete": "list", "aria-label": "Recherche rapide",
  });
  const liste = h("ul.palette__liste", { id: idListe, role: "listbox", "aria-label": "Résultats" });
  const aide = h("p.palette__aide", h("kbd", "↑"), h("kbd", "↓"), " pour choisir, ", h("kbd", "Entrée"), " pour ouvrir, ", h("kbd", "Échap"), " pour fermer.");
  const dialog = h("dialog.palette", { "aria-label": "Recherche rapide" }, h("div.palette__champ", icone("recherche"), entree), liste, aide);
  let elements = [];
  let actif = 0;

  const fermer = () => {
    dialog.close();
  };
  dialog.addEventListener("close", () => {
    dialog.remove();
    document.documentElement.classList.remove("dialogue-ouvert");
    if (precedent && document.contains(precedent)) precedent.focus({ preventScroll: true });
  });
  dialog.addEventListener("mousedown", (e) => {
    if (e.target === dialog) fermer();
  });

  function ligne(it, i) {
    return h(
      "li.palette__option",
      { id: `${idListe}-${i}`, role: "option", "aria-selected": "false", onmousemove: () => { if (actif !== i) { actif = i; surligner(false); } }, onclick: () => choisir(it) },
      icone(it.icone || "droite"),
      h("span.palette__texte", h("span.palette__libelle", it.libelle), it.sous ? h("span.palette__sous", it.sous) : null),
      it.indice ? h("span.palette__indice", it.indice) : null
    );
  }

  function dessiner() {
    const q = entree.value.trim();
    liste.replaceChildren();
    elements = [];
    const ajouterGroupe = (titre, items) => {
      if (!items.length) return;
      liste.append(h("li.palette__groupe", { role: "presentation" }, titre));
      for (const it of items) {
        const li = ligne(it, elements.length);
        elements.push({ ...it, noeud: li });
        liste.append(li);
      }
    };
    const t = normaliser(q);
    const pagesFiltrees = pages.filter((p) => !t || normaliser(p.libelle).includes(t)).map((p) => ({ libelle: p.libelle, icone: p.icone, indice: "Page", executer: () => naviguer(p.chemin) }));
    const actionsFiltrees = actions.filter((a) => !t || normaliser(a.libelle).includes(t)).map((a) => ({ libelle: a.libelle, icone: a.icone || "plus", indice: "Action", executer: a.executer }));
    if (!q) {
      ajouterGroupe("Actions", actionsFiltrees.slice(0, 5));
      ajouterGroupe("Aller à", pagesFiltrees.slice(0, 6));
    } else {
      for (const g of chercher(q)) {
        ajouterGroupe(
          g.total > g.items.length ? `${ENTITES[g.entite].libellePluriel} (${g.total})` : ENTITES[g.entite].libellePluriel,
          g.items.map((f) => ({ libelle: libelleFiche(g.entite, f), sous: sousTitre(g.entite, f), icone: ENTITES[g.entite].icone === "kanban" ? "affaires" : { user: "contacts", building: "entreprises", folder: "dossiers", "check-square": "taches", calendar: "calendrier", receipt: "factures", inbox: "demandes" }[ENTITES[g.entite].icone] || "droite", executer: () => naviguer(cheminFiche(g.entite, f.id)) }))
        );
      }
      ajouterGroupe("Pages", pagesFiltrees.slice(0, 4));
      ajouterGroupe("Actions", actionsFiltrees.slice(0, 4));
    }
    if (!elements.length) liste.append(h("li.palette__vide", { role: "presentation" }, q ? `Aucun résultat pour « ${q} ».` : "Commencez à écrire pour chercher."));
    actif = 0;
    surligner(true);
  }

  function surligner(defiler) {
    elements.forEach((e, i) => {
      const sel = i === actif;
      e.noeud.setAttribute("aria-selected", String(sel));
      e.noeud.classList.toggle("palette__option--actif", sel);
      if (sel) {
        entree.setAttribute("aria-activedescendant", e.noeud.id);
        if (defiler) e.noeud.scrollIntoView({ block: "nearest" });
      }
    });
    if (!elements.length) entree.removeAttribute("aria-activedescendant");
  }

  function choisir(it) {
    fermer();
    setTimeout(() => it.executer?.(), 0);
  }

  entree.addEventListener("input", dessiner);
  entree.addEventListener("keydown", (e) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      if (elements.length) actif = (actif + 1) % elements.length;
      surligner(true);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      if (elements.length) actif = (actif - 1 + elements.length) % elements.length;
      surligner(true);
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (elements[actif]) choisir(elements[actif]);
    }
  });
  document.body.append(dialog);
  document.documentElement.classList.add("dialogue-ouvert");
  dialog.showModal();
  dessiner();
  entree.focus();
}
