// =============================================================================
// La frise : un chemin d'étapes (ou de statuts). L'étape courante est en relief,
// celles déjà franchies en teinte légère, les suivantes en contour ; l'issue
// défavorable (affaire perdue, dossier refusé) reste à l'écart derrière un filet.
// Chaque étape est un bouton quand la personne peut écrire.
// =============================================================================
import { h } from "../noyau/dom.js";

/**
 * frise({ etapes, courant, ecrire, surChoix, libelleChemin, libelleIssues, titreBouton })
 *   etapes  : [{ id, nom, ton }] dans l'ordre ; ton : "ouverte" | "gagnee" | "perdue" (« perdue » se met à l'écart)
 *   courant : identifiant de l'étape courante
 *   surChoix(etape) : appelé au clic sur une autre étape
 */
export function frise({ etapes, courant, ecrire = false, surChoix = null, libelleChemin = "Étapes", libelleIssues = "Issue défavorable", titreBouton = (e) => `Choisir « ${e.nom} »` }) {
  const rang = etapes.findIndex((e) => e.id === courant);
  const defavorable = etapes[rang]?.ton === "perdue";
  const pastille = (e, i) => {
    const statut = i === rang ? "courante" : !defavorable && e.ton !== "perdue" && i < rang ? "franchie" : "future";
    const classes = ["etape-frise", `etape-frise--${statut}`, `etape-frise--${e.ton}`];
    if (i === rang || !ecrire) return h("li", h("span", { class: classes, "aria-current": i === rang ? "step" : null }, e.nom));
    return h("li", h("button", { type: "button", class: classes, title: titreBouton(e), onclick: () => surChoix?.(e) }, e.nom));
  };
  const indexees = etapes.map((e, i) => [e, i]);
  const chemin = indexees.filter(([e]) => e.ton !== "perdue");
  const issues = indexees.filter(([e]) => e.ton === "perdue");
  // Sur un grand écran, le chemin tient sur une ou deux rangées : 6 étapes → 6 colonnes, 9 étapes → 5 colonnes.
  const grandesColonnes = chemin.length <= 6 ? chemin.length : Math.ceil(chemin.length / 2);
  return h(
    "div.frise",
    { css: { "--colonnes-larges": String(Math.max(3, grandesColonnes)) } },
    h(
      "div.frise__corps",
      h("ol.frise__chemin", { "aria-label": libelleChemin }, chemin.map(([e, i]) => pastille(e, i))),
      issues.length ? h("ol.frise__issues", { "aria-label": libelleIssues }, issues.map(([e, i]) => pastille(e, i))) : null
    )
  );
}
