// =============================================================================
// Rédiger un courriel à partir d'un gabarit.
//
//   • Compte Google connecté (Paramètres → Google) : « Envoyer avec Gmail ». Le message part du compte Gmail de la
//     personne, se retrouve dans ses « Envoyés » et s'inscrit dans l'historique de la fiche.
//   • Sinon, ou en solution de rechange : le message s'ouvre dans le logiciel de courriel de la personne (ou se copie),
//     et l'envoi peut être consigné dans l'historique de la fiche. Le CRM n'envoie alors rien lui-même.
//
// Champs de fusion des gabarits (Paramètres → Gabarits de courriel) :
//   {{prenom}} {{nom}} {{entreprise}} {{programme}} {{date_limite}} {{delai}}
//   {{montant}} {{numero}} {{echeance}} {{signature}}
// Un champ dont la valeur est inconnue devient « [à compléter] » dans le message,
// pour qu'on le voie avant d'envoyer.
// =============================================================================
import { h, idUnique, copierTexte } from "../noyau/dom.js";
import { icone } from "../noyau/icones.js";
import { etat, notifier, liees, fiche, mettreAJourFiche } from "../noyau/etat.js";
import { envoyer, ErreurApi } from "../noyau/api.js";
import { tenter } from "../noyau/ecriture.js";
import { naviguer } from "../noyau/routeur.js";
import { peutEnvoyerGmail, compteGoogle, envoyerGmail, nouvelleCleEnvoi, lienGmailEnvoyes, signalerErreurGoogle } from "../noyau/google.js";
import { argent, dateComplete, nomComplet, normaliser } from "../commun/format.js";
import { calculerTotaux } from "../commun/calculs.js";
import { validerValeur } from "../commun/valider.js";
import { separerAdresses, MAX_DESTINATAIRES } from "../commun/adresses.js";
import { btn, avis } from "./composants.js";
import { creerChamp } from "./formulaire.js";
import { ouvrirDialogue } from "./dialogue.js";
import { toast } from "./toast.js";

/** Ce qu'on écrit à la place d'un champ de fusion dont on ne connaît pas la valeur. */
const A_COMPLETER = {
  prenom: "", nom: "", signature: "", entreprise: "[entreprise]", programme: "[programme]", date_limite: "[date limite]",
  delai: "[délai]", montant: "[montant]", numero: "[numéro]", echeance: "[échéance]",
};

/** Passages laissés entre crochets par un gabarit quand une information manque, ou à remplir à la main. */
const PASSAGES_A_COMPLETER = [...new Set([...Object.values(A_COMPLETER).filter(Boolean), "[date et heure]", "[à compléter]"])];
const passagesRestants = (...textes) => PASSAGES_A_COMPLETER.filter((p) => textes.some((t) => t.toLowerCase().includes(p)));

/** Remplace les champs {{…}} d'un gabarit par leurs valeurs. */
export function remplirGabarit(modele, variables = {}) {
  return String(modele ?? "")
    .replace(/\{\{\s*(\w+)\s*\}\}/g, (_, nom) => {
      const v = variables[nom];
      if (v !== undefined && v !== null && String(v).trim() !== "") return String(v);
      return Object.hasOwn(A_COMPLETER, nom) ? A_COMPLETER[nom] : "";
    })
    .replace(/Bonjour\s+,/g, "Bonjour,")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

/**
 * Les valeurs des champs de fusion pour un contact, une entreprise, un dossier ou une facture.
 * Ce qui manque est laissé vide (le champ apparaîtra entre crochets dans le message).
 */
export function variablesCourriel({ contact = null, entreprise = null, dossier = null, facture = null } = {}) {
  const c = etat.config || {};
  const v = {
    prenom: contact?.prenom || "",
    nom: contact ? nomComplet(contact) : "",
    entreprise: entreprise?.nom || "",
    programme: dossier?.programme || dossier?.titre || "",
    date_limite: dossier?.date_limite ? dateComplete(dossier.date_limite) : "",
    delai: `dans les ${c.delai_reponse_heures ?? 48} heures ouvrables`,
    signature: c.entreprise?.signature || "",
  };
  if (facture) {
    const t = facture.totaux || calculerTotaux(facture.lignes || [], facture.taux || c.taxes, facture.paiements || []);
    const ouverte = facture.type === "facture" && facture.statut !== "brouillon" && facture.statut !== "annulee" && t.solde > 0;
    v.numero = facture.numero || "";
    v.montant = argent(ouverte ? t.solde : t.total);
    v.echeance = facture.date_echeance ? dateComplete(facture.date_echeance) : "";
  }
  return v;
}

// ----- Destinataires proposés pour une fiche ------------------------------------------------------------------------------
/** Les personnes d'une entreprise qu'on peut joindre par courriel, par ordre alphabétique. */
export function contactsJoignables(entrepriseId) {
  if (!entrepriseId) return [];
  return liees("contacts", "entreprise_id", entrepriseId)
    .filter((c) => !c.supprime && !c.archive && !c.anonymise && c.courriel)
    .sort((a, b) => nomComplet(a).localeCompare(nomComplet(b), "fr", { sensitivity: "base" }));
}

/**
 * Qui écrire depuis une fiche ? Retourne { contact, entreprise, dossier, destinataire, suggestions, lier } ou null s'il n'y a personne à qui écrire.
 *   contacts       : la personne elle-même
 *   entreprises    : la première personne de l'entreprise, les autres sont proposées
 *   dossiers/affaires : le contact de la fiche, sinon la première personne de l'entreprise
 */
export function destinatairesDeFiche(entite, f) {
  if (!f || f.supprime) return null;
  const vivante = (x) => (x && !x.supprime && !x.anonymise ? x : null);
  const entreprise = f.entreprise_id ? vivante(fiche("entreprises", f.entreprise_id)) : entite === "entreprises" ? f : null;
  const equipe = contactsJoignables(entreprise?.id);
  let contact = null;
  if (entite === "contacts") contact = f.courriel ? f : null;
  else if (entite === "entreprises") contact = equipe[0] || null;
  else {
    const lie = f.contact_id ? vivante(fiche("contacts", f.contact_id)) : null;
    contact = lie?.courriel ? lie : equipe[0] || null;
  }
  if (!contact) return null;
  const autres = equipe.filter((c) => c.id !== contact.id).slice(0, 6);
  const lie2 = entite === "contacts" ? (entreprise ? { type: "entreprises", id: entreprise.id } : null) : entite === "entreprises" ? { type: "contacts", id: contact.id } : entreprise ? { type: "entreprises", id: entreprise.id } : null;
  return {
    contact, entreprise, dossier: entite === "dossiers" ? f : null, destinataire: contact.courriel,
    suggestions: autres.map((c) => ({ courriel: c.courriel, nom: nomComplet(c) || c.courriel })),
    lier: { lieType: entite, lieId: f.id, lie2 },
  };
}

/** Ouvre la fenêtre pour écrire depuis la fiche d'un contact, d'une entreprise, d'un dossier ou d'une affaire. */
export function ecrireDepuis(entite, f, options = {}) {
  const d = destinatairesDeFiche(entite, f);
  if (!d) {
    toast("Aucune adresse courriel à qui écrire : ajoutez-en une à un contact de cette fiche.", { ton: "info" });
    return Promise.resolve(false);
  }
  return ouvrirCourriel({
    destinataire: d.destinataire, suggestions: d.suggestions, lier: d.lier,
    variables: variablesCourriel({ contact: d.contact, entreprise: d.entreprise, dossier: d.dossier }),
    ...options,
  });
}

// ----- Ouverture dans la messagerie ---------------------------------------------------------------------------------------
/** Au-delà, certains logiciels de courriel coupent le message : on le copie et on n'ouvre que l'objet. */
const LONGUEUR_MAX_LIEN = 1900;

function ouvrirMessagerie(href) {
  const lien = h("a", { href, rel: "noopener", hidden: true });
  document.body.append(lien);
  lien.click();
  lien.remove();
}

/** Consigne le courriel dans l'historique de la fiche (type « courriel », envoyé). */
async function consigner({ lieType, lieId, lie2 = null }, sujet, texte) {
  const charge = {
    type: "courriel", direction: "sortant", titre: (sujet || "Courriel").slice(0, 200), texte: texte.slice(0, 8000), lie_type: lieType, lie_id: lieId,
  };
  if (lie2?.id) {
    charge.lie2_type = lie2.type;
    charge.lie2_id = lie2.id;
  }
  const r = await tenter(() => envoyer("/activites", charge));
  if (r) notifier("activites");
  return !!r;
}

// ----- Envoi avec Gmail -------------------------------------------------------------------------------------------------------
/** Réponses du serveur qui veulent dire « votre connexion à Google ne permet plus d'envoyer » : on propose d'aller la réparer. */
const CODES_CONNEXION = new Set(["google_a_reconnecter", "google_non_connecte", "google_non_configure", "google_portee", "google_fonction_desactivee", "google_preference", "google_api_desactivee"]);
const TITRES_ERREUR = { google_envoi_incertain: "Envoi non confirmé", google_envoi_en_cours: "Envoi déjà en cours", limite: "Limite d’envois atteinte" };

/** Une saisie d'adresses n'est pas du texte ordinaire : pas de majuscule automatique ni de correcteur. */
function regler(champ) {
  const saisie = champ?.noeud.querySelector("input");
  if (!saisie) return;
  saisie.setAttribute("inputmode", "email");
  saisie.setAttribute("autocapitalize", "off");
  saisie.setAttribute("spellcheck", "false");
}

const texteAdresses = (v) => (Array.isArray(v) ? v.filter(Boolean).join(", ") : String(v || ""));

/**
 * Fenêtre de rédaction d'un courriel.
 *   destinataire : adresse (ou liste) proposée      cc : adresses en copie conforme proposées
 *   suggestions  : [{ courriel, nom }] — autres personnes à ajouter d'un clic (envoi avec Gmail)
 *   objet, message : texte de départ (un gabarit choisi les remplace)
 *   gabaritId    : gabarit appliqué à l'ouverture    variables : voir variablesCourriel
 *   lier         : { lieType, lieId, lie2?: { type, id } } — fiche où consigner l'envoi
 *   repondreA    : { messageId } — message Gmail auquel on répond (le courriel reste dans la même conversation)
 *   surEnvoye    : (résultat) => void — appelé après un envoi avec Gmail réussi
 *   gmail        : false pour forcer l'ouverture dans la messagerie (par défaut : Gmail si le compte est connecté)
 * Retourne une promesse : true si le courriel est parti avec Gmail, ou s'il a été ouvert dans la messagerie (ou consigné).
 */
export function ouvrirCourriel({
  titre = "Écrire un courriel", destinataire = "", cc = "", suggestions = [], objet: objetInitial = "", message: messageInitial = "",
  gabaritId = null, variables = {}, lier = null, aide = "", repondreA = null, surEnvoye = null, gmail = peutEnvoyerGmail(),
} = {}) {
  const avecGmail = !!gmail && peutEnvoyerGmail();
  const gabarits = etat.config?.gabarits_courriel || [];
  const depart = gabarits.find((g) => g.id === gabaritId) || null;
  const signature = String(etat.config?.entreprise?.signature || "").trim();
  const description = avecGmail
    ? [`Le courriel part de votre compte Gmail (${compteGoogle()}) et se retrouve dans vos « Envoyés ».`, aide].filter(Boolean).join(" ")
    : aide || "Le message s’ouvre dans votre logiciel de courriel. Le CRM n’envoie rien à votre place.";

  // Le texte d'introduction défile avec le formulaire (et non dans l'en-tête) : sur un téléphone, chaque ligne de la zone fixe compte.
  return ouvrirDialogue({
    titre, taille: "grand",
    contenu: (ctx) => {
      const idGab = idUnique("courriel-gab");
      const gab = h(
        "select.saisie",
        { id: idGab },
        h("option", { value: "" }, "Message libre"),
        gabarits.map((g) => h("option", { value: g.id }, g.nom))
      );
      gab.value = depart ? depart.id : "";
      const a = avecGmail
        ? creerChamp("a", { type: "texte", libelle: "À", max: 600 }, texteAdresses(destinataire), { requis: true, placeholder: "nom@exemple.com", aide: "Une ou plusieurs adresses, séparées par des virgules." })
        : creerChamp("a", { type: "courriel", libelle: "À", max: 254 }, texteAdresses(destinataire), { requis: false, aide: "Facultatif : vous pouvez aussi choisir le destinataire dans votre logiciel de courriel." });
      const copie = avecGmail ? creerChamp("cc", { type: "texte", libelle: "Cc (copie conforme)", max: 600 }, texteAdresses(cc), { placeholder: "nom@exemple.com" }) : null;
      if (avecGmail) {
        regler(a);
        regler(copie);
      }
      // Avec Gmail, l'objet et le message sont obligatoires ; en ouvrant la messagerie, l'un ou l'autre suffit.
      const objet = creerChamp("objet", { type: "texte", libelle: "Objet", max: 200 }, objetInitial, { requis: avecGmail });
      const message = creerChamp("message", { type: "texte_long", libelle: "Message", max: 8000 }, messageInitial, { rows: 12, requis: avecGmail });
      const consigne = lier ? creerChamp("consigner", { type: "booleen", libelle: "Ajouter ce courriel à l’historique de la fiche" }, true, {}) : null;
      const avecSignature = avecGmail && signature ? creerChamp("signature", { type: "booleen", libelle: "Ajouter la signature de l’entreprise à la fin du message" }, true, {}) : null;

      const appliquer = () => {
        const g = gabarits.find((x) => x.id === gab.value);
        if (!g) return;
        objet.definir(remplirGabarit(g.objet, variables));
        message.definir(remplirGabarit(g.corps, variables));
        ctx.modifie(true);
      };
      gab.addEventListener("change", appliquer);
      if (depart) {
        objet.definir(remplirGabarit(depart.objet, variables));
        message.definir(remplirGabarit(depart.corps, variables));
      }
      // Ce qu'on a écrit ne se perd pas d'un clic à côté : la fermeture demande confirmation.
      for (const champ of [a, objet, message]) champ.noeud.addEventListener("input", () => ctx.modifie(true));
      copie?.noeud.addEventListener("input", () => ctx.modifie(true));

      // Les notifications restent derrière la fenêtre : les confirmations et les erreurs s'affichent donc ici.
      const retourCopie = h("p.courriel__retour.petit", { role: "status", "aria-live": "polite" });
      const statut = h("p.courriel__statut.petit.muet", { role: "status", "aria-live": "polite" });
      const alerte = h("div.courriel__alerte");
      let minuteurCopie = null;
      const copier = (libelle, lire, confirmation) =>
        btn(libelle, {
          petit: true, icone: "copier",
          onclick: async () => {
            const ok = await copierTexte(lire());
            retourCopie.textContent = ok ? confirmation : "La copie n’a pas fonctionné. Sélectionnez le texte et copiez-le à la main.";
            retourCopie.classList.toggle("courriel__retour--erreur", !ok);
            clearTimeout(minuteurCopie);
            minuteurCopie = setTimeout(() => (retourCopie.textContent = ""), 5000);
          },
        });

      // ----- Destinataires
      /** Lit À (et Cc) ; affiche les erreurs sur les champs. Retourne { a, cc } ou null. */
      function lireDestinataires() {
        a.erreur(null);
        copie?.erreur(null);
        if (!avecGmail) {
          const adresse = a.lire().trim();
          if (adresse) {
            const r = validerValeur({ type: "courriel" }, adresse);
            if (r.erreur) {
              a.erreur(r.erreur);
              a.focus();
              return null;
            }
          }
          return { a: adresse ? [adresse] : [], cc: [] };
        }
        const principaux = separerAdresses(a.lire());
        const copies = separerAdresses(copie.lire());
        const erreurs = [];
        if (principaux.invalides.length) erreurs.push([a, `Adresse invalide : ${principaux.invalides[0].slice(0, 60)}`]);
        else if (!principaux.adresses.length) erreurs.push([a, "Indiquez au moins un destinataire."]);
        if (copies.invalides.length) erreurs.push([copie, `Adresse invalide : ${copies.invalides[0].slice(0, 60)}`]);
        const enCopie = copies.adresses.filter((x) => !principaux.adresses.includes(x));
        if (!erreurs.length && principaux.adresses.length + enCopie.length > MAX_DESTINATAIRES) erreurs.push([a, `Au plus ${MAX_DESTINATAIRES} destinataires en tout.`]);
        if (erreurs.length) {
          for (const [champ, texte] of erreurs) champ.erreur(texte);
          if (erreurs.some(([champ]) => champ === copie)) {
            zoneCopie.hidden = false;
            boutonCopie.hidden = true;
          }
          erreurs[0][0].focus();
          return null;
        }
        return { a: principaux.adresses, cc: enCopie };
      }

      const zoneCopie = h("div", { hidden: !copie || !texteAdresses(cc) }, copie ? copie.noeud : null);
      const boutonCopie = copie
        ? btn("Ajouter une copie conforme (Cc)", {
            petit: true, ton: "discret", icone: "plus",
            onclick: () => {
              zoneCopie.hidden = false;
              boutonCopie.hidden = true;
              copie.focus();
            },
          })
        : null;
      if (boutonCopie && !zoneCopie.hidden) boutonCopie.hidden = true;

      const ajouterAdresse = (adresse) => {
        const brut = a.lire().trim().replace(/[,;\s]+$/, "");
        if (separerAdresses(brut).adresses.includes(adresse.toLowerCase())) return;
        a.definir(brut ? `${brut}, ${adresse}` : adresse);
        ctx.modifie(true);
        a.erreur(null);
      };
      const pastilles = avecGmail && suggestions.length
        ? h(
            "div.courriel__suggestions",
            h("span.muet.petit", "Ajouter :"),
            suggestions.map((s) => btn(s.nom, { petit: true, ton: "discret", icone: "plus", titre: s.courriel, onclick: () => ajouterAdresse(s.courriel) }))
          )
        : null;

      // ----- Ouverture dans la messagerie
      async function ouvrirDansLaMessagerie() {
        alerte.replaceChildren();
        const dest = lireDestinataires();
        if (!dest) return;
        const sujet = objet.lire().trim();
        const texte = message.lire().replace(/\r\n?/g, "\n");
        if (!sujet && !texte.trim()) {
          message.erreur("Écrivez un objet ou un message.");
          message.focus();
          return;
        }
        let consignee = false;
        if (consigne?.lire() && lier) {
          ctx.occupe(true);
          consignee = await consigner(lier, sujet, texte);
          ctx.occupe(false);
          if (!consignee) return;
        }
        const adresses = dest.a.map((x) => encodeURIComponent(x).replace(/%40/g, "@")).join(",");
        const copies = dest.cc.length ? `&cc=${dest.cc.map((x) => encodeURIComponent(x).replace(/%40/g, "@")).join(",")}` : "";
        const avecCorps = `mailto:${adresses}?subject=${encodeURIComponent(sujet)}${copies}&body=${encodeURIComponent(texte.replace(/\n/g, "\r\n"))}`;
        let long = false;
        let href = avecCorps;
        if (avecCorps.length > LONGUEUR_MAX_LIEN) {
          long = true;
          href = `mailto:${adresses}?subject=${encodeURIComponent(sujet)}${copies}`;
          await copierTexte(texte);
        }
        ouvrirMessagerie(href);
        ctx.fermer(true);
        toast(
          long
            ? "Le message est long : il a été copié. Collez-le dans votre courriel."
            : `Le courriel est prêt dans votre logiciel de courriel.${consignee ? " Il a été ajouté à l’historique." : ""}`,
          { ton: "ok", duree: long ? 10000 : undefined }
        );
      }

      // ----- Envoi avec Gmail
      // Une clé par fenêtre : si la réponse se perd en route, un nouvel essai ne renvoie pas le message une seconde fois.
      let cle = nouvelleCleEnvoi();
      // Avec Gmail, rien ne repasse par la messagerie pour une dernière relecture : on prévient une fois des passages restés à compléter.
      let restantsSignales = "";

      function afficherAlerte(e) {
        const incertain = e.code === "google_envoi_incertain";
        const actions = [];
        if (CODES_CONNEXION.has(e.code)) {
          actions.push(
            btn("Ouvrir Paramètres → Google", {
              petit: true,
              // Si un message a été écrit, on demande d'abord si l'on peut le perdre.
              onclick: async () => {
                await ctx.demanderFermeture();
                if (!ctx.dialog.open) naviguer("/parametres/google");
              },
            })
          );
        }
        if (incertain) {
          const ouvrir = btn("Ouvrir mes envoyés Gmail", { petit: true, icone: "externe", href: lienGmailEnvoyes() });
          ouvrir.target = "_blank";
          ouvrir.rel = "noopener noreferrer";
          actions.push(ouvrir, btn("Envoyer quand même", { petit: true, onclick: () => envoyerAvecGmail({ nouvelleCle: true }) }));
        }
        // Hors des cas où il suffit d'attendre ou de réessayer, on rappelle que la messagerie reste possible, et on la montre.
        const reessayer = e.statut === 429 || ["google_envoi_en_cours", "google_envoi_incertain", "reseau"].includes(e.code);
        if (!reessayer && "open" in autres) autres.open = true;
        const solution = reessayer ? "" : " Vous pouvez aussi ouvrir le message dans votre logiciel de courriel (en bas de cette fenêtre).";
        alerte.replaceChildren(
          avis({ ton: incertain ? "attention" : "erreur", titre: TITRES_ERREUR[e.code] || "Le courriel n’est pas parti", texte: `${e.message}${solution}`, actions, role: "alert" })
        );
        alerte.scrollIntoView?.({ block: "nearest" });
      }

      async function envoyerAvecGmail({ nouvelleCle = false } = {}) {
        if (nouvelleCle) cle = nouvelleCleEnvoi();
        alerte.replaceChildren();
        objet.erreur(null);
        message.erreur(null);
        const dest = lireDestinataires();
        if (!dest) return;
        const sujet = objet.lire().trim();
        let corps = message.lire().replace(/\r\n?/g, "\n").trim();
        if (!sujet) {
          objet.erreur("Écrivez un objet.");
          objet.focus();
          return;
        }
        if (/[\u0000-\u001f\u007f\u2028\u2029]/.test(sujet)) {
          objet.erreur("L’objet ne peut contenir ni saut de ligne ni caractère de contrôle.");
          objet.focus();
          return;
        }
        if (!corps) {
          message.erreur("Écrivez un message.");
          message.focus();
          return;
        }
        const restants = passagesRestants(sujet, corps);
        if (restants.length && restantsSignales !== restants.join("|")) {
          restantsSignales = restants.join("|");
          alerte.replaceChildren(
            avis({
              ton: "attention", titre: "Il reste des passages à compléter", role: "alert",
              texte: `Le courriel contient encore ${restants.map((p) => `« ${p} »`).join(", ")}. Complétez-le, ou cliquez de nouveau sur « Envoyer avec Gmail » pour l’envoyer tel quel.`,
            })
          );
          alerte.scrollIntoView?.({ block: "nearest" });
          return;
        }
        // La signature s'ajoute une seule fois : un gabarit qui la contient déjà n'est pas doublé.
        if (avecSignature?.lire() && !normaliser(corps).includes(normaliser(signature))) corps = `${corps}\n\n${signature}`;
        const charge = { cle, a: dest.a, cc: dest.cc, objet: sujet, corps };
        if (consigne?.lire() && lier) {
          charge.lie = { type: lier.lieType, id: lier.lieId };
          if (lier.lie2?.id) charge.lie2 = { type: lier.lie2.type, id: lier.lie2.id };
        }
        if (repondreA?.messageId) charge.repondre_a = { message_id: repondreA.messageId };

        ctx.occupe(true);
        statut.textContent = "Envoi en cours…";
        let r;
        try {
          r = await envoyerGmail(charge);
        } catch (e) {
          ctx.occupe(false);
          statut.textContent = "";
          if (!(e instanceof ErreurApi)) throw e;
          if (e.statut === 422 && e.champs) {
            const champs = { a, cc: copie, objet, corps: message };
            let premier = null;
            for (const [k, texte] of Object.entries(e.champs)) {
              if (!champs[k]) continue;
              champs[k].erreur(texte);
              premier ||= champs[k];
              if (k === "cc") {
                zoneCopie.hidden = false;
                boutonCopie.hidden = true;
              }
            }
            if (premier) {
              premier.focus();
              return;
            }
          }
          afficherAlerte(e);
          signalerErreurGoogle(e);
          return;
        }
        // Le courriel est parti : on met l'historique, les tâches et la liste des courriels échangés à jour.
        if (r.activite) notifier("activites");
        if (r.tache) mettreAJourFiche("taches", r.tache);
        notifier("gmail");
        ctx.modifie(false);
        ctx.fermer(true);
        toast(
          r.deja
            ? "Ce courriel était déjà parti : il n’a pas été renvoyé."
            : `Courriel envoyé avec Gmail.${r.activite ? " Il a été ajouté à l’historique." : ""}`,
          { ton: "ok" }
        );
        if (r.avertissement) toast(r.avertissement, { ton: "erreur", duree: 12000 });
        try {
          await surEnvoye?.(r);
        } catch (e) {
          console.error("[courriel] suite de l’envoi :", e);
        }
      }

      const boutonMessagerie = btn("Ouvrir dans mon logiciel de courriel", { ton: avecGmail ? "secondaire" : "primaire", icone: "courriel", onclick: ouvrirDansLaMessagerie });
      // Un message écrit ne se perd pas d'un clic sur « Annuler » : la fermeture demande confirmation, comme le « × » de l'en-tête.
      ctx.definirPied(btn("Annuler", { onclick: () => ctx.demanderFermeture() }), avecGmail ? btn("Envoyer avec Gmail", { ton: "primaire", icone: "envoyer", onclick: () => envoyerAvecGmail() }) : boutonMessagerie);

      const copies = h(
        "div.courriel__copies",
        h("p.muet.petit", "Si votre logiciel de courriel ne s’ouvre pas, copiez le texte et collez-le dans votre courriel."),
        h("div.rangee", copier("Copier l’objet", () => objet.lire().trim(), "Objet copié."), copier("Copier le message", () => message.lire(), "Message copié.")),
        retourCopie
      );
      // Avec Gmail, ces solutions de rechange restent à portée de main sans encombrer la fenêtre.
      const autres = avecGmail
        ? h(
            "details.replie.courriel__autres",
            h("summary.replie__titre", icone("droite", "ic--p replie__fleche"), h("span.replie__nom", "Autres façons d’envoyer ce message")),
            h("div.replie__corps", h("p.muet.petit", "Par exemple pour joindre un fichier : le message s’ouvre alors dans votre logiciel de courriel, que vous complétez et envoyez vous-même."), h("div.rangee", boutonMessagerie), copies)
          )
        : copies;

      return h(
        "form.formulaire.courriel",
        { novalidate: true, onsubmit: (e) => (e.preventDefault(), avecGmail ? envoyerAvecGmail() : ouvrirDansLaMessagerie()) },
        description ? h("p.courriel__intro", description) : null,
        alerte,
        h("div.champ", h("label.champ__etiquette", { for: idGab }, "Gabarit"), h("div.saisie-select", gab, icone("bas", "ic--p")), h("p.champ__aide", "Choisir un gabarit remplace l’objet et le message ci-dessous.")),
        a.noeud,
        pastilles,
        boutonCopie ? h("div.courriel__ajout-cc", boutonCopie) : null,
        zoneCopie,
        objet.noeud,
        message.noeud,
        avecSignature ? avecSignature.noeud : null,
        consigne ? consigne.noeud : null,
        statut,
        autres
      );
    },
  }).promesse.then((v) => v === true);
}
