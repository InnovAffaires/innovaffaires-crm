// =============================================================================
// Rédiger un courriel à partir d'un gabarit. Le CRM n'envoie rien lui-même : le
// message s'ouvre dans le logiciel de courriel de la personne (ou se copie), et
// l'envoi peut être consigné dans l'historique de la fiche.
//
// Champs de fusion des gabarits (Paramètres → Gabarits de courriel) :
//   {{prenom}} {{nom}} {{entreprise}} {{programme}} {{date_limite}} {{delai}}
//   {{montant}} {{numero}} {{echeance}} {{signature}}
// Un champ dont la valeur est inconnue devient « [à compléter] » dans le message,
// pour qu'on le voie avant d'envoyer.
// =============================================================================
import { h, idUnique, copierTexte } from "../noyau/dom.js";
import { icone } from "../noyau/icones.js";
import { etat, notifier } from "../noyau/etat.js";
import { envoyer } from "../noyau/api.js";
import { tenter } from "../noyau/ecriture.js";
import { argent, dateComplete, nomComplet } from "../commun/format.js";
import { calculerTotaux } from "../commun/calculs.js";
import { validerValeur } from "../commun/valider.js";
import { btn } from "./composants.js";
import { creerChamp } from "./formulaire.js";
import { ouvrirDialogue } from "./dialogue.js";
import { toast } from "./toast.js";

/** Ce qu'on écrit à la place d'un champ de fusion dont on ne connaît pas la valeur. */
const A_COMPLETER = {
  prenom: "", nom: "", signature: "", entreprise: "[entreprise]", programme: "[programme]", date_limite: "[date limite]",
  delai: "[délai]", montant: "[montant]", numero: "[numéro]", echeance: "[échéance]",
};

/** Remplace les champs {{…}} d'un gabarit par leurs valeurs. */
export function remplirGabarit(modele, variables = {}) {
  return String(modele ?? "")
    .replace(/\{\{\s*(\w+)\s*\}\}/g, (_, nom) => {
      const v = variables[nom];
      if (v !== undefined && v !== null && String(v).trim() !== "") return String(v);
      return Object.hasOwn(A_COMPLETER, nom) ? A_COMPLETER[nom] : "";
    })
    .replace(/Bonjour\s+,/g, "Bonjour,")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

/**
 * Les valeurs des champs de fusion pour un contact, une entreprise, un dossier ou une facture.
 * Ce qui manque est laissé vide (le champ apparaîtra entre crochets dans le message).
 */
export function variablesCourriel({ contact = null, entreprise = null, dossier = null, facture = null } = {}) {
  const c = etat.config || {};
  const v = {
    prenom: contact?.prenom || "",
    nom: contact ? nomComplet(contact) : "",
    entreprise: entreprise?.nom || "",
    programme: dossier?.programme || dossier?.titre || "",
    date_limite: dossier?.date_limite ? dateComplete(dossier.date_limite) : "",
    delai: `dans les ${c.delai_reponse_heures ?? 48} heures ouvrables`,
    signature: c.entreprise?.signature || "",
  };
  if (facture) {
    const t = facture.totaux || calculerTotaux(facture.lignes || [], facture.taux || c.taxes, facture.paiements || []);
    const ouverte = facture.type === "facture" && facture.statut !== "brouillon" && facture.statut !== "annulee" && t.solde > 0;
    v.numero = facture.numero || "";
    v.montant = argent(ouverte ? t.solde : t.total);
    v.echeance = facture.date_echeance ? dateComplete(facture.date_echeance) : "";
  }
  return v;
}

/** Au-delà, certains logiciels de courriel coupent le message : on le copie et on n'ouvre que l'objet. */
const LONGUEUR_MAX_LIEN = 1900;

function ouvrirMessagerie(href) {
  const lien = h("a", { href, rel: "noopener", hidden: true });
  document.body.append(lien);
  lien.click();
  lien.remove();
}

/** Consigne le courriel dans l'historique de la fiche (type « courriel », envoyé). */
async function consigner({ lieType, lieId, lie2 = null }, sujet, texte) {
  const charge = {
    type: "courriel", direction: "sortant", titre: (sujet || "Courriel").slice(0, 200), texte: texte.slice(0, 8000), lie_type: lieType, lie_id: lieId,
  };
  if (lie2?.id) {
    charge.lie2_type = lie2.type;
    charge.lie2_id = lie2.id;
  }
  const r = await tenter(() => envoyer("/activites", charge));
  if (r) notifier("activites");
  return !!r;
}

/**
 * Fenêtre de rédaction d'un courriel.
 *   destinataire : adresse proposée       gabaritId : gabarit appliqué à l'ouverture
 *   variables    : voir variablesCourriel  lier : { lieType, lieId, lie2?: { type, id } } — fiche où consigner l'envoi
 * Retourne une promesse : true si le courriel a été ouvert dans la messagerie (ou consigné).
 */
export function ouvrirCourriel({ titre = "Écrire un courriel", destinataire = "", gabaritId = null, variables = {}, lier = null, aide = "" } = {}) {
  const gabarits = etat.config?.gabarits_courriel || [];
  const depart = gabarits.find((g) => g.id === gabaritId) || null;

  return ouvrirDialogue({
    titre, taille: "grand", description: aide || "Le message s’ouvre dans votre logiciel de courriel. Le CRM n’envoie rien à votre place.",
    contenu: (ctx) => {
      const idGab = idUnique("courriel-gab");
      const gab = h(
        "select.saisie",
        { id: idGab },
        h("option", { value: "" }, "Message libre"),
        gabarits.map((g) => h("option", { value: g.id }, g.nom))
      );
      gab.value = depart ? depart.id : "";
      const a = creerChamp("a", { type: "courriel", libelle: "À", max: 254 }, destinataire, { requis: false, aide: "Facultatif : vous pouvez aussi choisir le destinataire dans votre logiciel de courriel." });
      const objet = creerChamp("objet", { type: "texte", libelle: "Objet", max: 200 }, "", {});
      const message = creerChamp("message", { type: "texte_long", libelle: "Message", max: 8000 }, "", { rows: 12 });
      const consigne = lier ? creerChamp("consigner", { type: "booleen", libelle: "Ajouter ce courriel à l’historique de la fiche" }, true, {}) : null;

      const appliquer = () => {
        const g = gabarits.find((x) => x.id === gab.value);
        if (!g) return;
        objet.definir(remplirGabarit(g.objet, variables));
        message.definir(remplirGabarit(g.corps, variables));
      };
      gab.addEventListener("change", appliquer);
      if (depart) appliquer();

      // Les notifications restent derrière la fenêtre : la confirmation de copie s'affiche donc ici.
      const retourCopie = h("p.courriel__retour.petit", { role: "status", "aria-live": "polite" });
      let minuteurCopie = null;
      const copier = (libelle, lire, confirmation) =>
        btn(libelle, {
          petit: true, icone: "copier",
          onclick: async () => {
            const ok = await copierTexte(lire());
            retourCopie.textContent = ok ? confirmation : "La copie n’a pas fonctionné. Sélectionnez le texte et copiez-le à la main.";
            retourCopie.classList.toggle("courriel__retour--erreur", !ok);
            clearTimeout(minuteurCopie);
            minuteurCopie = setTimeout(() => (retourCopie.textContent = ""), 5000);
          },
        });

      async function ouvrirDansLaMessagerie() {
        a.erreur(null);
        const adresse = a.lire().trim();
        if (adresse) {
          const r = validerValeur({ type: "courriel" }, adresse);
          if (r.erreur) {
            a.erreur(r.erreur);
            a.focus();
            return;
          }
        }
        const sujet = objet.lire().trim();
        const texte = message.lire().replace(/\r\n?/g, "\n");
        if (!sujet && !texte.trim()) {
          message.erreur("Écrivez un objet ou un message.");
          message.focus();
          return;
        }
        let consignee = false;
        if (consigne?.lire() && lier) {
          ctx.occupe(true);
          consignee = await consigner(lier, sujet, texte);
          ctx.occupe(false);
          if (!consignee) return;
        }
        const dest = adresse ? encodeURIComponent(adresse).replace(/%40/g, "@") : "";
        const avecCorps = `mailto:${dest}?subject=${encodeURIComponent(sujet)}&body=${encodeURIComponent(texte.replace(/\n/g, "\r\n"))}`;
        let long = false;
        let href = avecCorps;
        if (avecCorps.length > LONGUEUR_MAX_LIEN) {
          long = true;
          href = `mailto:${dest}?subject=${encodeURIComponent(sujet)}`;
          await copierTexte(texte);
        }
        ouvrirMessagerie(href);
        ctx.fermer(true);
        toast(
          long
            ? "Le message est long : il a été copié. Collez-le dans votre courriel."
            : `Le courriel est prêt dans votre logiciel de courriel.${consignee ? " Il a été ajouté à l’historique." : ""}`,
          { ton: "ok", duree: long ? 10000 : undefined }
        );
      }

      ctx.definirPied(btn("Annuler", { onclick: () => ctx.fermer(false) }), btn("Ouvrir dans mon logiciel de courriel", { ton: "primaire", icone: "courriel", onclick: ouvrirDansLaMessagerie }));
      return h(
        "form.formulaire.courriel",
        { novalidate: true, onsubmit: (e) => (e.preventDefault(), ouvrirDansLaMessagerie()) },
        h("div.champ", h("label.champ__etiquette", { for: idGab }, "Gabarit"), h("div.saisie-select", gab, icone("bas", "ic--p")), h("p.champ__aide", "Choisir un gabarit remplace l’objet et le message ci-dessous.")),
        a.noeud,
        objet.noeud,
        message.noeud,
        h(
          "div.courriel__copies",
          h("p.muet.petit", "Si votre logiciel de courriel ne s’ouvre pas, copiez le texte et collez-le dans votre courriel."),
          h("div.rangee", copier("Copier l’objet", () => objet.lire().trim(), "Objet copié."), copier("Copier le message", () => message.lire(), "Message copié.")),
          retourCopie
        ),
        consigne ? consigne.noeud : null
      );
    },
  }).promesse.then((v) => v === true);
}
