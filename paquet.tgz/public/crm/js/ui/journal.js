// =============================================================================
// Journal d'une fiche : notes, appels, courriels, rencontres consignés à la main,
// plus l'historique automatique (étapes, statuts, factures). Sur l'accueil, la
// même ligne sert pour l'activité récente de toutes les fiches.
// =============================================================================
import { h, remplir, paragraphes } from "../noyau/dom.js";
import { icone } from "../noyau/icones.js";
import { etat, maintenant, nomUtilisateur, abonner } from "../noyau/etat.js";
import { envoyer, modifier, supprimer } from "../noyau/api.js";
import { tenter, lireActivites } from "../noyau/ecriture.js";
import { ACTIVITE, TYPES_ACTIVITE } from "../commun/schema.js";
import { validerActivite } from "../commun/valider.js";
import { ilYa } from "../commun/format.js";
import { btn, menuActions, etatVide } from "./composants.js";
import { creerChamp } from "./formulaire.js";
import { ouvrirDialogue, confirmer } from "./dialogue.js";
import { lienLie } from "../vues/aides.js";

const ICONE_ACT = { note: "note", appel: "appel", courriel: "courriel", rencontre: "rendez-vous", document: "document", systeme: "historique" };
const TYPES_SAISIE = TYPES_ACTIVITE.filter((t) => t.id !== "systeme");
const NOMS_CONSIGNES = { note: "Note ajoutée.", appel: "Appel consigné.", courriel: "Courriel consigné.", rencontre: "Rencontre consignée.", document: "Document consigné." };

const fmtComplet = new Intl.DateTimeFormat("fr-CA", { timeZone: "America/Toronto", dateStyle: "long", timeStyle: "short" });
const dateComplete = (ms) => fmtComplet.format(ms);

// ----- Une ligne -------------------------------------------------------------------------------------------------------------------------
/**
 * ligneActivite(a, { contexte, hote, surModifier, surSupprimer })
 *   contexte : afficher les fiches auxquelles l'entrée est liée (accueil)
 *   hote     : { type, id } — la fiche qui affiche déjà ce journal (son lien est omis)
 */
export function ligneActivite(a, { contexte = false, hote = null, surModifier = null, surSupprimer = null } = {}) {
  const ms = Date.parse(a.date);
  const systeme = a.type === "systeme";
  const libelleType = TYPES_ACTIVITE.find((t) => t.id === a.type)?.libelle || a.type;
  const sens = a.direction === "entrant" ? "reçu" : a.direction === "sortant" ? "envoyé" : "";

  const liens = [];
  const estHote = (t, i) => hote && hote.type === t && hote.id === i;
  for (const [t, i] of [[a.lie_type, a.lie_id], [a.lie2_type, a.lie2_id]]) {
    if (!t || !i || (!contexte && estHote(t, i))) continue;
    const l = lienLie(t, i, { court: true });
    if (l) liens.push(l);
  }

  const meta = [
    h("span.act__type", libelleType.toLowerCase() === "historique" ? "Historique" : libelleType, sens ? ` ${sens}` : ""),
    a.duree_min ? h("span", `${a.duree_min} min`) : null,
    !systeme && a.par && nomUtilisateur(a.par) ? h("span", `par ${nomUtilisateur(a.par)}`) : null,
  ].filter(Boolean);

  const actions =
    !systeme && etat.droits.ecrire && (surModifier || surSupprimer)
      ? menuActions({
          aria: "Actions sur cette entrée",
          elements: [
            surModifier ? { libelle: "Modifier", icone: "modifier", onclick: () => surModifier(a) } : null,
            surSupprimer ? { libelle: "Supprimer", icone: "corbeille", danger: true, onclick: () => surSupprimer(a) } : null,
          ].filter(Boolean),
        })
      : null;

  return h(
    "li.act",
    { class: [`act--${a.type}`, contexte ? "act--court" : ""], "data-activite": a.id },
    h("span.act__icone", { "aria-hidden": "true" }, icone(ICONE_ACT[a.type] || "note", "ic--p")),
    h(
      "div.act__corps",
      h("p.act__titre", a.titre ? h("strong", a.titre) : h("strong", systeme ? "Changement" : libelleType)),
      a.texte ? h("div.act__texte", systeme ? h("p", a.texte) : paragraphes(a.texte)) : null,
      h(
        "p.act__meta",
        h("time", { datetime: a.date, title: Number.isFinite(ms) ? dateComplete(ms) : "" }, Number.isFinite(ms) ? ilYa(ms, maintenant()) : ""),
        ...meta.flatMap((m) => [h("span.act__sep", { "aria-hidden": "true" }, "·"), m]),
        ...liens.flatMap((l) => [h("span.act__sep", { "aria-hidden": "true" }, "·"), l])
      )
    ),
    actions ? h("div.act__actions", actions) : null
  );
}

// ----- Formulaire de saisie -----------------------------------------------------------------------------------------------
/**
 * formulaireActivite({ lieType, lieId, lie2, existante, typeInitial, surFait, surAnnuler })
 * Retourne { noeud, focus, occupe(bool) }.
 */
function formulaireActivite({ lieType, lieId, lie2 = null, existante = null, typeInitial = "note", surFait, surAnnuler }) {
  const v = existante || {};
  const c = {
    type: creerChamp("type", { ...ACTIVITE.type, options: TYPES_SAISIE }, existante ? v.type : typeInitial, { requis: true, libelle: "Type d’entrée" }),
    date: creerChamp("date", ACTIVITE.date, v.date || new Date(maintenant()).toISOString(), { requis: true, libelle: "Date et heure" }),
    titre: creerChamp("titre", ACTIVITE.titre, v.titre, { libelle: "Titre", placeholder: "Facultatif" }),
    texte: creerChamp("texte", ACTIVITE.texte, v.texte, { libelle: "Détails", rows: 4, placeholder: "Résumé de l’échange, décisions prises, prochaines étapes…", etendu: true }),
    direction: creerChamp("direction", ACTIVITE.direction, v.direction || "sortant", { libelle: "Sens" }),
    duree_min: creerChamp("duree_min", ACTIVITE.duree_min, v.duree_min, { libelle: "Durée", placeholder: "Facultatif", suffixe: "min" }),
  };

  const alerte = h("p.champ__erreur", { role: "alert", hidden: true });
  const enregistrer = h("button.btn.btn--primaire", { type: "submit" }, existante ? "Enregistrer les modifications" : "Enregistrer");
  const annuler = h("button.btn", { type: "button", onclick: () => surAnnuler?.() }, "Annuler");
  const form = h(
    "form.formulaire.formulaire--activite",
    { novalidate: true },
    h("div.grille.grille--2", c.type.noeud, c.date.noeud),
    c.titre.noeud,
    c.texte.noeud,
    h("div.grille.grille--2", c.direction.noeud, c.duree_min.noeud),
    alerte,
    h("div.formulaire__actions", annuler, enregistrer)
  );

  function majVisibilite() {
    const t = c.type.lire();
    c.direction.noeud.hidden = !(t === "appel" || t === "courriel");
    c.duree_min.noeud.hidden = !(t === "appel" || t === "rencontre");
  }
  c.type.controle.addEventListener("change", majVisibilite);
  majVisibilite();

  let occupe = false;
  const occuper = (o) => {
    occupe = o;
    for (const el of form.querySelectorAll("input, select, textarea, button")) el.disabled = o;
  };

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (occupe) return;
    const type = c.type.lire();
    const o = { type, date: c.date.lire(), titre: c.titre.lire().trim(), texte: c.texte.lire().trim(), lie_type: lieType, lie_id: lieId };
    if (lie2) {
      o.lie2_type = lie2.type;
      o.lie2_id = lie2.id;
    }
    if (type === "appel" || type === "courriel") o.direction = c.direction.lire();
    if (type === "appel" || type === "rencontre") o.duree_min = c.duree_min.lire();
    const r = validerActivite(o);
    const erreurs = { ...r.erreurs };
    if (!o.titre && !o.texte && !erreurs.titre && !erreurs.texte) erreurs.texte = "Écrivez un titre ou des détails.";
    for (const x of Object.values(c)) x.erreur(null);
    alerte.hidden = true;
    const cles = Object.keys(erreurs);
    if (cles.length) {
      let premier = null;
      for (const k of cles) {
        if (c[k]) {
          c[k].erreur(erreurs[k]);
          premier ||= c[k];
        } else {
          alerte.hidden = false;
          alerte.textContent = erreurs[k];
        }
      }
      premier?.focus();
      return;
    }
    const charge = { ...r.valeur };
    if (existante) for (const k of ["titre", "texte", "direction", "duree_min"]) if (!(k in charge)) charge[k] = "";
    occuper(true);
    const rep = await tenter(() => (existante ? modifier(`/activites/${encodeURIComponent(existante.id)}`, charge) : envoyer("/activites", charge)), {
      succes: existante ? "Entrée modifiée." : NOMS_CONSIGNES[type] || "Entrée ajoutée.",
    });
    occuper(false);
    if (rep) surFait?.(rep.activite);
  });

  return {
    noeud: form,
    focus: () => c.texte.focus(),
    occupe: occuper,
  };
}

// ----- Journal d'une fiche -------------------------------------------------------------------------------------------
/**
 * journal({ lieType, lieId, lie2, titre, aide })
 *   lieType/lieId : la fiche hôte (type de collection : « contacts », « opportunites »…)
 *   lie2          : { type, id } — seconde fiche à laquelle lier les nouvelles entrées (ex. l'entreprise d'un dossier)
 * Retourne { noeud, recharger() }.
 */
export function journal({ lieType, lieId, lie2 = null, titre = "Historique", aide = "Notes, appels, courriels et rencontres, du plus récent au plus ancien." }) {
  const peutEcrire = etat.droits.ecrire;
  const zoneListe = h("div.journal__liste", h("p.liste-vide", "Chargement…"));
  const zoneSaisie = h("div.journal__saisie");
  let activites = [];
  let enCours = false;
  let suivant = false;

  function dessiner() {
    if (!activites.length) {
      remplir(zoneListe, etatVide({ icone: "note", titre: "Rien pour l’instant", texte: peutEcrire ? "Consignez ici un appel, un courriel, une rencontre ou une note : vous retrouverez tout l’historique au même endroit." : "Aucune entrée n’a été consignée." }));
      return;
    }
    remplir(
      zoneListe,
      h("ul.journal", activites.map((a) => ligneActivite(a, { hote: { type: lieType, id: lieId }, surModifier: modifierEntree, surSupprimer: supprimerEntree })))
    );
  }

  async function recharger() {
    if (enCours) {
      suivant = true;
      return;
    }
    enCours = true;
    try {
      activites = await lireActivites(lieType, lieId, 150);
      dessiner();
    } catch (e) {
      remplir(zoneListe, h("p.liste-vide", e?.message || "L’historique n’a pas pu être chargé."));
    } finally {
      enCours = false;
      if (suivant) {
        suivant = false;
        recharger();
      }
    }
  }

  function afficherBoutons() {
    remplir(
      zoneSaisie,
      peutEcrire
        ? h(
            "div.journal__boutons",
            { role: "group", "aria-label": "Consigner une entrée" },
            TYPES_SAISIE.filter((t) => t.id !== "document").map((t) => btn(t.libelle, { petit: true, icone: ICONE_ACT[t.id], onclick: () => ouvrirSaisie(t.id) }))
          )
        : null
    );
  }
  function ouvrirSaisie(type) {
    const f = formulaireActivite({
      lieType, lieId, lie2, typeInitial: type,
      surFait: () => {
        afficherBoutons();
        recharger();
      },
      surAnnuler: afficherBoutons,
    });
    remplir(zoneSaisie, h("div.journal__formulaire", f.noeud));
    f.focus();
  }

  function modifierEntree(a) {
    ouvrirDialogue({
      titre: "Modifier l’entrée", taille: "moyen",
      contenu: (ctx) => {
        const f = formulaireActivite({ lieType: a.lie_type, lieId: a.lie_id, lie2: a.lie2_type ? { type: a.lie2_type, id: a.lie2_id } : null, existante: a, surFait: () => { ctx.fermer(true); recharger(); }, surAnnuler: () => ctx.fermer(false) });
        return f.noeud;
      },
    });
  }
  async function supprimerEntree(a) {
    const ok = await confirmer({ titre: "Supprimer cette entrée ?", message: "Elle sera retirée définitivement du journal.", libelleConfirmer: "Supprimer", danger: true });
    if (!ok) return;
    const r = await tenter(() => supprimer(`/activites/${encodeURIComponent(a.id)}`), { succes: "Entrée supprimée." });
    if (r) recharger();
  }

  afficherBoutons();
  recharger();
  const noeud = h(
    "section.panneau.journal-panneau",
    { "aria-label": titre },
    h("header.panneau__tete", h("div.panneau__titres", h("h2", titre), aide ? h("p.panneau__sous", aide) : null)),
    h("div.panneau__corps", zoneSaisie, zoneListe)
  );
  // Un courriel consigné depuis une autre fenêtre (composeur) annonce « activites » : le journal affiché se met à jour.
  const desabonner = abonner((changes) => {
    if (!changes.has("activites")) return;
    if (!noeud.isConnected) {
      desabonner();
      return;
    }
    recharger();
  });
  return { noeud, recharger };
}
