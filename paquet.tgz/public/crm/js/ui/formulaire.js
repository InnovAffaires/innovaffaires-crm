// =============================================================================
// Formulaires pilotés par le schéma : un champ du schéma → un contrôle accessible
// (étiquette, aide, message d'erreur, valeur lue et validée comme sur le serveur).
// =============================================================================
import { h, idUnique } from "../noyau/dom.js";
import { icone } from "../noyau/icones.js";
import { ENTITES } from "../commun/schema.js";
import { listeOptions, validerFiche } from "../commun/valider.js";
import { instantLocal, partiesLocales } from "../commun/dates.js";
import { etat, actives, nomFiche, libelleFiche } from "../noyau/etat.js";
import { combobox } from "./combobox.js";

// ----- Options des champs « lien » -----------------------------------------------------
export function optionsRef(cible) {
  switch (cible) {
    case "utilisateurs":
      return etat.equipe.map((u) => ({ id: u.id, libelle: u.nom }));
    case "contacts":
      return actives("contacts")
        .filter((c) => !c.archive)
        .map((c) => ({ id: c.id, libelle: libelleFiche("contacts", c), sous: nomFiche("entreprises", c.entreprise_id), cherche: `${c.courriel || ""}` }))
        .sort((a, b) => a.libelle.localeCompare(b.libelle, "fr-CA"));
    case "entreprises":
      return actives("entreprises")
        .filter((e) => !e.archive)
        .map((e) => ({ id: e.id, libelle: e.nom, sous: e.ville || "" }))
        .sort((a, b) => a.libelle.localeCompare(b.libelle, "fr-CA"));
    case "opportunites":
      return actives("opportunites")
        .map((o) => ({ id: o.id, libelle: o.titre, sous: nomFiche("entreprises", o.entreprise_id) }))
        .sort((a, b) => a.libelle.localeCompare(b.libelle, "fr-CA"));
    case "dossiers":
      return actives("dossiers")
        .map((d) => ({ id: d.id, libelle: d.titre, sous: nomFiche("entreprises", d.entreprise_id) }))
        .sort((a, b) => a.libelle.localeCompare(b.libelle, "fr-CA"));
    case "factures":
      return actives("factures")
        .map((f) => ({ id: f.id, libelle: libelleFiche("factures", f), sous: nomFiche("entreprises", f.entreprise_id) }))
        .sort((a, b) => b.libelle.localeCompare(a.libelle, "fr-CA"));
    case "demandes":
      return actives("demandes")
        .map((d) => ({ id: d.id, libelle: libelleFiche("demandes", d), sous: d.courriel }))
        .sort((a, b) => a.libelle.localeCompare(b.libelle, "fr-CA"));
    default:
      return [];
  }
}

const sansEspaces = (s) => String(s ?? "").replace(/[\s  $]/g, "");
const versTexteNombre = (n, decimales) => (n === null || n === undefined || n === "" ? "" : decimales ? Number(n).toFixed(decimales).replace(".", ",") : String(n).replace(".", ","));

function dateHeureDepuisIso(iso) {
  if (!iso) return { date: "", heure: "" };
  const ms = typeof iso === "number" ? iso : Date.parse(iso);
  if (!Number.isFinite(ms)) return { date: "", heure: "" };
  const p = partiesLocales(ms);
  return { date: p.date, heure: p.heure };
}

/**
 * Crée un champ de formulaire.
 * opts : { libelle, aide, placeholder, requis, etendu, desactive, rows, config, creationRapide, suggestions }
 */
export function creerChamp(cle, spec, valeur, opts = {}) {
  const id = idUnique(`f-${cle}`);
  const libelle = opts.libelle || spec.libelle || cle;
  const requis = opts.requis ?? !!spec.requis;
  const desactive = !!opts.desactive;
  const idAide = opts.aide ? `${id}-aide` : null;
  const idErr = `${id}-err`;
  const decrit = [idAide, idErr].filter(Boolean).join(" ");
  let lire;
  let definir;
  let controle; // élément principal pour le focus
  let corps;
  let etiquetteSurSoi = false;

  const commun = { id, "aria-describedby": decrit, "aria-required": requis ? "true" : null, disabled: desactive };

  switch (spec.type) {
    case "texte":
    case "courriel":
    case "tel":
    case "url": {
      const type = { courriel: "email", tel: "tel", url: "url", texte: "text" }[spec.type];
      const input = h("input.saisie", {
        ...commun, type, maxlength: spec.max ?? 200, autocomplete: opts.autocomplete || "off", spellcheck: spec.type === "texte" ? "true" : "false",
        inputmode: { courriel: "email", tel: "tel", url: "url" }[spec.type] || null, placeholder: opts.placeholder || null,
        autocapitalize: spec.type === "texte" ? "sentences" : "off",
      });
      input.value = valeur ?? "";
      controle = input;
      corps = input;
      lire = () => input.value;
      definir = (v) => (input.value = v ?? "");
      break;
    }
    case "texte_long": {
      const ta = h("textarea.saisie.saisie--long", { ...commun, rows: opts.rows || 4, maxlength: spec.max ?? 8000, placeholder: opts.placeholder || null, spellcheck: "true" });
      ta.value = valeur ?? "";
      const ajuster = () => {
        ta.style.height = "auto";
        ta.style.height = `${Math.min(ta.scrollHeight + 2, 480)}px`;
      };
      ta.addEventListener("input", ajuster);
      requestAnimationFrame(ajuster);
      controle = ta;
      corps = ta;
      lire = () => ta.value;
      definir = (v) => {
        ta.value = v ?? "";
        ajuster();
      };
      break;
    }
    case "nombre":
    case "montant":
    case "pourcent": {
      const input = h("input.saisie.saisie--nombre", {
        ...commun, type: "text", inputmode: spec.entier ? "numeric" : "decimal", autocomplete: "off", placeholder: opts.placeholder || null,
      });
      const decimales = spec.type === "montant" ? 2 : 0;
      input.value = versTexteNombre(valeur, spec.type === "montant" && valeur !== null && valeur !== undefined && valeur !== "" ? decimales : 0);
      input.addEventListener("blur", () => {
        const s = sansEspaces(input.value);
        if (s === "") return;
        const n = parseFloat(s.replace(",", "."));
        if (Number.isFinite(n) && /^-?\d+([.,]\d+)?$/.test(s)) input.value = versTexteNombre(spec.type === "montant" ? Math.round(n * 100) / 100 : n, spec.type === "montant" ? 2 : 0);
      });
      controle = input;
      const suffixe = spec.type === "montant" ? "$" : spec.type === "pourcent" ? "%" : opts.suffixe || "";
      corps = h("div.saisie-groupe", input, suffixe ? h("span.saisie-groupe__suffixe", { "aria-hidden": "true" }, suffixe) : null);
      lire = () => sansEspaces(input.value);
      definir = (v) => (input.value = versTexteNombre(v, spec.type === "montant" && v !== null && v !== undefined && v !== "" ? 2 : 0));
      break;
    }
    case "date": {
      const input = h("input.saisie.saisie--date", { ...commun, type: "date", min: "1990-01-01", max: "2199-12-31" });
      input.value = valeur ?? "";
      controle = input;
      corps = input;
      lire = () => input.value;
      definir = (v) => (input.value = v ?? "");
      break;
    }
    case "heure": {
      const input = h("input.saisie.saisie--heure", { ...commun, type: "time" });
      input.value = valeur ?? "";
      controle = input;
      corps = input;
      lire = () => input.value;
      definir = (v) => (input.value = v ?? "");
      break;
    }
    case "datetime": {
      const { date, heure } = dateHeureDepuisIso(valeur);
      const d = h("input.saisie.saisie--date", { ...commun, type: "date", min: "1990-01-01", max: "2199-12-31" });
      const t = h("input.saisie.saisie--heure", { type: "time", "aria-label": `${libelle} — heure`, disabled: desactive });
      d.value = date;
      t.value = heure;
      controle = d;
      corps = h("div.saisie-double", d, t);
      lire = () => (d.value ? new Date(instantLocal(d.value, t.value || "00:00")).toISOString() : "");
      definir = (v) => {
        const p = dateHeureDepuisIso(v);
        d.value = p.date;
        t.value = p.heure;
      };
      break;
    }
    case "choix": {
      const sel = h("select.saisie", { ...commun });
      const options = listeOptions(spec, opts.config || etat.config);
      if (!requis || !valeur) sel.append(h("option", { value: "" }, requis ? "Choisir…" : "—"));
      for (const o of options) sel.append(h("option", { value: o.id }, o.libelle));
      sel.value = valeur ?? "";
      if (sel.value !== (valeur ?? "")) sel.value = "";
      controle = sel;
      corps = h("div.saisie-select", sel, icone("bas", "ic--p"));
      lire = () => sel.value;
      definir = (v) => (sel.value = v ?? "");
      break;
    }
    case "booleen": {
      const cb = h("input", { id, type: "checkbox", disabled: desactive, "aria-describedby": decrit || null });
      cb.checked = !!valeur;
      controle = cb;
      etiquetteSurSoi = true;
      corps = h("label.case", { for: id }, cb, h("span.case__boite", { "aria-hidden": "true" }, icone("coche", "ic--p")), h("span", libelle));
      lire = () => cb.checked;
      definir = (v) => (cb.checked = !!v);
      break;
    }
    case "multi": {
      const suggestions = opts.suggestions || (() => []);
      let valeurs = Array.isArray(valeur) ? [...valeur] : [];
      const puces = h("span.puces");
      const saisie = h("input.puces__saisie", { id, type: "text", maxlength: 40, autocomplete: "off", disabled: desactive, "aria-describedby": decrit, placeholder: valeurs.length ? "" : opts.placeholder || "Ajouter…", list: `${id}-sugg` });
      const datalist = h("datalist", { id: `${id}-sugg` });
      const remplirSuggestions = () => {
        datalist.replaceChildren(...suggestions().filter((s) => !valeurs.some((v) => v.toLowerCase() === s.toLowerCase())).slice(0, 50).map((s) => h("option", { value: s })));
      };
      const dessiner = () => {
        puces.replaceChildren(
          ...valeurs.map((v) =>
            h("span.puce", v, h("button.puce__x", { type: "button", "aria-label": `Retirer « ${v} »`, disabled: desactive, onclick: () => { valeurs = valeurs.filter((x) => x !== v); dessiner(); corps.dispatchEvent(new CustomEvent("change", { bubbles: true })); saisie.focus(); } }, icone("fermer", "ic--p")))
          )
        );
        saisie.placeholder = valeurs.length ? "" : opts.placeholder || "Ajouter…";
        remplirSuggestions();
      };
      const ajouter = () => {
        const t = saisie.value.replace(/[,;]+/g, " ").replace(/\s+/g, " ").trim();
        saisie.value = "";
        if (!t) return;
        if (!valeurs.some((v) => v.toLowerCase() === t.toLowerCase())) valeurs.push(t.slice(0, 40));
        dessiner();
        corps.dispatchEvent(new CustomEvent("change", { bubbles: true }));
      };
      saisie.addEventListener("keydown", (e) => {
        if (e.key === "Enter" || e.key === ",") {
          if (saisie.value.trim()) {
            e.preventDefault();
            ajouter();
          } else if (e.key === ",") e.preventDefault();
        } else if (e.key === "Backspace" && !saisie.value && valeurs.length) {
          valeurs.pop();
          dessiner();
          corps.dispatchEvent(new CustomEvent("change", { bubbles: true }));
        }
      });
      saisie.addEventListener("change", ajouter);
      saisie.addEventListener("blur", ajouter);
      corps = h("div.puces-champ", puces, saisie, datalist);
      dessiner();
      controle = saisie;
      lire = () => {
        const reste = saisie.value.replace(/[,;]+/g, " ").replace(/\s+/g, " ").trim();
        return reste && !valeurs.some((v) => v.toLowerCase() === reste.toLowerCase()) ? [...valeurs, reste] : [...valeurs];
      };
      definir = (v) => {
        valeurs = Array.isArray(v) ? [...v] : [];
        dessiner();
      };
      break;
    }
    case "ref": {
      const cb = combobox({
        id, valeur: valeur || null, requis, desactive, placeholder: opts.placeholder || "Rechercher…",
        options: () => optionsRef(spec.cible), creer: opts.creationRapide || null, aucun: opts.aucun || "Aucun",
      });
      cb.entree.setAttribute("aria-describedby", decrit);
      controle = cb.entree;
      corps = cb.noeud;
      lire = cb.lire;
      definir = cb.definir;
      break;
    }
    default:
      throw new Error(`Type de champ non géré dans le formulaire : ${spec.type} (${cle})`);
  }

  const erreurNoeud = h("p.champ__erreur", { id: idErr, hidden: true });
  const noeud = h(
    "div.champ",
    { class: { "champ--etendu": opts.etendu, "champ--case": etiquetteSurSoi, [`champ--${spec.type}`]: true }, dataset: { champ: cle } },
    etiquetteSurSoi ? null : h("label.champ__etiquette", { for: id }, libelle, requis ? h("span.champ__requis", { "aria-hidden": "true" }, " *") : null),
    corps,
    opts.aide ? h("p.champ__aide", { id: idAide }, opts.aide) : null,
    erreurNoeud
  );
  const initial = JSON.stringify(lire());
  const api = {
    cle, spec, noeud, controle, lire, definir,
    erreur(msg) {
      erreurNoeud.hidden = !msg;
      erreurNoeud.textContent = msg || "";
      noeud.classList.toggle("champ--erreur", !!msg);
      for (const c of [controle]) {
        if (!c) continue;
        if (msg) c.setAttribute("aria-invalid", "true");
        else c.removeAttribute("aria-invalid");
      }
    },
    focus: () => controle?.focus(),
    modifie: () => JSON.stringify(lire()) !== initial,
    reinitialiser: () => {},
    desactiver(v) {
      for (const el of noeud.querySelectorAll("input, select, textarea, button")) el.disabled = !!v;
    },
  };
  noeud.addEventListener("input", () => api.erreur(null));
  noeud.addEventListener("change", () => api.erreur(null));
  return api;
}

// ----- Formulaire d'entité -------------------------------------------------------------------
/**
 * creerFormulaire({ entite, valeurs, disposition, desactive, editeurs, creationsRapides, surChangement, surSoumission })
 *   disposition : [{ titre?, aide?, colonnes?: 1|2|3, champs: ["cle" | { cle, etendu, aide, libelle, placeholder, rows, requis }] }]
 *   editeurs    : { cle: { noeud, lire(), definir?(v), erreurs?(map), modifie?() } }  (pour les champs « liste »)
 */
export function creerFormulaire({ entite, valeurs = {}, disposition, desactive = false, editeurs = {}, creationsRapides = {}, surChangement = null, surSoumission = null, config = etat.config, existant = null }) {
  const ent = ENTITES[entite];
  const champs = new Map();
  let existantCourant = existant;
  const alerte = h("div.formulaire__alerte", { role: "alert", hidden: true });
  const sections = [];

  for (const g of disposition) {
    const grille = h("div.grille", { class: `grille--${g.colonnes || 2}` });
    for (const item of g.champs) {
      const def = typeof item === "string" ? { cle: item } : item;
      const spec = ent.champs[def.cle];
      if (!spec) throw new Error(`Champ inconnu ${entite}.${def.cle}`);
      const ed = editeurs[def.cle];
      if (ed || spec.type === "liste") {
        if (!ed) throw new Error(`Éditeur manquant pour ${entite}.${def.cle}`);
        champs.set(def.cle, {
          cle: def.cle, spec, noeud: ed.noeud, lire: ed.lire, erreur: () => {}, editeur: ed,
          focus: () => (ed.focus ? ed.focus() : ed.noeud?.querySelector("input,select,textarea,button")?.focus()),
          modifie: () => (ed.modifie ? ed.modifie() : false),
          desactiver: (v) => ed.desactiver?.(v),
        });
        if (ed.noeud) {
          ed.noeud.classList.add("champ--etendu");
          grille.append(ed.noeud);
        }
        continue;
      }
      const c = creerChamp(def.cle, spec, valeurs[def.cle], {
        libelle: def.libelle, aide: def.aide, placeholder: def.placeholder, etendu: def.etendu, rows: def.rows, requis: def.requis, desactive: def.desactive ?? desactive, config,
        creationRapide: spec.type === "ref" ? creationsRapides[spec.cible] || null : null, suggestions: def.suggestions || (def.cle === "etiquettes" ? () => etiquettesConnues() : null), aucun: def.aucun,
        suffixe: def.suffixe, autocomplete: def.autocomplete,
      });
      champs.set(def.cle, c);
      grille.append(c.noeud);
    }
    sections.push(h("section.groupe", g.titre ? h("h3.groupe__titre", g.titre) : null, g.aide ? h("p.groupe__aide", g.aide) : null, grille));
  }

  const noeud = h("form.formulaire", { novalidate: true, autocomplete: "off", onsubmit: (e) => { e.preventDefault(); surSoumission?.(); } }, alerte, ...sections);
  if (surChangement) {
    noeud.addEventListener("input", () => surChangement());
    noeud.addEventListener("change", () => surChangement());
  }

  const api = {
    noeud, champs,
    lire() {
      const o = {};
      for (const [k, c] of champs) o[k] = c.lire();
      return o;
    },
    modifie: () => [...champs.values()].some((c) => c.modifie()),
    /** Montre les erreurs (objet { champ: message, "liste.0.cle": message, _global }). */
    afficherErreurs(erreurs = {}) {
      alerte.hidden = true;
      alerte.textContent = "";
      let premier = null;
      for (const c of champs.values()) c.erreur?.(null);
      const globales = [];
      const parEditeur = new Map();
      for (const [k, m] of Object.entries(erreurs)) {
        if (k === "_global") {
          globales.push(m);
          continue;
        }
        const racine = k.split(".")[0];
        const c = champs.get(racine);
        if (!c) {
          globales.push(m);
          continue;
        }
        if (k.includes(".") || c.editeur) {
          if (!parEditeur.has(racine)) parEditeur.set(racine, {});
          parEditeur.get(racine)[k] = m;
          if (c.editeur) continue;
        }
        c.erreur?.(m);
        premier ||= c;
      }
      for (const [racine, map] of parEditeur) {
        const c = champs.get(racine);
        c.editeur?.erreurs?.(map);
        premier ||= c;
      }
      const n = Object.keys(erreurs).length;
      if (n) {
        alerte.hidden = false;
        alerte.replaceChildren(...[h("strong", n === 1 && !globales.length ? "Un champ est à corriger." : "Certains champs sont à corriger.")], ...globales.map((g) => h("p", g)));
        premier?.focus();
        if (!premier) alerte.scrollIntoView({ block: "nearest" });
      }
    },
    /**
     * Valide comme le serveur. Retourne { ok, valeur, charge } : `charge` est ce qu'il faut envoyer
     * (création : toute la valeur ; modification : seulement les champs changés, null pour effacer).
     */
    valider({ creation }) {
      const brut = api.lire();
      const r = validerFiche(entite, brut, { creation, config, existant: existantCourant });
      if (Object.keys(r.erreurs).length) {
        api.afficherErreurs(r.erreurs);
        return { ok: false, erreurs: r.erreurs };
      }
      api.afficherErreurs({});
      if (creation) return { ok: true, valeur: r.valeur, charge: r.valeur };
      // Modification : on n'envoie que ce que la personne a réellement changé, pour ne jamais
      // écraser le travail d'un autre utilisateur sur les autres champs.
      const charge = {};
      for (const [k, v] of Object.entries(r.valeur)) {
        const c = champs.get(k);
        if (!c || !c.modifie()) continue;
        if (JSON.stringify(existantCourant?.[k] ?? null) !== JSON.stringify(v)) charge[k] = v;
      }
      for (const k of r.efface) {
        const c = champs.get(k);
        const avant = existantCourant?.[k];
        if (c && c.modifie() && avant !== undefined && avant !== null && avant !== "" && !(Array.isArray(avant) && !avant.length)) charge[k] = null;
      }
      return { ok: true, valeur: r.valeur, charge };
    },
    /** Après un conflit : la version du serveur devient la référence des comparaisons. */
    definirExistant(f) {
      existantCourant = f;
    },
    focusPremier() {
      const c = [...champs.values()].find((x) => x.focus);
      c?.focus();
    },
    desactiver(v) {
      for (const c of champs.values()) c.desactiver?.(v);
    },
  };
  return api;
}

/** Étiquettes déjà utilisées dans les contacts et entreprises + liste de la configuration. */
export function etiquettesConnues() {
  const s = new Set((etat.config?.etiquettes || []).map((e) => (typeof e === "string" ? e : e.libelle || e.id)));
  for (const n of ["contacts", "entreprises"]) for (const f of actives(n)) for (const e of f.etiquettes || []) s.add(e);
  return [...s].filter(Boolean).sort((a, b) => a.localeCompare(b, "fr-CA"));
}

