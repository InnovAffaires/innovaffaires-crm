// =============================================================================
// Barre d'outils des listes : recherche, filtres (listes déroulantes natives),
// compteur et bouton pour tout réinitialiser.
// =============================================================================
import { h, idUnique, anti_rebond } from "../noyau/dom.js";
import { icone } from "../noyau/icones.js";

/**
 * barreFiltres({ placeholder, q, surRecherche, filtres, droite, aria })
 *   filtres : [{ id, libelle, options: [{id, libelle}], valeur, tout, surChangement(valeur) }]
 * Retourne { noeud, definirCompte(texte), maj() } ; maj() relit les valeurs (après un « Réinitialiser »).
 */
export function barreFiltres({ placeholder = "Rechercher…", q = "", surRecherche, filtres = [], droite = null, aria = "Rechercher dans la liste", surReinitialiser = null, focusId = "q" }) {
  const idQ = idUnique("rech");
  const entree = h("input.saisie.recherche-liste__entree", {
    id: idQ, type: "search", placeholder, autocomplete: "off", spellcheck: "false", "aria-label": aria, "data-focus-id": focusId, enterkeyhint: "search",
  });
  entree.value = q;
  const declencher = anti_rebond(() => {
    surRecherche?.(entree.value);
    majBouton();
  }, 130);
  entree.addEventListener("input", declencher);
  entree.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && entree.value) {
      e.preventDefault();
      entree.value = "";
      surRecherche?.("");
      majBouton();
    }
  });

  const selects = filtres.map((f) => {
    const id = idUnique(`flt-${f.id}`);
    const sel = h("select.saisie.saisie--filtre", { id, "data-focus-id": `flt-${f.id}` }, h("option", { value: "" }, f.tout || f.libelle), (typeof f.options === "function" ? f.options() : f.options).map((o) => h("option", { value: o.id }, o.libelle)));
    sel.value = f.valeur || "";
    if (sel.value !== (f.valeur || "")) sel.value = "";
    sel.addEventListener("change", () => {
      f.valeur = sel.value;
      f.surChangement?.(sel.value);
      majBouton();
    });
    return { f, sel, noeud: h("div.filtre", h("label.sr-only", { for: id }, f.libelle), h("div.saisie-select", sel, icone("bas", "ic--p"))) };
  });

  const reinit = h(
    "button.btn.btn--discret.btn--petit",
    { type: "button", hidden: true, onclick: () => {
      entree.value = "";
      for (const s of selects) {
        s.sel.value = "";
        s.f.valeur = "";
      }
      surReinitialiser?.();
      majBouton();
    } },
    icone("fermer", "ic--p"),
    h("span", "Réinitialiser")
  );
  const compte = h("p.barre-filtres__compte", { role: "status", "aria-live": "polite" });

  function actif() {
    return !!entree.value.trim() || selects.some((s) => s.sel.value);
  }
  function majBouton() {
    reinit.hidden = !actif();
  }

  const noeud = h(
    "div.barre-filtres",
    h("div.recherche-liste", icone("recherche", "ic--p"), entree),
    selects.map((s) => s.noeud),
    reinit,
    droite ? h("div.barre-filtres__droite", droite) : null,
    compte
  );
  majBouton();
  return {
    noeud,
    entree,
    definirCompte(texte) {
      compte.textContent = texte;
    },
    maj() {
      for (const s of selects) s.sel.value = s.f.valeur || "";
      majBouton();
    },
  };
}
