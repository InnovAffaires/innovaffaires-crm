/* ==========================================================================
   Créateur de plan d'affaires : éléments d'interface.

   Construit les contrôles de saisie (texte, nombre, choix, cases, mois, listes de lignes,
   démarches) à partir de la description des champs du modèle (plan-modele.js).

   Règles de ce fichier :
   - Aucun innerHTML : tout passe par createElement / textContent, donc rien de ce que la
     personne écrit n'est jamais interprété comme du HTML.
   - Un champ ne connaît pas l'application : il lit et écrit sa valeur par un « accès »
     { get(), set(valeur) } que l'application lui fournit.
   - ES5 : même code partout, sans transpilation.
   ========================================================================== */
(function (g) {
  'use strict';

  var NS = g.PlanAffaires = g.PlanAffaires || {};
  var Calc = NS.Calculs || (typeof require === 'function' ? require('./plan-calculs.js') : null);
  var M = NS.Modele || (typeof require === 'function' ? require('./plan-modele.js') : null);
  var NBSP = ' ';
  var MOINS = '−';

  function doc() { return g.document; }
  function a(o, k) { return Object.prototype.hasOwnProperty.call(o, k); }

  /* ---------- Construction d'éléments ---------- */
  function ajouter(parent, enfants) {
    if (enfants === undefined || enfants === null || enfants === false) return parent;
    if (!Array.isArray(enfants)) enfants = [enfants];
    enfants.forEach(function (c) {
      if (c === undefined || c === null || c === false) return;
      if (Array.isArray(c)) { ajouter(parent, c); return; }
      parent.appendChild(typeof c === 'object' ? c : doc().createTextNode(String(c)));
    });
    return parent;
  }
  /* h('div', { class: 'x', id: 'y', onclick: fn }, [enfants]) : les valeurs null, undefined et false sont ignorées.
     Les attributs « on… » n'acceptent que des fonctions : jamais de texte exécutable. */
  function h(tag, props, enfants) {
    var n = doc().createElement(tag);
    if (props) {
      Object.keys(props).forEach(function (k) {
        var v = props[k];
        if (v === null || v === undefined || v === false) return;
        if (k === 'class') n.className = v;
        else if (k === 'texte') n.textContent = v;
        else if (k.slice(0, 2) === 'on') { if (typeof v === 'function') n.addEventListener(k.slice(2), v); }
        else n.setAttribute(k, v === true ? '' : String(v));
      });
    }
    return ajouter(n, enfants);
  }

  var SVG_NS = 'http://www.w3.org/2000/svg';
  var ICONES = {
    haut: 'M6 15l6-6 6 6',
    bas: 'M6 9l6 6 6-6',
    croix: 'M6 6l12 12M18 6L6 18',
    plus: 'M12 5v14M5 12h14',
    gauche: 'M15 6l-6 6 6 6',
    droite: 'M9 6l6 6-6 6',
    coche: 'M4 13l5.5 5.5L22 4',
    imprimer: 'M7 9V3h10v6M7 17H4v-7h16v7h-3M7 14h10v7H7z',
    telecharger: 'M12 4v11m0 0l-4-4m4 4l4-4M5 20h14',
    televerser: 'M12 16V5m0 0L8 9m4-4l4 4M5 20h14',
    oeil: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 9a3 3 0 100 6 3 3 0 000-6z',
    externe: 'M14 4h6v6M20 4l-9 9M18 14v5H5V6h5',
    corbeille: 'M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3',
    fichier: 'M6 3h8l4 4v14H6zM14 3v4h4M9 13h6M9 17h6',
    info: 'M12 8h.01M11 12h1v5h1M12 3a9 9 0 100 18 9 9 0 000-18z'
  };
  function icone(nom, classe) {
    var svg = doc().createElementNS(SVG_NS, 'svg');
    svg.setAttribute('class', 'ic' + (classe ? ' ' + classe : ''));
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('fill', 'none');
    svg.setAttribute('stroke', 'currentColor');
    svg.setAttribute('stroke-width', '2');
    svg.setAttribute('stroke-linecap', 'round');
    svg.setAttribute('stroke-linejoin', 'round');
    svg.setAttribute('aria-hidden', 'true');
    svg.setAttribute('focusable', 'false');
    var p = doc().createElementNS(SVG_NS, 'path');
    p.setAttribute('d', ICONES[nom] || '');
    svg.appendChild(p);
    return svg;
  }

  var compteur = 0;
  function uid(prefixe) { compteur++; return (prefixe || 'p') + compteur; }

  /* ---------- Nombres saisis à la française ---------- */
  /* 1250.5 → « 1 250,5 » (espaces insécables, virgule, au plus maxDec décimales, sans zéros inutiles) */
  function formaterNombre(n, maxDec, completer) {
    if (typeof n !== 'number' || !isFinite(n)) return '';
    var neg = n < 0;
    var s = Math.abs(n).toFixed(maxDec || 0);
    // Les montants à décimales gardent toutes leurs décimales (12,50) ; les autres nombres perdent les zéros inutiles (12,5).
    if (s.indexOf('.') !== -1 && !(completer && Math.abs(n) % 1 !== 0)) s = s.replace(/0+$/, '').replace(/\.$/, '');
    var parts = s.split('.');
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, NBSP);
    return (neg ? MOINS : '') + parts[0] + (parts[1] ? ',' + parts[1] : '');
  }

  /* Lit ce que la personne a tapé dans un champ numérique.
     → { vide: true } | { message } | { valeur } */
  function lireSaisie(c, texte) {
    var t = String(texte === undefined || texte === null ? '' : texte).trim();
    if (t === '') return { vide: true };
    var n = Calc.lireNombre(t);
    if (n === null) {
      return { message: c.type === 'entier' ? 'Entrez un nombre entier, par exemple 12.' : c.type === 'pct' ? 'Entrez un pourcentage, par exemple 12,5.' : 'Entrez un montant, par exemple 1' + NBSP + '250,50.' };
    }
    if (c.type === 'argent') {
      if (n < 0) return { message: 'Le montant ne peut pas être négatif.' };
      if (n > 1e9) return { message: 'Ce montant est trop élevé.' };
      return { valeur: Math.round(n * 100) / 100 };
    }
    if (c.type === 'pct') {
      var mn = c.min !== undefined ? c.min : -100, mx = c.max !== undefined ? c.max : 1000;
      if (n < mn || n > mx) return { message: 'Entrez un pourcentage entre ' + formaterNombre(mn, 0) + NBSP + '% et ' + formaterNombre(mx, 0) + NBSP + '%.' };
      return { valeur: Math.round(n * 100) / 100 };
    }
    // entier
    if (Math.floor(n) !== n) return { message: 'Entrez un nombre entier, sans décimales.' };
    var emin = c.min !== undefined ? c.min : 0, emax = c.max !== undefined ? c.max : 1e6;
    if (n < emin || n > emax) return { message: 'Entrez un nombre entre ' + formaterNombre(emin, 0) + ' et ' + formaterNombre(emax, 0) + '.' };
    return { valeur: n };
  }

  /* ---------- Enveloppe commune : étiquette, aide, exemple, erreur ---------- */
  function etiquetteDe(c) {
    var enfants = [c.etiquette];
    if (c.facultatif) enfants.push(' ', h('small', null, '(facultatif)'));
    return enfants;
  }
  function blocAide(c, id) {
    var enfants = [];
    if (c.aide) enfants.push(h('span', { 'class': 'champ__aide-texte' }, c.aide));
    if (c.exemple) enfants.push(h('span', { 'class': 'champ__exemple' }, 'Exemple' + NBSP + ': ' + c.exemple));
    return enfants.length ? h('div', { 'class': 'champ__aide', id: id + '-aide' }, enfants) : null;
  }
  function blocErreur(id) { return h('div', { 'class': 'erreur', id: id + '-err', 'aria-live': 'polite' }); }
  function decrire(controle, id, aAide) {
    controle.setAttribute('aria-describedby', (aAide ? id + '-aide ' : '') + id + '-err');
  }
  function enveloppe(c, id, controle, o) {
    o = o || {};
    var aide = blocAide(c, id);
    var err = blocErreur(id);
    decrire(o.cibleDescription || controle, id, !!aide);
    var etiquette = h('label', { 'for': o.pour || id }, etiquetteDe(c));
    var champ = h('div', { 'class': 'champ' + (o.classe ? ' ' + o.classe : '') + (c.col ? ' col-' + (c.col <= 3 ? 'petit' : c.col <= 6 ? 'moyen' : 'grand') : ''), 'data-champ': c.cle }, [
      etiquette, aide, o.avant || null, controle, o.apres || null, err
    ]);
    if (c.col) champ.style.setProperty('--col', String(c.col));
    return { noeud: champ, err: err, controle: controle };
  }
  function montrerErreur(rep, message) {
    rep.err.textContent = message || '';
    if (message) rep.controle.setAttribute('aria-invalid', 'true'); else rep.controle.removeAttribute('aria-invalid');
  }

  /* ---------- Champs ---------- */
  function champTexte(c, acces, id) {
    var inp = h('input', { type: 'text', id: id, maxlength: c.max || M.MAX_TEXTE, autocomplete: 'off' });
    inp.value = acces.get() || '';
    inp.addEventListener('input', function () { acces.set(inp.value); });
    return enveloppe(c, id, inp);
  }

  function champLong(c, acces, id) {
    var max = c.max || (c.court ? M.MAX_COURT : M.MAX_LONG);
    var ta = h('textarea', { id: id, maxlength: max, rows: c.court ? 2 : 4, 'data-auto': '1' });
    ta.value = acces.get() || '';
    var cpt = h('div', { 'class': 'champ__compteur', 'aria-hidden': 'true' });
    function compter() {
      var n = ta.value.length;
      cpt.textContent = formaterNombre(n, 0) + ' / ' + formaterNombre(max, 0);
      cpt.className = 'champ__compteur' + (n >= max * 0.9 ? ' champ__compteur--plein' : '');
    }
    compter();
    ta.addEventListener('input', function () { acces.set(ta.value); compter(); ajusterTextarea(ta); });
    return enveloppe(c, id, ta, { apres: cpt });
  }

  function ajusterTextarea(ta) {
    if (!ta || !ta.style) return;
    ta.style.height = 'auto';
    var h2 = ta.scrollHeight;
    if (h2 > 0) ta.style.height = Math.min(h2 + 2, 520) + 'px';
  }
  function ajusterTextareas(racine) {
    var liste = racine.querySelectorAll('textarea[data-auto]');
    for (var i = 0; i < liste.length; i++) ajusterTextarea(liste[i]);
  }

  function champNombre(c, acces, id) {
    var maxDec = c.type === 'entier' ? 0 : 2;
    var inp = h('input', { type: 'text', id: id, inputmode: c.type === 'entier' ? 'numeric' : 'decimal', autocomplete: 'off', 'class': 'nombre', 'data-unite': c.unite || null });
    var rep;
    function afficher() {
      var v = acces.get();
      if ((v === null || v === undefined) && c.type === 'entier' && c.defaut !== undefined) v = c.defaut;
      inp.value = (v === null || v === undefined) ? '' : formaterNombre(v, maxDec, c.type === 'argent');
    }
    afficher();
    inp.addEventListener('input', function () {
      var r = lireSaisie(c, inp.value);
      if (r.vide) { montrerErreur(rep, ''); acces.set(null); }
      else if (r.message) montrerErreur(rep, r.message);
      else { montrerErreur(rep, ''); acces.set(r.valeur); }
    });
    inp.addEventListener('blur', function () {
      var r = lireSaisie(c, inp.value);
      if (r.message) return; // l'erreur reste affichée : la personne la corrige
      if (r.vide && c.type === 'entier' && c.defaut !== undefined) acces.set(c.defaut);
      afficher();
    });
    var cible = inp;
    var unite = c.unite ? h('span', { 'class': 'saisie__unite', 'aria-hidden': 'true' }, c.unite) : null;
    var boite = h('div', { 'class': 'saisie' + (unite ? ' saisie--unite' : '') }, [inp, unite]);
    rep = enveloppe(c, id, boite, { cibleDescription: cible, pour: id });
    rep.controle = inp;
    return rep;
  }

  function optionsDe(c, valeur) {
    var out = [];
    var aPlaceholder = !c.numerique && c.defaut === undefined;
    if (aPlaceholder) out.push(h('option', { value: '' }, 'Choisir…'));
    c.options.forEach(function (o) { out.push(h('option', { value: String(o.v) }, o.l)); });
    return out;
  }
  function champChoix(c, acces, id) {
    var sel = h('select', { id: id }, optionsDe(c));
    var v = acces.get();
    sel.value = v === null || v === undefined ? '' : String(v);
    if (sel.value !== (v === null || v === undefined ? '' : String(v))) sel.value = c.numerique ? String(c.options[0].v) : '';
    sel.addEventListener('change', function () { acces.set(c.numerique ? Number(sel.value) : sel.value); });
    return enveloppe(c, id, sel);
  }

  function champCoche(c, acces, id) {
    var inp = h('input', { type: 'checkbox', id: id });
    inp.checked = acces.get() === true;
    inp.addEventListener('change', function () { acces.set(inp.checked); });
    var aide = blocAide(c, id);
    if (aide) inp.setAttribute('aria-describedby', id + '-aide');
    return { noeud: h('div', { 'class': 'champ champ--case', 'data-champ': c.cle }, [inp, h('label', { 'for': id }, c.etiquette), aide]), controle: inp };
  }

  function champCases(c, acces, id) {
    var courant = (acces.get() || []).slice();
    var entrees = [];
    var boites = c.options.map(function (o, i) {
      var cid = id + '-' + i;
      var inp = h('input', { type: 'checkbox', id: cid, value: o.v });
      inp.checked = courant.indexOf(o.v) !== -1;
      entrees.push(inp);
      inp.addEventListener('change', function () {
        acces.set(c.options.filter(function (x, k) { return entrees[k].checked; }).map(function (x) { return x.v; }));
      });
      return h('div', { 'class': 'champ champ--case' }, [inp, h('label', { 'for': cid }, o.l)]);
    });
    var aide = blocAide(c, id);
    var fs = h('fieldset', { 'class': 'champ champ--cases', 'data-champ': c.cle, 'aria-describedby': aide ? id + '-aide' : null }, [
      h('legend', null, etiquetteDe(c)), aide, h('div', { 'class': 'cases-grille' }, boites)
    ]);
    return { noeud: fs, controle: fs };
  }

  /* Mois : deux listes (mois, année). La valeur ne s'enregistre que lorsque les deux sont choisies. */
  function champMois(c, acces, id) {
    var maintenant = new Date();
    var anneeCourante = maintenant.getFullYear(), moisCourant = maintenant.getMonth() + 1;
    var val = Calc.lireMois(acces.get());
    var annees = [];
    for (var y = anneeCourante - 3; y <= anneeCourante + 5; y++) annees.push(y);
    if (val && annees.indexOf(val.annee) === -1) { annees.push(val.annee); annees.sort(); }
    var selM = h('select', { id: id + '-m', 'aria-label': c.etiquette + ' : mois' }, [h('option', { value: '' }, 'Mois')].concat(M.MOIS_NOMS.map(function (n, i) { return h('option', { value: String(i + 1) }, n); })));
    var selA = h('select', { id: id + '-a', 'aria-label': c.etiquette + ' : année' }, [h('option', { value: '' }, 'Année')].concat(annees.map(function (n) { return h('option', { value: String(n) }, String(n)); })));
    if (val) { selM.value = String(val.mois); selA.value = String(val.annee); }
    function maj(modifie) {
      if (modifie === 'm' && selM.value && !selA.value) {
        // Année par défaut : la prochaine occurrence de ce mois.
        selA.value = String(parseInt(selM.value, 10) >= moisCourant ? anneeCourante : anneeCourante + 1);
      }
      if (selM.value && selA.value) acces.set(selA.value + '-' + (selM.value.length < 2 ? '0' : '') + selM.value);
      else acces.set('');
    }
    selM.addEventListener('change', function () { maj('m'); });
    selA.addEventListener('change', function () { maj('a'); });
    var aide = blocAide(c, id);
    var err = blocErreur(id);
    var groupe = h('div', { 'class': 'champ champ--mois', role: 'group', 'aria-labelledby': id + '-lib', 'aria-describedby': (aide ? id + '-aide ' : '') + id + '-err', 'data-champ': c.cle }, [
      h('span', { 'class': 'champ__etiquette', id: id + '-lib' }, etiquetteDe(c)), aide, h('div', { 'class': 'mois-duo' }, [selM, selA]), err
    ]);
    return { noeud: groupe, controle: selM };
  }

  /* Répartiteur */
  function champ(c, acces, o) {
    o = o || {};
    var id = o.id || uid('c');
    switch (c.type) {
      case 'texte': return champTexte(c, acces, id);
      case 'long': return champLong(c, acces, id);
      case 'argent': case 'pct': case 'entier': return champNombre(c, acces, id);
      case 'choix': return champChoix(c, acces, id);
      case 'coche': return champCoche(c, acces, id);
      case 'cases': return champCases(c, acces, id);
      case 'mois': return champMois(c, acces, id);
      case 'liste': return liste(c, acces, o);
      case 'demarches': return demarches(c, acces, o);
      default: return null;
    }
  }

  /* ---------- Listes de lignes ---------- */
  function trouverLigne(arr, id) {
    for (var i = 0; i < arr.length; i++) if (arr[i].id === id) return arr[i];
    return null;
  }
  function estPret(type) { return !!Calc.TYPES_PRET[type]; }

  /* c : champ « liste » du modèle ; acces.get() renvoie le tableau de lignes (modifié sur place).
     o : { changer(), apres({ type: 'ajout' | 'suppression' | 'deplacement' | 'suggestions', cle, id, index, ligne, sens }) } */
  function liste(c, acces, o) {
    var id = o.id || uid('l');
    var arr = acces.get();
    var min = c.min || 0, max = c.max || 30;
    var compacte = c.disposition === 'compacte';
    var nom = c.titreLigne || 'Ligne';
    var ol = h('ol', { 'class': 'lignes' + (compacte ? ' lignes--compacte' : ''), role: 'list' });

    arr.forEach(function (ligne, i) {
      var titreId = id + '-t' + i;
      var champs = h('div', { 'class': 'ligne__champs' });
      var pretCibles = [];
      c.sous.forEach(function (s) {
        var accesLigne = {
          get: function () { return ligne[s.cle]; },
          set: function (v) {
            ligne[s.cle] = v;
            if (s.cle === 'type' && c.cle === 'sources') majPret();
            o.changer();
          }
        };
        var rep = champ(s, accesLigne, { id: id + '-' + i + '-' + s.cle });
        if (!rep) return;
        if (s.pret) pretCibles.push(rep.noeud);
        champs.appendChild(rep.noeud);
      });
      function majPret() {
        var affiche = estPret(ligne.type);
        pretCibles.forEach(function (n) { n.hidden = !affiche; });
      }
      if (c.cle === 'sources') majPret();

      var outils = h('div', { 'class': 'ligne__outils' }, [
        bouton('haut', 'Monter la ligne ' + (i + 1) + ' (' + nom + ')', i === 0, function () { deplacer(i, -1); }, 'monter-' + ligne.id),
        bouton('bas', 'Descendre la ligne ' + (i + 1) + ' (' + nom + ')', i === arr.length - 1, function () { deplacer(i, 1); }, 'descendre-' + ligne.id),
        bouton('croix', 'Supprimer la ligne ' + (i + 1) + ' (' + nom + ')', arr.length <= min, function () { supprimer(i); }, 'supprimer-' + ligne.id)
      ]);
      ol.appendChild(h('li', { 'class': 'ligne', 'data-ligne': ligne.id }, [
        h('div', { role: 'group', 'aria-labelledby': titreId }, [
          h('div', { 'class': 'ligne__tete' }, [h('span', { 'class': 'ligne__titre', id: titreId }, nom + ' ' + (i + 1)), outils]),
          champs
        ])
      ]));
    });

    function bouton(ic, etiquette, desactive, fn, focus) {
      return h('button', { type: 'button', 'class': 'btn-icone', 'aria-label': etiquette, title: etiquette, disabled: desactive, 'data-focus': focus, onclick: fn }, [icone(ic)]);
    }
    function deplacer(i, sens) {
      var j = i + sens;
      if (j < 0 || j >= arr.length) return;
      var x = arr[i]; arr[i] = arr[j]; arr[j] = x;
      o.apres({ type: 'deplacement', cle: c.cle, id: x.id, sens: sens });
    }
    function supprimer(i) {
      if (arr.length <= min) return;
      var retiree = arr.splice(i, 1)[0];
      o.apres({ type: 'suppression', cle: c.cle, index: i, ligne: retiree });
    }
    function ajouterLigne(defauts) {
      var l = M.ligne(c, defauts);
      arr.push(l);
      return l;
    }

    var plein = arr.length >= max;
    var bAjouter = h('button', { type: 'button', 'class': 'btn btn--contour btn--petit', disabled: plein, 'data-focus': 'ajouter-' + c.cle, onclick: function () {
      var l = ajouterLigne();
      o.apres({ type: 'ajout', cle: c.cle, id: l.id });
    } }, [icone('plus'), c.ajouter || 'Ajouter']);
    var pied = [bAjouter];
    if (c.suggestions) {
      pied.push(h('button', { type: 'button', 'class': 'btn btn--contour btn--petit', disabled: plein, onclick: function () {
        var cle = c.suggestions === 'risques' ? 'desc' : 'action';
        var existants = arr.map(function (l) { return String(l[cle] || '').trim(); });
        var ajoutees = [];
        M.suggestions(c.suggestions).forEach(function (sug) {
          if (arr.length >= max || existants.indexOf(sug[cle]) !== -1) return;
          // Une ligne vide du départ est réutilisée avant d'en ajouter une nouvelle.
          var vide = null;
          for (var k = 0; k < arr.length; k++) if (!String(arr[k][cle] || '').trim()) { vide = arr[k]; break; }
          if (vide) { Object.keys(sug).forEach(function (kk) { vide[kk] = sug[kk]; }); ajoutees.push(vide.id); }
          else ajoutees.push(ajouterLigne(sug).id);
        });
        o.apres({ type: 'suggestions', cle: c.cle, ids: ajoutees });
      } }, [icone('plus'), 'Ajouter des suggestions']));
    }
    pied.push(h('span', { 'class': 'lignes__compte' }, arr.length + ' sur ' + max + (plein ? ' (maximum atteint)' : '')));

    var aide = c.aide ? h('p', { 'class': 'champ__aide lignes__aide', id: id + '-aide' }, c.aide) : null;
    var fs = h('div', { 'class': 'liste', 'data-liste': c.cle, role: 'group', 'aria-labelledby': id + '-lib', 'aria-describedby': aide ? id + '-aide' : null }, [
      h('h3', { 'class': 'liste__titre', id: id + '-lib' }, etiquetteDe(c)), aide, ol, h('div', { 'class': 'liste__pied' }, pied)
    ]);
    return { noeud: fs, controle: bAjouter };
  }

  /* ---------- Démarches de démarrage ---------- */
  function demarches(c, acces, o) {
    var id = o.id || uid('d');
    var etats = acces.get();
    var lignes = M.DEMARCHES.map(function (d, i) {
      var sid = id + '-' + i;
      var sel = h('select', { id: sid, 'aria-describedby': sid + '-detail' }, M.STATUTS_DEMARCHE.map(function (s) { return h('option', { value: s.v }, s.l); }));
      sel.value = etats[d.id] || 'afaire';
      sel.addEventListener('change', function () { etats[d.id] = sel.value; o.changer(); });
      var detail = [];
      if (d.detail) detail.push(h('span', null, d.detail));
      if (d.lien && /^https:\/\//.test(d.lien.url)) {
        detail.push(' ', h('a', { href: d.lien.url, target: '_blank', rel: 'noopener noreferrer' }, [d.lien.texte, h('span', { 'class': 'sr-only' }, ' (s’ouvre dans un nouvel onglet)')]));
      }
      return h('li', { 'class': 'demarche' }, [
        h('div', { 'class': 'demarche__texte' }, [h('label', { 'for': sid, 'class': 'demarche__titre' }, d.titre), h('p', { 'class': 'demarche__detail', id: sid + '-detail' }, detail)]),
        h('div', { 'class': 'demarche__etat' }, [sel])
      ]);
    });
    var aide = c.aide ? h('p', { 'class': 'champ__aide', id: id + '-aide' }, c.aide) : null;
    return {
      noeud: h('div', { 'class': 'demarches', 'data-liste': c.cle, role: 'group', 'aria-labelledby': id + '-lib' }, [
        h('h3', { 'class': 'liste__titre', id: id + '-lib' }, c.etiquette), aide, h('ul', { 'class': 'demarches__liste', role: 'list' }, lignes)
      ])
    };
  }

  var UI = {
    h: h, ajouter: ajouter, icone: icone, uid: uid,
    formaterNombre: formaterNombre, lireSaisie: lireSaisie,
    champ: champ, liste: liste, demarches: demarches, trouverLigne: trouverLigne,
    ajusterTextarea: ajusterTextarea, ajusterTextareas: ajusterTextareas, montrerErreur: montrerErreur, enveloppe: enveloppe
  };
  NS.UI = UI;
  if (typeof module !== 'undefined' && module.exports) module.exports = UI;
})(typeof window !== 'undefined' ? window : globalThis);
