/* ==========================================================================
   Créateur de plan d'affaires : composition du document.

   À partir des réponses (plan-modele.js) et des résultats (plan-calculs.js), compose un
   « modèle de document » neutre : une liste de blocs (titres, paragraphes, listes, tableaux,
   graphiques…). Le même modèle sert à l'aperçu à l'écran, à l'impression (PDF) et au fichier
   Word (plan-export.js) : les trois affichent donc exactement les mêmes chiffres.

   Blocs :
     { t:'couverture', surtitre, titre, lignes:[…], date, mention }
     { t:'h1', texte, saut? }  { t:'h2', texte }
     { t:'p', texte }          (les retours à la ligne « \n » sont conservés)
     { t:'liste', items:[…], ordonnee? }
     { t:'tableau', titre, colonnes:[{ t, a:'g'|'d'|'c', l }], lignes:[ [cellules] | { c:[…], s:'total'|'titre'|'sous' } ], note? }
     { t:'kv', lignes:[[libellé, valeur]] }
     { t:'graphique', id, titre, description }
     { t:'note', texte }       { t:'aCompleter', texte, etape }

   Les textes saisis par la personne ne sont jamais interprétés : ils sont insérés comme texte
   (textContent côté navigateur, échappement côté chaîne).
   ========================================================================== */
(function (g) {
  'use strict';

  var NS = g.PlanAffaires = g.PlanAffaires || {};
  var Calc = NS.Calculs || (typeof require === 'function' ? require('./plan-calculs.js') : null);
  var M = NS.Modele || (typeof require === 'function' ? require('./plan-modele.js') : null);

  var NBSP = '\u00a0';
  var T = M.T;
  var MOIS_COURTS = ['janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juill.', 'août', 'sept.', 'oct.', 'nov.', 'déc.'];

  /* ---------- Outils de texte et de nombres ---------- */
  function t(v) { return typeof v === 'string' ? v.trim() : ''; }
  function lib(options, v) {
    for (var i = 0; i < options.length; i++) if (options[i].v === v) return options[i].l;
    return '';
  }
  function fois(n) { return Calc.decimal(n, 1) + NBSP + 'fois'; }
  /* Prix avec cents seulement s'il y en a : 95 $, 29,99 $. */
  function prix(n) {
    if (typeof n !== 'number' || !isFinite(n)) return '—';
    if (Math.abs(n - Math.round(n)) < 0.005) return Calc.argent(n);
    var s;
    try { s = new Intl.NumberFormat('fr-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(Math.abs(n)); } catch (e) { s = Math.abs(n).toFixed(2).replace('.', ','); }
    return (n < 0 ? '−' : '') + s + NBSP + '$';
  }
  function quantite(n) { return Calc.entier(Math.round(n)); }

  function jourMois(d) {
    var j = d.getDate();
    return (j === 1 ? '1er' : String(j)) + ' ' + M.MOIS_NOMS[d.getMonth()] + ' ' + d.getFullYear();
  }

  /* Mois d'exploitation m (1 à 36) → { mois: 0 à 11, annee } ; null si le début des ventes est inconnu. */
  function moisDe(debut, m) {
    if (!debut) return null;
    var idx = debut.mois - 1 + (m - 1);
    return { mois: idx % 12, annee: debut.annee + Math.floor(idx / 12) };
  }
  function etiquetteMois(debut, m) {
    if (m === 0) return 'avant l’ouverture';
    var x = moisDe(debut, m);
    return x ? M.MOIS_NOMS[x.mois] + ' ' + x.annee : 'mois ' + m;
  }
  /* En-tête de colonne mensuelle sur deux lignes : « avr. » / « 2027 ». */
  function enteteMois(debut, m) {
    var x = moisDe(debut, m);
    return x ? MOIS_COURTS[x.mois] + '\n' + x.annee : 'Mois\n' + m;
  }
  /* « avr. 2027 – mars 2028 » pour l'année d'exploitation an (1 à 3). */
  function periodeAn(debut, an) {
    var a = moisDe(debut, 12 * (an - 1) + 1), b = moisDe(debut, 12 * an);
    if (!a) return '';
    return MOIS_COURTS[a.mois] + ' ' + a.annee + ' – ' + MOIS_COURTS[b.mois] + ' ' + b.annee;
  }
  function enteteAn(debut, an) {
    var p = periodeAn(debut, an);
    return 'Année ' + an + (p ? '\n' + p : '');
  }

  function fichierBase(nom) {
    var s = t(nom).toLowerCase();
    try { s = s.normalize('NFD').replace(/[̀-ͯ]/g, ''); } catch (e) { /* ancien navigateur : on garde les accents retirés plus bas */ }
    s = s.replace(/\(.*?\)/g, ' ').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40).replace(/-+$/g, '');
    return 'plan-affaires' + (s ? '-' + s : '');
  }

  /* ---------- Texte libre → blocs (paragraphes et listes) ---------- */
  function texteVersBlocs(texte) {
    var s = String(texte === null || texte === undefined ? '' : texte).replace(/\r\n?/g, '\n').trim();
    if (!s) return [];
    var blocs = [];
    s.split(/\n{2,}/).forEach(function (par) {
      var courant = null; // { type: 'p' | 'ul' | 'ol', lignes: [] }
      var fermer = function () {
        if (!courant) return;
        if (courant.type === 'p') blocs.push({ t: 'p', texte: courant.lignes.join('\n') });
        else blocs.push({ t: 'liste', items: courant.lignes, ordonnee: courant.type === 'ol' });
        courant = null;
      };
      par.split('\n').forEach(function (brut) {
        var l = brut.replace(/\s+$/, '');
        if (!l.trim()) return;
        var puce = /^\s*[-–•*]\s+(\S.*)$/.exec(l);
        var num = /^\s*\d{1,2}[.)]\s+(\S.*)$/.exec(l);
        var type = puce ? 'ul' : num ? 'ol' : 'p';
        var contenu = puce ? puce[1] : num ? num[1] : l.trim();
        if (!courant || courant.type !== type) { fermer(); courant = { type: type, lignes: [] }; }
        courant.lignes.push(contenu);
      });
      fermer();
    });
    return blocs;
  }

  /* ---------- Arbre d'éléments (rendu sûr : chaîne échappée ou nœuds DOM) ---------- */
  function h(tag, attrs, enfants) {
    return { tag: tag, attrs: attrs || {}, enfants: enfants === undefined ? [] : (Array.isArray(enfants) ? enfants : [enfants]) };
  }
  var VIDES = { br: 1, hr: 1, col: 1, line: 1, path: 1, rect: 1, circle: 1, polyline: 1 };
  var SVG_TAGS = { svg: 1, g: 1, path: 1, line: 1, rect: 1, text: 1, title: 1, desc: 1, polyline: 1, circle: 1, defs: 1, pattern: 1, tspan: 1 };
  var SVG_NS = 'http://www.w3.org/2000/svg';

  function echapper(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function attrValide(nom, val) {
    if (!/^[a-zA-Z][a-zA-Z0-9:-]*$/.test(nom) || /^on/i.test(nom)) return false;
    if ((nom === 'href' || nom === 'xlink:href') && !/^(#|https:\/\/)/.test(String(val))) return false;
    return true;
  }
  function enChaine(n) {
    if (n === null || n === undefined || n === false) return '';
    if (typeof n === 'string' || typeof n === 'number') return echapper(n);
    if (Array.isArray(n)) return n.map(enChaine).join('');
    var a = '';
    Object.keys(n.attrs).forEach(function (k) {
      var v = n.attrs[k];
      if (v === null || v === undefined || v === false || !attrValide(k, v)) return;
      a += ' ' + k + '="' + echapper(v === true ? k : v) + '"';
    });
    if (VIDES[n.tag] && !n.enfants.length) return '<' + n.tag + a + (SVG_TAGS[n.tag] ? ' />' : '>');
    return '<' + n.tag + a + '>' + n.enfants.map(enChaine).join('') + '</' + n.tag + '>';
  }
  function enDom(n, doc) {
    if (n === null || n === undefined || n === false) return doc.createDocumentFragment();
    if (typeof n === 'string' || typeof n === 'number') return doc.createTextNode(String(n));
    if (Array.isArray(n)) {
      var f = doc.createDocumentFragment();
      n.forEach(function (x) { f.appendChild(enDom(x, doc)); });
      return f;
    }
    var el = SVG_TAGS[n.tag] ? doc.createElementNS(SVG_NS, n.tag) : doc.createElement(n.tag);
    Object.keys(n.attrs).forEach(function (k) {
      var v = n.attrs[k];
      if (v === null || v === undefined || v === false || !attrValide(k, v)) return;
      el.setAttribute(k, v === true ? k : String(v));
    });
    n.enfants.forEach(function (c) { el.appendChild(enDom(c, doc)); });
    return el;
  }

  /* Texte avec retours à la ligne → liste de nœuds et de <br>. */
  function lignesTexte(texte) {
    var out = [];
    String(texte).split('\n').forEach(function (l, i) {
      if (i) out.push(h('br'));
      out.push(l);
    });
    return out;
  }

  /* ---------- Fabrique de blocs ---------- */
  function col(titre, a, l) { return { t: T(titre), a: a || 'g', l: l || 1 }; }
  function tableau(titre, colonnes, lignes, note) {
    var b = { t: 'tableau', titre: T(titre), colonnes: colonnes, lignes: lignes };
    if (note) b.note = T(note);
    return b;
  }

  /* ---------- Composition ---------- */
  function composer(etat, options) {
    options = options || {};
    var r = etat.r;
    var baisse = options.baisse !== undefined ? options.baisse : (etat.ui && etat.ui.baisse) || 0;
    var res = Calc.calculer(r, { baisse: baisse });
    var base = res.base;
    var debut = res.entree.debut;
    var date = options.date instanceof Date ? options.date : new Date();
    var mention = options.mention !== undefined ? !!options.mention : !(etat.ui && etat.ui.mention === false);
    var manques = [];
    var blocs = [];
    var numero = 0;

    function ajouter(b) { blocs.push(b); return b; }
    function h1(texte, saut) { numero++; return ajouter({ t: 'h1', texte: numero + '. ' + T(texte), saut: !!saut }); }
    function h2(texte) { return ajouter({ t: 'h2', texte: T(texte) }); }
    function note(texte) { return ajouter({ t: 'note', texte: T(texte) }); }
    function completer(etape, texte) {
      var tx = 'À compléter' + NBSP + ': ' + T(texte);
      manques.push({ etape: etape, texte: T(texte) });
      return ajouter({ t: 'aCompleter', texte: tx, etape: etape });
    }
    /* Texte de la personne : paragraphes ou, s'il manque, une mention « À compléter ». */
    function texteOuManque(valeur, etape, manque) {
      var bl = texteVersBlocs(valeur);
      if (!bl.length) { if (manque) completer(etape, manque); return false; }
      bl.forEach(ajouter);
      return true;
    }
    function section(titre, valeur, etape, manque) {
      if (!t(valeur) && !manque) return;
      h2(titre);
      texteOuManque(valeur, etape, manque);
    }

    var nom = t(r.projet.nom);
    var ventesAn1 = base.annuel.rev[0];
    var aDesVentes = ventesAn1 > 0 || base.annuel.rev[1] > 0 || base.annuel.rev[2] > 0;

    /* ----- Couverture ----- */
    var promoteurs = (r.equipe.promoteurs || []).filter(function (p) { return t(p.nom); }).map(function (p) { return t(p.nom); });
    var lignesCouv = [];
    if (t(r.projet.secteur)) lignesCouv.push(t(r.projet.secteur));
    if (t(r.projet.lieu)) lignesCouv.push(t(r.projet.lieu));
    var forme = lib(M.FORMES, r.projet.forme);
    if (forme && r.projet.forme !== 'inconnue') lignesCouv.push(forme);
    if (promoteurs.length) lignesCouv.push((promoteurs.length > 1 ? 'Promoteurs' : 'Promoteur') + NBSP + ': ' + promoteurs.join(', '));
    ajouter({
      t: 'couverture',
      surtitre: 'Plan d’affaires',
      titre: nom || 'Nom de l’entreprise à compléter',
      lignes: lignesCouv,
      date: jourMois(date),
      mention: mention ? 'Préparé avec le créateur de plan d’affaires d’InnovAffaires (innovaffaires.com)' : ''
    });
    if (!nom) manques.push({ etape: 'projet', texte: 'le nom de l’entreprise' });

    /* ----- 1. Sommaire ----- */
    h1('Sommaire', true);
    if (!texteOuManque(r.sommaire.phrase, 'sommaire', 'résumé de votre projet en quelques phrases')) { /* mention ajoutée */ }
    section('Pourquoi ce projet, et pourquoi maintenant', r.sommaire.pourquoi, 'sommaire');
    section('Ce que nous demandons', r.sommaire.demande, 'sommaire');
    h2('Chiffres clés');
    if (aDesVentes) {
      var an3 = [0, 1, 2];
      ajouter(tableau('Chiffres clés des trois premières années',
        [col('', 'g', 3), col(enteteAn(debut, 1), 'd', 2), col(enteteAn(debut, 2), 'd', 2), col(enteteAn(debut, 3), 'd', 2)],
        [
          ['Ventes'].concat(an3.map(function (i) { return Calc.argent(base.annuel.rev[i]); })),
          ['Marge brute'].concat(an3.map(function (i) { return Calc.argent(base.annuel.margeBrute[i]); })),
          { c: ['Résultat avant impôts'].concat(an3.map(function (i) { return Calc.argent(base.annuel.resultat[i]); })), s: 'total' },
          ['Trésorerie en fin d’année'].concat(an3.map(function (i) { return Calc.argent(base.annuel.soldeFin[i]); }))
        ]));
      var kvCles = [];
      if (debut) kvCles.push(['Début des ventes', etiquetteMois(debut, 1)]);
      kvCles.push(['Dépenses de démarrage', Calc.argent(res.besoin.utilisations)]);
      kvCles.push(['Financement prévu', Calc.argent(res.besoin.sources) + (res.besoin.nonConfirme > 0 ? ' (dont ' + Calc.argent(res.besoin.nonConfirme) + ' non confirmé)' : '')]);
      if (base.annuel.seuil[0] !== null) kvCles.push(['Seuil de rentabilité, année 1', Calc.argent(base.annuel.seuil[0]) + ' de ventes']);
      ajouter({ t: 'kv', lignes: kvCles });
    } else {
      completer('ventes', 'ventes prévues (étape Ventes) : les chiffres clés s’afficheront ici');
    }

    /* ----- 2. Le projet ----- */
    h1('Le projet');
    var id = [];
    id.push(['Entreprise', nom || 'À compléter']);
    if (forme && r.projet.forme !== 'inconnue') id.push(['Forme juridique envisagée', forme]);
    if (t(r.projet.secteur)) id.push(['Secteur d’activité', t(r.projet.secteur)]);
    if (t(r.projet.lieu)) id.push(['Territoire', t(r.projet.lieu)]);
    if (lib(M.STADES, r.projet.stade)) id.push(['Stade du projet', lib(M.STADES, r.projet.stade)]);
    if (debut) id.push(['Début prévu des ventes', etiquetteMois(debut, 1)]);
    ajouter({ t: 'kv', lignes: id });
    if (!debut) completer('projet', 'mois de début des ventes');
    section('Description de l’entreprise', r.projet.mission, 'projet', 'description de l’entreprise');
    section('Besoin auquel l’entreprise répond', r.projet.probleme, 'projet', 'problème ou besoin auquel vous répondez');
    section('Objectifs des douze premiers mois', r.projet.objectifs, 'projet', 'objectifs des douze premiers mois');
    section('Vision à trois ans', r.projet.vision, 'projet');

    /* ----- 3. Produits et services ----- */
    h1('Produits et services');
    var offres = (r.offre.lignes || []).filter(function (l) { return t(l.nom) || (typeof l.prix === 'number' && l.prix > 0); });
    if (offres.length) {
      ajouter(tableau('Produits et services offerts',
        [col('Offre', 'g', 4), col('Unité', 'g', 1.4), col('Prix', 'd', 1.3), col('Coût direct', 'd', 1.3), col('Marge par unité', 'd', 2)],
        offres.map(function (l) {
          var p = typeof l.prix === 'number' ? l.prix : null, c = typeof l.cout === 'number' ? l.cout : 0;
          var marge = p === null ? '—' : prix(p - c) + (p > 0 ? ' (' + Calc.pourcent((p - c) / p, true) + ')' : '');
          return [t(l.nom) + (t(l.description) ? '\n' + t(l.description) : '') || 'Sans nom', t(l.unite), p === null ? '—' : prix(p), prix(c), marge];
        }),
        'Prix avant taxes. Le coût direct est ce que chaque vente coûte en matériel, pièces ou sous-traitance. La marge par unité est le prix moins le coût direct; la marge brute de l’état des résultats déduit aussi les frais de transaction.'));
    } else {
      completer('offre', 'produits et services offerts, avec leurs prix');
    }
    section('Ce qui distingue l’offre', r.offre.avantage, 'offre', 'ce qui distingue votre offre');
    section('Marque, savoir-faire et droits à protéger', r.offre.pi, 'offre');

    /* ----- 4. Le marché ----- */
    h1('Le marché');
    section('Clientèle visée', r.marche.clientele, 'marche', 'description de vos clients types');
    var segments = (r.marche.segments || []).filter(function (s) { return t(s.nom); });
    if (segments.length) {
      ajouter(tableau('Segments de clientèle',
        [col('Segment', 'g', 2), col('Taille estimée', 'g', 2), col('Description', 'g', 4)],
        segments.map(function (s) { return [t(s.nom), t(s.taille) || '—', t(s.qui) || '—']; })));
    }
    section('Taille du marché et territoire visé', r.marche.taille, 'marche', 'taille du marché et territoire visé');
    section('Tendances du secteur', r.marche.tendances, 'marche');
    section('Vérification de l’intérêt des clients', r.marche.validation, 'marche', 'démarches faites pour vérifier l’intérêt des clients');

    /* ----- 5. La concurrence ----- */
    h1('La concurrence');
    var concurrents = (r.concurrence.concurrents || []).filter(function (c) { return t(c.nom); });
    if (concurrents.length) {
      ajouter(tableau('Comparaison avec les concurrents',
        [col('Concurrent', 'g', 2), col('Offre', 'g', 2.5), col('Prix', 'g', 1.8), col('Forces', 'g', 2.2), col('Faiblesses', 'g', 2.2)],
        concurrents.map(function (c) { return [t(c.nom), t(c.offre) || '—', t(c.prix) || '—', t(c.forces) || '—', t(c.faiblesses) || '—']; })));
    }
    if (concurrents.length < 3) completer('concurrence', 'au moins trois concurrents comparés');
    section('Positionnement', r.concurrence.positionnement, 'concurrence', 'façon dont vous vous démarquez');
    section('Concurrence indirecte et solutions de rechange', r.concurrence.indirecte, 'concurrence');

    /* ----- 6. Mise en marché ----- */
    h1('Mise en marché');
    section('Proposition de valeur', r.marketing.valeur, 'marketing', 'proposition de valeur');
    section('Établissement des prix', r.marketing.prix, 'marketing');
    var canaux = (r.marketing.canaux || []).map(function (v) { return lib(M.CANAUX, v); }).filter(Boolean);
    h2('Ventes');
    if (canaux.length) ajouter({ t: 'liste', items: canaux, ordonnee: false }); else completer('marketing', 'canaux de vente');
    texteVersBlocs(r.marketing.canauxDetail).forEach(ajouter);
    var promos = (r.marketing.promo || []).map(function (v) { return lib(M.PROMOS, v); }).filter(Boolean);
    h2('Promotion');
    if (promos.length) ajouter({ t: 'liste', items: promos, ordonnee: false }); else completer('marketing', 'moyens de promotion');
    texteVersBlocs(r.marketing.promoDetail).forEach(ajouter);
    h2('Plan de lancement des 90 premiers jours');
    var actions = (r.marketing.lancement || []).filter(function (a) { return t(a.action); });
    if (actions.length) {
      var lignesLancement = [];
      M.PERIODES.concat([{ v: '', l: 'Période non précisée' }]).forEach(function (p) {
        actions.filter(function (a) { return (a.periode || '') === p.v; }).forEach(function (a) {
          lignesLancement.push([p.l, t(a.action), t(a.resp) || '—']);
        });
      });
      ajouter(tableau('Plan de lancement', [col('Période', 'g', 2), col('Action', 'g', 6), col('Responsable', 'g', 2)], lignesLancement));
    }
    if (actions.length < 3) completer('marketing', 'au moins trois actions de lancement');

    /* ----- 7. Opérations ----- */
    h1('Opérations');
    var local = lib(M.LOCAUX, r.operations.local);
    h2('Lieu de travail');
    if (local) ajouter({ t: 'p', texte: local + '.' }); else completer('operations', 'endroit où vous travaillerez');
    texteVersBlocs(r.operations.lieu).forEach(ajouter);
    section('Équipement, logiciels et technologies', r.operations.equipement, 'operations');
    section('De la commande à la livraison', r.operations.processus, 'operations', 'façon de livrer votre produit ou service');
    section('Capacité de production', r.operations.capacite, 'operations');
    var fournisseurs = (r.operations.fournisseurs || []).filter(function (f) { return t(f.nom); });
    if (fournisseurs.length) {
      h2('Fournisseurs clés');
      ajouter(tableau('Fournisseurs clés', [col('Fournisseur', 'g', 3), col('Fournit', 'g', 3), col('Délais et conditions', 'g', 4)],
        fournisseurs.map(function (f) { return [t(f.nom), t(f.fournit) || '—', t(f.conditions) || '—']; })));
    }
    h2('Démarches de démarrage');
    ajouter(tableau('État des démarches de démarrage', [col('Démarche', 'g', 7), col('État', 'g', 2)],
      M.DEMARCHES.map(function (d) { return [T(d.titre), lib(M.STATUTS_DEMARCHE, (r.operations.demarches || {})[d.id]) || 'À faire']; })));

    /* ----- 8. Équipe ----- */
    h1('Équipe');
    var promos2 = (r.equipe.promoteurs || []).filter(function (p) { return t(p.nom); });
    if (promos2.length) {
      h2('Promoteurs');
      ajouter(tableau('Promoteurs',
        [col('Nom', 'g', 3), col('Rôle', 'g', 3), col('Part', 'd', 1), col('Rémunération mensuelle', 'd', 2.4)],
        promos2.map(function (p) {
          var remun = typeof p.remun === 'number' && p.remun > 0 ? Calc.argent(p.remun) + ' dès le mois ' + (p.debutRemun || 1) : 'Aucune prévue';
          return [t(p.nom), t(p.role) || '—', typeof p.part === 'number' ? Calc.pourcent(p.part) : '—', remun];
        })));
      promos2.forEach(function (p) {
        if (t(p.exp)) ajouter({ t: 'p', texte: t(p.nom) + NBSP + ': ' + t(p.exp) });
      });
    } else {
      completer('equipe', 'au moins un promoteur');
    }
    var embauches = (r.equipe.employes || []).filter(function (e) { return t(e.poste) || (typeof e.salaire === 'number' && e.salaire > 0); });
    if (embauches.length) {
      h2('Embauches prévues');
      ajouter(tableau('Embauches prévues',
        [col('Poste', 'g', 4), col('Nombre', 'd', 1.2), col('Salaire annuel brut', 'd', 2.2), col('Embauche', 'g', 2.4)],
        embauches.map(function (e) {
          return [t(e.poste) || 'Sans titre', String(e.nombre || 1), typeof e.salaire === 'number' ? Calc.argent(e.salaire) : '—', 'Mois ' + (e.mois || 1) + (debut ? ' (' + etiquetteMois(debut, e.mois || 1) + ')' : '')];
        }),
        'Les charges sociales de l’employeur s’ajoutent au salaire brut.'));
    }
    section('Conseillers et partenaires', r.equipe.conseillers, 'equipe');
    section('Compétences à acquérir ou à embaucher', r.equipe.manques, 'equipe');

    /* ----- 9. Risques ----- */
    h1('Risques');
    var niveau = { faible: 1, moyen: 2, eleve: 3 };
    var risques = (r.risques.liste || []).filter(function (x) { return t(x.desc); }).map(function (x, i) {
      var score = (niveau[x.proba] || 0) * (niveau[x.impact] || 0);
      return { x: x, i: i, score: score };
    });
    risques.sort(function (a, b) { return b.score - a.score || a.i - b.i; });
    if (risques.length) {
      ajouter(tableau('Principaux risques et mesures prévues',
        [col('Risque', 'g', 3.4), col('Probabilité', 'g', 1.4), col('Impact', 'g', 1.2), col('Mesure pour le réduire', 'g', 4)],
        risques.map(function (o) { return [t(o.x.desc), lib(M.NIVEAUX_RISQUE, o.x.proba) || '—', lib(M.NIVEAUX_RISQUE, o.x.impact) || '—', t(o.x.mesure) || '—']; }),
        'Classés du plus important au moins important (probabilité multipliée par impact).'));
    }
    if (risques.length < 3) completer('risques', 'au moins trois risques et les mesures prévues');
    section('Si les ventes sont inférieures aux prévisions', r.risques.planB, 'risques');

    /* ----- 10. Plan financier ----- */
    h1('Plan financier', true);
    note('Tous les montants sont en dollars canadiens, avant taxes de vente (TPS et TVQ), arrondis au dollar. Aucun impôt sur le résultat n’est calculé.');
    planFinancier(ajouter, h2, note, completer, res, r, debut, baisse, aDesVentes);

    /* ----- Avertissement final ----- */
    note('Ce plan contient des prévisions fondées sur les hypothèses de l’entrepreneur. Il ne constitue ni un conseil financier, comptable ou juridique, ni une garantie de résultats : faites valider vos chiffres par un professionnel avant de les présenter à un prêteur.');

    return {
      blocs: blocs,
      meta: {
        nom: nom, titre: 'Plan d’affaires' + (nom ? ' — ' + nom : ''), date: jourMois(date), langue: 'fr-CA',
        fichier: fichierBase(nom), mention: mention, manques: manques, resultats: res
      }
    };
  }

  /* ---------- Plan financier ---------- */
  function planFinancier(ajouter, h2, note, completer, res, r, debut, baisse, aDesVentes) {
    var base = res.base, E = res.entree, an3 = [0, 1, 2];
    var $ = Calc.argent, n = Calc.entier;
    var somme = function (a, de, a2) { var s = 0; for (var i = de; i <= a2; i++) s += a[i]; return s; };
    var enteteAnnees = function (premiere) {
      return [col(premiere || '', 'g', 3.2), col(enteteAn(debut, 1), 'd', 2), col(enteteAn(debut, 2), 'd', 2), col(enteteAn(debut, 3), 'd', 2)];
    };

    /* Hypothèses */
    h2('Hypothèses');
    var fraisDemarrage = E.demarrage.reduce(function (t, x) { return t + x.montant; }, 0);
    var hyp = [];
    if (debut) hyp.push('Première année d’exploitation : ' + M.deMois(etiquetteMois(debut, 1)) + ' à ' + etiquetteMois(debut, 12) + '.');
    hyp.push('Croissance des ventes : ' + Calc.pourcent(E.hyp.g2) + ' à l’année 2 et ' + Calc.pourcent(E.hyp.g3) + ' à l’année 3, par rapport au total de l’année précédente.');
    var saisonVarie = E.saison.some(function (x) { return x !== 100; });
    if (saisonVarie) {
      hyp.push('Variation selon les saisons (indices, 100 = mois moyen) : ' + M.MOIS_NOMS.map(function (nm, i) { return nm + ' ' + Calc.decimal(E.saison[i], 1); }).join(', ') + '.');
    } else {
      hyp.push('Aucune variation saisonnière des ventes n’est prévue.');
    }
    hyp.push('Délai de paiement des clients : ' + (E.hyp.delaiClients === 0 ? 'comptant' : E.hyp.delaiClients + ' jours') + '. Délai de paiement des fournisseurs : ' + (E.hyp.delaiFournisseurs === 0 ? 'comptant' : E.hyp.delaiFournisseurs + ' jours') + '.');
    if (E.hyp.fraisTransaction > 0) hyp.push('Frais de transaction : ' + Calc.pourcent(E.hyp.fraisTransaction) + ' des ventes.');
    if (E.hyp.hausse !== 0) hyp.push('Hausse annuelle des charges et des salaires : ' + Calc.pourcent(E.hyp.hausse) + ' à partir de l’année 2.');
    if (E.employes.length) hyp.push('Charges sociales de l’employeur : ' + Calc.pourcent(E.hyp.chargesSociales) + ' des salaires.');
    if (E.promoteurs.some(function (p) { return p.remun > 0; })) hyp.push('La rémunération des promoteurs reste au même montant pendant les trois années et ne comprend aucune cotisation d’employeur.');
    hyp.push('Les investissements sont amortis en ligne droite sur leur durée de vie.');
    if (fraisDemarrage > 0) hyp.push('Les frais de démarrage (' + $(fraisDemarrage) + ') sont payés avant l’ouverture : ils réduisent la trésorerie de départ, mais ne sont pas déduits du résultat des trois années. Un comptable pourrait les passer en charges dès la première année.');
    if (E.hyp.coussin > 0) hyp.push('Réserve de trésorerie minimale souhaitée : ' + $(E.hyp.coussin) + '.');
    ajouter({ t: 'liste', items: hyp.map(T), ordonnee: false });
    var chargesSaisies = (r.charges.liste || []).some(function (x) { return typeof x.montant === 'number' && x.montant > 0; });
    if (!chargesSaisies && !r.charges.aucune) completer('charges', 'charges fixes mensuelles (étape Charges)');

    /* Budget de démarrage */
    h2('Budget de démarrage');
    var invest = (r.financement.invest || []).filter(function (x) { return typeof x.montant === 'number' && x.montant > 0; });
    var frais = (r.financement.demarrage || []).filter(function (x) { return typeof x.montant === 'number' && x.montant > 0; });
    if (invest.length || frais.length) {
      var lignesUse = [];
      if (invest.length) {
        lignesUse.push({ c: ['Investissements (achats durables)', '', ''], s: 'titre' });
        invest.forEach(function (x) { lignesUse.push([t(x.nom) || 'Sans nom', $(x.montant), (x.duree || 5) + ' ans']); });
      }
      if (frais.length) {
        lignesUse.push({ c: ['Frais de démarrage', '', ''], s: 'titre' });
        frais.forEach(function (x) { lignesUse.push([t(x.nom) || 'Sans nom', $(x.montant), '']); });
      }
      lignesUse.push({ c: ['Total des dépenses de démarrage', $(res.besoin.utilisations), ''], s: 'total' });
      ajouter(tableau('Utilisation des fonds', [col('Poste', 'g', 6), col('Montant', 'd', 2), col('Amortissement', 'd', 2)], lignesUse));
    } else if (!r.financement.aucun) {
      completer('financement', 'dépenses de démarrage (investissements et frais)');
    } else {
      ajouter({ t: 'p', texte: 'Aucune dépense de démarrage n’est prévue.' });
    }
    var sources = (r.financement.sources || []).filter(function (x) { return typeof x.montant === 'number' && x.montant > 0 && x.type !== 'marge'; });
    if (sources.length) {
      ajouter(tableau('Sources de financement',
        [col('Source', 'g', 3.4), col('Type', 'g', 2.4), col('Statut', 'g', 1.4), col('Montant', 'd', 1.6), col('Modalités', 'g', 3)],
        sources.concat([null]).map(function (x) {
          if (!x) return { c: ['Total des sources', '', '', $(res.besoin.sources), ''], s: 'total' };
          var modalites = '—';
          if (Calc.TYPES_PRET[x.type]) {
            var morceaux = [];
            if (typeof x.taux === 'number') morceaux.push(Calc.pourcent(x.taux));
            if (x.duree) morceaux.push(x.duree + ' mois');
            if (x.grace) morceaux.push('dont ' + x.grace + ' mois sans remboursement du capital');
            modalites = morceaux.join(', ') || '—';
          } else if (x.mois) {
            modalites = 'Reçu au mois ' + x.mois;
          }
          return [t(x.nom) || '—', lib(M.TYPES_SOURCE, x.type), lib(M.STATUTS_SOURCE, x.statut) || '—', $(x.montant), modalites];
        })));
      var kvFin = [['Écart entre les sources et les dépenses de démarrage', $(res.besoin.ecart)]];
      if (res.besoin.margeCredit > 0) kvFin.push(['Marge de crédit disponible (non utilisée dans les calculs)', $(res.besoin.margeCredit)]);
      ajouter({ t: 'kv', lignes: kvFin });
    } else if (!r.financement.aucun) {
      completer('financement', 'sources de financement');
    } else {
      ajouter({ t: 'p', texte: 'Aucun financement externe n’est prévu.' });
    }

    if (!aDesVentes) {
      completer('ventes', 'prévision des ventes (étape Ventes) : les états financiers s’afficheront ici');
      return;
    }

    /* Prévision des ventes */
    h2('Prévision des ventes');
    ajouter(tableau('Quantités vendues et ventes par offre',
      [col('Offre', 'g', 3.4), col('Quantité\nan 1', 'd', 1.2), col('Quantité\nan 2', 'd', 1.2), col('Quantité\nan 3', 'd', 1.2), col('Ventes\nan 1', 'd', 1.6), col('Ventes\nan 2', 'd', 1.6), col('Ventes\nan 3', 'd', 1.6)],
      base.lignes.map(function (l) {
        return [l.nom + (l.unite ? ' (' + l.unite + ')' : '')].concat(an3.map(function (i) { return quantite(l.volAn[i]); })).concat(an3.map(function (i) { return $(l.revAn[i]); }));
      }).concat([{ c: ['Total des ventes', '', '', ''].concat(an3.map(function (i) { return $(base.annuel.rev[i]); })), s: 'total' }]),
      'Les quantités sont arrondies à l’unité; les montants sont calculés mois par mois.'));

    /* Résultats annuels */
    h2('Résultats prévisionnels');
    var ligneAn = function (libelle, serie, s) { var c = [libelle].concat(an3.map(function (i) { return $(serie[i]); })); return s ? { c: c, s: s } : c; };
    var an = base.annuel;
    var lignesRes = [
      ligneAn('Ventes', an.rev),
      ligneAn('Coûts directs', an.coutsDirects),
      ligneAn('Frais de transaction', an.frais),
      ligneAn('Marge brute', an.margeBrute, 'total'),
      ligneAn('Charges fixes', an.charges),
      ligneAn('Salaires et charges sociales', an.salaires),
      ligneAn('Rémunération des promoteurs', an.remuneration),
      ligneAn('Amortissement', an.amortissement),
      ligneAn('Intérêts sur les prêts', an.interets),
      ligneAn('Résultat avant impôts', an.resultat, 'total')
    ];
    ajouter(tableau('État des résultats prévisionnel, par année', enteteAnnees(), lignesRes, fraisDemarrage > 0
      ? 'Les frais de démarrage (' + $(fraisDemarrage) + ') ne sont pas déduits de ces résultats : ils sont payés avant l’ouverture et comptés dans la trésorerie. Un comptable pourrait les passer en charges dès la première année, ce qui réduirait d’autant le résultat de l’année 1.'
      : null));
    ajouter({ t: 'graphique', id: 'annuel', titre: 'Ventes et dépenses par année', description: T('Ventes et dépenses totales des trois premières années : ' + an3.map(function (i) { return 'année ' + (i + 1) + ', ventes ' + $(an.rev[i]) + ', dépenses ' + $(an.rev[i] - an.resultat[i]) + ', résultat ' + $(an.resultat[i]); }).join('; ') + '.') });

    /* Résultats mensuels, année 1 */
    h2('Résultats mensuels de l’année 1');
    [0, 1].forEach(function (moitie) {
      var m0 = 6 * moitie + 1, m1 = m0 + 5;
      var cols = [col('', 'g', 3.4)];
      for (var m = m0; m <= m1; m++) cols.push(col(enteteMois(debut, m), 'd', 1.35));
      cols.push(col('Total', 'd', 1.5));
      var ligne = function (libelle, f, s) {
        var c = [libelle], tot = 0;
        for (var m = m0; m <= m1; m++) { var v = f(m); tot += v; c.push(n(v)); }
        c.push(n(tot));
        return s ? { c: c, s: s } : c;
      };
      ajouter(tableau('Résultats mensuels, mois ' + m0 + ' à ' + m1 + (debut ? ' (' + etiquetteMois(debut, m0) + ' à ' + etiquetteMois(debut, m1) + ')' : ''), cols, [
        ligne('Ventes', function (m) { return base.rev[m]; }),
        ligne('Coûts directs et frais', function (m) { return base.coutsDirects[m] + base.frais[m]; }),
        ligne('Marge brute', function (m) { return base.margeBrute[m]; }, 'total'),
        ligne('Charges fixes', function (m) { return base.charges[m]; }),
        ligne('Salaires et charges sociales', function (m) { return base.salaires[m]; }),
        ligne('Rémunération des promoteurs', function (m) { return base.remuneration[m]; }),
        ligne('Amortissement', function (m) { return base.amortissement[m]; }),
        ligne('Intérêts', function (m) { return base.interets[m]; }),
        ligne('Résultat avant impôts', function (m) { return base.resultat[m]; }, 'total')
      ], moitie === 1 ? 'Montants en dollars.' : null));
    });

    /* Trésorerie */
    h2('Budget de trésorerie');
    var tr = base.tres;
    [0, 1].forEach(function (moitie) {
      var m0 = 6 * moitie + 1, m1 = m0 + 5;
      var cols = [col('', 'g', 3.4)];
      for (var m = m0; m <= m1; m++) cols.push(col(enteteMois(debut, m), 'd', 1.35));
      cols.push(col('Total', 'd', 1.5));
      var flux = function (libelle, f) {
        var c = [libelle], tot = 0;
        for (var m = m0; m <= m1; m++) { var v = f(m); tot += v; c.push(n(v)); }
        c.push(n(tot));
        return c;
      };
      var ouverture = ['Solde d’ouverture'], fermeture = ['Solde de fin de mois'];
      for (var m = m0; m <= m1; m++) { ouverture.push(n(tr.solde[m - 1])); fermeture.push(n(tr.solde[m])); }
      ouverture.push(n(tr.solde[m0 - 1]));
      fermeture.push(n(tr.solde[m1]));
      ajouter(tableau('Trésorerie mensuelle, mois ' + m0 + ' à ' + m1 + (debut ? ' (' + etiquetteMois(debut, m0) + ' à ' + etiquetteMois(debut, m1) + ')' : ''), cols, [
        ouverture,
        flux('Encaissements des ventes', function (k) { return tr.encaissements[k]; }),
        flux('Décaissements d’exploitation', function (k) { return tr.decaissements[k]; }),
        flux('Intérêts payés', function (k) { return tr.interets[k]; }),
        flux('Capital remboursé', function (k) { return tr.capital[k]; }),
        flux('Financement reçu', function (k) { return tr.financement[k]; }),
        { c: fermeture, s: 'total' }
      ], moitie === 1 ? 'Les décaissements d’exploitation comprennent les coûts directs, les charges fixes, les salaires et la rémunération des promoteurs. Montants en dollars.' : null));
    });
    var lignesTresAn = [
      ['Solde d’ouverture'].concat(an3.map(function (i) { return $(tr.solde[12 * i]); })),
      ['Encaissements des ventes'].concat(an3.map(function (i) { return $(an.encaissements[i]); })),
      ['Décaissements d’exploitation'].concat(an3.map(function (i) { return $(an.decaissements[i]); })),
      ['Intérêts payés'].concat(an3.map(function (i) { return $(an.interets[i]); })),
      ['Capital remboursé'].concat(an3.map(function (i) { return $(an.capital[i]); })),
      ['Financement reçu'].concat(an3.map(function (i) { return $(an.financement[i]); })),
      { c: ['Solde de fin d’année'].concat(an3.map(function (i) { return $(an.soldeFin[i]); })), s: 'total' }
    ];
    ajouter(tableau('Trésorerie, par année', enteteAnnees(), lignesTresAn));
    ajouter({
      t: 'graphique', id: 'tresorerie', titre: 'Solde de trésorerie sur 36 mois',
      description: T('Le solde de trésorerie passe de ' + $(tr.solde[0]) + ' avant l’ouverture à ' + $(tr.solde[36]) + ' au mois 36. Son point le plus bas est de ' + $(tr.min) + ' (' + etiquetteMois(debut, tr.moisMin) + ').')
    });

    /* Seuil de rentabilité et indicateurs */
    h2('Seuil de rentabilité et indicateurs');
    var indic = [
      ['Ventes prévues'].concat(an3.map(function (i) { return $(an.rev[i]); })),
      ['Seuil de rentabilité (ventes nécessaires)'].concat(an3.map(function (i) { return an.seuil[i] === null ? '—' : $(an.seuil[i]); })),
      ['Marge brute, en pourcentage des ventes'].concat(an3.map(function (i) { return an.tauxMarge[i] === null ? '—' : Calc.pourcent(an.tauxMarge[i], true); }))
    ];
    if (an.interets.some(function (v, i) { return v + an.capital[i] > 0; })) {
      indic.push(['Couverture du service de la dette'].concat(an3.map(function (i) { return an.ratioService[i] === null ? '—' : fois(an.ratioService[i]); })));
    }
    ajouter(tableau('Indicateurs par année', enteteAnnees(), indic,
      'Le seuil de rentabilité est le niveau de ventes pour lequel le résultat avant impôts est nul, selon la marge brute de l’année. La couverture du service de la dette compare le résultat avant amortissement et intérêts aux intérêts et au capital remboursés : plus elle dépasse 1, plus la marge est confortable.'));
    var kvInd = [];
    kvInd.push(['Premier mois bénéficiaire', base.premierMoisBeneficiaire === null ? 'Aucun dans les 36 premiers mois' : 'Mois ' + base.premierMoisBeneficiaire + ' (' + etiquetteMois(debut, base.premierMoisBeneficiaire) + ')']);
    var moisEnPerte = 0, moisEnPerteAn1 = 0;
    for (var mp = 1; mp <= 36; mp++) if (base.resultat[mp] < 0) { moisEnPerte++; if (mp <= 12) moisEnPerteAn1++; }
    kvInd.push(['Mois en perte', moisEnPerte === 0 ? 'Aucun sur 36' : moisEnPerte + ' sur 36' + (moisEnPerteAn1 ? ' (dont ' + moisEnPerteAn1 + ' la première année)' : '')]);
    kvInd.push(['Solde de trésorerie le plus bas', $(tr.min) + ' (' + etiquetteMois(debut, tr.moisMin) + ')']);
    ajouter({ t: 'kv', lignes: kvInd });

    /* Scénario prudent */
    if (res.scenario) {
      var sc = res.scenario;
      h2('Scénario prudent : ventes inférieures de ' + Calc.decimal(baisse, 0) + ' %');
      ajouter({ t: 'p', texte: T('Pour vérifier la solidité du plan, les ventes de chaque offre sont réduites de ' + Calc.decimal(baisse, 0) + ' % dans tous les mois; les autres hypothèses ne changent pas.') });
      ajouter(tableau('Effet d’une baisse des ventes de ' + Calc.decimal(baisse, 0) + ' %', enteteAnnees(), [
        ['Ventes'].concat(an3.map(function (i) { return $(sc.annuel.rev[i]); })),
        ['Résultat avant impôts'].concat(an3.map(function (i) { return $(sc.annuel.resultat[i]); })),
        { c: ['Trésorerie en fin d’année'].concat(an3.map(function (i) { return $(sc.annuel.soldeFin[i]); })), s: 'total' }
      ]));
      var kvSc = [['Solde de trésorerie le plus bas', $(sc.tres.min) + ' (' + etiquetteMois(debut, sc.tres.moisMin) + ')']];
      kvSc.push(['Financement supplémentaire à prévoir pour respecter la réserve souhaitée', $(res.besoin.supplementaireScenario || 0)]);
      if (res.besoin.margeCredit > 0) kvSc.push(['Marge de crédit disponible', $(res.besoin.margeCredit)]);
      ajouter({ t: 'kv', lignes: kvSc });
    }

    /* Besoin de financement */
    h2('Besoin de financement');
    var kvBesoin = [
      ['Dépenses de démarrage', $(res.besoin.utilisations)],
      ['Sources de financement prévues', $(res.besoin.sources)],
      ['Écart', $(res.besoin.ecart)]
    ];
    if (res.besoin.nonConfirme > 0) kvBesoin.push(['Part du financement non confirmée', $(res.besoin.nonConfirme)]);
    kvBesoin.push(['Financement supplémentaire pour maintenir la réserve de trésorerie' + (E.hyp.coussin > 0 ? ' de ' + $(E.hyp.coussin) : ''), $(res.besoin.supplementaire)]);
    ajouter({ t: 'kv', lignes: kvBesoin });
    texteVersBlocs(r.financement.garanties).length && (ajouter({ t: 'p', texte: 'Garanties offertes' }), texteVersBlocs(r.financement.garanties).forEach(ajouter));
    texteVersBlocs(r.financement.modalites).length && (ajouter({ t: 'p', texte: 'Autres précisions' }), texteVersBlocs(r.financement.modalites).forEach(ajouter));
  }

  /* ---------- Graphiques (SVG) ---------- */
  function echelle(min, max, cible) {
    if (!(max > min)) max = min + 1;
    var brut = (max - min) / cible;
    var p = Math.pow(10, Math.floor(Math.log(brut) / Math.LN10));
    var f = brut / p;
    var pas = (f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10) * p;
    var lo = Math.floor(min / pas) * pas, hi = Math.ceil(max / pas) * pas;
    var ticks = [];
    for (var v = lo; v <= hi + pas / 1000; v += pas) ticks.push(Math.round(v * 1e6) / 1e6);
    return { lo: lo, hi: hi, ticks: ticks };
  }
  function nb(x) { return Math.round(x * 10) / 10; }

  /* Placement d'une étiquette de texte près d'un point d'un graphique : on essaie
     plusieurs positions et on garde la première qui ne recouvre ni la courbe, ni
     une ligne de repère, ni une autre étiquette, et qui reste dans le cadre. */
  function largeurTexte(s) { return Math.round(String(s).length * 6.9); }
  function segmentTouche(r, x1, y1, x2, y2) {
    var n = Math.max(2, Math.ceil(Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1)) / 2));
    for (var i = 0; i <= n; i++) {
      var x = x1 + (x2 - x1) * i / n, y = y1 + (y2 - y1) * i / n;
      if (x >= r.x1 && x <= r.x2 && y >= r.y1 && y <= r.y2) return true;
    }
    return false;
  }
  function rectTouche(r, obst) {
    var i;
    for (i = 0; i < obst.rects.length; i++) {
      var q = obst.rects[i];
      if (r.x1 < q.x2 && r.x2 > q.x1 && r.y1 < q.y2 && r.y2 > q.y1) return true;
    }
    for (i = 0; i < obst.horiz.length; i++) {
      var l = obst.horiz[i];
      if (l.y >= r.y1 - 1 && l.y <= r.y2 + 1 && r.x1 < l.x2 && r.x2 > l.x1) return true;
    }
    for (i = 1; i < obst.courbe.length; i++) {
      if (segmentTouche(r, obst.courbe[i - 1][0], obst.courbe[i - 1][1], obst.courbe[i][0], obst.courbe[i][1])) return true;
    }
    return false;
  }
  function boiteTexte(e, w) {
    var x1 = e.a === 'start' ? e.x : e.a === 'end' ? e.x - w : e.x - w / 2;
    return { x1: x1 - 3, x2: x1 + w + 3, y1: e.y - 12, y2: e.y + 4 };
  }
  /* « textes » va du libellé complet au plus court : on garde le premier libellé pour lequel une
     position est libre (sur un écran étroit, « Réserve souhaitée : … » cède la place à « Réserve : … »). */
  function choisirEmplacement(essais, textes, obst, cadre) {
    for (var t = 0; t < textes.length; t++) {
      var w = largeurTexte(textes[t]);
      for (var i = 0; i < essais.length; i++) {
        var r = boiteTexte(essais[i], w);
        if (r.x1 < cadre.x1 || r.x2 > cadre.x2 || r.y1 < cadre.y1 || r.y2 > cadre.y2) continue;
        if (rectTouche(r, obst)) continue;
        return { e: essais[i], r: r, texte: textes[t], libre: true };
      }
    }
    var dernier = textes[textes.length - 1]; // aucun emplacement libre : le libellé le plus court à la première position, avec son halo
    return { e: essais[0], r: boiteTexte(essais[0], largeurTexte(dernier)), texte: dernier, libre: false };
  }

  /* Courbe du solde de trésorerie des 36 mois. Quand l'étiquette de la réserve ne trouve aucune place
     libre dans le graphique (écran étroit), on la sort du dessin : une ligne de légende au-dessus. */
  function graphiqueTresorerie(res, o) {
    var essai = dessinerTresorerie(res, o, false);
    return essai.libre ? essai.svg : dessinerTresorerie(res, o, true).svg;
  }
  function dessinerTresorerie(res, o, legende) {
    o = o || {};
    var W = o.largeur || 640, H = o.hauteur || 280, pre = o.id || 'g-tres';
    var tr = res.base.tres, solde = tr.solde;
    var coussin = res.entree.hyp.coussin;
    var mn = Math.min(0, tr.min, coussin), mx = Math.max(0, Math.max.apply(null, solde), coussin);
    var ech = echelle(mn, mx, 4);
    var gauche = 62, droite = 16, haut = legende ? 40 : 18, bas = 44;
    var libre = true;
    var X = function (m) { return nb(gauche + (W - gauche - droite) * m / 36); };
    var Y = function (v) { return nb(haut + (H - haut - bas) * (ech.hi - v) / (ech.hi - ech.lo)); };
    var enf = [];
    enf.push(h('title', { id: pre + '-t' }, 'Solde de trésorerie sur 36 mois'));
    enf.push(h('desc', { id: pre + '-d' }, T('Solde de fin de mois, du mois 0 (avant l’ouverture) au mois 36. Point le plus bas : ' + Calc.argent(tr.min) + ' au mois ' + tr.moisMin + '. Solde au mois 36 : ' + Calc.argent(solde[36]) + '.')));
    if (ech.lo < 0) enf.push(h('rect', { 'class': 'g-neg', x: gauche, y: Y(0), width: W - gauche - droite, height: nb(Y(ech.lo) - Y(0)) }));
    ech.ticks.forEach(function (v) {
      enf.push(h('line', { 'class': v === 0 ? 'g-zero' : 'g-grille', x1: gauche, x2: W - droite, y1: Y(v), y2: Y(v) }));
      enf.push(h('text', { 'class': 'g-axe', x: gauche - 8, y: nb(Y(v) + 4), 'text-anchor': 'end' }, Calc.entier(v)));
    });
    for (var m = 0; m <= 36; m += 6) {
      enf.push(h('line', { 'class': 'g-graduation', x1: X(m), x2: X(m), y1: Y(ech.lo), y2: nb(Y(ech.lo) + 5) }));
      enf.push(h('text', { 'class': 'g-axe', x: X(m), y: nb(Y(ech.lo) + 19), 'text-anchor': 'middle' }, String(m)));
    }
    enf.push(h('text', { 'class': 'g-axe', x: nb((gauche + W - droite) / 2), y: H - 6, 'text-anchor': 'middle' }, 'Mois depuis l’ouverture (0 = avant l’ouverture)'));
    var courbe = solde.map(function (v, i) { return [X(i), Y(v)]; });
    var obst = { courbe: courbe, rects: [], horiz: [{ y: Y(0), x1: gauche, x2: W - droite }, { y: Y(ech.lo), x1: gauche, x2: W - droite }] };
    var cadre = { x1: gauche + 2, x2: W - droite + 2, y1: haut - 8, y2: Y(ech.lo) - 2 };
    if (coussin > 0) {
      enf.push(h('line', { 'class': 'g-reserve', x1: gauche, x2: W - droite, y1: Y(coussin), y2: Y(coussin) }));
      obst.horiz.push({ y: Y(coussin), x1: gauche, x2: W - droite });
    }
    var bas2 = tr.moisMin, px = X(bas2), py = Y(tr.min);
    var texteBas = 'Plus bas' + NBSP + ': ' + Calc.argent(tr.min);
    var placeBas = choisirEmplacement([
      { x: px + 11, y: py + 4, a: 'start' }, { x: px + 11, y: py - 9, a: 'start' }, { x: px + 11, y: py + 19, a: 'start' },
      { x: px + 24, y: py + 4, a: 'start' }, { x: px + 38, y: py + 4, a: 'start' }, { x: px + 54, y: py + 4, a: 'start' },
      { x: px - 11, y: py + 4, a: 'end' }, { x: px - 11, y: py - 9, a: 'end' }, { x: px - 11, y: py + 19, a: 'end' },
      { x: px, y: py - 13, a: 'middle' }, { x: px, y: py + 24, a: 'middle' }
    ], [texteBas], obst, cadre);
    obst.rects.push(placeBas.r);
    if (coussin > 0) {
      var montantRes = NBSP + ': ' + Calc.argent(coussin), yr = Y(coussin);
      var textesRes = ['Réserve souhaitée' + montantRes, 'Réserve' + montantRes];
      if (legende) {
        var wLeg = largeurTexte(textesRes[0]);
        enf.push(h('line', { 'class': 'g-reserve', x1: gauche, x2: gauche + 22, y1: 12, y2: 12 }));
        enf.push(h('text', { 'class': 'g-axe', x: gauche + 28, y: 16 }, gauche + 28 + wLeg <= W - droite ? textesRes[0] : textesRes[1]));
      } else {
        var placeRes = choisirEmplacement([
          { x: W - droite - 4, y: yr - 5, a: 'end' }, { x: W - droite - 4, y: yr + 16, a: 'end' },
          { x: gauche + 6, y: yr - 5, a: 'start' }, { x: gauche + 6, y: yr + 16, a: 'start' }
        ], textesRes, obst, cadre);
        libre = placeRes.libre;
        enf.push(h('text', { 'class': 'g-etiquette', x: nb(placeRes.e.x), y: nb(placeRes.e.y), 'text-anchor': placeRes.e.a }, placeRes.texte));
      }
    }
    enf.push(h('polyline', { 'class': 'g-ligne', points: courbe.map(function (c) { return c[0] + ',' + c[1]; }).join(' '), fill: 'none' }));
    enf.push(h('circle', { 'class': 'g-point', cx: px, cy: py, r: 4.5 }));
    enf.push(h('text', { 'class': 'g-etiquette', x: nb(placeBas.e.x), y: nb(placeBas.e.y), 'text-anchor': placeBas.e.a }, texteBas));
    return { libre: libre, svg: h('svg', { 'class': 'graphique g-tres', viewBox: '0 0 ' + W + ' ' + H, width: W, height: H, role: 'img', 'aria-labelledby': pre + '-t ' + pre + '-d', focusable: 'false' }, enf) };
  }

  /* Barres groupées : ventes et dépenses totales de chaque année. */
  function graphiqueAnnuel(res, o) {
    o = o || {};
    var W = o.largeur || 640, H = o.hauteur || 280, pre = o.id || 'g-an';
    var an = res.base.annuel;
    var ventes = an.rev, depenses = an.rev.map(function (v, i) { return v - an.resultat[i]; });
    var mx = Math.max.apply(null, ventes.concat(depenses).concat([1]));
    var ech = echelle(0, mx, 4);
    var gauche = 62, droite = 16, haut = 34;
    var zone = (W - gauche - droite) / 3, largeur = Math.min(54, zone / 3);
    // Sur un écran étroit, les valeurs au-dessus de deux barres voisines se toucheraient et « Résultat : … »
    // dépasserait sa zone : on retire alors les valeurs des barres (le tableau les donne) et l'on écrit
    // le résultat sur deux lignes.
    var wVal = 0, wRes = 0;
    ventes.concat(depenses).forEach(function (v) { wVal = Math.max(wVal, largeurTexte(Calc.entier(v))); });
    an.resultat.forEach(function (v) { wRes = Math.max(wRes, largeurTexte('Résultat' + NBSP + ': ' + Calc.argent(v))); });
    var valeursSurBarres = wVal + 4 <= largeur + 2;
    var resultatEnDeux = wRes + 6 > zone;
    var bas = resultatEnDeux ? 54 : 40;
    var Y = function (v) { return nb(haut + (H - haut - bas) * (ech.hi - v) / (ech.hi - ech.lo)); };
    var enf = [];
    enf.push(h('title', { id: pre + '-t' }, 'Ventes et dépenses par année'));
    enf.push(h('desc', { id: pre + '-d' }, T(ventes.map(function (v, i) { return 'Année ' + (i + 1) + ' : ventes ' + Calc.argent(v) + ', dépenses ' + Calc.argent(depenses[i]) + ', résultat ' + Calc.argent(an.resultat[i]); }).join('. ') + '.')));
    enf.push(h('defs', {}, [h('pattern', { id: pre + '-hachure', width: 6, height: 6, patternUnits: 'userSpaceOnUse', patternTransform: 'rotate(45)' }, [
      h('rect', { 'class': 'g-fond-hachure', width: 6, height: 6 }), h('line', { 'class': 'g-trait-hachure', x1: 0, y1: 0, x2: 0, y2: 6 })
    ])]));
    ech.ticks.forEach(function (v) {
      enf.push(h('line', { 'class': v === 0 ? 'g-zero' : 'g-grille', x1: gauche, x2: W - droite, y1: Y(v), y2: Y(v) }));
      enf.push(h('text', { 'class': 'g-axe', x: gauche - 8, y: nb(Y(v) + 4), 'text-anchor': 'end' }, Calc.entier(v)));
    });
    [0, 1, 2].forEach(function (i) {
      var centre = gauche + zone * (i + 0.5);
      var x1 = nb(centre - largeur - 2), x2 = nb(centre + 2);
      var hv = nb(Y(0) - Y(ventes[i])), hd = nb(Y(0) - Y(depenses[i]));
      enf.push(h('rect', { 'class': 'g-barre-1', x: x1, y: Y(ventes[i]), width: largeur, height: Math.max(0, hv) }));
      enf.push(h('rect', { 'class': 'g-barre-2', x: x2, y: Y(depenses[i]), width: largeur, height: Math.max(0, hd), fill: 'url(#' + pre + '-hachure)' }));
      if (valeursSurBarres) {
        enf.push(h('text', { 'class': 'g-valeur', x: nb(x1 + largeur / 2), y: nb(Y(ventes[i]) - 5), 'text-anchor': 'middle' }, Calc.entier(ventes[i])));
        enf.push(h('text', { 'class': 'g-valeur', x: nb(x2 + largeur / 2), y: nb(Y(depenses[i]) - 5), 'text-anchor': 'middle' }, Calc.entier(depenses[i])));
      }
      enf.push(h('text', { 'class': 'g-axe', x: nb(centre), y: nb(Y(0) + 18), 'text-anchor': 'middle' }, 'Année ' + (i + 1)));
      if (resultatEnDeux) {
        var montant = Calc.argent(an.resultat[i]);
        var attrsMontant = { 'class': 'g-resultat', x: nb(centre), y: nb(Y(0) + 47), 'text-anchor': 'middle' };
        // Un montant démesuré dépasse même sa zone : on le comprime plutôt que de le laisser toucher son voisin.
        if (largeurTexte(montant) > zone - 4) { attrsMontant.textLength = nb(zone - 6); attrsMontant.lengthAdjust = 'spacingAndGlyphs'; }
        enf.push(h('text', { 'class': 'g-resultat', x: nb(centre), y: nb(Y(0) + 33), 'text-anchor': 'middle' }, 'Résultat' + NBSP + ':'));
        enf.push(h('text', attrsMontant, montant));
      } else {
        enf.push(h('text', { 'class': 'g-resultat', x: nb(centre), y: nb(Y(0) + 33), 'text-anchor': 'middle' }, 'Résultat' + NBSP + ': ' + Calc.argent(an.resultat[i])));
      }
    });
    // Légende
    enf.push(h('rect', { 'class': 'g-barre-1', x: gauche, y: 8, width: 12, height: 12 }));
    enf.push(h('text', { 'class': 'g-axe', x: gauche + 18, y: 18 }, 'Ventes'));
    enf.push(h('rect', { 'class': 'g-barre-2', x: gauche + 90, y: 8, width: 12, height: 12, fill: 'url(#' + pre + '-hachure)' }));
    enf.push(h('text', { 'class': 'g-axe', x: gauche + 108, y: 18 }, 'Dépenses totales'));
    return h('svg', { 'class': 'graphique g-annuel', viewBox: '0 0 ' + W + ' ' + H, width: W, height: H, role: 'img', 'aria-labelledby': pre + '-t ' + pre + '-d', focusable: 'false' }, enf);
  }

  /* ---------- Du modèle de document à l'arbre d'éléments ---------- */
  function cellule(texte, balise, attrs) {
    return h(balise, attrs || {}, lignesTexte(texte));
  }
  function arbreTableau(b, o, precedent) {
    var colgroup = null;
    // La légende reste visible, sauf si elle répète le sous-titre qui précède.
    var legendeCachee = !!(precedent && precedent.t === 'h2' && precedent.texte === b.titre);
    var total = b.colonnes.reduce(function (s, c) { return s + (c.l || 1); }, 0);
    colgroup = h('colgroup', {}, b.colonnes.map(function (c) { return h('col', { style: 'width:' + nb(100 * (c.l || 1) / total) + '%' }); }));
    var classeCol = function (c) { return c.a === 'd' ? 'chiffre' : c.a === 'c' ? 'centre' : ''; };
    var tete = h('thead', {}, [h('tr', {}, b.colonnes.map(function (c, i) {
      return cellule(c.t, 'th', { scope: 'col', 'class': classeCol(c) || null });
    }))]);
    var corps = h('tbody', {}, b.lignes.map(function (lg) {
      var cells = Array.isArray(lg) ? lg : lg.c, style = Array.isArray(lg) ? '' : lg.s || '';
      return h('tr', { 'class': style ? 'l-' + style : null }, cells.map(function (c, i) {
        var cl = classeCol(b.colonnes[i] || {});
        return i === 0 ? cellule(c, 'th', { scope: 'row', 'class': cl || null }) : cellule(c, 'td', { 'class': cl || null });
      }));
    }));
    var table = h('table', {}, [h('caption', { 'class': legendeCachee ? 'sr-only' : 'doc-legende' }, b.titre), colgroup, tete, corps]);
    var enfants = [h('div', { 'class': 'doc-defile-zone' }, [h('div', { 'class': 'doc-defile', tabindex: '0', role: 'region', 'aria-label': b.titre }, [table])])];
    if (b.note) enfants.push(h('p', { 'class': 'doc-note' }, b.note));
    return h('div', { 'class': 'doc-tableau' }, enfants);
  }

  /* options : niveau (niveau du premier titre, 3 par défaut), liens (fonction étape → href, pour « À compléter »), graphiques (fonction bloc → arbre SVG) */
  function arbre(doc, options) {
    options = options || {};
    var niveau = options.niveau || 3;
    var out = [];
    var precedent = null;
    doc.blocs.forEach(function (b) {
      switch (b.t) {
        case 'couverture':
          out.push(h('section', { 'class': 'doc-couverture', 'aria-label': 'Page couverture' }, [
            h('p', { 'class': 'doc-surtitre' }, b.surtitre),
            h('p', { 'class': 'doc-titre' }, b.titre),
            b.lignes.length ? h('ul', { 'class': 'doc-couv-lignes' }, b.lignes.map(function (l) { return h('li', {}, l); })) : null,
            h('p', { 'class': 'doc-date' }, b.date),
            b.mention ? h('p', { 'class': 'doc-mention' }, b.mention) : null
          ]));
          break;
        case 'h1': out.push(h('h' + niveau, { 'class': 'doc-h1' + (b.saut ? ' doc-saut' : '') }, b.texte)); break;
        case 'h2': out.push(h('h' + (niveau + 1), { 'class': 'doc-h2' }, b.texte)); break;
        case 'p': out.push(h('p', {}, lignesTexte(b.texte))); break;
        case 'liste': out.push(h(b.ordonnee ? 'ol' : 'ul', {}, b.items.map(function (i) { return h('li', {}, lignesTexte(i)); }))); break;
        case 'tableau': out.push(arbreTableau(b, options, precedent)); break;
        case 'kv':
          out.push(h('dl', { 'class': 'doc-kv' }, b.lignes.reduce(function (acc, l) { acc.push(h('dt', {}, l[0])); acc.push(h('dd', {}, lignesTexte(l[1]))); return acc; }, [])));
          break;
        case 'graphique': {
          var svg = options.graphiques ? options.graphiques(b) : null;
          if (svg) out.push(h('figure', { 'class': 'doc-figure' }, [svg, h('figcaption', {}, b.titre)]));
          break;
        }
        case 'note': out.push(h('p', { 'class': 'doc-note' }, b.texte)); break;
        case 'aCompleter': {
          var href = options.liens ? options.liens(b.etape) : null;
          out.push(h('p', { 'class': 'doc-completer' }, href ? [b.texte + ' ', h('a', { href: href, 'class': 'doc-lien-completer' }, 'Compléter')] : b.texte));
          break;
        }
        default: break;
      }
      precedent = b;
    });
    return h('div', { 'class': 'doc' }, out);
  }

  /* Graphique d'un bloc, selon son identifiant. */
  function graphiqueDuBloc(res, b, o) {
    o = o || {};
    if (b.id === 'tresorerie') return graphiqueTresorerie(res, { largeur: o.largeur, hauteur: o.hauteur, id: (o.prefixe || 'doc') + '-tres' });
    if (b.id === 'annuel') return graphiqueAnnuel(res, { largeur: o.largeur, hauteur: o.hauteur, id: (o.prefixe || 'doc') + '-an' });
    return null;
  }

  NS.Document = {
    MOIS_COURTS: MOIS_COURTS,
    composer: composer, arbre: arbre, enChaine: enChaine, enDom: enDom, h: h,
    texteVersBlocs: texteVersBlocs, fichierBase: fichierBase, jourMois: jourMois,
    etiquetteMois: etiquetteMois, enteteMois: enteteMois, periodeAn: periodeAn, moisDe: moisDe,
    graphiqueTresorerie: graphiqueTresorerie, graphiqueAnnuel: graphiqueAnnuel, graphiqueDuBloc: graphiqueDuBloc, echelle: echelle,
    prix: prix
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = NS.Document;
})(typeof window !== 'undefined' ? window : globalThis);
