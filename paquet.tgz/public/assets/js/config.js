/* ==========================================================================
   Réglages du site. Modifiez ce fichier sans toucher au reste du code.

   Le formulaire de contact a quatre modes, selon ce que vous renseignez ici :

   1. pointEnvoi : "/api/formulaire"   (version avec CRM)
      Le message arrive directement dans le CRM InnovAffaires installé sur le
      même site (dossier crm/). C'est le réglage de la version à publier : il
      est inscrit automatiquement au moment de produire le dossier.

   2. pointEnvoi : l'adresse d'un autre service (Formspree ou équivalent)
      Le message est envoyé directement à ce service. Il doit accepter une
      requête POST au format JSON et répondre en JSON. Si vous utilisez un
      service tiers, nommez-le dans la politique de confidentialité.

   3. Seulement courriel renseigné (réglage de la version sans CRM)
      L'application de courriel du visiteur s'ouvre avec un message prérempli
      adressé à cette adresse. Rien n'est transmis tant que le visiteur n'a
      pas envoyé ce courriel. Si rien ne s'ouvre (courriel Web, par exemple),
      le visiteur peut copier son message et l'adresse.

   4. Les deux sont vides
      Le formulaire vérifie les champs, puis propose de copier le message.
      Il n'affiche jamais « envoyé » : rien n'est transmis.
   ========================================================================== */
window.SITE_CONFIG = {
  courriel: "info@innovaffaires.com",

  // Exemple : "https://formspree.io/f/xxxxxxxx"
  pointEnvoi: "/api/formulaire"
};
