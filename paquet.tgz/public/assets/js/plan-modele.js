/* ==========================================================================
   Créateur de plan d'affaires : modèle de données.

   - ETAPES : les étapes, leurs questions et leurs aides (source unique : l'écran
     de saisie, l'aperçu et les exportations en dérivent).
   - etatVide(), assainir() : l'état d'un plan et sa validation stricte (copie
     d'une sauvegarde, lecture du stockage local) ; rien d'inconnu n'est conservé.
   - etatEtape(), progression() : étapes complètes, ce qui manque.
   - messageAlerte() : le texte des alertes du moteur de calcul.

   Les réponses d'une personne ne sont jamais interprétées comme du code ni du
   HTML : elles sont affichées avec textContent et échappées dans les exports.
   ========================================================================== */
(function (g) {
  'use strict';

  var NS = g.PlanAffaires = g.PlanAffaires || {};
  var Calc = NS.Calculs || (typeof require === 'function' ? require('./plan-calculs.js') : null);

  var VERSION_ETAT = 1;
  var MAX_TEXTE = 160;
  var MAX_LONG = 3000;
  var MAX_COURT = 600;

  /* ---------- Typographie québécoise des textes de l'outil (jamais appliquée aux réponses de la personne) ---------- */
  function T(s) {
    return String(s)
      .replace(/'/g, '’')
      .replace(/\.\.\./g, '…')
      .replace(/«[\s  ]*/g, '« ')
      .replace(/[\s  ]*»/g, ' »')
      .replace(/[   ]+:/g, ' :')
      .replace(/(\d) (?=\d{3}\b)/g, '$1 ')
      .replace(/(\d) (?=[$%€])/g, '$1 ')
      .replace(/(\d) (?=h\b)/g, '$1 ');
  }

  /* ---------- Listes de choix ---------- */
  var FORMES = [
    { v: 'individuelle', l: 'Entreprise individuelle (travailleur autonome)' },
    { v: 'societe-actions', l: 'Société par actions (compagnie)' },
    { v: 'societe-nom-collectif', l: 'Société en nom collectif' },
    { v: 'cooperative', l: 'Coopérative' },
    { v: 'obnl', l: 'Organisme à but non lucratif' },
    { v: 'inconnue', l: 'Je ne sais pas encore' }
  ];
  var STADES = [
    { v: 'idee', l: 'J’ai une idée' },
    { v: 'preparation', l: 'Je prépare mon lancement' },
    { v: 'demarre', l: 'J’ai démarré il y a moins d’un an' },
    { v: 'etabli', l: 'L’entreprise existe depuis plus d’un an' }
  ];
  var LOCAUX = [
    { v: 'domicile', l: 'À la maison' },
    { v: 'loue', l: 'Dans un local loué' },
    { v: 'achete', l: 'Dans un local dont je suis propriétaire' },
    { v: 'clients', l: 'Chez mes clients ou en déplacement' },
    { v: 'en-ligne', l: 'En ligne seulement' },
    { v: 'autre', l: 'Autre' }
  ];
  var CANAUX = [
    { v: 'personne', l: 'En personne (boutique, kiosque, rendez-vous)' },
    { v: 'web', l: 'Site Web ou boutique en ligne' },
    { v: 'reseaux', l: 'Réseaux sociaux' },
    { v: 'partenaires', l: 'Partenaires ou revendeurs' },
    { v: 'directe', l: 'Vente directe (prospection, appels)' },
    { v: 'salons', l: 'Salons et événements' },
    { v: 'references', l: 'Références et bouche-à-oreille' },
    { v: 'autre', l: 'Autre' }
  ];
  var PROMOS = [
    { v: 'web', l: 'Site Web et référencement' },
    { v: 'reseaux', l: 'Réseaux sociaux' },
    { v: 'courriel', l: 'Infolettre ou courriel' },
    { v: 'publicite', l: 'Publicité payante' },
    { v: 'medias', l: 'Relations publiques et médias' },
    { v: 'reseautage', l: 'Réseautage et associations' },
    { v: 'partenariats', l: 'Partenariats' },
    { v: 'imprimes', l: 'Imprimés (cartes, dépliants, affiches)' },
    { v: 'autre', l: 'Autre' }
  ];
  var PERIODES = [
    { v: 'avant', l: 'Avant le lancement' },
    { v: 'j30', l: 'Jours 1 à 30' },
    { v: 'j60', l: 'Jours 31 à 60' },
    { v: 'j90', l: 'Jours 61 à 90' }
  ];
  var NIVEAUX_RISQUE = [
    { v: 'faible', l: 'Faible' },
    { v: 'moyen', l: 'Moyen' },
    { v: 'eleve', l: 'Élevé' }
  ];
  var TYPES_SOURCE = [
    { v: 'apport', l: 'Mise de fonds des promoteurs' },
    { v: 'proche', l: 'Prêt d’un proche' },
    { v: 'banque', l: 'Prêt d’une institution financière' },
    { v: 'organisme', l: 'Prêt d’un organisme de financement' },
    { v: 'subvention', l: 'Subvention ou contribution non remboursable' },
    { v: 'investisseur', l: 'Investisseur (apport en capital)' },
    { v: 'marge', l: 'Marge de crédit disponible (non utilisée dans les calculs)' }
  ];
  var STATUTS_SOURCE = [
    { v: 'confirme', l: 'Confirmé' },
    { v: 'demande', l: 'Demandé' },
    { v: 'envisage', l: 'Envisagé' }
  ];
  var STATUTS_DEMARCHE = [
    { v: 'afaire', l: 'À faire' },
    { v: 'encours', l: 'En cours' },
    { v: 'fait', l: 'Fait' },
    { v: 'na', l: 'Sans objet' }
  ];
  var DELAIS_CLIENTS = [
    { v: 0, l: 'Comptant (au moment de la vente)' },
    { v: 30, l: '30 jours' },
    { v: 60, l: '60 jours' },
    { v: 90, l: '90 jours' }
  ];
  var DELAIS_FOURNISSEURS = [
    { v: 0, l: 'Comptant' },
    { v: 30, l: '30 jours' },
    { v: 60, l: '60 jours' }
  ];
  var MOIS_NOMS = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
  /* « de » devant un nom de mois, avec l'élision : d’avril, d’août, d’octobre, mais de mai. Accepte « avril 2027 ». */
  function deMois(texte) {
    texte = String(texte);
    return (/^[aeiouyàâäéèêëîïôöùûüh]/i.test(texte) ? 'd’' : 'de ') + texte;
  }

  /* Démarches de démarrage (liste de contrôle de l'étape Opérations). Les liens mènent aux pages officielles. */
  var LIEN_REQ = 'https://www.quebec.ca/entreprises-et-travailleurs-autonomes/demarrer-entreprise/immatriculer-constituer-entreprise/immatriculation-entreprise/a-propos';
  var LIEN_PETIT_FOURNISSEUR = 'https://www.revenuquebec.ca/fr/entreprises/taxes/tpstvh-et-tvq/inscription-aux-fichiers-de-la-tps-et-de-la-tvq/petit-fournisseur/';
  var LIEN_CNESST = 'https://www.cnesst.gouv.qc.ca/fr/demarches-formulaires/employeurs/inscription-cnesst';
  var DEMARCHES = [
    { id: 'forme', titre: 'Choisir la forme juridique', detail: 'Entreprise individuelle, société par actions, coopérative… Un avocat, un notaire ou un comptable peut vous conseiller; cet outil ne donne pas de conseil juridique.' },
    { id: 'req', titre: 'S’immatriculer au Registraire des entreprises du Québec', detail: 'Obligatoire notamment si votre entreprise individuelle porte un autre nom que votre nom et prénom, ou s’il s’agit d’une société en nom collectif ou en commandite constituée au Québec; une société par actions est immatriculée au moment de sa constitution. Vérifiez votre situation sur le site du Registraire.', lien: { texte: 'Immatriculation d’une entreprise (gouvernement du Québec)', url: LIEN_REQ } },
    { id: 'nom', titre: 'Vérifier que le nom n’est pas déjà utilisé', detail: 'La recherche dans le registre des entreprises ne garantit pas l’absence de conflit de marque de commerce : celle-ci se vérifie séparément.' },
    { id: 'taxes', titre: 'Évaluer l’inscription aux taxes de vente (TPS et TVQ)', detail: 'Selon Revenu Québec, un petit fournisseur (ventes taxables d’au plus 30 000 $ par trimestre civil et sur les quatre derniers trimestres) n’a pas à s’inscrire; au-delà de ce seuil, l’inscription est obligatoire. Les taux sont de 5 % (TPS) et de 9,975 % (TVQ), calculés tous deux sur le prix de vente. Les montants de cet outil sont avant taxes.', lien: { texte: 'Petit fournisseur (Revenu Québec)', url: LIEN_PETIT_FOURNISSEUR } },
    { id: 'banque', titre: 'Ouvrir un compte bancaire pour l’entreprise' },
    { id: 'assurances', titre: 'Souscrire les assurances nécessaires', detail: 'Responsabilité civile, biens, interruption d’affaires… selon votre activité. Un courtier peut vous aider.' },
    { id: 'permis', titre: 'Obtenir les permis, licences ou accréditations de votre secteur', detail: 'Municipalité, ordre professionnel, ministère : cela dépend de votre activité.' },
    { id: 'employeur', titre: 'Vous inscrire comme employeur (retenues à la source)', detail: 'À faire avant votre première embauche, auprès de Revenu Québec et de l’Agence du revenu du Canada.' },
    { id: 'cnesst', titre: 'Vous inscrire à la CNESST', detail: 'Les entreprises qui ont au moins un travailleur, à temps plein ou à temps partiel, doivent s’inscrire. Vérifiez le délai à respecter auprès de la CNESST.', lien: { texte: 'S’inscrire à la CNESST', url: LIEN_CNESST } },
    { id: 'contrats', titre: 'Préparer vos contrats types et conditions de vente', detail: 'À faire valider par un avocat avant usage.' }
  ];

  /* Lignes suggérées : ajoutées à la création d'un plan (sans montant). */
  var CHARGES_TYPES = [
    'Loyer', 'Assurances', 'Électricité, chauffage, Internet et téléphone', 'Logiciels et abonnements', 'Marketing et publicité',
    'Comptabilité et services professionnels', 'Transport et déplacements', 'Fournitures et entretien', 'Frais bancaires', 'Formation et cotisations'
  ];
  var INVEST_TYPES = ['Équipement et outillage', 'Ordinateur et téléphone', 'Mobilier et aménagement', 'Véhicule'];
  var DEMARRAGE_TYPES = [
    'Immatriculation au Registraire des entreprises', 'Frais juridiques et comptables', 'Permis et licences', 'Identité visuelle et site Web',
    'Dépôts et garanties (local, services publics)', 'Publicité de lancement', 'Formation'
  ];
  var RISQUES_TYPES = [
    'Les ventes démarrent plus lentement que prévu',
    'Un client important ou un fournisseur clé est perdu',
    'Les coûts (matériaux, loyer, intérêts) augmentent',
    'Une personne clé devient indisponible',
    'Un nouveau concurrent arrive ou les prix baissent',
    'Un permis ou un financement tarde à être obtenu'
  ];
  var LANCEMENT_TYPES = [
    ['Valider le nom, le logo et les couleurs de l’entreprise', 'avant'],
    ['Mettre en ligne le site Web ou une page de présentation', 'avant'],
    ['Ouvrir le compte bancaire et souscrire les assurances', 'avant'],
    ['Annoncer l’ouverture à mon réseau et à mes premiers contacts', 'j30'],
    ['Proposer un premier service ou un essai aux clients visés', 'j30'],
    ['Recueillir des avis et des références auprès des premiers clients', 'j60'],
    ['Publier du contenu régulièrement (site, réseaux sociaux ou infolettre)', 'j60'],
    ['Comparer les ventes réelles aux prévisions et ajuster le plan', 'j90'],
    ['Revoir les prix et l’offre selon les commentaires reçus', 'j90']
  ];

  /* ---------- Fabrique de champs ---------- */
  function champ(type, cle, etiquette, o) {
    var c = { type: type, cle: cle, etiquette: etiquette };
    if (o) for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) c[k] = o[k];
    return c;
  }
  var fac = { facultatif: true };
  function m(o1, o2) { var r = {}; var k; for (k in o1) r[k] = o1[k]; for (k in o2) r[k] = o2[k]; return r; }

  /* ---------- Étapes ---------- */
  var PHASES = [
    { id: 'projet', titre: 'Votre projet' },
    { id: 'strategie', titre: 'Votre stratégie' },
    { id: 'chiffres', titre: 'Vos chiffres' },
    { id: 'fin', titre: 'Pour terminer' }
  ];

  var ETAPES = [
    {
      id: 'projet', phase: 'projet', titre: 'Votre projet', court: 'Projet',
      intro: 'Commençons par l’essentiel : ce que vous lancez, pour qui et où vous en êtes. Rien n’est définitif : vous pourrez tout modifier.',
      aide: {
        titre: 'Ce que l’on cherche à comprendre',
        points: [
          'En quelques lignes : quoi, pour qui et pourquoi vous.',
          'Soyez précis. « Nous réparons des vélos à domicile dans Lanaudière » en dit plus que « Nous offrons des services ».',
          'Le mois de début des ventes sert de point de départ à toutes vos prévisions financières.'
        ]
      },
      champs: [
        champ('texte', 'nom', 'Nom de l’entreprise', { exemple: 'Atelier Vélo Mobile', aide: 'Le nom que vous comptez utiliser, même s’il n’est pas définitif.' }),
        champ('choix', 'forme', 'Forme juridique envisagée', m(fac, { options: FORMES, aide: 'Un avocat, un notaire ou un comptable peut vous aider à choisir.' })),
        champ('texte', 'secteur', 'Secteur d’activité', m(fac, { exemple: 'Réparation et entretien de vélos' })),
        champ('texte', 'lieu', 'Municipalité ou région', m(fac, { exemple: 'Lanaudière' })),
        champ('choix', 'stade', 'Où en êtes-vous?', m(fac, { options: STADES })),
        champ('mois', 'debut', 'Début prévu des ventes', { aide: 'Le premier mois où vous comptez facturer des clients. Un mois approximatif suffit.' }),
        champ('long', 'mission', 'En quelques phrases, que fait votre entreprise?', { exemple: 'Nous réparons et entretenons les vélos à domicile ou au bureau, pour les gens qui n’ont pas le temps d’aller en boutique.', aide: 'Dites ce que vous vendez, à qui, et ce qui vous distingue.' }),
        champ('long', 'probleme', 'Quel problème ou quel besoin réglez-vous?', { exemple: 'Les ateliers sont souvent débordés au printemps et les délais dépassent deux semaines.', aide: 'Pourquoi des clients paieraient-ils pour votre offre?' }),
        champ('long', 'objectifs', 'Vos objectifs pour les 12 premiers mois', { exemple: 'Ouvrir en avril, servir 20 clients par mois à l’automne et couvrir toutes mes dépenses d’ici le douzième mois.', aide: 'Visez des objectifs précis et mesurables : nombre de clients, chiffre d’affaires, date de lancement.' }),
        champ('long', 'vision', 'Où voulez-vous être dans trois ans?', m(fac, { exemple: 'Une équipe de deux techniciens et un point de service fixe.' }))
      ]
    },
    {
      id: 'offre', phase: 'projet', titre: 'Votre offre', court: 'Offre',
      intro: 'Listez ce que vous vendez. Les prix et les coûts que vous entrez ici servent ensuite à calculer vos revenus et votre marge.',
      aide: {
        titre: 'Pour des chiffres réalistes',
        points: [
          'Entrez les prix avant taxes (TPS 5 % et TVQ 9,975 %) : les taxes perçues ne sont pas des revenus.',
          'Le coût direct est ce que chaque vente vous coûte : matériel, pièces, sous-traitance, commissions. N’y mettez ni votre temps ni vos frais fixes.',
          'Une offre à l’heure ou au projet, un abonnement mensuel et un produit se calculent tous de la même façon : choisissez l’unité qui convient.'
        ]
      },
      champs: [
        champ('liste', 'lignes', 'Vos produits et services', {
          aide: 'Une ligne par produit ou service (au plus 8). Les prix sont avant taxes.',
          min: 1, max: 8, titreLigne: 'Offre', ajouter: 'Ajouter un produit ou un service',
          sous: [
            champ('texte', 'nom', 'Nom', { col: 4, exemple: 'Mise au point complète' }),
            champ('texte', 'unite', 'Unité de vente', { col: 2, exemple: 'service', defaut: 'unité', aide: 'heure, projet, unité, mois…' }),
            champ('texte', 'description', 'Description', m(fac, { col: 6, exemple: 'Réglage des freins et des vitesses, lubrification, vérification générale' })),
            champ('argent', 'prix', 'Prix de vente par unité', { col: 3, unite: '$' }),
            champ('argent', 'cout', 'Coût direct par unité', m(fac, { col: 3, unite: '$', aide: 'Matériel, pièces, sous-traitance' }))
          ]
        }),
        champ('long', 'avantage', 'Qu’est-ce qui vous distingue de ce qui existe déjà?', { exemple: 'Nous nous déplaçons chez le client : pas de dépôt, pas d’attente en boutique.', aide: 'Rapidité, prix, qualité, expertise, service, proximité… Choisissez ce qui compte vraiment pour vos clients.' }),
        champ('long', 'pi', 'Marque, savoir-faire ou droits à protéger', m(fac, { exemple: 'Nom commercial en cours de vérification; méthode d’entretien documentée.' }))
      ]
    },
    {
      id: 'marche', phase: 'projet', titre: 'Votre marché', court: 'Marché',
      intro: 'Montrez que vous connaissez vos clients et que le marché est assez grand pour votre entreprise.',
      aide: {
        titre: 'Ce que les prêteurs et les organismes regardent',
        points: [
          'Une clientèle décrite avec précision, plutôt que « tout le monde ».',
          'Un chiffre appuyé sur une source publique (Statistique Canada, Institut de la statistique du Québec, association de votre secteur). Nommez la source.',
          'Une preuve d’intérêt : entrevues, précommandes, essais, lettres d’intention.'
        ]
      },
      champs: [
        champ('long', 'clientele', 'Qui sont vos clients types?', { exemple: 'Des adultes de 25 à 55 ans qui pédalent chaque semaine, vivent en banlieue et travaillent à plein temps.', aide: 'Qui ils sont, où ils se trouvent, ce qu’ils cherchent et pourquoi ils achèteraient chez vous.' }),
        champ('liste', 'segments', 'Segments de clientèle', {
          aide: 'Si vous servez plusieurs groupes distincts, décrivez-les (au plus 4).',
          facultatif: true, min: 0, max: 4, titreLigne: 'Segment', ajouter: 'Ajouter un segment',
          sous: [
            champ('texte', 'nom', 'Nom du segment', { col: 3, exemple: 'Cyclistes de banlieue' }),
            champ('texte', 'taille', 'Nombre estimé de clients potentiels', m(fac, { col: 3 })),
            champ('long', 'qui', 'Qui sont-ils et que cherchent-ils?', { col: 6, court: true })
          ]
        }),
        champ('long', 'taille', 'Taille du marché et territoire visé', { exemple: 'Environ 40 000 adultes cyclistes dans le territoire desservi (source : …).', aide: 'Combien de clients potentiels y a-t-il dans votre territoire? Nommez la source de vos chiffres.' }),
        champ('long', 'tendances', 'Tendances du secteur', m(fac, { exemple: 'Hausse de l’usage du vélo utilitaire et du vélo électrique.' })),
        champ('long', 'validation', 'Qu’avez-vous fait pour vérifier l’intérêt de vos clients?', { exemple: 'Dix entrevues avec des cyclistes, un sondage dans deux groupes locaux, quatre précommandes.', aide: 'Entrevues, sondage, précommandes, essais gratuits, lettres d’intention… Si vous n’avez encore rien fait, écrivez ce que vous comptez faire.' })
      ]
    },
    {
      id: 'concurrence', phase: 'projet', titre: 'Vos concurrents', court: 'Concurrence',
      intro: 'Comparez-vous à au moins trois concurrents directs. Les nommer est un signe de sérieux : tout marché a des concurrents, même indirects.',
      aide: {
        titre: 'Comment les trouver',
        points: [
          'Cherchez en ligne comme le ferait votre client : « réparation vélo + votre ville ».',
          'Notez leurs prix publics, leurs forces et leurs faiblesses honnêtement.',
          'Si personne ne fait exactement comme vous, listez ce que vos clients font aujourd’hui à la place.'
        ]
      },
      champs: [
        champ('liste', 'concurrents', 'Vos concurrents', {
          aide: 'Au moins trois, au plus six.',
          min: 3, max: 6, titreLigne: 'Concurrent', ajouter: 'Ajouter un concurrent',
          sous: [
            champ('texte', 'nom', 'Nom', { col: 3, exemple: 'Cycles du Centre' }),
            champ('texte', 'prix', 'Prix habituels', m(fac, { col: 3, exemple: '80 $ à 120 $ la mise au point' })),
            champ('long', 'offre', 'Ce qu’il offre', m(fac, { col: 6, court: true })),
            champ('long', 'forces', 'Ses forces', m(fac, { col: 3, court: true })),
            champ('long', 'faiblesses', 'Ses faiblesses', m(fac, { col: 3, court: true }))
          ]
        }),
        champ('long', 'positionnement', 'Comment vous démarquez-vous de ces concurrents?', { exemple: 'Nous sommes les seuls à intervenir à domicile avec un délai de 48 heures.' }),
        champ('long', 'indirecte', 'Concurrence indirecte et solutions de rechange', m(fac, { exemple: 'Réparer soi-même, acheter un vélo neuf, utiliser un service de réparation en grande surface.', aide: 'Que font les clients aujourd’hui, faute de mieux?' }))
      ]
    },
    {
      id: 'marketing', phase: 'strategie', titre: 'Votre mise en marché', court: 'Mise en marché',
      intro: 'Comment ferez-vous connaître votre offre et la vendre? Terminez par un plan de lancement de 90 jours : c’est ce qui transforme le plan en actions.',
      aide: {
        titre: 'Restez concret',
        points: [
          'Choisissez deux ou trois canaux que vous pouvez vraiment tenir plutôt que dix que vous négligerez.',
          'Votre budget de marketing se saisit à l’étape Charges, avec vos autres dépenses.',
          'Un plan de lancement réaliste compte des actions petites et datées, avec un responsable.'
        ]
      },
      champs: [
        champ('long', 'valeur', 'Votre proposition de valeur en une ou deux phrases', { exemple: 'Un vélo qui roule bien, sans quitter la maison ni attendre deux semaines.' }),
        champ('long', 'prix', 'Comment avez-vous fixé vos prix?', m(fac, { exemple: 'Alignés sur les ateliers de la région, avec une prime pour le déplacement.', aide: 'Coûts, prix des concurrents, valeur perçue par les clients.' })),
        champ('cases', 'canaux', 'Où et comment vendez-vous?', { options: CANAUX, aide: 'Cochez tout ce qui s’applique.' }),
        champ('long', 'canauxDetail', 'Précisions sur la vente', m(fac, { exemple: 'Prise de rendez-vous en ligne, paiement sur place.' })),
        champ('cases', 'promo', 'Comment ferez-vous connaître votre offre?', { options: PROMOS, aide: 'Cochez tout ce qui s’applique.' }),
        champ('long', 'promoDetail', 'Précisions sur la promotion', m(fac, { exemple: 'Page Facebook locale, affichettes dans trois commerces, infolettre mensuelle.' })),
        champ('liste', 'lancement', 'Plan de lancement des 90 premiers jours', {
          aide: 'Au moins trois actions (au plus 12). Le bouton ci-dessous ajoute des suggestions que vous pouvez modifier.',
          min: 3, max: 12, titreLigne: 'Action', ajouter: 'Ajouter une action', suggestions: 'lancement', disposition: 'compacte',
          sous: [
            champ('texte', 'action', 'Action', { col: 6, exemple: 'Annoncer l’ouverture à mon réseau' }),
            champ('choix', 'periode', 'Quand', { col: 3, options: PERIODES }),
            champ('texte', 'resp', 'Responsable', m(fac, { col: 3 }))
          ]
        })
      ]
    },
    {
      id: 'operations', phase: 'strategie', titre: 'Vos opérations', court: 'Opérations',
      intro: 'Comment l’entreprise fonctionne au quotidien : où, avec quoi, avec qui, et quelles démarches vous devez faire.',
      aide: {
        titre: 'Les démarches en un coup d’œil',
        points: [
          'La liste de contrôle ci-dessous résume les démarches courantes de démarrage au Québec. Elle ne remplace pas l’avis d’un professionnel.',
          'Les règles et les seuils changent : confirmez chaque démarche auprès de l’organisme concerné.'
        ]
      },
      champs: [
        champ('choix', 'local', 'Où travaillerez-vous?', { options: LOCAUX }),
        champ('long', 'lieu', 'Lieu et installations', m(fac, { exemple: 'Atelier dans mon garage pour l’entreposage; interventions chez les clients.' })),
        champ('long', 'equipement', 'Équipement, logiciels et technologies', m(fac, { exemple: 'Remorque à vélo, outillage de mécanique, tablette de paiement, logiciel de rendez-vous.' })),
        champ('long', 'processus', 'Comment livrez-vous votre produit ou service, de la commande à la livraison?', { exemple: '1) Le client réserve en ligne; 2) je confirme et j’apporte les pièces; 3) j’effectue le travail; 4) paiement et facture sur place.' }),
        champ('long', 'capacite', 'Quelle quantité pouvez-vous livrer par mois?', m(fac, { exemple: 'Environ 30 interventions par mois, seul, à plein temps.', aide: 'Cette capacité doit être cohérente avec vos prévisions de ventes.' })),
        champ('liste', 'fournisseurs', 'Fournisseurs clés', {
          aide: 'Au plus 5.', facultatif: true, min: 0, max: 5, titreLigne: 'Fournisseur', ajouter: 'Ajouter un fournisseur',
          sous: [
            champ('texte', 'nom', 'Nom', { col: 3 }),
            champ('texte', 'fournit', 'Ce qu’il fournit', m(fac, { col: 3 })),
            champ('texte', 'conditions', 'Délais et conditions de paiement', m(fac, { col: 6 }))
          ]
        }),
        champ('demarches', 'demarches', 'Démarches de démarrage', { aide: 'Faites le point sur ce qui est fait, en cours ou à faire.' })
      ]
    },
    {
      id: 'equipe', phase: 'strategie', titre: 'Votre équipe', court: 'Équipe',
      intro: 'Qui fait tourner l’entreprise? Les prêteurs financent d’abord des personnes. La rémunération et les embauches que vous entrez ici sont reprises dans vos prévisions.',
      aide: {
        titre: 'La rémunération compte',
        points: [
          'Même sans salaire, prévoyez ce que vous devez retirer de l’entreprise pour vivre : vos prévisions seront plus réalistes.',
          'Pour une société par actions, le total des parts doit faire 100 %.',
          'Pour les salariés, entrez le salaire annuel brut de chaque personne : les charges de l’employeur s’ajoutent à l’étape Charges.'
        ]
      },
      champs: [
        champ('liste', 'promoteurs', 'Promoteurs', {
          aide: 'Les personnes qui lancent l’entreprise (au plus 4).',
          min: 1, max: 4, titreLigne: 'Promoteur', ajouter: 'Ajouter un promoteur',
          sous: [
            champ('texte', 'nom', 'Nom', { col: 3 }),
            champ('texte', 'role', 'Rôle', m(fac, { col: 3, exemple: 'Technicien et gestionnaire' })),
            champ('long', 'exp', 'Expérience et compétences utiles', m(fac, { col: 6, court: true, exemple: 'Dix ans comme mécanicien de vélos; formation en gestion.' })),
            champ('pct', 'part', 'Part de l’entreprise', m(fac, { col: 2, unite: '%' })),
            champ('argent', 'remun', 'Rémunération prévue par mois', m(fac, { col: 2, unite: '$', aide: 'Ce que l’entreprise vous verse' })),
            champ('entier', 'debutRemun', 'À partir du mois', m(fac, { col: 2, min: 1, max: 36, defaut: 1, aide: '1 = premier mois' }))
          ]
        }),
        champ('liste', 'employes', 'Embauches prévues', {
          aide: 'Les employés que vous comptez embaucher pendant les trois premières années (au plus 6).',
          facultatif: true, min: 0, max: 6, titreLigne: 'Poste', ajouter: 'Ajouter une embauche',
          sous: [
            champ('texte', 'poste', 'Poste', { col: 3 }),
            champ('entier', 'nombre', 'Nombre de personnes', { col: 1, min: 1, max: 100, defaut: 1 }),
            champ('argent', 'salaire', 'Salaire annuel brut par personne', { col: 2, unite: '$' }),
            champ('entier', 'mois', 'Embauché au mois', { col: 2, min: 1, max: 36, defaut: 1, aide: '1 = premier mois, 13 = début de l’année 2' })
          ]
        }),
        champ('long', 'conseillers', 'Conseillers et partenaires externes', m(fac, { exemple: 'Comptable externe, mentor de l’organisme de développement économique local.', aide: 'Comptable, avocat, mentor, organisme d’accompagnement…' })),
        champ('long', 'manques', 'Compétences à acquérir ou à embaucher', m(fac, { exemple: 'Comptabilité et marketing numérique : formation prévue au premier trimestre.' }))
      ]
    },
    {
      id: 'risques', phase: 'strategie', titre: 'Vos risques', court: 'Risques',
      intro: 'Tout projet comporte des risques. Les nommer et prévoir une réponse rassure plus qu’un plan qui prétend ne pas en avoir.',
      aide: {
        titre: 'Comment procéder',
        points: [
          'Pour chaque risque, évaluez la probabilité (est-ce probable?) et l’impact (est-ce grave?).',
          'Une mesure, c’est une action concrète : diversifier ses clients, garder une réserve, avoir un fournisseur de remplacement.',
          'Le bouton ci-dessous ajoute des risques courants que vous pouvez adapter ou supprimer.'
        ]
      },
      champs: [
        champ('liste', 'liste', 'Principaux risques', {
          aide: 'Au moins trois (au plus 8).',
          min: 3, max: 8, titreLigne: 'Risque', ajouter: 'Ajouter un risque', suggestions: 'risques',
          sous: [
            champ('long', 'desc', 'Risque', { col: 6, court: true, exemple: 'Les ventes démarrent plus lentement que prévu' }),
            champ('choix', 'proba', 'Probabilité', { col: 2, options: NIVEAUX_RISQUE }),
            champ('choix', 'impact', 'Impact', { col: 2, options: NIVEAUX_RISQUE }),
            champ('long', 'mesure', 'Mesure pour le réduire', { col: 6, court: true })
          ]
        }),
        champ('long', 'planB', 'Si vos ventes sont inférieures aux prévisions, que ferez-vous?', m(fac, { exemple: 'Réduire les dépenses de marketing, offrir des forfaits aux entreprises, conserver un emploi à temps partiel.', aide: 'L’étape Résultats vous montre l’effet d’une baisse des ventes sur votre trésorerie.' }))
      ]
    },
    {
      id: 'ventes', phase: 'chiffres', titre: 'Vos ventes', court: 'Ventes', bloc: 'ventes',
      intro: 'Combien en vendrez-vous? Pour chaque offre, indiquez la quantité mensuelle au lancement et au douzième mois : l’outil calcule la progression, puis les années 2 et 3.',
      aide: {
        titre: 'Des prévisions défendables',
        points: [
          'Partez de votre capacité réelle et de vos premiers clients plutôt que d’un objectif de revenus.',
          'Une quantité au douzième mois deux ou trois fois supérieure à celle du lancement est déjà ambitieuse; justifiez-la.',
          'Si vos ventes varient selon les saisons, entrez des indices dans la section prévue à cet effet.',
          'Les années 2 et 3 partent du total de l’année précédente. Si vos ventes montent vite pendant l’année 1, une croissance trop faible ferait redescendre les ventes mensuelles de l’année 2 sous celles de votre douzième mois.'
        ]
      },
      champs: [
        champ('carte', 'lignes', 'Quantités vendues par mois', { custom: true }),
        champ('pct', 'g2', 'Croissance des ventes de l’année 2', m(fac, { unite: '%', aide: 'Par rapport au total de l’année 1, y compris ses premiers mois plus lents. Entrez 0 pour un total annuel identique.', custom: true })),
        champ('pct', 'g3', 'Croissance des ventes de l’année 3', m(fac, { unite: '%', aide: 'Par rapport au total de l’année 2.', custom: true })),
        champ('choix', 'delaiClients', 'Délai de paiement de vos clients', m(fac, { options: DELAIS_CLIENTS, numerique: true, aide: 'Comptant si vos clients paient au moment de la vente.', custom: true })),
        champ('serie12', 'saison', 'Variation selon les saisons', m(fac, { custom: true }))
      ]
    },
    {
      id: 'charges', phase: 'chiffres', titre: 'Vos charges', court: 'Charges', bloc: 'charges',
      intro: 'Les dépenses qui reviennent chaque mois, que vous vendiez beaucoup ou peu. Les salaires et la rémunération viennent de l’étape Équipe.',
      aide: {
        titre: 'Pour ne rien oublier',
        points: [
          'Si une dépense est annuelle (assurance, cotisation), divisez-la par 12.',
          'Prévoyez un budget de marketing même modeste : sans lui, les ventes prévues ne viennent pas toutes seules.',
          'Vos coûts directs (matériel par vente) sont déjà comptés à l’étape Offre : ne les mettez pas ici.'
        ]
      },
      champs: [
        champ('liste', 'liste', 'Charges fixes mensuelles', {
          custom: true, min: 0, max: 30, titreLigne: 'Charge', ajouter: 'Ajouter une charge', disposition: 'compacte',
          sous: [
            champ('texte', 'nom', 'Charge', { col: 7 }),
            champ('argent', 'montant', 'Montant par mois', { col: 3, unite: '$' }),
            champ('entier', 'mois', 'Dès le mois', { col: 2, min: 1, max: 36, defaut: 1, aide: '1 = premier mois' })
          ]
        }),
        champ('coche', 'aucune', 'Je n’ai aucune charge fixe à déclarer', fac),
        champ('pct', 'hausse', 'Hausse annuelle des charges et des salaires', m(fac, { unite: '%', custom: true, aide: 'Appliquée à partir de l’année 2.' })),
        champ('pct', 'chargesSociales', 'Charges sociales de l’employeur', m(fac, { unite: '%', custom: true, aide: 'En pourcentage des salaires versés aux employés. À valider avec votre comptable.' })),
        champ('pct', 'fraisTransaction', 'Frais de transaction sur les ventes', m(fac, { unite: '%', custom: true, aide: 'Cartes de crédit, plateformes de paiement : pourcentage retenu sur chaque vente.' })),
        champ('choix', 'delaiFournisseurs', 'Délai de paiement de vos fournisseurs', m(fac, { options: DELAIS_FOURNISSEURS, numerique: true, custom: true }))
      ]
    },
    {
      id: 'financement', phase: 'chiffres', titre: 'Démarrage et financement', court: 'Financement', bloc: 'financement',
      intro: 'De combien avez-vous besoin pour ouvrir, et d’où viendra l’argent? Les sources de financement doivent couvrir les dépenses de démarrage, puis tenir votre trésorerie à flot.',
      aide: {
        titre: 'Comment lire cette étape',
        points: [
          'Les investissements sont des achats durables (équipement, véhicule). Ils sont étalés sur leur durée de vie.',
          'Les frais de démarrage sont payés avant l’ouverture : immatriculation, permis, site Web, première prime d’assurance. Ils réduisent votre trésorerie de départ, mais ne sont pas déduits du résultat des trois années.',
          'N’ajoutez pas ici les marchandises que vous revendrez : elles sont déjà comptées dans vos coûts directs, au moment de chaque vente. Si vous devez acheter un premier stock avant l’ouverture, prévoyez une réserve de trésorerie plus élevée.',
          'Un prêt doit avoir un taux et une durée pour que les remboursements soient calculés.'
        ]
      },
      champs: [
        champ('liste', 'invest', 'Investissements (achats durables)', {
          custom: true, min: 0, max: 30, titreLigne: 'Investissement', ajouter: 'Ajouter un investissement', disposition: 'compacte',
          sous: [
            champ('texte', 'nom', 'Investissement', { col: 7 }),
            champ('argent', 'montant', 'Montant', { col: 3, unite: '$' }),
            champ('entier', 'duree', 'Durée de vie (années)', { col: 2, min: 1, max: 40, defaut: 5 })
          ]
        }),
        champ('liste', 'demarrage', 'Frais de démarrage', {
          custom: true, min: 0, max: 30, titreLigne: 'Frais', ajouter: 'Ajouter un frais', disposition: 'compacte',
          sous: [
            champ('texte', 'nom', 'Frais', { col: 8 }),
            champ('argent', 'montant', 'Montant', { col: 4, unite: '$' })
          ]
        }),
        champ('liste', 'sources', 'Sources de financement', {
          custom: true, min: 0, max: 12, titreLigne: 'Source', ajouter: 'Ajouter une source de financement',
          sous: [
            champ('choix', 'type', 'Type', { col: 6, options: TYPES_SOURCE, defaut: 'apport' }),
            champ('texte', 'nom', 'Nom ou provenance', m(fac, { col: 6, exemple: 'Mon épargne personnelle' })),
            champ('choix', 'statut', 'Statut', { col: 4, options: STATUTS_SOURCE, defaut: 'envisage' }),
            champ('argent', 'montant', 'Montant', { col: 4, unite: '$' }),
            champ('entier', 'mois', 'Reçu au mois', m(fac, { col: 4, min: 0, max: 36, defaut: 0, aide: '0 = avant l’ouverture, 1 = premier mois' })),
            champ('pct', 'taux', 'Taux d’intérêt annuel', m(fac, { col: 4, unite: '%', pret: true })),
            champ('entier', 'duree', 'Durée du prêt (mois)', m(fac, { col: 4, min: 0, max: 360, pret: true })),
            champ('entier', 'grace', 'Mois sans remboursement du capital', m(fac, { col: 4, min: 0, max: 359, pret: true }))
          ]
        }),
        champ('coche', 'aucun', 'Je n’ai ni dépense de démarrage ni financement à déclarer', fac),
        champ('argent', 'coussin', 'Réserve de trésorerie minimale souhaitée', m(fac, { unite: '$', custom: true, aide: 'Montant que votre compte ne devrait jamais descendre sous. Il sert à calculer le financement dont vous avez besoin.' })),
        champ('long', 'garanties', 'Garanties que vous pouvez offrir', m(fac, { exemple: 'Caution personnelle, équipement acheté, assurance vie.', aide: 'Un prêteur voudra savoir ce qui garantit le remboursement.' })),
        champ('long', 'modalites', 'Autres précisions sur le financement', m(fac, { exemple: 'Demande déposée à l’organisme de financement local; décision attendue dans six semaines.' }))
      ]
    },
    {
      id: 'resultats', phase: 'chiffres', titre: 'Vos résultats', court: 'Résultats', bloc: 'resultats', sansChamps: true,
      intro: 'Voici ce que vos hypothèses donnent sur trois ans. Si un chiffre vous surprend, c’est le signe qu’une hypothèse mérite d’être revue : revenez à l’étape concernée.',
      aide: {
        titre: 'Comment interpréter',
        points: [
          'Le résultat est ce que l’entreprise gagne sur papier; la trésorerie est l’argent réellement disponible. Une entreprise rentable peut manquer d’argent.',
          'Essayez une baisse des ventes de 20 % : si votre trésorerie tient, votre plan est plus solide.',
          'Aucun impôt ni aucune taxe de vente n’est calculé : demandez à un comptable d’en tenir compte.'
        ]
      },
      champs: []
    },
    {
      id: 'sommaire', phase: 'fin', titre: 'Votre sommaire', court: 'Sommaire',
      intro: 'Le sommaire est la première page lue. Écrivez-le en dernier : trois courts textes suffisent, l’outil ajoute vos chiffres clés.',
      aide: {
        titre: 'Court et clair',
        points: [
          'Une phrase qui dit tout : ce que vous faites, pour qui, et pourquoi ça fonctionnera.',
          'Si vous cherchez du financement, précisez le montant et ce qu’il permet de faire.'
        ]
      },
      champs: [
        champ('long', 'phrase', 'Votre projet en quelques phrases', { exemple: 'Atelier Vélo Mobile répare et entretient les vélos à domicile dans Lanaudière. Il vise 90 interventions par mois au douzième mois.' }),
        champ('long', 'pourquoi', 'Pourquoi ce projet, et pourquoi maintenant?', m(fac, { exemple: 'L’usage du vélo augmente et les ateliers sont débordés au printemps.' })),
        champ('long', 'demande', 'Ce que vous demandez', m(fac, { exemple: 'Un prêt de 8 000 $ pour acheter l’outillage et couvrir les premiers mois.' }))
      ]
    },
    {
      id: 'export', phase: 'fin', titre: 'Aperçu et exportation', court: 'Exportation', bloc: 'export', sansChamps: true,
      intro: 'Relisez votre plan, puis enregistrez-le en PDF, en Word ou en sauvegarde. Votre plan reste sur cet appareil tant que vous ne l’exportez pas.',
      aide: { titre: 'Avant d’envoyer votre plan', points: ['Relisez les sections marquées « À compléter ».', 'Faites valider vos chiffres par un comptable avant de les présenter à un prêteur.'] },
      champs: []
    }
  ];

  /* ---------- Accès aux étapes ---------- */
  function etapeParId(id) {
    for (var i = 0; i < ETAPES.length; i++) if (ETAPES[i].id === id) return ETAPES[i];
    return null;
  }
  /* Section des réponses où se trouvent les champs d'une étape (les étapes « ventes » et « charges » ont leur propre section). */
  function sectionDe(etape) {
    return etape.section || etape.id;
  }

  /* ---------- État d'un plan ---------- */
  var alphabet = 'abcdefghijklmnopqrstuvwxyz0123456789';
  function nouvelId() {
    var s = 'x';
    for (var i = 0; i < 7; i++) s += alphabet.charAt(Math.floor(Math.random() * alphabet.length));
    return s;
  }
  function iso() { return new Date().toISOString(); }

  function ligne(ch, defauts) {
    var l = { id: nouvelId() };
    ch.sous.forEach(function (s) {
      if (s.type === 'cases') l[s.cle] = [];
      else if (s.defaut !== undefined) l[s.cle] = s.defaut;
      else l[s.cle] = (s.type === 'argent' || s.type === 'pct' || s.type === 'entier') ? null : '';
    });
    if (defauts) for (var k in defauts) if (Object.prototype.hasOwnProperty.call(defauts, k)) l[k] = defauts[k];
    return l;
  }
  function champListe(etapeId, cle) {
    var e = etapeParId(etapeId);
    for (var i = 0; i < e.champs.length; i++) if (e.champs[i].cle === cle) return e.champs[i];
    return null;
  }

  function etatVide() {
    var r = {};
    ETAPES.forEach(function (e) {
      if (!e.champs.length) return;
      var sec = sectionDe(e);
      if (!r[sec]) r[sec] = {};
      e.champs.forEach(function (c) {
        if (c.type === 'liste') {
          var n = c.min || 0;
          r[sec][c.cle] = [];
          for (var i = 0; i < n; i++) r[sec][c.cle].push(ligne(c));
        } else if (c.type === 'cases') r[sec][c.cle] = [];
        else if (c.type === 'demarches') {
          r[sec][c.cle] = {};
          DEMARCHES.forEach(function (d) { r[sec][c.cle][d.id] = 'afaire'; });
        } else if (c.type === 'carte') r[sec][c.cle] = {};
        else if (c.type === 'serie12') r[sec][c.cle] = [null, null, null, null, null, null, null, null, null, null, null, null];
        else if (c.type === 'coche') r[sec][c.cle] = false;
        else if (c.type === 'argent' || c.type === 'pct' || c.type === 'entier') r[sec][c.cle] = null;
        else if (c.numerique) r[sec][c.cle] = 0;
        else r[sec][c.cle] = '';
      });
    });
    // L'étape Ventes écrit dans « ventes » ; l'étape Charges dans « charges » ; l'étape Financement dans « financement ».
    // Lignes suggérées (sans montant) pour guider la saisie.
    CHARGES_TYPES.forEach(function (nom) { r.charges.liste.push(m(ligne(champListe('charges', 'liste')), { nom: nom })); });
    INVEST_TYPES.forEach(function (nom) { r.financement.invest.push(m(ligne(champListe('financement', 'invest')), { nom: nom })); });
    DEMARRAGE_TYPES.forEach(function (nom) { r.financement.demarrage.push(m(ligne(champListe('financement', 'demarrage')), { nom: nom })); });
    r.financement.sources.push(m(ligne(champListe('financement', 'sources')), { type: 'apport', nom: 'Mise de fonds personnelle', statut: 'confirme' }));
    accorderVentes(r);
    return r;
  }

  /* Garde dans « ventes.lignes » une entrée par offre, dans l'ordre des offres, et aucune pour une offre supprimée.
     À appeler après chaque ajout, suppression ou déplacement d'une offre. */
  function accorderVentes(r) {
    var anciennes = r.ventes.lignes && typeof r.ventes.lignes === 'object' ? r.ventes.lignes : {};
    var nouvelles = {};
    r.offre.lignes.forEach(function (l) {
      nouvelles[l.id] = Object.prototype.hasOwnProperty.call(anciennes, l.id) && anciennes[l.id] ? anciennes[l.id] : { debut: 1, m1: null, m12: null };
    });
    r.ventes.lignes = nouvelles;
    return r;
  }

  function nouvelEtat() {
    return { v: VERSION_ETAT, cree: iso(), maj: iso(), etape: 'accueil', r: etatVide(), ui: { baisse: 0, mention: true } };
  }

  /* Ajoute les lignes suggérées d'une liste (risques, lancement). */
  function suggestions(nom) {
    if (nom === 'risques') return RISQUES_TYPES.map(function (t) { return { desc: t }; });
    if (nom === 'lancement') return LANCEMENT_TYPES.map(function (t) { return { action: t[0], periode: t[1] }; });
    return [];
  }

  /* ---------- Assainissement strict (sauvegarde importée, stockage local) ---------- */
  function chaine(v, max) {
    if (typeof v !== 'string') return '';
    // Retire les caractères de contrôle (sauf saut de ligne et tabulation) et les caractères interdits en XML.
    var s = v.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f￾￿\u007f]/g, '').replace(/\r\n?/g, '\n');
    return s.length > max ? s.slice(0, max) : s;
  }
  function entierBorne(v, min, max, defaut) {
    var n = Calc.lireNombre(v);
    if (n === null) return defaut;
    n = Math.floor(n);
    return n < min ? min : n > max ? max : n;
  }
  function nombreBorne(v, min, max) {
    var n = Calc.lireNombre(v);
    if (n === null) return null;
    return n < min ? min : n > max ? max : n;
  }
  function dansOptions(v, options, defaut) {
    for (var i = 0; i < options.length; i++) if (options[i].v === v) return v;
    return defaut;
  }
  function idSur(v) {
    return typeof v === 'string' && /^[a-z0-9]{1,16}$/i.test(v) ? v : nouvelId();
  }

  function valeurChamp(c, v, contexte) {
    switch (c.type) {
      case 'texte': return chaine(v, c.max || MAX_TEXTE).replace(/\n/g, ' ');
      case 'long': return chaine(v, c.max || (c.court ? MAX_COURT : MAX_LONG));
      case 'choix':
        if (c.numerique) {
          var n = Calc.lireNombre(v);
          return dansOptions(n, c.options, c.options[0].v);
        }
        return dansOptions(v, c.options, c.defaut !== undefined ? c.defaut : '');
      case 'cases': {
        // Une seule passe, arrêtée dès que toutes les options sont prises : une copie de sauvegarde piégée qui
        // contiendrait des centaines de milliers de valeurs ne doit pas figer le navigateur. L'ordre saisi est conservé.
        var entree = Array.isArray(v) ? v : [], choisies = [];
        for (var ci = 0; ci < entree.length && choisies.length < c.options.length; ci++) {
          var x = entree[ci];
          if (choisies.indexOf(x) === -1 && c.options.some(function (o) { return o.v === x; })) choisies.push(x);
        }
        return choisies;
      }
      case 'mois': {
        var mm = Calc.lireMois(v);
        return mm ? v : '';
      }
      case 'argent': return nombreBorne(v, 0, 1e9);
      case 'pct': return nombreBorne(v, c.min !== undefined ? c.min : -100, c.max !== undefined ? c.max : 1000);
      case 'entier': {
        var e = Calc.lireNombre(v);
        if (e === null) return c.defaut !== undefined ? c.defaut : null;
        e = Math.floor(e);
        var mn = c.min !== undefined ? c.min : 0, mx = c.max !== undefined ? c.max : 1e6;
        return e < mn ? mn : e > mx ? mx : e;
      }
      case 'coche': return v === true;
      case 'liste': return listeValide(c, v);
      case 'demarches': {
        var d = {};
        DEMARCHES.forEach(function (x) { d[x.id] = dansOptions(v && typeof v === 'object' ? v[x.id] : undefined, STATUTS_DEMARCHE, 'afaire'); });
        return d;
      }
      case 'serie12': {
        var s = [];
        for (var i = 0; i < 12; i++) s.push(nombreBorne(Array.isArray(v) ? v[i] : null, 0, 1000));
        return s;
      }
      case 'carte': {
        var out = {};
        var ids = contexte && contexte.idsOffre ? contexte.idsOffre : [];
        ids.forEach(function (id) {
          var src = v && typeof v === 'object' && Object.prototype.hasOwnProperty.call(v, id) && v[id] && typeof v[id] === 'object' ? v[id] : {};
          out[id] = { debut: entierBorne(src.debut, 1, 12, 1), m1: nombreBorne(src.m1, 0, 1e9), m12: nombreBorne(src.m12, 0, 1e9) };
        });
        return out;
      }
      default: return null;
    }
  }

  function listeValide(c, v) {
    var rows = Array.isArray(v) ? v.slice(0, c.max || 30) : [];
    var vus = {};
    var out = rows.map(function (row) {
      row = row && typeof row === 'object' ? row : {};
      var l = { id: idSur(row.id) };
      while (vus[l.id]) l.id = nouvelId();
      vus[l.id] = true;
      c.sous.forEach(function (s) { l[s.cle] = valeurChamp(s, row[s.cle]); });
      return l;
    });
    var min = c.min || 0;
    while (out.length < min) out.push(ligne(c));
    return out;
  }

  /* Reconstruit un état propre à partir d'un objet inconnu (jamais de copie directe : rien d'inattendu n'est conservé). */
  function assainir(brut) {
    if (!brut || typeof brut !== 'object' || Array.isArray(brut)) return null;
    var src = brut.r && typeof brut.r === 'object' ? brut.r : {};
    var propre = nouvelEtat();
    propre.cree = typeof brut.cree === 'string' && !isNaN(Date.parse(brut.cree)) ? new Date(brut.cree).toISOString() : propre.cree;
    propre.maj = typeof brut.maj === 'string' && !isNaN(Date.parse(brut.maj)) ? new Date(brut.maj).toISOString() : propre.maj;
    propre.etape = typeof brut.etape === 'string' && (brut.etape === 'accueil' || etapeParId(brut.etape)) ? brut.etape : 'accueil';
    var ui = brut.ui && typeof brut.ui === 'object' ? brut.ui : {};
    // Le curseur de l'outil va de 0 à 50 % par pas de 5 : une copie de sauvegarde ne peut pas imposer une autre valeur.
    propre.ui = { baisse: Math.round(entierBorne(ui.baisse, 0, 50, 0) / 5) * 5, mention: ui.mention !== false };

    var r = {};
    ETAPES.forEach(function (e) {
      if (!e.champs.length) return;
      var sec = sectionDe(e);
      var s = src[sec] && typeof src[sec] === 'object' && !Array.isArray(src[sec]) ? src[sec] : {};
      if (!r[sec]) r[sec] = {};
      e.champs.forEach(function (c) {
        var ctx = null;
        if (c.type === 'carte') {
          var offres = r.offre && Array.isArray(r.offre.lignes) ? r.offre.lignes : [];
          ctx = { idsOffre: offres.map(function (l) { return l.id; }) };
        }
        var val = Object.prototype.hasOwnProperty.call(s, c.cle) ? s[c.cle] : undefined;
        r[sec][c.cle] = valeurChamp(c, val, ctx);
        if (c.type === 'liste' && val === undefined) r[sec][c.cle] = nouvelEtat().r[sec][c.cle] || r[sec][c.cle];
      });
    });
    propre.r = r;
    return propre;
  }

  /* ---------- Complétude ---------- */
  function t(v) { return typeof v === 'string' ? v.trim() : ''; }
  function nbLignes(liste, test) { return (liste || []).filter(test).length; }
  function plusDeZero(v) { return typeof v === 'number' && v > 0; }

  var VERIFS = {
    projet: function (r) {
      var p = r.projet;
      return [
        ['le nom de l’entreprise', !!t(p.nom)],
        ['le mois de début des ventes', !!Calc.lireMois(p.debut)],
        ['la description de l’entreprise', !!t(p.mission)],
        ['le problème ou le besoin auquel vous répondez', !!t(p.probleme)],
        ['vos objectifs des 12 premiers mois', !!t(p.objectifs)]
      ];
    },
    offre: function (r) {
      var o = r.offre;
      return [
        ['au moins un produit ou service avec un nom et un prix', nbLignes(o.lignes, function (l) { return t(l.nom) && plusDeZero(l.prix); }) >= 1],
        ['ce qui vous distingue', !!t(o.avantage)]
      ];
    },
    marche: function (r) {
      var k = r.marche;
      return [
        ['la description de vos clients types', !!t(k.clientele)],
        ['la taille du marché et le territoire visé', !!t(k.taille)],
        ['ce que vous avez fait pour vérifier l’intérêt des clients', !!t(k.validation)]
      ];
    },
    concurrence: function (r) {
      var c = r.concurrence;
      return [
        ['au moins trois concurrents nommés', nbLignes(c.concurrents, function (x) { return !!t(x.nom); }) >= 3],
        ['la façon dont vous vous démarquez', !!t(c.positionnement)]
      ];
    },
    marketing: function (r) {
      var k = r.marketing;
      return [
        ['votre proposition de valeur', !!t(k.valeur)],
        ['au moins un canal de vente', k.canaux.length >= 1],
        ['au moins un moyen de promotion', k.promo.length >= 1],
        ['au moins trois actions de lancement', nbLignes(k.lancement, function (x) { return !!t(x.action); }) >= 3]
      ];
    },
    operations: function (r) {
      var o = r.operations;
      return [
        ['l’endroit où vous travaillerez', !!o.local],
        ['la façon de livrer votre produit ou service', !!t(o.processus)]
      ];
    },
    equipe: function (r) {
      var e = r.equipe;
      return [['au moins un promoteur nommé', nbLignes(e.promoteurs, function (x) { return !!t(x.nom); }) >= 1]];
    },
    risques: function (r) {
      var k = r.risques;
      return [['au moins trois risques décrits', nbLignes(k.liste, function (x) { return !!t(x.desc); }) >= 3]];
    },
    ventes: function (r) {
      var o = r.offre.lignes, v = r.ventes.lignes;
      var ok = o.some(function (l) { var x = v[l.id]; return x && (plusDeZero(x.m1) || plusDeZero(x.m12)); });
      return [['des quantités vendues pour au moins une offre', ok]];
    },
    charges: function (r) {
      var c = r.charges;
      return [['vos charges fixes (ou la mention « aucune charge »)', c.aucune || nbLignes(c.liste, function (x) { return plusDeZero(x.montant); }) >= 1]];
    },
    financement: function (r) {
      var f = r.financement;
      var sources = nbLignes(f.sources, function (x) { return plusDeZero(x.montant) && x.type !== 'marge'; });
      return [['vos sources de financement (ou la mention « rien à déclarer »)', f.aucun || sources >= 1]];
    },
    sommaire: function (r) {
      return [['votre projet en quelques phrases', !!t(r.sommaire.phrase)]];
    }
  };

  /* { etat: 'complet' | 'encours' | 'vide', fait, total, manques: [libellés] } pour une étape. */
  function etatEtape(id, r) {
    var f = VERIFS[id];
    if (!f) {
      // Résultats et exportation : complets quand les étapes de chiffres (ou toutes) le sont.
      var deps = id === 'resultats' ? ['ventes', 'charges', 'financement'] : ETAPES.map(function (e) { return e.id; }).filter(function (x) { return VERIFS[x]; });
      var tous = deps.every(function (d) { return etatEtape(d, r).etat === 'complet'; });
      var aucun = deps.every(function (d) { return etatEtape(d, r).etat === 'vide'; });
      return { etat: tous ? 'complet' : aucun ? 'vide' : 'encours', fait: tous ? 1 : 0, total: 1, manques: [] };
    }
    var verifs = f(r);
    var fait = verifs.filter(function (x) { return x[1]; }).length;
    return {
      etat: fait === verifs.length ? 'complet' : fait === 0 ? 'vide' : 'encours',
      fait: fait, total: verifs.length,
      manques: verifs.filter(function (x) { return !x[1]; }).map(function (x) { return x[0]; })
    };
  }

  function progression(r) {
    var fait = 0, total = 0, etapes = {}, completes = 0, nb = 0;
    ETAPES.forEach(function (e) {
      var s = etatEtape(e.id, r);
      etapes[e.id] = s;
      if (VERIFS[e.id]) { fait += s.fait; total += s.total; nb++; if (s.etat === 'complet') completes++; }
    });
    return { fait: fait, total: total, pourcent: total ? Math.round(100 * fait / total) : 0, etapes: etapes, completes: completes, nbEtapes: nb };
  }

  /* ---------- Textes des alertes ---------- */
  function messageAlerte(a) {
    var p = a.params || {};
    var $ = Calc.argent;
    var nom = function (s) { return '« ' + (s || 'sans nom') + ' »'; };
    switch (a.code) {
      case 'debut_manquant': return T('Indiquez le mois de début des ventes (étape Projet) : les prévisions de la première année et les variations de saison en dépendent.');
      case 'aucune_vente': return T('Aucune vente n’est prévue la première année. Entrez des quantités à l’étape Ventes.');
      case 'prix_sous_cout': return T('Le coût direct de ' + nom(p.nom) + ' dépasse son prix de vente : chaque vente vous ferait perdre de l’argent.');
      case 'an2_sous_mois12': return T('Pour ' + nom(p.nom) + ', les ventes moyennes de l’année 2 (' + Calc.decimal(p.moyenneAn2, 1) + ' par mois) sont inférieures à votre rythme du mois 12 (' + Calc.decimal(p.mois12, 1) + '). La croissance de l’année 2 s’applique au total de l’année 1 : augmentez-la si vos ventes continuent de monter.');
      case 'demarrage_non_couvert': return T('Vos sources de financement ne couvrent pas les dépenses de démarrage : il manque ' + $(p.manque) + '.');
      case 'tresorerie_negative': return T('Votre trésorerie devient négative au mois ' + p.mois + ' (' + $(p.montant) + '). Son point le plus bas est de ' + $(p.minimum) + ' au mois ' + p.moisMin + '. Ajoutez du financement, reportez des dépenses ou revoyez vos ventes.');
      case 'seuil_tps_trimestre': return T('Vos ventes prévues dépassent 30 000 $ en un trimestre (' + $(p.ventes) + '). Selon Revenu Québec, vous devriez alors vous inscrire aux fichiers de la TPS et de la TVQ : vérifiez votre situation auprès de Revenu Québec.');
      case 'seuil_tps_annee': return T('Vos ventes prévues pour la première année (' + $(p.ventes) + ') dépassent 30 000 $. Selon Revenu Québec, l’inscription aux fichiers de la TPS et de la TVQ devient obligatoire au-delà de ce seuil sur quatre trimestres consécutifs : vérifiez votre situation auprès de Revenu Québec.');
      case 'sous_seuil_tps': return T('Vos ventes prévues pour la première année (' + $(p.ventes) + ') restent sous 30 000 $. Vous pourriez être un petit fournisseur, pour qui l’inscription aux taxes de vente est facultative : confirmez-le auprès de Revenu Québec.');
      case 'parts_incorrectes': return T('Les parts des promoteurs totalisent ' + Calc.pourcent(p.total) + ' au lieu de 100 %.');
      case 'pret_sans_duree': return T('Précisez la durée du prêt ' + nom(p.nom) + ' : sans elle, aucun remboursement n’est calculé.');
      case 'sans_remuneration': return T('Aucune rémunération n’est prévue pour les promoteurs. Même sans salaire, prévoyez ce que vous devez retirer de l’entreprise pour vivre : vos prévisions seront plus réalistes.');
      case 'charges_vides': return T('Aucune charge fixe n’est entrée. Loyer, assurances, logiciels, téléphone : la plupart des entreprises en ont.');
      case 'sources_vides': return T('Aucune source de financement n’est entrée alors que vous avez des dépenses de démarrage.');
      case 'financement_non_confirme': return T($(p.montant) + ' du financement n’est pas encore confirmé.');
      case 'pertes_deux_ans': return T('Votre entreprise est déficitaire les deux premières années. Revoyez vos prix, vos volumes ou vos charges, ou prévoyez comment vous couvrirez ces pertes.');
      default: return '';
    }
  }

  NS.Modele = {
    VERSION_ETAT: VERSION_ETAT, MAX_TEXTE: MAX_TEXTE, MAX_LONG: MAX_LONG, MAX_COURT: MAX_COURT,
    T: T, PHASES: PHASES, ETAPES: ETAPES, DEMARCHES: DEMARCHES,
    FORMES: FORMES, STADES: STADES, LOCAUX: LOCAUX, CANAUX: CANAUX, PROMOS: PROMOS, PERIODES: PERIODES,
    NIVEAUX_RISQUE: NIVEAUX_RISQUE, TYPES_SOURCE: TYPES_SOURCE, STATUTS_SOURCE: STATUTS_SOURCE, STATUTS_DEMARCHE: STATUTS_DEMARCHE,
    DELAIS_CLIENTS: DELAIS_CLIENTS, DELAIS_FOURNISSEURS: DELAIS_FOURNISSEURS, MOIS_NOMS: MOIS_NOMS, deMois: deMois,
    etapeParId: etapeParId, sectionDe: sectionDe, champListe: champListe,
    nouvelId: nouvelId, ligne: ligne, nouvelEtat: nouvelEtat, etatVide: etatVide, accorderVentes: accorderVentes, suggestions: suggestions,
    assainir: assainir, valeurChamp: valeurChamp,
    etatEtape: etatEtape, progression: progression, messageAlerte: messageAlerte
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = NS.Modele;
})(typeof window !== 'undefined' ? window : globalThis);
