/* ==========================================================================
   Améliorations progressives.
   Sans JavaScript, le site reste lisible et navigable : le menu s'affiche en
   entier, les secteurs se suivent à la verticale, la FAQ s'ouvre avec le
   navigateur et le répertoire montre tous les programmes.
   ========================================================================== */
(function () {
  'use strict';

  var doc = document;
  var cfg = window.SITE_CONFIG || {};

  function $(sel, ctx) { return (ctx || doc).querySelector(sel); }
  function $$(sel, ctx) { return Array.prototype.slice.call((ctx || doc).querySelectorAll(sel)); }
  function el(tag, classe, texte) {
    var n = doc.createElement(tag);
    if (classe) n.className = classe;
    if (texte !== undefined && texte !== null) n.textContent = texte;
    return n;
  }
  function essayer(fn) { try { fn(); } catch (e) { if (window.console) console.error(e); } }

  /* ----------------------------------------------------------------------
     Navigation : panneau sur petit écran, menu « Ressources » sur grand écran
     ---------------------------------------------------------------------- */
  function initNav() {
    var bascule = $('.nav-toggle');
    var nav = $('.nav');
    var etiquette = bascule ? $('.nav-toggle__texte', bascule) : null;
    var groupes = $$('.nav__groupe');

    function ouvrirMenu(ouvert) {
      if (!bascule || !nav) return;
      bascule.setAttribute('aria-expanded', ouvert ? 'true' : 'false');
      nav.classList.toggle('is-open', ouvert);
      if (etiquette) etiquette.textContent = ouvert ? 'Fermer' : 'Menu';
    }
    function ouvrirGroupe(g, ouvert) {
      var b = $('button', g);
      g.classList.toggle('is-open', ouvert);
      if (b) b.setAttribute('aria-expanded', ouvert ? 'true' : 'false');
    }

    if (bascule && nav) {
      bascule.addEventListener('click', function () {
        ouvrirMenu(bascule.getAttribute('aria-expanded') !== 'true');
      });
      nav.addEventListener('click', function (e) {
        if (e.target && e.target.closest && e.target.closest('a')) ouvrirMenu(false);
      });
    }

    groupes.forEach(function (g) {
      var b = $('button', g);
      if (!b) return;
      b.addEventListener('click', function () { ouvrirGroupe(g, !g.classList.contains('is-open')); });
      g.addEventListener('focusout', function (e) {
        if (e.relatedTarget && !g.contains(e.relatedTarget)) ouvrirGroupe(g, false);
      });
    });

    doc.addEventListener('click', function (e) {
      groupes.forEach(function (g) { if (!g.contains(e.target)) ouvrirGroupe(g, false); });
    });

    doc.addEventListener('keydown', function (e) {
      if (e.key !== 'Escape') return;
      var ouvert = groupes.filter(function (g) { return g.classList.contains('is-open'); })[0];
      if (ouvert) {
        ouvrirGroupe(ouvert, false);
        var b = $('button', ouvert);
        if (b) b.focus();
      }
      if (bascule && bascule.getAttribute('aria-expanded') === 'true') {
        ouvrirMenu(false);
        bascule.focus();
      }
    });
  }

  /* ----------------------------------------------------------------------
     Copier dans le presse-papiers (avec solution de repli)
     ---------------------------------------------------------------------- */
  function copier(texte, bouton) {
    var cible = bouton ? ($('.copie__t', bouton) || bouton) : null;
    function fini(ok) {
      if (!cible) return;
      var avant = cible.getAttribute('data-avant') || cible.textContent;
      cible.setAttribute('data-avant', avant);
      cible.textContent = ok ? 'Copié' : 'Copie impossible';
      setTimeout(function () { cible.textContent = avant; }, 2200);
    }
    function repli() {
      var zone = el('textarea');
      zone.value = texte;
      zone.setAttribute('readonly', '');
      zone.style.position = 'fixed';
      zone.style.top = '0';
      zone.style.opacity = '0';
      doc.body.appendChild(zone);
      zone.select();
      var ok = false;
      try { ok = doc.execCommand('copy'); } catch (e) { ok = false; }
      doc.body.removeChild(zone);
      fini(ok);
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(texte).then(function () { fini(true); }, repli);
    } else {
      repli();
    }
  }

  function initCopie() {
    $$('[data-copie], [data-copie-cible]').forEach(function (b) {
      b.hidden = false;
      b.addEventListener('click', function () {
        var texte = b.getAttribute('data-copie');
        var id = b.getAttribute('data-copie-cible');
        if (!texte && id) {
          var cible = doc.getElementById(id);
          // Les espaces insécables de la mise en forme deviennent de vraies espaces
          // (un numéro copié doit se coller proprement dans un téléphone ou un formulaire).
          texte = cible ? cible.textContent.trim().replace(/[  ]/g, ' ') : '';
        }
        if (texte) copier(texte, b);
      });
    });
  }

  /* ----------------------------------------------------------------------
     Secteurs : chemise à onglets (accessible au clavier)
     ---------------------------------------------------------------------- */
  function initSecteurs() {
    var racine = $('.secteurs');
    if (!racine) return;
    var liste = $('.secteurs__onglets', racine);
    var panneaux = $$('.secteurs__panneau', racine);
    if (!liste || panneaux.length < 2) return;

    var mq = window.matchMedia ? window.matchMedia('(max-width: 52rem)') : null;
    function orienter() { liste.setAttribute('aria-orientation', mq && mq.matches ? 'horizontal' : 'vertical'); }
    liste.setAttribute('role', 'tablist');
    orienter();
    if (mq && mq.addEventListener) mq.addEventListener('change', orienter);

    var onglets = panneaux.map(function (p) {
      var titre = $('h3', p);
      var b = el('button', null, titre ? titre.textContent : p.id);
      b.type = 'button';
      b.id = 'onglet-' + p.id;
      b.setAttribute('role', 'tab');
      b.setAttribute('aria-controls', p.id);
      p.setAttribute('role', 'tabpanel');
      p.setAttribute('aria-labelledby', b.id);
      p.tabIndex = 0;
      liste.appendChild(b);
      return b;
    });
    racine.classList.add('is-actif');

    function choisir(i, focus) {
      onglets.forEach(function (b, k) {
        var actif = k === i;
        b.setAttribute('aria-selected', actif ? 'true' : 'false');
        b.tabIndex = actif ? 0 : -1;
        panneaux[k].hidden = !actif;
      });
      if (focus) onglets[i].focus();
    }

    onglets.forEach(function (b, i) {
      b.addEventListener('click', function () { choisir(i, false); });
      b.addEventListener('keydown', function (e) {
        var n = onglets.length;
        var j = null;
        if (e.key === 'ArrowDown' || e.key === 'ArrowRight') j = (i + 1) % n;
        else if (e.key === 'ArrowUp' || e.key === 'ArrowLeft') j = (i - 1 + n) % n;
        else if (e.key === 'Home') j = 0;
        else if (e.key === 'End') j = n - 1;
        if (j !== null) { e.preventDefault(); choisir(j, true); }
      });
    });

    function depuisHash() {
      var id = '';
      try { id = decodeURIComponent((location.hash || '').slice(1)); } catch (e) { id = ''; }
      return panneaux.map(function (p) { return p.id; }).indexOf(id);
    }
    var depart = depuisHash();
    choisir(depart >= 0 ? depart : 0, false);
    window.addEventListener('hashchange', function () {
      var k = depuisHash();
      if (k >= 0) choisir(k, false);
    });
  }

  /* ----------------------------------------------------------------------
     Formulaires de contact
     ---------------------------------------------------------------------- */
  var COURRIEL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

  function initFormulaires() {
    $$('form.formulaire').forEach(function (form) {
      form.noValidate = true;
      var zone = $('[data-statut]', form);

      var regles = [
        { nom: 'nom', ok: function (v) { return v.trim().length >= 2; }, msg: function () { return 'Indiquez votre nom.'; } },
        {
          nom: 'courriel',
          ok: function (v) { return COURRIEL.test(v.trim()); },
          msg: function (v) {
            return v.trim() ? 'Cette adresse courriel semble incomplète. Exemple : nom@exemple.ca' : 'Indiquez votre adresse courriel.';
          }
        },
        {
          nom: 'projet',
          ok: function (v) { return v.trim().length >= 15; },
          msg: function (v) {
            return v.trim() ? 'Ajoutez quelques détails : une ou deux phrases suffisent.' : 'Décrivez votre projet en quelques mots.';
          }
        },
        { nom: 'consentement', ok: function (v) { return v === 'oui'; }, msg: function () { return 'Cochez la case pour que nous puissions traiter votre demande.'; } }
      ];

      function champ(nom) { return form.elements[nom]; }
      function valeur(nom) {
        var c = champ(nom);
        if (!c) return '';
        return c.type === 'checkbox' ? (c.checked ? 'oui' : '') : String(c.value || '');
      }
      function signaler(nom, message) {
        var c = champ(nom);
        var e = $('[data-erreur-pour="' + nom + '"]', form);
        if (!c) return;
        if (message) c.setAttribute('aria-invalid', 'true'); else c.removeAttribute('aria-invalid');
        if (e) e.textContent = message || '';
      }

      function afficher(genre, titre, paragraphes, boutons, sansDefilement) {
        if (!zone) return;
        zone.textContent = '';
        zone.className = 'statut is-visible' + (genre === 'erreur' ? ' statut--erreur' : '');
        var p = el('p');
        p.appendChild(el('strong', null, titre));
        zone.appendChild(p);
        paragraphes.forEach(function (t) { zone.appendChild(el('p', null, t)); });
        if (boutons && boutons.length) {
          var rang = el('div', 'actions');
          boutons.forEach(function (b) { rang.appendChild(b); });
          zone.appendChild(rang);
        }
        // Sur un petit écran, le message se trouve sous le bouton : on s'assure qu'il est à l'écran
        // (sauf quand on amène plutôt le visiteur sur le champ à corriger).
        if (!sansDefilement && zone.scrollIntoView) zone.scrollIntoView({ block: 'nearest' });
      }
      // Met le curseur dans le champ à corriger et s'assure qu'il est à l'écran, sous l'en-tête fixe
      // (le navigateur ne défile pas tout seul quand le champ est visible, même à moitié caché par l'en-tête).
      function amener(c) {
        try { c.focus({ preventScroll: true }); } catch (e) { c.focus(); }
        if (!c.getBoundingClientRect || !c.scrollIntoView) return;
        function placer() {
          var r = c.getBoundingClientRect();
          if (r.top < 96 || r.bottom > (window.innerHeight || 0) - 16) {
            // Déplacement immédiat : le défilement doux de la page serait encore en cours quand le visiteur
            // commence à corriger le champ. (Un navigateur plus ancien ne connaît pas « instant » : repli.)
            try { c.scrollIntoView({ block: 'center', behavior: 'instant' }); } catch (e) { c.scrollIntoView({ block: 'center' }); }
          }
        }
        placer();
        // Un défilement doux déjà demandé (par la page ou par le navigateur) peut encore s'achever après coup et
        // remettre le champ sous l'en-tête : on revérifie un instant plus tard, sauf si le visiteur reprend la main.
        var reprises = [200, 500].map(function (ms) { return setTimeout(placer, ms); });
        var gestes = ['wheel', 'touchstart', 'keydown', 'pointerdown'];
        function laisser() {
          reprises.forEach(clearTimeout);
          gestes.forEach(function (g) { document.removeEventListener(g, laisser, true); });
        }
        gestes.forEach(function (g) { document.addEventListener(g, laisser, { capture: true, passive: true }); });
        setTimeout(laisser, 600);
      }
      function bouton(libelle, action) {
        var b = el('button', 'btn btn--contour', libelle);
        b.type = 'button';
        b.addEventListener('click', function () { action(b); });
        return b;
      }

      form.addEventListener('input', function (e) {
        if (e.target && e.target.name && e.target.getAttribute('aria-invalid')) signaler(e.target.name, '');
      });
      form.addEventListener('change', function (e) {
        if (e.target && e.target.name && e.target.getAttribute('aria-invalid')) signaler(e.target.name, '');
      });

      form.addEventListener('submit', function (ev) {
        ev.preventDefault();
        if (champ('site_web') && champ('site_web').value) return; // champ piège : les robots le remplissent

        var premier = null;
        regles.forEach(function (r) {
          var v = valeur(r.nom);
          var bon = r.ok(v);
          signaler(r.nom, bon ? '' : r.msg(v));
          if (!bon && !premier) premier = champ(r.nom);
        });
        if (premier) {
          afficher('erreur', 'Quelques champs sont à corriger.', ['Les champs concernés sont signalés plus haut dans le formulaire.'], null, true);
          amener(premier);
          return;
        }

        var sel = champ('organisation');
        var organisation = sel && sel.value ? sel.options[sel.selectedIndex].text : '';
        var donnees = {
          nom: valeur('nom').trim(),
          courriel: valeur('courriel').trim(),
          telephone: valeur('telephone').trim(),
          organisation: organisation,
          projet: valeur('projet').trim()
        };
        // Page d'un forfait : le formulaire porte le nom du forfait demandé (attribut data-forfait) et, au choix du
        // visiteur, le niveau (champ « niveau »; sans choix : « à déterminer »).
        var forfait = form.getAttribute('data-forfait') || '';
        var niveau = forfait && champ('niveau') ? valeur('niveau').trim() : '';
        var niveauTexte = niveau || 'à déterminer';
        var sujet = (forfait ? 'Demande de soumission – ' + forfait + (niveau ? ' (' + niveau + ')' : '') + ' – ' : 'Demande de renseignements – ') + donnees.nom;
        var lignes = ['Nom : ' + donnees.nom, 'Courriel : ' + donnees.courriel];
        if (donnees.telephone) lignes.push('Téléphone : ' + donnees.telephone);
        if (donnees.organisation) lignes.push('Type d’organisation : ' + donnees.organisation);
        if (forfait) lignes.push('Forfait : ' + forfait);
        if (forfait && champ('niveau')) lignes.push('Niveau : ' + niveauTexte);
        lignes.push('', 'Projet :', donnees.projet);
        var message = lignes.join('\n');

        var boutonEnvoi = $('button[type="submit"]', form);
        function occupe(oui) {
          if (!boutonEnvoi) return;
          boutonEnvoi.disabled = oui;
          boutonEnvoi.setAttribute('aria-busy', oui ? 'true' : 'false');
        }
        function copierMessage() {
          return bouton('Copier le message', function (b) { copier(message, b); });
        }
        // Filet de sécurité : si le message n'a pas pu être transmis, le visiteur peut l'envoyer lui-même par courriel.
        function adresseCourriel() {
          return 'mailto:' + cfg.courriel + '?subject=' + encodeURIComponent(sujet) + '&body=' + encodeURIComponent(message.replace(/\n/g, '\r\n'));
        }
        function boutonsSecours() {
          var liste = [];
          if (cfg.courriel) {
            var lien = el('a', 'btn btn--contour', 'Envoyer par courriel');
            lien.href = adresseCourriel();
            liste.push(lien);
          }
          liste.push(copierMessage());
          return liste;
        }

        if (cfg.pointEnvoi) {
          occupe(true);
          afficher('info', 'Envoi en cours…', ['Merci de patienter quelques secondes.']);
          // Les champs « consentement », « site_web » (piège), « delai_ms » et « source_page » servent au CRM
          // InnovAffaires, qui les contrôle ; un autre service d'envoi les ignore.
          // Le forfait demandé ouvre le texte du projet, pour qu'on le voie tout de suite dans la demande reçue
          // (le CRM limite ce texte à 4 000 caractères : au-delà, on n'ajoute rien).
          var projetEnvoye = donnees.projet;
          if (forfait) {
            // Deuxième ligne facultative : « Niveau : Essentiel » (ou « Niveau : à déterminer »), lue par le CRM.
            var entete = 'Forfait demandé : ' + forfait + '\n';
            if (champ('niveau')) entete += 'Niveau : ' + niveauTexte + '\n';
            entete += '\n';
            if (entete.length + projetEnvoye.length <= 4000) projetEnvoye = entete + projetEnvoye;
          }
          var envoi = {
            nom: donnees.nom,
            courriel: donnees.courriel,
            telephone: donnees.telephone,
            organisation: donnees.organisation,
            projet: projetEnvoye,
            consentement: true,
            site_web: '',
            delai_ms: (window.performance && performance.now) ? Math.round(performance.now()) : undefined,
            source_page: location.pathname
          };
          fetch(cfg.pointEnvoi, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify(envoi)
          }).then(function (r) {
            return r.json().catch(function () { return null; }).then(function (corps) {
              return { ok: r.ok, statut: r.status, corps: corps };
            });
          }, function () {
            return null; // réseau coupé ou service injoignable
          }).then(function (rep) {
            occupe(false);
            // Une réponse sans JSON (page d'erreur d'un intermédiaire, par exemple) n'est jamais prise pour une réussite.
            if (rep && rep.ok && rep.corps) {
              form.reset();
              var delai = form.getAttribute('data-delai') || 'dès que possible';
              afficher('succes', 'Merci, votre message a été envoyé.', ['Nous vous répondrons ' + delai + ', à l’adresse indiquée.']);
              return;
            }
            if (rep && rep.statut === 422 && rep.corps && rep.corps.champs) {
              var premierFautif = null;
              Object.keys(rep.corps.champs).forEach(function (nom) {
                if (!champ(nom)) return;
                signaler(nom, String(rep.corps.champs[nom]));
                if (!premierFautif) premierFautif = champ(nom);
              });
              if (premierFautif) {
                afficher('erreur', 'Quelques champs sont à corriger.', ['Les champs concernés sont signalés plus haut dans le formulaire.'], null, true);
                amener(premierFautif);
                return;
              }
            }
            if (rep && rep.statut === 429) {
              var attente = rep.corps && rep.corps.erreur ? rep.corps.erreur : 'Réessayez dans un moment ou écrivez-nous par courriel.';
              afficher('erreur', 'Trop d’envois en peu de temps.', [attente], boutonsSecours());
              return;
            }
            var suite = ['Votre message n’a pas été transmis. Vous pouvez réessayer dans un instant ou nous l’envoyer par courriel.'];
            if (cfg.courriel) suite.push('Adresse : ' + cfg.courriel);
            afficher('erreur', 'L’envoi n’a pas fonctionné.', suite, boutonsSecours());
          });
          return;
        }

        if (cfg.courriel) {
          var url = adresseCourriel();
          afficher('info', 'Dernière étape : envoyez le courriel qui vient de s’ouvrir.', [
            'Votre message n’est pas encore transmis. Votre application de courriel devrait s’ouvrir avec un message prérempli : il ne reste qu’à l’envoyer.',
            'Si rien ne s’ouvre, copiez le message et écrivez-nous à ' + cfg.courriel + '.'
          ], [
            copierMessage(),
            bouton('Copier l’adresse', function (b) { copier(cfg.courriel, b); })
          ]);
          window.location.href = url;
          return;
        }

        afficher('info', 'Le formulaire n’est pas encore activé : votre message n’a pas été envoyé.', [
          'Il s’agit d’une version de démonstration du site. Copiez votre message ci-dessous pour nous l’envoyer par courriel.',
          'Pour l’équipe du site : renseignez l’adresse de réception dans le fichier assets/js/config.js.'
        ], [copierMessage()]);
      });
    });
  }

  /* ----------------------------------------------------------------------
     Répertoire des subventions : recherche et filtres
     ---------------------------------------------------------------------- */
  function plierCar(c) {
    if (c === '’' || c === '‘') return '\'';
    if (c === ' ' || c === ' ') return ' ';
    var f = c.normalize ? c.normalize('NFD').replace(/[̀-ͯ]/g, '') : c;
    if (f.length !== 1) f = c;
    var l = f.toLowerCase();
    return l.length === 1 ? l : f;
  }
  function plier(s) {
    var out = '';
    for (var i = 0; i < s.length; i++) out += plierCar(s.charAt(i));
    return out;
  }

  function surligner(noeud, jetons) {
    if (noeud._orig === undefined) noeud._orig = noeud.textContent;
    var t = noeud._orig;
    noeud.textContent = '';
    var plages = [];
    if (jetons.length) {
      var f = plier(t);
      jetons.forEach(function (j) {
        var i = f.indexOf(j);
        while (i !== -1) { plages.push([i, i + j.length]); i = f.indexOf(j, i + j.length); }
      });
    }
    if (!plages.length) { noeud.textContent = t; return; }
    plages.sort(function (a, b) { return a[0] - b[0]; });
    var fus = [plages[0].slice()];
    for (var k = 1; k < plages.length; k++) {
      var dernier = fus[fus.length - 1];
      if (plages[k][0] <= dernier[1]) dernier[1] = Math.max(dernier[1], plages[k][1]);
      else fus.push(plages[k].slice());
    }
    var pos = 0;
    var frag = doc.createDocumentFragment();
    fus.forEach(function (r) {
      if (r[0] > pos) frag.appendChild(doc.createTextNode(t.slice(pos, r[0])));
      frag.appendChild(el('mark', null, t.slice(r[0], r[1])));
      pos = r[1];
    });
    if (pos < t.length) frag.appendChild(doc.createTextNode(t.slice(pos)));
    noeud.appendChild(frag);
  }

  function initRepertoire() {
    var table = $('#programmes');
    if (!table) return;
    var lignes = $$('tbody tr', table);
    var champRecherche = $('#f-q');
    var selSecteur = $('#f-secteur');
    var selPalier = $('#f-palier');
    var selType = $('#f-type');
    var reinit = $('#f-reinit');
    var compte = $('#f-compte');
    var vide = $('#f-vide');
    if (!champRecherche || !compte) return;

    lignes.forEach(function (tr) {
      var morceaux = $$('[data-hl], td', tr).map(function (n) { return n.textContent; });
      morceaux.push(tr.getAttribute('data-mots') || '');
      tr._foin = plier(morceaux.join(' ').replace(/\s+/g, ' '));
    });

    function contient(attr, valeur) {
      return (' ' + (attr || '') + ' ').indexOf(' ' + valeur + ' ') !== -1;
    }
    function libelle(n, total) {
      if (n === 0) return 'Aucun programme ne correspond à votre recherche';
      if (n === total) return total + (total > 1 ? ' programmes' : ' programme') + ' dans le répertoire';
      return n + (n > 1 ? ' programmes' : ' programme') + ' sur ' + total;
    }

    function filtrer() {
      var jetons = plier(champRecherche.value).split(/\s+/).filter(Boolean);
      var s = selSecteur ? selSecteur.value : '';
      var p = selPalier ? selPalier.value : '';
      var t = selType ? selType.value : '';
      var visibles = 0;
      lignes.forEach(function (tr) {
        var bon = jetons.every(function (j) { return tr._foin.indexOf(j) !== -1; });
        if (bon && s) bon = contient(tr.getAttribute('data-secteurs'), s) || contient(tr.getAttribute('data-secteurs'), 'tous');
        if (bon && p) bon = tr.getAttribute('data-palier') === p;
        if (bon && t) bon = contient(tr.getAttribute('data-types'), t);
        tr.hidden = !bon;
        if (bon) visibles++;
        $$('[data-hl]', tr).forEach(function (n) { surligner(n, bon ? jetons : []); });
      });
      compte.textContent = libelle(visibles, lignes.length);
      if (vide) vide.classList.toggle('is-visible', visibles === 0);
      table.hidden = visibles === 0;
    }

    function depuisHash() {
      var h = '';
      try { h = decodeURIComponent((location.hash || '').slice(1)); } catch (e) { h = ''; }
      if (!h || !selSecteur) return;
      for (var i = 0; i < selSecteur.options.length; i++) {
        if (selSecteur.options[i].value === h) { selSecteur.value = h; break; }
      }
    }

    [champRecherche, selSecteur, selPalier, selType].forEach(function (c) {
      if (!c) return;
      c.addEventListener('input', filtrer);
      c.addEventListener('change', filtrer);
    });
    champRecherche.addEventListener('keydown', function (e) { if (e.key === 'Enter') e.preventDefault(); });
    if (reinit) {
      reinit.addEventListener('click', function () {
        champRecherche.value = '';
        [selSecteur, selPalier, selType].forEach(function (c) { if (c) c.value = ''; });
        filtrer();
        champRecherche.focus();
      });
    }
    window.addEventListener('hashchange', function () { depuisHash(); filtrer(); });
    depuisHash();
    filtrer();
  }

  /* ----------------------------------------------------------------------
     Blogue : filtre par catégorie
     ---------------------------------------------------------------------- */
  function initBlogue() {
    var puces = $('.puces');
    var liste = $('.sommaire');
    if (!puces || !liste) return;
    var articles = $$('li[data-categorie]', liste);
    var categories = [];
    articles.forEach(function (li) {
      var c = li.getAttribute('data-categorie');
      if (categories.indexOf(c) === -1) categories.push(c);
    });
    if (categories.length < 2) return;

    var boutons = [];
    function choisir(valeur) {
      boutons.forEach(function (b) { b.setAttribute('aria-pressed', b.getAttribute('data-valeur') === valeur ? 'true' : 'false'); });
      articles.forEach(function (li) { li.hidden = valeur !== '' && li.getAttribute('data-categorie') !== valeur; });
    }
    ['Tous'].concat(categories).forEach(function (nom, i) {
      var li = el('li');
      var b = el('button', 'puce', nom);
      b.type = 'button';
      b.setAttribute('data-valeur', i === 0 ? '' : nom);
      b.addEventListener('click', function () { choisir(i === 0 ? '' : nom); });
      li.appendChild(b);
      puces.appendChild(li);
      boutons.push(b);
    });
    choisir('');
  }

  /* ---------------------------------------------------------------------- */
  /* ----------------------------------------------------------------------
     Page du forfait : les boutons « Choisir un niveau » amènent au formulaire avec ce niveau déjà choisi
     (sans JavaScript, ils mènent au formulaire et le visiteur choisit lui-même).
     ---------------------------------------------------------------------- */
  function initNiveaux() {
    $$('a[data-niveau]').forEach(function (a) {
      a.addEventListener('click', function () {
        var choix = $('form.formulaire select[name="niveau"]');
        if (!choix) return;
        var voulu = a.getAttribute('data-niveau');
        for (var i = 0; i < choix.options.length; i++) {
          if (choix.options[i].value === voulu) { choix.selectedIndex = i; break; }
        }
      });
    });
  }

  [initNav, initCopie, initSecteurs, initFormulaires, initNiveaux, initRepertoire, initBlogue].forEach(essayer);
})();
