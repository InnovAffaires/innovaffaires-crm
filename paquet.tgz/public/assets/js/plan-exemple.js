/* ==========================================================================
   Créateur de plan d'affaires : plan d'exemple.

   Une entreprise ET des chiffres FICTIFS, pour montrer ce que donne l'outil
   quand toutes les étapes sont remplies. Rien ici ne décrit une entreprise réelle
   ni ne prédit un résultat : les noms, les prix et les quantités sont inventés.
   ========================================================================== */
(function (g) {
  'use strict';

  var NS = g.PlanAffaires = g.PlanAffaires || {};
  var M = NS.Modele || (typeof require === 'function' ? require('./plan-modele.js') : null);

  function exemple() {
    var e = M.nouvelEtat();
    var r = e.r;
    var ligne = function (etape, cle, valeurs) { return Object.assign(M.ligne(M.champListe(etape, cle)), valeurs); };

    r.projet = {
      nom: 'Atelier Vélo Mobile (exemple fictif)',
      forme: 'individuelle',
      secteur: 'Réparation et entretien de vélos',
      lieu: 'Lanaudière',
      stade: 'preparation',
      debut: '2027-04',
      mission: 'Atelier Vélo Mobile répare et entretient les vélos à domicile et au bureau, dans la région de Lanaudière. Nous venons chez le client avec un atelier sur roues : l’entretien d’un vélo ne demande ni dépôt en boutique ni plusieurs jours d’attente.',
      probleme: 'Au printemps, les ateliers de la région sont débordés et les délais atteignent souvent deux semaines. Beaucoup de cyclistes renoncent à faire réparer leur vélo, ou le font trop tard, et roulent avec des freins ou des vitesses mal réglés.',
      objectifs: 'Ouvrir en avril 2027, réaliser environ 35 000 $ de ventes la première année et couvrir toutes les dépenses, rémunération comprise, avant la fin de cette année. Passer à plus de 50 000 $ de ventes la deuxième année.',
      vision: 'Dans trois ans : une aide saisonnière à temps partiel, un point de service fixe pour l’hiver et des ententes avec quelques employeurs de la région.'
    };

    r.offre = {
      lignes: [
        ligne('offre', 'lignes', { nom: 'Mise au point complète', unite: 'service', description: 'Réglage des freins et des vitesses, lubrification, vérification générale.', prix: 95, cout: 18 }),
        ligne('offre', 'lignes', { nom: 'Réparation sur place', unite: 'intervention', description: 'Crevaison, chaîne, dérailleur : main-d’œuvre et petites pièces incluses.', prix: 70, cout: 20 }),
        ligne('offre', 'lignes', { nom: 'Forfait de saison', unite: 'forfait', description: 'Deux mises au point dans la saison et la priorité aux rendez-vous.', prix: 160, cout: 36 })
      ],
      avantage: 'Le service vient au client, avec un rendez-vous confirmé en ligne et un délai de 48 heures. Le forfait de saison réserve deux mises au point à un prix avantageux.',
      pi: 'Nom commercial à valider au registre des entreprises; procédure d’entretien documentée.'
    };

    r.marche = {
      clientele: 'Des adultes de 25 à 60 ans qui pédalent régulièrement, habitent en banlieue ou en milieu semi-rural et travaillent à temps plein. Ils ont peu de temps, tiennent à leur vélo et paient volontiers pour la commodité.',
      segments: [
        ligne('marche', 'segments', { nom: 'Cyclistes de banlieue', taille: 'À estimer (source publique)', qui: 'Familles et professionnels qui roulent le soir et la fin de semaine.' }),
        ligne('marche', 'segments', { nom: 'Employeurs de la région', taille: 'À estimer', qui: 'Entreprises qui offrent l’entretien des vélos à leurs employés comme avantage.' })
      ],
      taille: 'À documenter : nombre d’adultes qui pédalent chaque semaine dans le territoire desservi, selon une source publique (exemple fictif; aucun chiffre n’est avancé ici).',
      tendances: 'Exemple : intérêt pour le vélo utilitaire et électrique, délais plus longs dans les magasins spécialisés au printemps. À appuyer par des sources.',
      validation: 'Dix entrevues avec des cyclistes de la région, un sondage dans deux groupes locaux et quatre précommandes de forfaits de saison (exemple fictif).'
    };

    r.concurrence = {
      concurrents: [
        ligne('concurrence', 'concurrents', { nom: 'Cycles du Centre (exemple fictif)', offre: 'Magasin de vélos avec atelier de réparation.', prix: 'Mise au point : environ 90 $ à 120 $', forces: 'Pièces en stock, réputation établie.', faiblesses: 'Délai de deux semaines au printemps; le client doit déposer son vélo.' }),
        ligne('concurrence', 'concurrents', { nom: 'Réparateur indépendant (exemple fictif)', offre: 'Réparations dans un petit atelier.', prix: 'Variable', forces: 'Prix bas.', faiblesses: 'Heures d’ouverture limitées, pas de réservation en ligne.' }),
        ligne('concurrence', 'concurrents', { nom: 'Atelier communautaire (exemple fictif)', offre: 'Outils et conseils offerts aux membres.', prix: 'Cotisation annuelle', forces: 'Faible coût.', faiblesses: 'Le client répare lui-même; horaire restreint.' })
      ],
      positionnement: 'Nous sommes les seuls à nous déplacer chez le client avec un délai de 48 heures et une réservation en ligne.',
      indirecte: 'Réparer soi-même, passer par une grande surface, ou rouler sans entretien jusqu’à la panne.'
    };

    r.marketing = {
      valeur: 'Un vélo qui roule bien, sans quitter la maison ni attendre deux semaines.',
      prix: 'Prix alignés sur ceux des ateliers de la région, avec une légère prime pour le déplacement. Le forfait de saison favorise la fidélité.',
      canaux: ['web', 'reseaux', 'references'],
      canauxDetail: 'Réservation en ligne; paiement sur place avec une tablette.',
      promo: ['reseaux', 'web', 'reseautage', 'imprimes'],
      promoDetail: 'Page Facebook locale, affichettes dans trois commerces, présence à deux événements cyclistes.',
      lancement: M.suggestions('lancement').map(function (s) { return ligne('marketing', 'lancement', Object.assign({ resp: 'Camille' }, s)); })
    };

    var d = {};
    M.DEMARCHES.forEach(function (x) { d[x.id] = 'afaire'; });
    Object.assign(d, { forme: 'fait', req: 'encours', nom: 'fait', permis: 'na' });
    r.operations = {
      local: 'clients',
      lieu: 'Entreposage dans un garage à domicile; interventions chez les clients.',
      equipement: 'Remorque-atelier, outillage de mécanique, tablette de paiement, logiciel de réservation.',
      processus: 'Le client réserve en ligne. Je confirme le rendez-vous et je prépare les pièces courantes, puis j’effectue l’entretien chez lui. Le paiement et la facture se font sur place.',
      capacite: 'Environ 25 interventions par semaine en pleine saison, seule. Une aide saisonnière à temps partiel est prévue la troisième année.',
      fournisseurs: [ligne('operations', 'fournisseurs', { nom: 'Distributeur régional de pièces (exemple fictif)', fournit: 'Pièces et lubrifiants', conditions: 'Livraison en trois jours; paiement à 30 jours' })],
      demarches: d
    };

    r.equipe = {
      promoteurs: [ligne('equipe', 'promoteurs', { nom: 'Camille Tremblay (exemple fictif)', role: 'Mécanicienne et gestionnaire', exp: 'Huit ans comme mécanicienne de vélos en boutique; formation en gestion de petite entreprise.', part: 100, remun: 1600, debutRemun: 4 })],
      employes: [ligne('equipe', 'employes', { poste: 'Aide saisonnière à temps partiel', nombre: 1, salaire: 7200, mois: 25 })],
      conseillers: 'Comptable externe; mentor d’un organisme d’accompagnement des entreprises.',
      manques: 'Marketing numérique : formation prévue avant l’ouverture.'
    };

    var risque = function (desc, proba, impact, mesure) { return ligne('risques', 'liste', { desc: desc, proba: proba, impact: impact, mesure: mesure }); };
    r.risques = {
      liste: [
        risque('Les ventes démarrent plus lentement que prévu', 'moyen', 'eleve', 'Réduire les dépenses de marketing, offrir des forfaits aux entreprises et conserver un revenu complémentaire pendant six mois.'),
        risque('Un client important ou un fournisseur clé est perdu', 'faible', 'moyen', 'Deux fournisseurs de pièces; ententes avec plusieurs employeurs.'),
        risque('Les coûts (pièces, carburant, intérêts) augmentent', 'moyen', 'moyen', 'Réviser les prix chaque année; garder une réserve de trésorerie.'),
        risque('Une personne clé devient indisponible', 'faible', 'eleve', 'Assurance invalidité; liste de techniciens remplaçants.'),
        risque('Un nouveau concurrent arrive ou les prix baissent', 'moyen', 'moyen', 'Miser sur le forfait de saison et la qualité du service.'),
        risque('Un permis ou un financement tarde à être obtenu', 'moyen', 'moyen', 'Déposer les demandes tôt; reporter l’ouverture d’un mois au besoin.')
      ],
      planB: 'Si les ventes sont inférieures de 20 % aux prévisions : réduire le marketing de moitié, viser les employeurs et reporter l’embauche.'
    };

    var vl = {};
    vl[r.offre.lignes[0].id] = { debut: 1, m1: 12, m12: 24 };
    vl[r.offre.lignes[1].id] = { debut: 1, m1: 9, m12: 16 };
    vl[r.offre.lignes[2].id] = { debut: 1, m1: 3, m12: 6 };
    // Janvier à décembre : le total des indices fait 1 200 (une moyenne de 100 par mois).
    r.ventes = { lignes: vl, g2: 50, g3: 25, delaiClients: 0, saison: [20, 25, 60, 140, 175, 170, 160, 150, 125, 90, 45, 40] };

    var charge = function (nom, montant) { return ligne('charges', 'liste', { nom: nom, montant: montant, mois: 1 }); };
    r.charges = {
      liste: [
        charge('Loyer', null), charge('Assurances', 85), charge('Électricité, chauffage, Internet et téléphone', 95),
        charge('Logiciels et abonnements', 40), charge('Marketing et publicité', 150), charge('Comptabilité et services professionnels', 90),
        charge('Transport et déplacements', 220), charge('Fournitures et entretien', 60), charge('Frais bancaires', 25), charge('Formation et cotisations', 30)
      ],
      aucune: false, hausse: 2, chargesSociales: 15, fraisTransaction: 2.5, delaiFournisseurs: 30
    };

    var dem = function (nom, montant) { return ligne('financement', 'demarrage', { nom: nom, montant: montant }); };
    var inv = function (nom, montant, duree) { return ligne('financement', 'invest', { nom: nom, montant: montant, duree: duree }); };
    r.financement = {
      invest: [inv('Remorque-atelier et outillage de mécanique', 5200, 5), inv('Ordinateur portable et tablette de paiement', 1400, 3), inv('Mobilier et aménagement', null, 5), inv('Véhicule', null, 5)],
      demarrage: [
        dem('Immatriculation au Registraire des entreprises', 41), dem('Frais juridiques et comptables', 450), dem('Permis et licences', null),
        dem('Identité visuelle et site Web', 1200), dem('Dépôts et garanties (local, services publics)', null), dem('Affichage et décalques de la remorque', 1100),
        dem('Publicité de lancement', 500), dem('Formation', 300)
      ],
      sources: [
        ligne('financement', 'sources', { type: 'apport', nom: 'Épargne personnelle', statut: 'confirme', montant: 5000, mois: 0 }),
        ligne('financement', 'sources', { type: 'organisme', nom: 'Prêt de démarrage d’un organisme local (exemple fictif)', statut: 'demande', montant: 8000, taux: 6, duree: 36, grace: 3, mois: 0 }),
        ligne('financement', 'sources', { type: 'marge', nom: 'Marge de crédit', statut: 'envisage', montant: 3000, mois: 0 })
      ],
      aucun: false,
      coussin: 1000,
      garanties: 'Caution personnelle de la promotrice; équipement acheté.',
      modalites: 'Demande à déposer auprès d’un organisme de financement local; remboursement sur 36 mois, dont trois mois sans remboursement du capital.'
    };

    r.sommaire = {
      phrase: 'Atelier Vélo Mobile répare et entretient les vélos chez le client, dans Lanaudière, avec réservation en ligne et un délai de 48 heures. Entreprise individuelle lancée par une mécanicienne expérimentée, elle vise l’équilibre financier avant la fin de la première année.',
      pourquoi: 'Les ateliers sont débordés au printemps et les cyclistes cherchent plus de commodité.',
      demande: 'Un prêt de démarrage de 8 000 $ pour acheter l’outillage et couvrir les premiers mois.'
    };

    e.etape = 'projet';
    e.ui = { baisse: 20, mention: true };
    return e;
  }

  NS.Exemple = { exemple: exemple };
  if (typeof module !== 'undefined' && module.exports) module.exports = NS.Exemple;
})(typeof window !== 'undefined' ? window : globalThis);
