/* ==========================================================================
   Créateur de plan d'affaires : exportations.

   - docx(doc) : fichier Word (.docx) construit à la main à partir du modèle de document
     (plan-document.js) ; archive ZIP sans compression, écrite ici même.
   - sauvegarde(etat), lire(texte) : copie de sécurité du plan (JSON) et sa relecture stricte.
   - telecharger(nom, donnees, type) : enregistrement d'un fichier depuis le navigateur.

   Tout se passe dans le navigateur : aucun contenu n'est transmis à un serveur.
   Les textes de la personne sont toujours échappés (XML) avant d'entrer dans le fichier.
   ========================================================================== */
(function (g) {
  'use strict';

  var NS = g.PlanAffaires = g.PlanAffaires || {};
  var M = NS.Modele || (typeof require === 'function' ? require('./plan-modele.js') : null);

  var FORMAT = 'innovaffaires-plan-affaires';
  var TAILLE_MAX_SAUVEGARDE = 2 * 1024 * 1024;

  /* ---------- Texte → XML ---------- */
  /* Retire ce que XML 1.0 interdit : contrôles (sauf tabulation et sauts de ligne), U+FFFE, U+FFFF et demi-paires isolées. */
  function propre(s) {
    s = String(s === null || s === undefined ? '' : s);
    var out = '';
    for (var i = 0; i < s.length; i++) {
      var c = s.charCodeAt(i);
      if (c >= 0xd800 && c <= 0xdbff) {
        var d = s.charCodeAt(i + 1);
        if (d >= 0xdc00 && d <= 0xdfff) { out += s.charAt(i) + s.charAt(i + 1); i++; } else out += '�';
      } else if (c >= 0xdc00 && c <= 0xdfff) {
        out += '�';
      } else if (c < 0x20 && c !== 9 && c !== 10 && c !== 13) {
        continue;
      } else if (c === 0xfffe || c === 0xffff) {
        continue;
      } else out += s.charAt(i);
    }
    return out;
  }
  function esc(s) {
    return propre(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  var W = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"';
  var R = 'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"';
  var ENTETE_XML = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n';

  /* Couleurs du site, pour que le plan imprimé ressemble au reste du matériel d'InnovAffaires. */
  var ARDOISE = '3A4559', OR = 'B8912F', ENCRE = '151515', CRAYON = '58595C', TRAIT = 'C1C4CD', TRAIT_FORT = '9B9DA4', FEUILLE = 'E6EEF3', PALE = 'F3F5F8';

  /* ---------- Paragraphes et passages ---------- */
  function passage(texte, o) {
    o = o || {};
    var rpr = '';
    if (o.gras) rpr += '<w:b/><w:bCs/>';
    if (o.ital) rpr += '<w:i/><w:iCs/>';
    if (o.couleur) rpr += '<w:color w:val="' + o.couleur + '"/>';
    if (o.taille) rpr += '<w:sz w:val="' + o.taille + '"/><w:szCs w:val="' + o.taille + '"/>';
    if (o.surligne) rpr += '<w:highlight w:val="' + o.surligne + '"/>';
    var morceaux = propre(texte).replace(/\r\n?/g, '\n').split('\n');
    var corps = '';
    morceaux.forEach(function (m, i) {
      if (i) corps += '<w:br/>';
      if (m) corps += '<w:t xml:space="preserve">' + esc(m) + '</w:t>';
    });
    if (!corps) return '';
    return '<w:r>' + (rpr ? '<w:rPr>' + rpr + '</w:rPr>' : '') + corps + '</w:r>';
  }

  /* o : style, suivant (keepNext), saut (pageBreakBefore), num {id}, bordureBas, fond, avant, apres, interligne, retrait {g, s}, jc */
  function paragraphe(contenu, o) {
    o = o || {};
    var ppr = '';
    if (o.style) ppr += '<w:pStyle w:val="' + o.style + '"/>';
    if (o.suivant) ppr += '<w:keepNext/>';
    if (o.garder) ppr += '<w:keepLines/>';
    if (o.saut) ppr += '<w:pageBreakBefore/>';
    if (o.num) ppr += '<w:numPr><w:ilvl w:val="0"/><w:numId w:val="' + o.num + '"/></w:numPr>';
    if (o.bordureBas) ppr += '<w:pBdr><w:bottom w:val="single" w:sz="' + o.bordureBas.sz + '" w:space="4" w:color="' + o.bordureBas.couleur + '"/></w:pBdr>';
    if (o.fond) ppr += '<w:shd w:val="clear" w:color="auto" w:fill="' + o.fond + '"/>';
    if (o.avant !== undefined || o.apres !== undefined || o.interligne !== undefined) {
      ppr += '<w:spacing' + (o.avant !== undefined ? ' w:before="' + o.avant + '"' : '') + (o.apres !== undefined ? ' w:after="' + o.apres + '"' : '') +
        (o.interligne !== undefined ? ' w:line="' + o.interligne + '" w:lineRule="auto"' : '') + '/>';
    }
    if (o.retrait) ppr += '<w:ind w:left="' + o.retrait.g + '"' + (o.retrait.s ? ' w:hanging="' + o.retrait.s + '"' : '') + '/>';
    if (o.jc) ppr += '<w:jc w:val="' + o.jc + '"/>';
    return '<w:p>' + (ppr ? '<w:pPr>' + ppr + '</w:pPr>' : '') + (contenu || '') + '</w:p>';
  }

  /* ---------- Tableaux ---------- */
  var LARGEUR_TEXTE = 9360; // lettre américaine, marges de 2,54 cm

  function largeurs(colonnes, total) {
    var somme = colonnes.reduce(function (s, c) { return s + (c.l || 1); }, 0);
    var w = colonnes.map(function (c) { return Math.floor(total * (c.l || 1) / somme); });
    var reste = total - w.reduce(function (s, x) { return s + x; }, 0);
    w[w.length - 1] += reste;
    return w;
  }
  function bordure(nom, sz, couleur) { return '<w:' + nom + ' w:val="single" w:sz="' + sz + '" w:space="0" w:color="' + couleur + '"/>'; }

  function cellule(texte, largeur, o) {
    o = o || {};
    var tcpr = '<w:tcW w:w="' + largeur + '" w:type="dxa"/>';
    if (o.bordures) tcpr += '<w:tcBorders>' + o.bordures + '</w:tcBorders>';
    if (o.fond) tcpr += '<w:shd w:val="clear" w:color="auto" w:fill="' + o.fond + '"/>';
    tcpr += '<w:vAlign w:val="' + (o.valign || 'top') + '"/>';
    var p = paragraphe(passage(texte, { gras: o.gras, couleur: o.couleur, taille: o.taille }), { style: 'TableauTexte', jc: o.jc, suivant: o.suivant });
    return '<w:tc><w:tcPr>' + tcpr + '</w:tcPr>' + p + '</w:tc>';
  }

  function tableauXml(b) {
    var w = largeurs(b.colonnes, LARGEUR_TEXTE);
    var taille = b.colonnes.length >= 6 ? 18 : 19;
    var jc = function (c) { return c.a === 'd' ? 'right' : c.a === 'c' ? 'center' : 'left'; };
    var xml = '<w:tbl><w:tblPr><w:tblW w:w="' + LARGEUR_TEXTE + '" w:type="dxa"/>' +
      '<w:tblBorders>' + bordure('top', 6, TRAIT_FORT) + bordure('bottom', 6, TRAIT_FORT) + bordure('insideH', 4, TRAIT) + '</w:tblBorders>' +
      '<w:tblLayout w:type="fixed"/><w:tblCellMar><w:left w:w="70" w:type="dxa"/><w:right w:w="70" w:type="dxa"/></w:tblCellMar>' +
      '<w:tblLook w:val="0420" w:firstRow="1" w:lastRow="0" w:firstColumn="0" w:lastColumn="0" w:noHBand="0" w:noVBand="1"/></w:tblPr>';
    xml += '<w:tblGrid>' + w.map(function (x) { return '<w:gridCol w:w="' + x + '"/>'; }).join('') + '</w:tblGrid>';
    // en-tête (répété sur chaque page)
    xml += '<w:tr><w:trPr><w:cantSplit/><w:tblHeader/></w:trPr>' + b.colonnes.map(function (c, i) {
      return cellule(c.t, w[i], { gras: true, taille: taille, jc: jc(c), fond: FEUILLE, couleur: ARDOISE, valign: 'bottom', bordures: bordure('bottom', 8, ARDOISE), suivant: true });
    }).join('') + '</w:tr>';
    var ensemble = b.lignes.length <= 24; // un tableau court reste sur une seule page
    b.lignes.forEach(function (lg, n) {
      var cells = Array.isArray(lg) ? lg : lg.c, style = Array.isArray(lg) ? '' : lg.s || '';
      var dernier = n === b.lignes.length - 1;
      xml += '<w:tr><w:trPr><w:cantSplit/></w:trPr>' + cells.map(function (texte, i) {
        var c = b.colonnes[i] || { a: 'g' };
        var o = { taille: taille, jc: jc(c), suivant: !dernier && (ensemble || style === 'titre') };
        if (i === 0 && !style) o.gras = false;
        if (style === 'total') { o.gras = true; o.bordures = bordure('top', 6, ARDOISE); o.fond = PALE; }
        else if (style === 'titre') { o.gras = true; o.fond = FEUILLE; o.couleur = ARDOISE; }
        return cellule(texte, w[i], o);
      }).join('') + '</w:tr>';
    });
    return xml + '</w:tbl>';
  }

  function kvXml(b) {
    var longueur = b.lignes.reduce(function (m, l) { return Math.max(m, String(l[0]).length); }, 0);
    var gauche = longueur > 44 ? 5400 : longueur > 30 ? 4300 : 3600;
    var w = [gauche, LARGEUR_TEXTE - gauche];
    var xml = '<w:tbl><w:tblPr><w:tblW w:w="' + LARGEUR_TEXTE + '" w:type="dxa"/>' +
      '<w:tblBorders>' + bordure('bottom', 4, TRAIT) + bordure('insideH', 4, TRAIT) + '</w:tblBorders>' +
      '<w:tblLayout w:type="fixed"/><w:tblCellMar><w:left w:w="70" w:type="dxa"/><w:right w:w="70" w:type="dxa"/></w:tblCellMar>' +
      '<w:tblLook w:val="0000" w:firstRow="0" w:lastRow="0" w:firstColumn="0" w:lastColumn="0" w:noHBand="1" w:noVBand="1"/></w:tblPr>' +
      '<w:tblGrid><w:gridCol w:w="' + w[0] + '"/><w:gridCol w:w="' + w[1] + '"/></w:tblGrid>';
    b.lignes.forEach(function (l, n) {
      var suivant = n < b.lignes.length - 1 && b.lignes.length <= 12;
      xml += '<w:tr><w:trPr><w:cantSplit/></w:trPr>' + cellule(l[0], w[0], { gras: true, couleur: ARDOISE, taille: 20, suivant: suivant }) + cellule(l[1], w[1], { taille: 20, suivant: suivant }) + '</w:tr>';
    });
    return xml + '</w:tbl>';
  }

  /* ---------- Corps du document ---------- */
  function corps(doc) {
    var xml = '';
    var ordonnees = 0; // nombre de listes numérotées (chacune repart de 1)
    var precedent = null;
    doc.blocs.forEach(function (b) {
      switch (b.t) {
        case 'couverture':
          xml += paragraphe(passage(b.surtitre, { gras: true, couleur: OR, taille: 28 }), { style: 'CouvSurtitre' });
          xml += paragraphe(passage(b.titre, { gras: true }), { style: 'CouvTitre' });
          b.lignes.forEach(function (l) { xml += paragraphe(passage(l), { style: 'CouvLigne' }); });
          xml += paragraphe(passage(b.date), { style: 'CouvDate' });
          if (b.mention) xml += paragraphe(passage(b.mention), { style: 'CouvMention' });
          break;
        case 'h1': xml += paragraphe(passage(b.texte), { style: 'Heading1', saut: b.saut }); break;
        case 'h2': xml += paragraphe(passage(b.texte), { style: 'Heading2' }); break;
        case 'p': xml += paragraphe(passage(b.texte)); break;
        case 'liste': {
          var id = 1;
          if (b.ordonnee) { ordonnees++; id = 1 + ordonnees; }
          b.items.forEach(function (item) { xml += paragraphe(passage(item), { style: 'ListParagraph', num: id }); });
          break;
        }
        case 'tableau':
          if (!(precedent && precedent.t === 'h2' && precedent.texte === b.titre)) xml += paragraphe(passage(b.titre), { style: 'LegendeTableau', suivant: true });
          xml += tableauXml(b);
          xml += paragraphe(b.note ? passage(b.note) : '', { style: b.note ? 'NoteBas' : 'EspaceTableau' });
          break;
        case 'kv': xml += kvXml(b) + paragraphe('', { style: 'EspaceTableau' }); break;
        case 'note': xml += paragraphe(passage(b.texte), { style: 'NoteBas' }); break;
        case 'aCompleter': xml += paragraphe(passage(b.texte), { style: 'ACompleter' }); break;
        default: break; // graphiques : seulement à l'écran et à l'impression; les tableaux du document portent les mêmes chiffres
      }
      precedent = b;
    });
    return { xml: xml, ordonnees: ordonnees };
  }

  /* ---------- Parties de l'archive ---------- */
  function styles() {
    var pstyle = function (id, nom, o) {
      o = o || {};
      return '<w:style w:type="paragraph"' + (o.defaut ? ' w:default="1"' : '') + ' w:styleId="' + id + '"><w:name w:val="' + nom + '"/>' +
        (o.base ? '<w:basedOn w:val="' + o.base + '"/>' : '') + (o.suivant ? '<w:next w:val="' + o.suivant + '"/>' : '') +
        (o.ui ? '<w:uiPriority w:val="' + o.ui + '"/>' : '') + (o.qformat ? '<w:qFormat/>' : '') +
        (o.ppr ? '<w:pPr>' + o.ppr + '</w:pPr>' : '') + (o.rpr ? '<w:rPr>' + o.rpr + '</w:rPr>' : '') + '</w:style>';
    };
    var rpr = function (taille, couleur, extra) {
      return (extra || '') + (couleur ? '<w:color w:val="' + couleur + '"/>' : '') + '<w:sz w:val="' + taille + '"/><w:szCs w:val="' + taille + '"/>';
    };
    return ENTETE_XML + '<w:styles ' + W + '>' +
      '<w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:eastAsia="Calibri" w:cs="Calibri"/><w:sz w:val="22"/><w:szCs w:val="22"/><w:lang w:val="fr-CA" w:eastAsia="fr-CA" w:bidi="ar-SA"/></w:rPr></w:rPrDefault>' +
      '<w:pPrDefault><w:pPr><w:spacing w:after="120" w:line="264" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>' +
      pstyle('Normal', 'Normal', { defaut: true, qformat: true, rpr: '<w:color w:val="' + ENCRE + '"/>' }) +
      pstyle('Heading1', 'heading 1', {
        base: 'Normal', suivant: 'Normal', ui: 9, qformat: true,
        ppr: '<w:keepNext/><w:keepLines/><w:pBdr><w:bottom w:val="single" w:sz="8" w:space="4" w:color="' + OR + '"/></w:pBdr><w:spacing w:before="400" w:after="160"/><w:outlineLvl w:val="0"/>',
        rpr: rpr(36, ARDOISE, '<w:b/><w:bCs/>')
      }) +
      pstyle('Heading2', 'heading 2', {
        base: 'Normal', suivant: 'Normal', ui: 9, qformat: true,
        ppr: '<w:keepNext/><w:keepLines/><w:spacing w:before="260" w:after="80"/><w:outlineLvl w:val="1"/>',
        rpr: rpr(26, ARDOISE, '<w:b/><w:bCs/>')
      }) +
      pstyle('ListParagraph', 'List Paragraph', { base: 'Normal', ui: 34, qformat: true, ppr: '<w:spacing w:after="60"/><w:contextualSpacing/>' }) +
      pstyle('CouvSurtitre', 'Couverture - surtitre', { base: 'Normal', suivant: 'CouvTitre', ppr: '<w:spacing w:before="2600" w:after="120"/>' }) +
      pstyle('CouvTitre', 'Couverture - titre', {
        base: 'Normal', ppr: '<w:pBdr><w:bottom w:val="single" w:sz="12" w:space="8" w:color="' + OR + '"/></w:pBdr><w:spacing w:before="0" w:after="360" w:line="240" w:lineRule="auto"/>',
        rpr: rpr(68, ENCRE, '<w:b/><w:bCs/>')
      }) +
      pstyle('CouvLigne', 'Couverture - ligne', { base: 'Normal', ppr: '<w:spacing w:after="60"/>', rpr: rpr(26, CRAYON) }) +
      pstyle('CouvDate', 'Couverture - date', { base: 'Normal', ppr: '<w:spacing w:before="720" w:after="0"/>', rpr: rpr(24, CRAYON) }) +
      pstyle('CouvMention', 'Couverture - mention', { base: 'Normal', ppr: '<w:spacing w:before="2400" w:after="0"/>', rpr: rpr(18, '6B6C70') }) +
      pstyle('NoteBas', 'Note', { base: 'Normal', ppr: '<w:spacing w:before="40" w:after="160" w:line="240" w:lineRule="auto"/>', rpr: rpr(18, CRAYON, '<w:i/><w:iCs/>') }) +
      pstyle('EspaceTableau', 'Espace après tableau', { base: 'Normal', ppr: '<w:spacing w:before="0" w:after="120" w:line="120" w:lineRule="exact"/>', rpr: rpr(8) }) +
      pstyle('ACompleter', 'À compléter', {
        base: 'Normal', ppr: '<w:pBdr><w:left w:val="single" w:sz="24" w:space="6" w:color="' + OR + '"/></w:pBdr><w:shd w:val="clear" w:color="auto" w:fill="FFF4D6"/><w:spacing w:before="60" w:after="140"/>',
        rpr: rpr(21, ENCRE)
      }) +
      pstyle('LegendeTableau', 'Légende de tableau', { base: 'Normal', suivant: 'Normal', ppr: '<w:keepNext/><w:spacing w:before="160" w:after="60"/>', rpr: rpr(19, ARDOISE, '<w:b/><w:bCs/>') }) +
      pstyle('TableauTexte', 'Texte de tableau', { base: 'Normal', ppr: '<w:spacing w:before="30" w:after="30" w:line="240" w:lineRule="auto"/>', rpr: rpr(19) }) +
      pstyle('Footer', 'footer', { base: 'Normal', ui: 99, ppr: '<w:tabs><w:tab w:val="right" w:pos="' + LARGEUR_TEXTE + '"/></w:tabs><w:spacing w:after="0"/>', rpr: rpr(17, '6B6C70') }) +
      '<w:style w:type="table" w:default="1" w:styleId="TableauNormal"><w:name w:val="Normal Table"/><w:uiPriority w:val="99"/><w:semiHidden/><w:unhideWhenUsed/><w:tblPr><w:tblInd w:w="0" w:type="dxa"/><w:tblCellMar><w:top w:w="0" w:type="dxa"/><w:left w:w="108" w:type="dxa"/><w:bottom w:w="0" w:type="dxa"/><w:right w:w="108" w:type="dxa"/></w:tblCellMar></w:tblPr></w:style>' +
      '</w:styles>';
  }

  function numerotation(ordonnees) {
    var niveau = function (fmt, texte, retrait) {
      return '<w:lvl w:ilvl="0"><w:start w:val="1"/><w:numFmt w:val="' + fmt + '"/><w:lvlText w:val="' + texte + '"/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="' + retrait.g + '" w:hanging="' + retrait.s + '"/></w:pPr></w:lvl>';
    };
    var xml = ENTETE_XML + '<w:numbering ' + W + '>';
    xml += '<w:abstractNum w:abstractNumId="0"><w:multiLevelType w:val="singleLevel"/>' + niveau('bullet', '•', { g: 567, s: 283 }) + '</w:abstractNum>';
    xml += '<w:abstractNum w:abstractNumId="1"><w:multiLevelType w:val="singleLevel"/>' + niveau('decimal', '%1.', { g: 567, s: 340 }) + '</w:abstractNum>';
    xml += '<w:num w:numId="1"><w:abstractNumId w:val="0"/></w:num>';
    for (var i = 0; i < ordonnees; i++) {
      xml += '<w:num w:numId="' + (2 + i) + '"><w:abstractNumId w:val="1"/><w:lvlOverride w:ilvl="0"><w:startOverride w:val="1"/></w:lvlOverride></w:num>';
    }
    return xml + '</w:numbering>';
  }

  function pied(titre) {
    return ENTETE_XML + '<w:ftr ' + W + '>' + paragraphe(
      passage(titre) + '<w:r><w:tab/></w:r>' + passage('Page ') +
      '<w:fldSimple w:instr=" PAGE "><w:r><w:t>1</w:t></w:r></w:fldSimple>' + passage(' de ') +
      '<w:fldSimple w:instr=" NUMPAGES "><w:r><w:t>1</w:t></w:r></w:fldSimple>', { style: 'Footer' }) + '</w:ftr>';
  }

  function documentXml(corpsXml) {
    return ENTETE_XML + '<w:document ' + W + ' ' + R + '><w:body>' + corpsXml +
      '<w:sectPr><w:footerReference w:type="default" r:id="rId4"/><w:pgSz w:w="12240" w:h="15840"/>' +
      '<w:pgMar w:top="1440" w:right="1440" w:bottom="1300" w:left="1440" w:header="708" w:footer="600" w:gutter="0"/><w:cols w:space="708"/><w:titlePg/></w:sectPr></w:body></w:document>';
  }

  function reglages() {
    return ENTETE_XML + '<w:settings ' + W + '><w:zoom w:percent="100"/><w:defaultTabStop w:val="720"/><w:characterSpacingControl w:val="doNotCompress"/>' +
      '<w:compat><w:compatSetting w:name="compatibilityMode" w:uri="http://schemas.microsoft.com/office/word" w:val="15"/></w:compat>' +
      '<w:themeFontLang w:val="fr-CA"/><w:decimalSymbol w:val=","/><w:listSeparator w:val=";"/></w:settings>';
  }

  var TYPES_CONTENU = ENTETE_XML + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' +
    '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>' +
    '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>' +
    '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>' +
    '<Override PartName="/word/numbering.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml"/>' +
    '<Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/>' +
    '<Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/>' +
    '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>' +
    '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>';

  var RELS_RACINE = ENTETE_XML + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
    '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>' +
    '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>' +
    '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>';

  var RELS_DOCUMENT = ENTETE_XML + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
    '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>' +
    '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering" Target="numbering.xml"/>' +
    '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings" Target="settings.xml"/>' +
    '<Relationship Id="rId4" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer1.xml"/></Relationships>';

  function proprietes(doc, date) {
    var iso = date.toISOString().replace(/\.\d+Z$/, 'Z');
    var auteur = doc.meta.nom || 'Plan d’affaires';
    return ENTETE_XML + '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">' +
      '<dc:title>' + esc(doc.meta.titre) + '</dc:title><dc:creator>' + esc(auteur) + '</dc:creator><cp:lastModifiedBy>' + esc(auteur) + '</cp:lastModifiedBy>' +
      '<dc:language>fr-CA</dc:language><dcterms:created xsi:type="dcterms:W3CDTF">' + iso + '</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">' + iso + '</dcterms:modified></cp:coreProperties>';
  }
  var PROPRIETES_APP = ENTETE_XML + '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>Créateur de plan d’affaires</Application></Properties>';

  /* ---------- Archive ZIP (sans compression) ---------- */
  var TABLE_CRC = null;
  function crc32(octets) {
    if (!TABLE_CRC) {
      TABLE_CRC = new Uint32Array(256);
      for (var n = 0; n < 256; n++) {
        var c = n;
        for (var k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
        TABLE_CRC[n] = c >>> 0;
      }
    }
    var crc = 0xffffffff;
    for (var i = 0; i < octets.length; i++) crc = TABLE_CRC[(crc ^ octets[i]) & 0xff] ^ (crc >>> 8);
    return (crc ^ 0xffffffff) >>> 0;
  }
  function utf8(s) {
    if (typeof TextEncoder !== 'undefined') return new TextEncoder().encode(s);
    var bin = unescape(encodeURIComponent(s)), out = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }
  function dos(date) {
    var annee = Math.max(1980, date.getFullYear());
    return {
      heure: (date.getHours() << 11) | (date.getMinutes() << 5) | (date.getSeconds() >> 1),
      jour: ((annee - 1980) << 9) | ((date.getMonth() + 1) << 5) | date.getDate()
    };
  }
  /* fichiers : [{ nom, octets }] */
  function zip(fichiers, date) {
    var d = dos(date);
    var locaux = [], centraux = [], decalage = 0;
    fichiers.forEach(function (f) {
      var nom = utf8(f.nom), crc = crc32(f.octets), taille = f.octets.length;
      var local = new Uint8Array(30 + nom.length);
      var v = new DataView(local.buffer);
      v.setUint32(0, 0x04034b50, true); v.setUint16(4, 20, true); v.setUint16(6, 0x0800, true); v.setUint16(8, 0, true);
      v.setUint16(10, d.heure, true); v.setUint16(12, d.jour, true); v.setUint32(14, crc, true);
      v.setUint32(18, taille, true); v.setUint32(22, taille, true); v.setUint16(26, nom.length, true); v.setUint16(28, 0, true);
      local.set(nom, 30);
      var central = new Uint8Array(46 + nom.length);
      var c = new DataView(central.buffer);
      c.setUint32(0, 0x02014b50, true); c.setUint16(4, 20, true); c.setUint16(6, 20, true); c.setUint16(8, 0x0800, true); c.setUint16(10, 0, true);
      c.setUint16(12, d.heure, true); c.setUint16(14, d.jour, true); c.setUint32(16, crc, true);
      c.setUint32(20, taille, true); c.setUint32(24, taille, true); c.setUint16(28, nom.length, true);
      c.setUint16(30, 0, true); c.setUint16(32, 0, true); c.setUint16(34, 0, true); c.setUint16(36, 0, true); c.setUint32(38, 0, true); c.setUint32(42, decalage, true);
      central.set(nom, 46);
      locaux.push(local, f.octets);
      centraux.push(central);
      decalage += local.length + taille;
    });
    var tailleCentrale = centraux.reduce(function (s, x) { return s + x.length; }, 0);
    var fin = new Uint8Array(22);
    var e = new DataView(fin.buffer);
    e.setUint32(0, 0x06054b50, true); e.setUint16(8, fichiers.length, true); e.setUint16(10, fichiers.length, true);
    e.setUint32(12, tailleCentrale, true); e.setUint32(16, decalage, true);
    var parts = locaux.concat(centraux, [fin]);
    var total = parts.reduce(function (s, x) { return s + x.length; }, 0);
    var out = new Uint8Array(total), pos = 0;
    parts.forEach(function (x) { out.set(x, pos); pos += x.length; });
    return out;
  }

  /* ---------- Fichier Word ---------- */
  function docx(doc, options) {
    options = options || {};
    var date = options.date instanceof Date ? options.date : new Date();
    var c = corps(doc);
    var fichiers = [
      { nom: '[Content_Types].xml', octets: utf8(TYPES_CONTENU) },
      { nom: '_rels/.rels', octets: utf8(RELS_RACINE) },
      { nom: 'word/document.xml', octets: utf8(documentXml(c.xml)) },
      { nom: 'word/_rels/document.xml.rels', octets: utf8(RELS_DOCUMENT) },
      { nom: 'word/styles.xml', octets: utf8(styles()) },
      { nom: 'word/numbering.xml', octets: utf8(numerotation(c.ordonnees)) },
      { nom: 'word/settings.xml', octets: utf8(reglages()) },
      { nom: 'word/footer1.xml', octets: utf8(pied(doc.meta.titre)) },
      { nom: 'docProps/core.xml', octets: utf8(proprietes(doc, date)) },
      { nom: 'docProps/app.xml', octets: utf8(PROPRIETES_APP) }
    ];
    return zip(fichiers, date);
  }

  /* ---------- Sauvegarde du plan (JSON) ---------- */
  function sauvegarde(etat, date) {
    return JSON.stringify({ format: FORMAT, version: 1, exporte: (date instanceof Date ? date : new Date()).toISOString(), plan: etat }, null, 2);
  }
  /* Relit une sauvegarde : { etat } ou { erreur: 'trop-gros' | 'illisible' | 'format' }. Rien du fichier n'est copié tel quel : tout passe par l'assainissement. */
  function lire(texte) {
    if (typeof texte !== 'string' || !texte.trim()) return { erreur: 'illisible' };
    if (texte.length > TAILLE_MAX_SAUVEGARDE) return { erreur: 'trop-gros' };
    var brut;
    try { brut = JSON.parse(texte.charCodeAt(0) === 0xfeff ? texte.slice(1) : texte); } catch (e) { return { erreur: 'illisible' }; }
    if (!brut || typeof brut !== 'object' || Array.isArray(brut)) return { erreur: 'format' };
    var plan = brut.format === FORMAT && brut.plan && typeof brut.plan === 'object' ? brut.plan : brut;
    if (!plan.r || typeof plan.r !== 'object' || Array.isArray(plan.r)) return { erreur: 'format' };
    var etat = M.assainir(plan);
    return etat ? { etat: etat } : { erreur: 'format' };
  }

  /* ---------- Téléchargement (navigateur) ---------- */
  function telecharger(nom, donnees, type) {
    if (typeof document === 'undefined' || typeof Blob === 'undefined') return false;
    var blob = new Blob([donnees], { type: type || 'application/octet-stream' });
    var url = (g.URL || g.webkitURL).createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = nom;
    a.rel = 'noopener';
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { (g.URL || g.webkitURL).revokeObjectURL(url); }, 10000);
    return true;
  }

  NS.Export = {
    FORMAT: FORMAT, TAILLE_MAX_SAUVEGARDE: TAILLE_MAX_SAUVEGARDE,
    TYPE_DOCX: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', TYPE_JSON: 'application/json',
    docx: docx, sauvegarde: sauvegarde, lire: lire, telecharger: telecharger,
    zip: zip, crc32: crc32, utf8: utf8, propre: propre, esc: esc
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = NS.Export;
})(typeof window !== 'undefined' ? window : globalThis);
