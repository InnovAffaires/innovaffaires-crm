/* ==========================================================================
   Créateur de plan d'affaires : moteur de calcul financier.

   Fonctions pures : à partir des réponses de la personne (voir plan-modele.js),
   elles produisent les résultats prévisionnels, la trésorerie et les
   indicateurs sur 36 mois. Aucun accès au navigateur : le même fichier sert au
   site et aux essais automatiques (Node).

   RÈGLES DE CALCUL (à garder identiques dans l'essai indépendant,
   appli/tests/outils/plan_oracle.py)
   - Tous les montants sont en dollars, avant taxes, ARRONDIS AU DOLLAR à chaque
     case mensuelle (demi vers l'extérieur de zéro) : les totaux des tableaux
     tombent toujours juste. Les années 2 et 3 sont calculées mois par mois.
   - Les séries mensuelles ont 37 cases : la case 0 est « avant l'ouverture »
     (démarrage), les cases 1 à 36 sont les mois d'exploitation.
   - Ventes de la première année : pour chaque offre, la quantité mensuelle
     passe en ligne droite de « quantité au lancement » (mois de début) à
     « quantité au mois 12 », puis est multipliée par l'indice saisonnier du mois
     civil (100 = mois normal) et par (1 − baisse des ventes).
   - Années 2 et 3 : total de la quantité de l'année 1 × (1 + croissance),
     réparti selon le poids de chaque mois civil (indice ÷ somme des indices).
   - Prêts : versement à la fin de chaque mois à partir du mois de réception
     (au moins le mois 1) ; intérêts du mois = arrondi(solde × taux ÷ 12) ;
     mensualité constante arrondie ; le dernier versement solde le prêt.
   - Trésorerie : les ventes sont encaissées après le délai de paiement des clients (par tranches de 30 jours), moins les frais de
     transaction, retenus au moment de l'encaissement ; les coûts directs sont payés après le délai des fournisseurs ; charges,
     salaires et rémunération sont payés le mois même.
   - Investissements : payés au mois 0, puis amortis en ligne droite (l'amortissement entre dans le résultat).
     Frais de démarrage : payés au mois 0, ils réduisent la trésorerie mais NE SONT PAS déduits du résultat
     (convention annoncée à la personne dans le plan et dans l'étape Financement). La rémunération des
     promoteurs reste fixe sur trois ans, sans cotisation d'employeur.
   - Aucun impôt sur le résultat ni aucune taxe de vente n'est calculé.
   ========================================================================== */
(function (g) {
  'use strict';

  var NS = g.PlanAffaires = g.PlanAffaires || {};

  var HORIZON = 36;
  var TYPES_PRET = { proche: true, banque: true, organisme: true };
  var SEUIL_PETIT_FOURNISSEUR = 30000; // Revenu Québec : ventes taxables par trimestre civil ou sur quatre trimestres

  /* ---------- Outils numériques ---------- */
  function nombre(v, defaut, min, max) {
    var n = typeof v === 'string' ? lireNombre(v) : v;
    if (typeof n !== 'number' || !isFinite(n)) return defaut;
    if (n < min) return min;
    if (n > max) return max;
    return n;
  }
  function entier(v, defaut, min, max) {
    return Math.floor(nombre(v, defaut, min, max));
  }
  function arrondi(x) {
    return x < 0 ? -Math.round(-x) : Math.round(x);
  }
  function serie(n, v) {
    var a = new Array(n);
    for (var i = 0; i < n; i++) a[i] = v;
    return a;
  }
  function somme(a, de, a_) {
    var s = 0;
    for (var i = de; i <= a_; i++) s += a[i];
    return s;
  }
  function sommeAn(a, an) {
    return somme(a, 12 * (an - 1) + 1, 12 * an);
  }

  /* Lit un nombre saisi à la française ou à l'anglaise : « 1 250,50 », « 1250.5 », « 1.250,50 », « 12 % », « 3 000 $ ».
     Renvoie null si le texte est vide ou n'est pas un nombre. */
  function lireNombre(texte) {
    if (typeof texte === 'number') return isFinite(texte) ? texte : null;
    if (typeof texte !== 'string') return null;
    var s = texte.replace(/[\s  $%]/g, '').replace(/−/g, '-');
    if (s === '') return null;
    var vir = s.lastIndexOf(','), pt = s.lastIndexOf('.');
    if (vir !== -1 && pt !== -1) {
      // Les deux signes : le dernier est la décimale, l'autre sépare les milliers.
      if (vir > pt) s = s.replace(/\./g, '').replace(',', '.');
      else s = s.replace(/,/g, '');
    } else if (vir !== -1) {
      if (s.indexOf(',') !== vir) return null; // plusieurs virgules
      s = s.replace(',', '.');
    }
    if (!/^-?(\d+\.?\d*|\.\d+)$/.test(s)) return null;
    var n = parseFloat(s);
    return isFinite(n) ? n : null;
  }

  /* « 2027-03 » → { annee: 2027, mois: 3 } ; null si le texte n'est pas un mois valide. */
  function lireMois(txt) {
    var m = /^(\d{4})-(0[1-9]|1[0-2])$/.exec(typeof txt === 'string' ? txt : '');
    if (!m) return null;
    var annee = parseInt(m[1], 10);
    if (annee < 2000 || annee > 2100) return null;
    return { annee: annee, mois: parseInt(m[2], 10) };
  }

  /* Mensualité d'un prêt à versements égaux (taux annuel en %, n versements). */
  function pmt(capital, tauxAnnuel, n) {
    var r = tauxAnnuel / 1200;
    if (n < 1) return 0;
    if (r === 0) return capital / n;
    return capital * r / (1 - Math.pow(1 + r, -n));
  }

  /* Échéancier d'un prêt. Renvoie { interets, capital } : tableaux de HORIZON + 1 cases (case 0 inutilisée). */
  function echeancier(capital, taux, duree, grace, moisReception) {
    var interets = serie(HORIZON + 1, 0);
    var cap = serie(HORIZON + 1, 0);
    var r = taux / 1200;
    var amortissement = duree - grace; // versements qui remboursent du capital (au moins 1)
    var mensualite = arrondi(pmt(capital, taux, amortissement));
    var solde = capital;
    var premier = Math.max(1, moisReception);
    for (var k = 0; k < duree; k++) {
      var interet = arrondi(solde * r);
      var part;
      if (k < grace) part = 0;
      else if (k === duree - 1) part = solde;
      else part = Math.max(0, Math.min(mensualite - interet, solde));
      solde -= part;
      var m = premier + k;
      if (m <= HORIZON) {
        interets[m] = interet;
        cap[m] = part;
      }
    }
    return { interets: interets, capital: cap };
  }

  /* ---------- Lecture des réponses ---------- */
  function texteCourt(v) {
    return typeof v === 'string' ? v.trim() : '';
  }

  function normaliser(r) {
    r = r || {};
    var projet = r.projet || {};
    var offre = r.offre || {};
    var ventes = r.ventes || {};
    var charges = r.charges || {};
    var fin = r.financement || {};
    var equipe = r.equipe || {};

    var saison = [];
    var s = Array.isArray(ventes.saison) ? ventes.saison : [];
    for (var i = 0; i < 12; i++) {
      saison.push(s[i] === null || s[i] === undefined || s[i] === '' ? 100 : nombre(s[i], 100, 0, 1000));
    }

    var lignes = (Array.isArray(offre.lignes) ? offre.lignes : []).slice(0, 12).map(function (l, i) {
      l = l || {};
      var v = (ventes.lignes && ventes.lignes[l.id]) || {};
      return {
        id: l.id,
        nom: texteCourt(l.nom) || 'Offre ' + (i + 1),
        unite: texteCourt(l.unite),
        prix: nombre(l.prix, 0, 0, 1e9),
        cout: nombre(l.cout, 0, 0, 1e9),
        debut: entier(v.debut, 1, 1, 12),
        m1: nombre(v.m1, 0, 0, 1e9),
        m12: nombre(v.m12, 0, 0, 1e9)
      };
    });

    return {
      debut: lireMois(projet.debut),
      forme: projet.forme || '',
      chargesAucune: charges.aucune === true,
      saison: saison,
      lignes: lignes,
      hyp: {
        delaiClients: entier(ventes.delaiClients, 0, 0, 120),
        delaiFournisseurs: entier(charges.delaiFournisseurs, 0, 0, 120),
        fraisTransaction: nombre(charges.fraisTransaction, 0, 0, 100),
        hausse: nombre(charges.hausse, 0, -50, 100),
        chargesSociales: nombre(charges.chargesSociales, 0, 0, 100),
        g2: nombre(ventes.g2, 0, -100, 1000),
        g3: nombre(ventes.g3, 0, -100, 1000),
        coussin: nombre(fin.coussin, 0, 0, 1e9)
      },
      charges: (Array.isArray(charges.liste) ? charges.liste : []).slice(0, 30).map(function (c) {
        c = c || {};
        return { id: c.id, nom: texteCourt(c.nom), montant: nombre(c.montant, 0, 0, 1e9), mois: entier(c.mois, 1, 1, HORIZON) };
      }),
      promoteurs: (Array.isArray(equipe.promoteurs) ? equipe.promoteurs : []).slice(0, 6).map(function (p) {
        p = p || {};
        return {
          nom: texteCourt(p.nom),
          part: p.part === null || p.part === undefined || p.part === '' ? null : nombre(p.part, 0, 0, 100),
          remun: nombre(p.remun, 0, 0, 1e9),
          debutRemun: entier(p.debutRemun, 1, 1, HORIZON)
        };
      }),
      employes: (Array.isArray(equipe.employes) ? equipe.employes : []).slice(0, 12).map(function (e) {
        e = e || {};
        return {
          poste: texteCourt(e.poste),
          nombre: nombre(e.nombre, 1, 0, 1000),
          salaire: nombre(e.salaire, 0, 0, 1e9),
          mois: entier(e.mois, 1, 1, HORIZON)
        };
      }),
      invest: (Array.isArray(fin.invest) ? fin.invest : []).slice(0, 30).map(function (x) {
        x = x || {};
        return { id: x.id, nom: texteCourt(x.nom), montant: nombre(x.montant, 0, 0, 1e9), duree: entier(x.duree, 5, 1, 40) };
      }),
      demarrage: (Array.isArray(fin.demarrage) ? fin.demarrage : []).slice(0, 30).map(function (x) {
        x = x || {};
        return { id: x.id, nom: texteCourt(x.nom), montant: nombre(x.montant, 0, 0, 1e9) };
      }),
      sources: (Array.isArray(fin.sources) ? fin.sources : []).slice(0, 12).map(function (x) {
        x = x || {};
        var type = typeof x.type === 'string' ? x.type : 'apport';
        var duree = entier(x.duree, 0, 0, 360);
        return {
          id: x.id,
          type: type,
          nom: texteCourt(x.nom),
          montant: nombre(x.montant, 0, 0, 1e9),
          taux: nombre(x.taux, 0, 0, 100),
          duree: duree,
          grace: entier(x.grace, 0, 0, Math.max(0, duree - 1)),
          mois: entier(x.mois, 0, 0, HORIZON),
          statut: x.statut || ''
        };
      })
    };
  }

  /* ---------- Une exécution complète du modèle ---------- */
  function executer(E, baisse) {
    var N = HORIZON;
    var f = 1 - baisse / 100;
    var H = E.hyp;

    // Mois civil (1 à 12) de chaque mois d'exploitation.
    var cal = serie(N + 1, 0);
    for (var m = 1; m <= N; m++) cal[m] = ((E.debut ? E.debut.mois - 1 : 0) + (m - 1)) % 12 + 1;
    var sommeIdx = 0;
    for (var i = 0; i < 12; i++) sommeIdx += E.saison[i];

    // Facteur d'augmentation annuelle, par produit répété (pas de puissance : mêmes opérations partout).
    var facteurAn = [1];
    for (var a = 1; a < 3; a++) facteurAn.push(facteurAn[a - 1] * (1 + H.hausse / 100));
    var fh = function (mois) { return facteurAn[Math.floor((mois - 1) / 12)]; };

    /* Ventes */
    var rev = serie(N + 1, 0);
    var cout = serie(N + 1, 0);
    var lignes = E.lignes.map(function (l) {
      var vol = serie(N + 1, 0), rv = serie(N + 1, 0), ct = serie(N + 1, 0);
      var totalAn1 = 0;
      for (var mm = 1; mm <= 12; mm++) {
        var v = 0;
        if (mm >= l.debut) {
          var base;
          if (mm === 12 || l.debut >= 12) base = l.m12;
          else base = l.m1 + (l.m12 - l.m1) * ((mm - l.debut) / (12 - l.debut));
          v = base * E.saison[cal[mm] - 1] / 100 * f;
        }
        vol[mm] = v;
        totalAn1 += v;
      }
      for (var an = 2; an <= 3; an++) {
        var croissance = an === 2 ? 1 + H.g2 / 100 : (1 + H.g2 / 100) * (1 + H.g3 / 100);
        for (var m2 = 12 * (an - 1) + 1; m2 <= 12 * an; m2++) {
          var poids = sommeIdx > 0 ? E.saison[cal[m2] - 1] / sommeIdx : 1 / 12;
          vol[m2] = totalAn1 * croissance * poids;
        }
      }
      for (var m3 = 1; m3 <= N; m3++) {
        rv[m3] = arrondi(vol[m3] * l.prix);
        ct[m3] = arrondi(vol[m3] * l.cout);
        rev[m3] += rv[m3];
        cout[m3] += ct[m3];
      }
      return {
        id: l.id, nom: l.nom, unite: l.unite, prix: l.prix, cout: l.cout, debut: l.debut, m1: l.m1, m12: l.m12,
        volume: vol, revenus: rv, couts: ct,
        volAn: [1, 2, 3].map(function (y) { return sommeAn(vol, y); }),
        revAn: [1, 2, 3].map(function (y) { return sommeAn(rv, y); }),
        coutAn: [1, 2, 3].map(function (y) { return sommeAn(ct, y); })
      };
    });

    var frais = serie(N + 1, 0);
    for (var m4 = 1; m4 <= N; m4++) frais[m4] = arrondi(rev[m4] * H.fraisTransaction / 100);

    /* Charges fixes */
    var chargesTot = serie(N + 1, 0);
    var detailCharges = E.charges.map(function (c) {
      var s = serie(N + 1, 0);
      for (var mm = c.mois; mm <= N; mm++) {
        s[mm] = arrondi(c.montant * fh(mm));
        chargesTot[mm] += s[mm];
      }
      return { nom: c.nom, valeurs: s };
    });

    /* Salaires (avec charges sociales de l'employeur) et rémunération des promoteurs */
    var sal = serie(N + 1, 0);
    E.employes.forEach(function (e) {
      for (var mm = e.mois; mm <= N; mm++) {
        var brut = e.nombre * e.salaire / 12;
        sal[mm] += arrondi(brut * (1 + H.chargesSociales / 100) * fh(mm));
      }
    });
    var remun = serie(N + 1, 0);
    E.promoteurs.forEach(function (p) {
      for (var mm = p.debutRemun; mm <= N; mm++) remun[mm] += arrondi(p.remun);
    });

    /* Amortissement linéaire des investissements */
    var amort = serie(N + 1, 0);
    E.invest.forEach(function (x) {
      var mensuel = arrondi(x.montant / (x.duree * 12));
      for (var mm = 1; mm <= Math.min(N, x.duree * 12); mm++) amort[mm] += mensuel;
    });

    /* Financement : entrées, intérêts et capital remboursé */
    var entrees = serie(N + 1, 0);
    var interets = serie(N + 1, 0);
    var capital = serie(N + 1, 0);
    var prets = [];
    E.sources.forEach(function (s) {
      if (!(s.montant > 0) || s.type === 'marge') return; // une marge de crédit disponible n'est pas de l'argent reçu
      entrees[s.mois] += s.montant;
      if (TYPES_PRET[s.type]) {
        if (s.duree >= 1) {
          var ech = echeancier(s.montant, s.taux, s.duree, s.grace, s.mois);
          for (var mm = 1; mm <= N; mm++) {
            interets[mm] += ech.interets[mm];
            capital[mm] += ech.capital[mm];
          }
          prets.push({ nom: s.nom, montant: s.montant });
        }
      }
    });

    /* Résultats */
    var margeBrute = serie(N + 1, 0);
    var resultat = serie(N + 1, 0);
    for (var m5 = 1; m5 <= N; m5++) {
      margeBrute[m5] = rev[m5] - cout[m5] - frais[m5];
      resultat[m5] = margeBrute[m5] - chargesTot[m5] - sal[m5] - remun[m5] - amort[m5] - interets[m5];
    }

    /* Trésorerie */
    var kC = Math.min(4, Math.floor(H.delaiClients / 30 + 0.5));
    var kF = Math.min(4, Math.floor(H.delaiFournisseurs / 30 + 0.5));
    var enc = serie(N + 1, 0), dec = serie(N + 1, 0), flux = serie(N + 1, 0);
    var solde = serie(N + 1, 0), variation = serie(N + 1, 0);
    var depDemarrage = 0, depInvest = 0, depFrais = 0;
    E.invest.forEach(function (x) { depInvest += x.montant; });
    E.demarrage.forEach(function (x) { depFrais += x.montant; });
    depDemarrage = depInvest + depFrais;
    solde[0] = entrees[0] - depDemarrage;
    for (var m6 = 1; m6 <= N; m6++) {
      enc[m6] = m6 - kC >= 1 ? rev[m6 - kC] : 0;
      dec[m6] = (m6 - kF >= 1 ? cout[m6 - kF] : 0) + (m6 - kC >= 1 ? frais[m6 - kC] : 0) + chargesTot[m6] + sal[m6] + remun[m6];
      flux[m6] = enc[m6] - dec[m6];
      variation[m6] = flux[m6] - interets[m6] - capital[m6] + entrees[m6];
      solde[m6] = solde[m6 - 1] + variation[m6];
    }
    var min = solde[0], moisMin = 0, minAn1 = solde[0], moisMinAn1 = 0;
    for (var m7 = 1; m7 <= N; m7++) {
      if (solde[m7] < min) { min = solde[m7]; moisMin = m7; }
      if (m7 <= 12 && solde[m7] < minAn1) { minAn1 = solde[m7]; moisMinAn1 = m7; }
    }
    var premierNegatif = null;
    for (var m8 = 0; m8 <= N; m8++) if (solde[m8] < 0) { premierNegatif = m8; break; }

    /* Totaux annuels et indicateurs */
    var an = [1, 2, 3];
    var fixesTot = serie(N + 1, 0);
    for (var m9 = 1; m9 <= N; m9++) fixesTot[m9] = chargesTot[m9] + sal[m9] + remun[m9] + amort[m9] + interets[m9];
    var annuel = {
      rev: an.map(function (y) { return sommeAn(rev, y); }),
      coutsDirects: an.map(function (y) { return sommeAn(cout, y); }),
      frais: an.map(function (y) { return sommeAn(frais, y); }),
      margeBrute: an.map(function (y) { return sommeAn(margeBrute, y); }),
      charges: an.map(function (y) { return sommeAn(chargesTot, y); }),
      salaires: an.map(function (y) { return sommeAn(sal, y); }),
      remuneration: an.map(function (y) { return sommeAn(remun, y); }),
      amortissement: an.map(function (y) { return sommeAn(amort, y); }),
      interets: an.map(function (y) { return sommeAn(interets, y); }),
      resultat: an.map(function (y) { return sommeAn(resultat, y); }),
      capital: an.map(function (y) { return sommeAn(capital, y); }),
      encaissements: an.map(function (y) { return sommeAn(enc, y); }),
      decaissements: an.map(function (y) { return sommeAn(dec, y); }),
      fluxExploitation: an.map(function (y) { return sommeAn(flux, y); }),
      financement: an.map(function (y) { return sommeAn(entrees, y); }),
      soldeFin: an.map(function (y) { return solde[12 * y]; })
    };
    annuel.fixes = an.map(function (y) { return sommeAn(fixesTot, y); });
    annuel.tauxMarge = an.map(function (y, i) { return annuel.rev[i] > 0 ? annuel.margeBrute[i] / annuel.rev[i] : null; });
    annuel.seuil = an.map(function (y, i) { return annuel.tauxMarge[i] !== null && annuel.tauxMarge[i] > 0 ? annuel.fixes[i] / annuel.tauxMarge[i] : null; });
    annuel.ratioService = an.map(function (y, i) {
      var service = annuel.interets[i] + annuel.capital[i];
      return service > 0 ? (annuel.resultat[i] + annuel.amortissement[i] + annuel.interets[i]) / service : null;
    });

    var premierMoisBeneficiaire = null;
    for (var m10 = 1; m10 <= N; m10++) {
      if (rev[m10] > 0 && resultat[m10] >= 0) { premierMoisBeneficiaire = m10; break; }
    }

    // Ventes par trimestre civil de la première année (seuil du petit fournisseur). Un trimestre civil
    // appartient à une seule année : pour un début en mai, avril de la deuxième année ne s'ajoute pas à mai et juin.
    // Douze mois consécutifs touchent au plus cinq trimestres (le premier et le dernier peuvent être partiels).
    var trim = [0, 0, 0, 0, 0];
    var debut0 = cal[1] - 1; // 0 = janvier
    for (var m11 = 1; m11 <= 12; m11++) trim[Math.floor((debut0 + m11 - 1) / 3) - Math.floor(debut0 / 3)] += rev[m11];

    return {
      cal: cal, lignes: lignes,
      rev: rev, coutsDirects: cout, frais: frais, margeBrute: margeBrute,
      charges: chargesTot, detailCharges: detailCharges, salaires: sal, remuneration: remun,
      amortissement: amort, interets: interets, resultat: resultat,
      annuel: annuel,
      tres: {
        encaissements: enc, decaissements: dec, fluxExploitation: flux, interets: interets, capital: capital,
        financement: entrees, variation: variation, solde: solde,
        min: min, moisMin: moisMin, minAn1: minAn1, moisMinAn1: moisMinAn1, premierNegatif: premierNegatif,
        delaiClients: kC, delaiFournisseurs: kF
      },
      demarrage: { invest: depInvest, frais: depFrais, total: depDemarrage },
      prets: prets,
      premierMoisBeneficiaire: premierMoisBeneficiaire,
      trimestres: trim
    };
  }

  /* ---------- Point d'entrée ---------- */
  function calculer(reponses, options) {
    options = options || {};
    var E = normaliser(reponses);
    var baisse = nombre(options.baisse, 0, 0, 100);
    var base = executer(E, 0);
    var scenario = baisse > 0 ? executer(E, baisse) : null;

    // Sources de financement
    var parType = {};
    var totalSources = 0, nonConfirme = 0, marge = 0;
    E.sources.forEach(function (s) {
      if (!(s.montant > 0)) return;
      if (s.type === 'marge') { marge += s.montant; return; }
      parType[s.type] = (parType[s.type] || 0) + s.montant;
      totalSources += s.montant;
      if (s.statut !== 'confirme') nonConfirme += s.montant;
    });
    var coussin = E.hyp.coussin;
    var manque = function (res) { return Math.max(0, coussin - res.tres.min); };
    var besoin = {
      utilisations: base.demarrage.total,
      sources: totalSources,
      ecart: totalSources - base.demarrage.total,
      nonConfirme: nonConfirme,
      margeCredit: marge,
      supplementaire: manque(base),
      recommande: totalSources + manque(base),
      parType: parType
    };
    if (scenario) besoin.supplementaireScenario = manque(scenario);

    var seuil = SEUIL_PETIT_FOURNISSEUR;
    var trimMax = Math.max.apply(null, base.trimestres);
    var ventesAn1 = base.annuel.rev[0];
    var tps = {
      seuil: seuil,
      ventesAn1: ventesAn1,
      trimestreMax: trimMax,
      depasseTrimestre: trimMax > seuil,
      depasseAnnee: ventesAn1 > seuil
    };

    /* Alertes : codes et paramètres ; les textes sont dans plan-modele.js. */
    var alertes = [];
    var ajouter = function (code, niveau, params, etape) { alertes.push({ code: code, niveau: niveau, params: params || {}, etape: etape || null }); };

    if (!E.debut) ajouter('debut_manquant', 'info', {}, 'projet');
    if (ventesAn1 === 0 && E.lignes.length) ajouter('aucune_vente', 'avert', {}, 'ventes');
    E.lignes.forEach(function (l) {
      if (l.prix > 0 && l.cout > l.prix) ajouter('prix_sous_cout', 'avert', { nom: l.nom }, 'offre');
    });
    base.lignes.forEach(function (l, i) {
      var moy2 = l.volAn[1] / 12;
      var ref = E.lignes[i].m12;
      if (l.volAn[0] > 0 && E.hyp.g2 > -100 && moy2 < ref * 0.995 && ref > 0) {
        ajouter('an2_sous_mois12', 'info', { nom: l.nom, moyenneAn2: moy2, mois12: ref }, 'ventes');
      }
    });
    if (base.tres.solde[0] < 0) ajouter('demarrage_non_couvert', 'avert', { manque: -base.tres.solde[0] }, 'financement');
    if (base.tres.premierNegatif !== null && base.tres.premierNegatif > 0) {
      ajouter('tresorerie_negative', 'avert', { mois: base.tres.premierNegatif, montant: base.tres.solde[base.tres.premierNegatif], minimum: base.tres.min, moisMin: base.tres.moisMin }, 'financement');
    }
    if (tps.depasseTrimestre) ajouter('seuil_tps_trimestre', 'info', { ventes: trimMax }, 'operations');
    else if (tps.depasseAnnee) ajouter('seuil_tps_annee', 'info', { ventes: ventesAn1 }, 'operations');
    else if (ventesAn1 > 0) ajouter('sous_seuil_tps', 'info', { ventes: ventesAn1 }, 'operations');
    var formeSociete = E.forme === 'societe-actions' || E.forme === 'societe-nom-collectif';
    var parts = E.promoteurs.filter(function (p) { return p.part !== null; });
    if (parts.length && formeSociete) {
      var total = parts.reduce(function (t, p) { return t + p.part; }, 0);
      if (Math.abs(total - 100) > 0.0001) ajouter('parts_incorrectes', 'avert', { total: total }, 'equipe');
    }
    E.sources.forEach(function (s) {
      if (s.montant > 0 && TYPES_PRET[s.type] && s.duree < 1) ajouter('pret_sans_duree', 'avert', { nom: s.nom }, 'financement');
    });
    var remunTotale = E.promoteurs.reduce(function (t, p) { return t + p.remun; }, 0);
    if (E.promoteurs.some(function (p) { return p.nom; }) && remunTotale === 0) ajouter('sans_remuneration', 'info', {}, 'equipe');
    if (!E.charges.some(function (c) { return c.montant > 0; }) && !E.chargesAucune && E.lignes.length) ajouter('charges_vides', 'info', {}, 'charges');
    if (totalSources === 0 && base.demarrage.total > 0) ajouter('sources_vides', 'avert', {}, 'financement');
    if (nonConfirme > 0 && totalSources > 0) ajouter('financement_non_confirme', 'info', { montant: nonConfirme }, 'financement');
    if (base.annuel.resultat[0] < 0 && base.annuel.resultat[1] < 0) ajouter('pertes_deux_ans', 'avert', {}, 'ventes');

    return {
      entree: E,
      base: base,
      scenario: scenario,
      baisse: baisse,
      besoin: besoin,
      tps: tps,
      alertes: alertes
    };
  }

  /* ---------- Formats (affichage en français canadien) ---------- */
  var fmtEntier = null, fmtDec = null, fmtPct = null;
  function formats() {
    if (fmtEntier) return;
    try {
      fmtEntier = new Intl.NumberFormat('fr-CA', { maximumFractionDigits: 0 });
      fmtDec = new Intl.NumberFormat('fr-CA', { maximumFractionDigits: 2 });
      fmtPct = new Intl.NumberFormat('fr-CA', { maximumFractionDigits: 1 });
    } catch (e) {
      fmtEntier = fmtDec = fmtPct = { format: function (n) { return String(n); } };
    }
  }
  var NBSP = ' ';
  /* 12 500 $ — le signe moins est typographique (−) ; null et NaN donnent un tiret. */
  function argent(n) {
    if (typeof n !== 'number' || !isFinite(n)) return '—';
    formats();
    var s = fmtEntier.format(Math.abs(Math.round(n))) + NBSP + '$';
    return n < 0 && Math.round(n) !== 0 ? '−' + s : s;
  }
  function entierFr(n) {
    if (typeof n !== 'number' || !isFinite(n)) return '—';
    formats();
    var s = fmtEntier.format(Math.abs(Math.round(n)));
    return n < 0 && Math.round(n) !== 0 ? '−' + s : s;
  }
  function decimal(n, chiffres) {
    if (typeof n !== 'number' || !isFinite(n)) return '—';
    formats();
    var s = new Intl.NumberFormat('fr-CA', { maximumFractionDigits: chiffres === undefined ? 2 : chiffres, minimumFractionDigits: 0 }).format(Math.abs(n));
    return n < 0 && parseFloat(s.replace(/\s/g, '').replace(',', '.')) !== 0 ? '−' + s : s;
  }
  /* 12,5 % — la valeur est déjà en pourcentage (12.5) ; avec ratio = true, elle est une fraction (0.125). */
  function pourcent(n, ratio) {
    if (typeof n !== 'number' || !isFinite(n)) return '—';
    formats();
    var v = ratio ? n * 100 : n;
    var s = fmtPct.format(Math.abs(v)) + NBSP + '%';
    return v < 0 && parseFloat(fmtPct.format(Math.abs(v)).replace(/\s/g, '').replace(',', '.')) !== 0 ? '−' + s : s;
  }

  NS.Calculs = {
    HORIZON: HORIZON,
    TYPES_PRET: TYPES_PRET,
    SEUIL_PETIT_FOURNISSEUR: SEUIL_PETIT_FOURNISSEUR,
    calculer: calculer,
    normaliser: normaliser,
    lireNombre: lireNombre,
    lireMois: lireMois,
    pmt: pmt,
    echeancier: echeancier,
    arrondi: arrondi,
    argent: argent,
    entier: entierFr,
    decimal: decimal,
    pourcent: pourcent
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = NS.Calculs;
})(typeof window !== 'undefined' ? window : globalThis);
