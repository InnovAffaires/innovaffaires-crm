/* ==========================================================================
   Créateur de plan d'affaires : l'application.

   Un questionnaire guidé (étapes), des chiffres calculés en direct, un aperçu du plan et
   trois exportations (impression / PDF, Word, copie de sauvegarde).

   Confidentialité : tout se passe dans le navigateur. Le plan est gardé dans le stockage
   local de l'appareil (clé « innovaffaires.plan.v1 ») et n'est transmis à personne.
   Sécurité : aucun innerHTML ; les textes de la personne passent par value / textContent,
   et par l'assainissement strict du modèle quand ils viennent d'un fichier ou du stockage.
   ES5, comme le reste du site.
   ========================================================================== */
(function (g) {
  'use strict';

  var NS = g.PlanAffaires;
  if (!NS || !NS.Calculs || !NS.Modele || !NS.Exemple || !NS.Document || !NS.Export || !NS.UI) return;
  var Calc = NS.Calculs, M = NS.Modele, Ex = NS.Exemple, D = NS.Document, X = NS.Export, UI = NS.UI;
  var h = UI.h, icone = UI.icone;
  var doc = g.document;
  var NBSP = ' ';
  var CLE = 'innovaffaires.plan.v1';

  /* ---------- État ---------- */
  var etat = null;            // le plan en cours (forme assainie du modèle)
  var racine = null;          // l'élément #plan-app
  var els = {};               // éléments de la coque
  var liens = {};             // adresses des autres pages (attributs data- de la racine)
  var stockage = { ok: true, derniere: null };
  var version = 0;            // augmente à chaque modification : invalide le cache des calculs
  var cache = null;
  var minuteurSauve = null, minuteurVivant = null, minuteurToast = null, minuteurImpression = null;
  var suppression = null;     // dernière ligne supprimée (pour « Annuler »)
  var etapeAffichee = null;
  var focusApres = null;
  var vuMaj = null;           // « maj » de la copie enregistrée sur laquelle repose le plan affiché (null : aucune copie)
  var nonEnregistre = false;  // des modifications attendent d'être enregistrées
  var conflit = null;         // fenêtre « modifié dans un autre onglet », tant qu'elle est ouverte
  var minuteurAnnonce = null;

  /* ---------- Outils ---------- */
  function $(sel, ctx) { return (ctx || doc).querySelector(sel); }
  function $$(sel, ctx) { return Array.prototype.slice.call((ctx || doc).querySelectorAll(sel)); }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function dateLongue(iso) {
    var d = new Date(iso);
    if (isNaN(d.getTime())) return '';
    return (d.getDate() === 1 ? '1er' : d.getDate()) + ' ' + M.MOIS_NOMS[d.getMonth()] + ' ' + d.getFullYear() + ' à ' + d.getHours() + NBSP + 'h' + NBSP + pad(d.getMinutes());
  }
  function heure(d) { return d.getHours() + NBSP + 'h' + NBSP + pad(d.getMinutes()); }
  function argent(n) { return typeof n === 'number' && isFinite(n) ? Calc.argent(n) : '—'; }
  function mois(n) { return n === null || n === undefined ? '—' : String(n); }
  function t(v) { return typeof v === 'string' ? v.trim() : ''; }
  function reduit() { return !!(g.matchMedia && g.matchMedia('(prefers-reduced-motion: reduce)').matches); }

  /* Plan vierge : tel qu'à sa création, aux identifiants près. */
  function normaliserVierge(e) {
    return JSON.stringify(e.r).replace(/"x[a-z0-9]{7}"/g, '"x"');
  }
  var signatureVierge = null;
  function estVierge(e) {
    if (!signatureVierge) signatureVierge = normaliserVierge(M.nouvelEtat());
    return normaliserVierge(e) === signatureVierge;
  }

  /* ---------- Stockage local ---------- */
  /* Le même plan peut être ouvert dans deux onglets. Chaque onglet retient la date (« maj ») de la copie enregistrée sur
     laquelle il repose et refuse d'écraser, sans que la personne ait choisi, une copie différente venue d'ailleurs. */
  function copieEnregistree() {
    try {
      var texte = g.localStorage.getItem(CLE);
      if (texte === null || texte === undefined) return { statut: 'absente' };
      if (!texte || texte.length > X.TAILLE_MAX_SAUVEGARDE) return { statut: 'illisible' };
      var brut = JSON.parse(texte);
      var e = M.assainir(brut);
      if (!e) return { statut: 'illisible' };
      var maj = typeof brut.maj === 'string' && !isNaN(Date.parse(brut.maj)) ? new Date(brut.maj).toISOString() : null;
      return { statut: 'ok', etat: e, maj: maj };
    } catch (err) { return { statut: 'illisible' }; }
  }
  /* Vrai si la copie enregistrée n'est plus celle sur laquelle repose ce plan (modifiée, remplacée ou effacée ailleurs). */
  function copieDifferente(c) {
    if (c.statut === 'absente') return vuMaj !== null;
    if (c.statut === 'illisible') return false;
    return c.maj !== vuMaj;
  }
  function ecrireStockage(forcer) {
    try {
      if (!forcer) {
        var c = copieEnregistree();
        if (copieDifferente(c)) { signalerCopieDifferente(c); return false; }
      }
      g.localStorage.setItem(CLE, JSON.stringify(etat));
      stockage.ok = true; stockage.derniere = new Date();
      vuMaj = etat.maj; nonEnregistre = false;
      return true;
    } catch (e) { stockage.ok = false; return false; }
  }
  function effacerStockage() {
    try { g.localStorage.removeItem(CLE); } catch (e) { /* rien à faire */ }
  }
  function sauvegarderMaintenant(forcer) {
    if (minuteurSauve) { g.clearTimeout(minuteurSauve); minuteurSauve = null; }
    if (!etat) return;
    ecrireStockage(forcer === true);
    majStatut();
  }
  function planifierSauvegarde() {
    if (minuteurSauve) g.clearTimeout(minuteurSauve);
    minuteurSauve = g.setTimeout(sauvegarderMaintenant, 400);
  }

  /* ---------- Calculs (mis en cache entre deux modifications) ---------- */
  function calculs() {
    if (!cache || cache.version !== version || cache.baisse !== etat.ui.baisse) {
      cache = { version: version, baisse: etat.ui.baisse, res: Calc.calculer(etat.r, { baisse: etat.ui.baisse }) };
    }
    return cache.res;
  }

  /* ---------- Modifications ---------- */
  function changer() {
    etat.maj = new Date().toISOString();
    nonEnregistre = true;
    version++;
    cache = null;
    planifierSauvegarde();
    if (minuteurVivant) g.clearTimeout(minuteurVivant);
    minuteurVivant = g.setTimeout(majVivant, 140);
  }
  function accesChamp(etape, c) {
    var sec = M.sectionDe(etape);
    return {
      get: function () { return etat.r[sec][c.cle]; },
      set: function (v) { etat.r[sec][c.cle] = v; changer(); }
    };
  }

  /* ---------- Annonces ---------- */
  /* Une région « status » présente dès le départ (et invisible) lit le message aux lecteurs d'écran : une région qu'on
     affiche et remplit en même temps n'est pas annoncée de façon fiable. Le message visible, lui, n'est pas une région vivante. */
  function annoncer(texte) {
    if (!els.annonce) return;
    if (minuteurAnnonce) g.clearTimeout(minuteurAnnonce);
    els.annonce.textContent = '';
    minuteurAnnonce = g.setTimeout(function () { minuteurAnnonce = null; if (els.annonce) els.annonce.textContent = texte; }, 80);
  }
  function notifier(texte, action) {
    if (!els.toast) return;
    els.toast.textContent = '';
    els.toast.appendChild(h('span', { 'class': 'plan-message__texte' }, texte));
    if (action) {
      els.toast.appendChild(h('button', { type: 'button', 'class': 'plan-message__action', onclick: function () { masquerToast(); action.fn(); } }, action.libelle));
    }
    els.toast.hidden = false;
    annoncer(texte);
    if (minuteurToast) g.clearTimeout(minuteurToast);
    minuteurToast = g.setTimeout(masquerToast, action ? 12000 : 6000);
  }
  function masquerToast() {
    if (minuteurToast) { g.clearTimeout(minuteurToast); minuteurToast = null; }
    if (els.toast) { els.toast.hidden = true; els.toast.textContent = ''; }
    if (minuteurAnnonce) { g.clearTimeout(minuteurAnnonce); minuteurAnnonce = null; }
    if (els.annonce) els.annonce.textContent = '';
  }

  /* ---------- Fenêtres de dialogue ---------- */
  function dialogue(titre, contenu, options) {
    options = options || {};
    var d = h('dialog', { 'class': 'plan-dialogue' + (options.classe ? ' ' + options.classe : ''), 'aria-labelledby': 'plan-dlg-titre' });
    var tete = h('div', { 'class': 'plan-dialogue__tete' }, [h('h2', { id: 'plan-dlg-titre' }, titre)]);
    d.appendChild(tete);
    d.appendChild(h('div', { 'class': 'plan-dialogue__corps' }, contenu));
    if (options.pied) d.appendChild(options.pied);   // pied fixe : il reste visible pendant qu'on fait défiler le corps
    var fermer = function () { if (typeof d.close === 'function') d.close(); else d.removeAttribute('open'); };
    d.addEventListener('close', function () { if (d.parentNode) d.parentNode.removeChild(d); if (options.apres) options.apres(); });
    // Échap ferme la fenêtre, sauf quand un choix est obligatoire (options.bloquer).
    d.addEventListener('cancel', function (e) { if (options.bloquer) e.preventDefault(); });
    d.addEventListener('click', function (e) { if (e.target === d && options.fermerAuClic !== false && !options.bloquer) fermer(); });
    (racine.parentNode || doc.body).appendChild(d);
    if (typeof d.showModal === 'function') d.showModal(); else d.setAttribute('open', '');
    return { noeud: d, fermer: fermer, tete: tete };
  }
  /* boutons : [{ libelle, classe, fn, ferme (défaut vrai), autofocus }] */
  function confirmer(titre, paragraphes, boutons, options) {
    var d;
    var pied = h('div', { 'class': 'plan-dialogue__pied' }, boutons.map(function (b) {
      return h('button', { type: 'button', 'class': 'btn ' + (b.classe || 'btn--contour'), autofocus: b.autofocus, onclick: function () {
        if (b.ferme !== false) d.fermer();
        if (b.fn) b.fn();
      } }, b.libelle);
    }));
    d = dialogue(titre, [paragraphes.map(function (p) { return h('p', null, p); }), pied], options);
    var af = $('[autofocus]', d.noeud);
    if (af) af.focus();
    return d;
  }

  /* ---------- Création, chargement, effacement du plan ---------- */
  function remplacerPlan(nouveau, etapeCible) {
    etat = nouveau;
    version++; cache = null; suppression = null;
    M.accorderVentes(etat.r);
    sauvegarderMaintenant(true);   // la personne a confirmé : on remplace la copie enregistrée, même si un autre onglet l'a modifiée
    aller(etapeCible || 'accueil');
  }
  function commencerNouveau() {
    var n = M.nouvelEtat();
    n.etape = 'projet';
    remplacerPlan(n, 'projet');
  }
  function chargerExemple() {
    var e = Ex.exemple();
    remplacerPlan(e, 'projet');
    notifier('L’exemple (une entreprise fictive) est chargé. Vous pouvez le modifier à votre guise.');
  }
  function effacerDonnees() {
    etat = M.nouvelEtat();
    version++; cache = null; suppression = null;
    if (minuteurSauve) { g.clearTimeout(minuteurSauve); minuteurSauve = null; }
    effacerStockage();
    vuMaj = null; nonEnregistre = false;
    stockage.derniere = null;
    aller('accueil');
    notifier('Votre plan a été effacé de cet appareil.');
  }
  function demanderEffacement() {
    var vierge = estVierge(etat);
    if (vierge) { effacerDonnees(); return; }
    confirmer('Effacer votre plan?', [
      'Votre plan enregistré sur cet appareil sera supprimé définitivement. Vous ne pourrez pas le récupérer.',
      'Pour le conserver, téléchargez d’abord une copie de sauvegarde.'
    ], [
      { libelle: 'Télécharger une copie d’abord', classe: 'btn--contour', ferme: false, fn: function () { telechargerSauvegarde(); } },
      { libelle: 'Effacer mon plan', classe: 'btn--plein', fn: effacerDonnees },
      { libelle: 'Annuler', classe: 'btn--contour', autofocus: true }
    ]);
  }
  function demanderRemplacement(titre, texte, action) {
    if (estVierge(etat)) { action(); return; }
    confirmer(titre, [texte, 'Pour conserver votre plan actuel, téléchargez d’abord une copie de sauvegarde.'], [
      { libelle: 'Télécharger une copie d’abord', classe: 'btn--contour', ferme: false, fn: function () { telechargerSauvegarde(); } },
      { libelle: 'Remplacer mon plan', classe: 'btn--plein', fn: action },
      { libelle: 'Annuler', classe: 'btn--contour', autofocus: true }
    ]);
  }

  /* ---------- Plusieurs onglets ---------- */
  /* La copie enregistrée n'est plus celle de cet onglet. Sans modification en attente ici, on reprend simplement la copie
     de l'autre onglet; sinon la personne choisit la version à garder (rien n'est écrasé sans son accord). */
  function signalerCopieDifferente(c) {
    if (!nonEnregistre) adopterCopie(c); else ouvrirConflit(c);
  }
  function adopterCopie(c) {
    var efface = c.statut !== 'ok';
    var etaitVierge = estVierge(etat);
    if (minuteurSauve) { g.clearTimeout(minuteurSauve); minuteurSauve = null; }
    var nouveau = efface ? M.nouvelEtat() : c.etat;
    nouveau.etape = efface ? 'accueil' : etat.etape;
    etat = nouveau;
    vuMaj = efface ? null : c.maj;
    nonEnregistre = false; version++; cache = null; suppression = null;
    M.accorderVentes(etat.r);
    if (efface) stockage.derniere = null;
    if (efface && etaitVierge) return;   // un plan vierge effacé : rien de visible ne change
    if (efface && etapeAffichee !== 'accueil') aller('accueil'); else rerendre();
    if (etaitVierge && estVierge(etat)) return;   // l'autre onglet vient seulement de créer un plan vierge
    notifier(efface ? 'Votre plan a été effacé dans un autre onglet.' : 'Votre plan a été mis à jour : il avait été modifié dans un autre onglet.');
  }
  function ouvrirConflit(c) {
    if (conflit) return;
    var efface = c.statut !== 'ok';
    conflit = confirmer(
      efface ? 'Ce plan a été effacé dans un autre onglet' : 'Ce plan a été modifié dans un autre onglet',
      [
        efface
          ? 'Le plan enregistré sur cet appareil n’existe plus, mais cet onglet contient encore des modifications.'
          : 'Cet onglet et un autre onglet contiennent des versions différentes de votre plan. Une seule peut rester enregistrée sur cet appareil.',
        'Choisissez la version à garder. Pour ne rien perdre, vous pouvez d’abord télécharger une copie de la version de cet onglet.'
      ],
      [
        { libelle: 'Télécharger la version de cet onglet', classe: 'btn--contour', ferme: false, autofocus: true, fn: function () { telechargerSauvegarde(); } },
        { libelle: efface ? 'Rétablir le plan de cet onglet' : 'Garder la version de cet onglet', classe: 'btn--plein', fn: function () {
          sauvegarderMaintenant(true);
          notifier('La version de cet onglet est enregistrée sur cet appareil.');
        } },
        { libelle: efface ? 'Repartir d’un plan vide' : 'Reprendre l’autre version', classe: 'btn--contour', fn: function () { adopterCopie(copieEnregistree()); } }
      ],
      { bloquer: true, apres: function () { conflit = null; } }
    );
  }
  /* Un autre onglet vient d'écrire dans le stockage local (cet événement n'arrive jamais dans l'onglet qui écrit). */
  function surStockage(ev) {
    if (!etat || (ev && ev.key !== null && ev.key !== CLE)) return;
    if (conflit || nonEnregistre || minuteurSauve) return;   // s'il y a des modifications ici, le choix se fait à l'enregistrement
    var c = copieEnregistree();
    if (copieDifferente(c)) adopterCopie(c);
  }

  /* ---------- Exportations ---------- */
  function composerDoc(options) {
    options = options || {};
    return D.composer(etat, { date: options.date || new Date(), baisse: etat.ui.baisse, mention: etat.ui.mention });
  }
  function telechargerWord() {
    var d = composerDoc();
    var octets = X.docx(d, { date: new Date() });
    if (X.telecharger(d.meta.fichier + '.docx', octets, X.TYPE_DOCX)) notifier('Le fichier Word est téléchargé. Il se trouve dans le dossier de téléchargements de votre navigateur.');
  }
  function telechargerSauvegarde() {
    var d = D.fichierBase(etat.r.projet.nom);
    var texte = X.sauvegarde(etat, new Date());
    if (X.telecharger(d + '-sauvegarde.json', texte, 'application/json')) notifier('La copie de sauvegarde est téléchargée. Gardez-la en lieu sûr : elle contient tout votre plan.');
  }
  function importerFichier(fichier) {
    if (!fichier) return;
    if (fichier.size > X.TAILLE_MAX_SAUVEGARDE) { notifier('Ce fichier est trop volumineux pour être une copie de sauvegarde (2' + NBSP + 'Mo au plus).'); return; }
    var lecteur = new g.FileReader();
    lecteur.onload = function () {
      var r = X.lire(String(lecteur.result || ''));
      if (r.erreur === 'trop-gros') { notifier('Ce fichier est trop volumineux pour être une copie de sauvegarde (2' + NBSP + 'Mo au plus).'); return; }
      if (r.erreur === 'illisible') { notifier('Ce fichier n’a pas pu être lu : ce n’est pas une copie de sauvegarde valide.'); return; }
      if (r.erreur) { notifier('Ce fichier n’est pas une copie de sauvegarde du créateur de plan d’affaires.'); return; }
      demanderRemplacement('Remplacer votre plan par cette copie?', 'La copie de sauvegarde remplacera le plan enregistré sur cet appareil.', function () {
        remplacerPlan(r.etat, r.etat.etape === 'accueil' ? 'projet' : r.etat.etape);
        notifier('La copie de sauvegarde est importée.');
      });
    };
    lecteur.onerror = function () { notifier('Ce fichier n’a pas pu être lu.'); };
    lecteur.readAsText(fichier);
  }
  function choisirFichier() {
    var inp = h('input', { type: 'file', accept: '.json,application/json', 'class': 'sr-only', tabindex: '-1', 'aria-hidden': 'true' });
    inp.addEventListener('change', function () { importerFichier(inp.files && inp.files[0]); if (inp.parentNode) inp.parentNode.removeChild(inp); });
    racine.appendChild(inp);
    inp.click();
  }

  /* Impression : le plan est composé dans une zone réservée, seule visible à l'impression. */
  function zoneImpression() {
    var z = doc.getElementById('plan-impression');
    if (!z) { z = h('div', { id: 'plan-impression', 'class': 'plan-impression', 'aria-hidden': 'true' }); doc.body.appendChild(z); }
    return z;
  }
  function preparerImpression() {
    var z = zoneImpression();
    z.textContent = '';
    var d = composerDoc();
    z.appendChild(D.enDom(D.arbre(d, { niveau: 2, graphiques: function (b) { return D.graphiqueDuBloc(d.meta.resultats, b, { prefixe: 'imp', largeur: 640, hauteur: 280 }); } }), doc));
  }
  function nettoyerImpression() {
    doc.body.classList.remove('plan-impression-active');
    var z = doc.getElementById('plan-impression');
    if (z) z.textContent = '';
    if (minuteurImpression) { g.clearTimeout(minuteurImpression); minuteurImpression = null; }
  }
  function imprimer() {
    preparerImpression();
    doc.body.classList.add('plan-impression-active');
    minuteurImpression = g.setTimeout(nettoyerImpression, 120000);
    g.setTimeout(function () { g.print(); }, 60);
  }

  /* ---------- Route ---------- */
  function aller(id) {
    var cible = '#/' + id;
    if (g.location.hash === cible) route(); else g.location.hash = cible;
  }
  function routeCourante() {
    var m = /^#\/([a-z]+)$/.exec(g.location.hash || '');
    if (m && (m[1] === 'accueil' || M.etapeParId(m[1]))) return m[1];
    return 'accueil';
  }
  function route(ouverture) {
    if (!etat) return;
    if (els.apercuFenetre) els.apercuFenetre.fermer();   // « Précédent » du navigateur, lien du document : l'aperçu ne reste pas ouvert
    var id = routeCourante();
    etapeAffichee = id;
    if (id !== 'accueil') { etat.etape = id; if (!estVierge(etat) || etat.maj !== etat.cree) planifierSauvegarde(); }
    // À l'ouverture de la page sur l'accueil de l'outil, on ne touche ni au défilement ni au focus : la personne lit la page depuis le haut
    // (titre, explications), au lieu d'arriver au milieu. Ensuite, chaque changement d'écran déplace le focus sur le titre de l'écran.
    rendre(id, { focus: !(ouverture === true && id === 'accueil') });
  }

  /* ---------- Coque ---------- */
  function monterCoque() {
    racine.textContent = '';
    racine.classList.add('plan-app--pret');
    els.annonce = h('div', { 'class': 'sr-only', role: 'status', 'aria-live': 'polite', 'aria-atomic': 'true' });
    els.toast = h('div', { 'class': 'plan-message', hidden: true });
    els.statut = h('span', { 'class': 'plan-statut', role: 'status' });
    els.progres = h('progress', { max: '100', value: '0', id: 'plan-progres' });
    els.progresTexte = h('label', { 'for': 'plan-progres', 'class': 'plan-progres__texte' }, '');
    els.bandeau = h('div', { 'class': 'plan-bandeau' }, [
      h('a', { href: '#/accueil', 'class': 'plan-bandeau__retour' }, [icone('gauche'), 'Accueil de l’outil']),
      h('div', { 'class': 'plan-progres' }, [els.progresTexte, els.progres]),
      h('div', { 'class': 'plan-bandeau__actions' }, [
        els.statut,
        h('button', { type: 'button', 'class': 'btn btn--contour btn--petit', onclick: ouvrirApercu }, [icone('oeil'), 'Aperçu du plan']),
        h('a', { href: '#/export', 'class': 'btn btn--plein btn--petit' }, [icone('telecharger'), 'Exporter'])
      ])
    ]);
    els.navigation = h('div', { 'class': 'plan-navigation' });
    els.principal = h('div', { 'class': 'plan-principal', id: 'plan-principal' });
    els.accueil = h('div', { 'class': 'plan-accueil-zone' });
    racine.appendChild(els.bandeau);
    racine.appendChild(h('div', { 'class': 'plan-corps' }, [els.navigation, els.principal]));
    racine.appendChild(els.accueil);
    racine.appendChild(els.annonce);
    racine.appendChild(els.toast);
    monterNavigation();
  }

  /* ---------- Navigation latérale ---------- */
  function monterNavigation() {
    els.navigation.textContent = '';
    var details = h('details', { 'class': 'plan-etapes-details', open: true });
    els.resume = h('summary', null, '');
    var nav = h('nav', { 'aria-label': 'Étapes du plan d’affaires' });
    M.PHASES.forEach(function (ph) {
      var items = M.ETAPES.filter(function (e) { return e.phase === ph.id; }).map(function (e) {
        var a = h('a', { href: '#/' + e.id, 'data-etape': e.id }, [
          h('span', { 'class': 'plan-nav__case', 'aria-hidden': 'true' }, [icone('coche')]),
          h('span', { 'class': 'plan-nav__titre' }, e.court),
          h('span', { 'class': 'sr-only plan-nav__etat' }, '')
        ]);
        return h('li', null, a);
      });
      nav.appendChild(h('section', { 'class': 'plan-nav__phase' }, [h('p', { 'class': 'plan-nav__phase-titre', id: 'plan-phase-' + ph.id }, ph.titre), h('ol', { role: 'list', 'aria-labelledby': 'plan-phase-' + ph.id }, items)]));
    });
    details.appendChild(els.resume);
    details.appendChild(nav);
    els.navigation.appendChild(details);
    els.details = details;
    if (g.matchMedia) {
      var mq = g.matchMedia('(min-width: 64rem)');
      var regler = function () { details.open = mq.matches; };
      regler();
      if (mq.addEventListener) mq.addEventListener('change', regler); else if (mq.addListener) mq.addListener(regler);
    }
    els.navigation.addEventListener('click', function (e) {
      // Sur petit écran, le menu des étapes se referme après le choix.
      if (e.target && e.target.closest && e.target.closest('a') && g.matchMedia && !g.matchMedia('(min-width: 64rem)').matches) details.open = false;
    });
  }
  function libelleEtat(s) { return s.etat === 'complet' ? ' (terminée)' : s.etat === 'encours' ? ' (commencée)' : ''; }
  function majNavigation() {
    var prog = M.progression(etat.r);
    $$('a[data-etape]', els.navigation).forEach(function (a) {
      var id = a.getAttribute('data-etape');
      var s = prog.etapes[id];
      var cur = id === etapeAffichee;
      a.className = 'plan-nav__lien plan-nav__lien--' + s.etat + (cur ? ' is-courant' : '');
      if (cur) a.setAttribute('aria-current', 'step'); else a.removeAttribute('aria-current');
      $('.plan-nav__etat', a).textContent = libelleEtat(s);
    });
    var e = M.etapeParId(etapeAffichee);
    var idx = M.ETAPES.indexOf(e);
    els.resume.textContent = e ? 'Étape ' + (idx + 1) + ' sur ' + M.ETAPES.length + ' : ' + e.court : 'Étapes du plan';
    return prog;
  }
  function majBandeau(prog) {
    prog = prog || M.progression(etat.r);
    els.progres.value = prog.pourcent;
    els.progres.setAttribute('aria-valuetext', prog.pourcent + ' % complété');
    els.progresTexte.textContent = 'Plan complété à ' + prog.pourcent + NBSP + '%';
    majStatut();
  }
  function majStatut() {
    if (!els.statut) return;
    var alerte = !stockage.ok;
    var texte = alerte ? 'Enregistrement impossible dans ce navigateur : téléchargez une copie de sauvegarde pour ne rien perdre.'
      : stockage.derniere ? 'Enregistré sur cet appareil à ' + heure(stockage.derniere) : '';
    var classe = 'plan-statut' + (alerte ? ' plan-statut--alerte' : '');
    // On ne touche à l'élément que si quelque chose change : un texte identique réécrit serait relu par les lecteurs d'écran.
    if (els.statut.className !== classe) els.statut.className = classe;
    if (els.statut.textContent !== texte) els.statut.textContent = texte;
  }

  /* ---------- Rendu général ---------- */
  function rendre(id, o) {
    o = o || {};
    racine.setAttribute('data-vue', id === 'accueil' ? 'accueil' : 'etape');
    if (id === 'accueil') {
      els.principal.textContent = '';
      rendreAccueil();
      majBandeau();
    } else {
      els.accueil.textContent = '';
      rendreEtape(M.etapeParId(id), o);
      var prog = majNavigation();
      majBandeau(prog);
    }
    if (o.focus) placerFocus(id);
  }
  function placerFocus(id) {
    var cible = id === 'accueil' ? $('#plan-titre-accueil', racine) : $('#plan-titre-etape', racine);
    if (cible) {
      var rect = racine.getBoundingClientRect();
      if (rect.top < 0 || rect.top > (g.innerHeight || 800) * 0.6) racine.scrollIntoView({ block: 'start', behavior: 'auto' });
      cible.focus({ preventScroll: true });
    }
  }
  function rerendre() {
    var y = g.pageYOffset;
    rendre(etapeAffichee, {});
    g.scrollTo(0, y);
    if (focusApres) {
      var f = $(focusApres, racine);
      focusApres = null;
      if (f) f.focus();
    }
  }

  /* ---------- Accueil ---------- */
  function rendreAccueil() {
    els.accueil.textContent = '';
    var existe = !estVierge(etat);
    var prog = M.progression(etat.r);
    var nom = t(etat.r.projet.nom);
    var haut = [];
    haut.push(h('h2', { id: 'plan-titre-accueil', tabindex: '-1' }, existe ? 'Reprendre votre plan' : 'Créez votre plan d’affaires'));
    if (existe) {
      haut.push(h('p', { 'class': 'plan-accueil__resume' }, [
        'Votre plan ', nom ? h('strong', null, '« ' + nom + ' »') : 'sans nom', ' est enregistré sur cet appareil. Dernière modification : ', dateLongue(etat.maj) || 'inconnue', '. Il est complété à ', prog.pourcent + NBSP + '%', '.'
      ]));
      haut.push(h('div', { 'class': 'actions' }, [
        h('button', { type: 'button', 'class': 'btn btn--plein', onclick: function () { aller(etat.etape && etat.etape !== 'accueil' ? etat.etape : 'projet'); } }, 'Reprendre mon plan'),
        h('button', { type: 'button', 'class': 'btn btn--contour', onclick: function () {
          demanderRemplacement('Commencer un nouveau plan?', 'Le nouveau plan remplacera celui qui est enregistré sur cet appareil.', commencerNouveau);
        } }, 'Commencer un nouveau plan')
      ]));
    } else {
      haut.push(h('p', { 'class': 'plan-accueil__resume' }, M.ETAPES.length + ' étapes pour décrire votre projet, chiffrer ses trois premières années et obtenir un document à présenter à un prêteur ou à un organisme. Vos réponses sont enregistrées à mesure que vous écrivez : vous pouvez arrêter et revenir.'));
      haut.push(h('div', { 'class': 'actions' }, [
        h('button', { type: 'button', 'class': 'btn btn--plein', onclick: commencerNouveau }, 'Commencer mon plan'),
        h('button', { type: 'button', 'class': 'btn btn--contour', onclick: chargerExemple }, 'Voir un exemple')
      ]));
    }
    var tenir = h('section', { 'class': 'plan-accueil__preparer', 'aria-labelledby': 'plan-preparer-titre' }, [
      h('h3', { id: 'plan-preparer-titre' }, 'Ce qui vous aidera'),
      h('ul', { role: 'list' }, [
        h('li', null, 'Les prix que vous comptez demander, avant taxes.'),
        h('li', null, 'Une estimation de vos dépenses mensuelles : loyer, assurances, logiciels, marketing.'),
        h('li', null, 'Ce que vous devez acheter ou payer avant d’ouvrir : équipement, permis, site Web.'),
        h('li', null, 'Vos sources de financement : épargne, prêt, subvention.')
      ]),
      h('p', { 'class': 'petit' }, 'Il vous manque des informations? Laissez les champs vides : l’outil vous dira ce qui manque.')
    ]);
    var vie = h('section', { 'class': 'plan-accueil__vie', 'aria-labelledby': 'plan-vie-titre' }, [
      h('h3', { id: 'plan-vie-titre' }, 'Vos réponses restent chez vous'),
      h('p', null, ['Le plan est enregistré dans ce navigateur, sur votre appareil. Rien n’est envoyé à InnovAffaires ni à personne d’autre. ', liens.confidentialite ? h('a', { href: liens.confidentialite }, 'Politique de confidentialité') : null, '.']),
      h('p', { 'class': 'petit' }, 'Si vous effacez les données de votre navigateur ou changez d’appareil, votre plan disparaît : téléchargez une copie de sauvegarde pour le conserver.')
    ]);
    var feuille = h('div', { 'class': 'feuille plan-accueil' }, [
      h('div', { 'class': 'plan-accueil__haut' }, haut),
      h('div', { 'class': 'plan-accueil__bas' }, [tenir, vie])
    ]);
    var import_ = h('p', { 'class': 'plan-accueil__import' }, [
      'Vous avez déjà une copie de sauvegarde? ',
      h('button', { type: 'button', 'class': 'plan-lien-bouton', onclick: choisirFichier }, 'Importer ma copie de sauvegarde'), '.'
    ]);
    els.accueil.appendChild(feuille);
    els.accueil.appendChild(import_);
  }

  /* ---------- Étapes ---------- */
  var TITRES_SECTION = {
    ventes: { g2: 'Après la première année', saison: 'Variation selon les saisons' },
    charges: { hausse: 'Hypothèses de calcul' },
    financement: { coussin: 'Réserve et garanties' }
  };

  function rendreEtape(e, o) {
    var idx = M.ETAPES.indexOf(e);
    var phase = M.PHASES.filter(function (p) { return p.id === e.phase; })[0];
    var tete = [
      h('p', { 'class': 'plan-etape__phase' }, phase.titre + ' · étape ' + (idx + 1) + ' sur ' + M.ETAPES.length),
      h('h2', { id: 'plan-titre-etape', tabindex: '-1' }, e.titre),
      h('p', { 'class': 'plan-etape__intro' }, e.intro)
    ];
    if (e.aide) {
      tete.push(h('details', { 'class': 'plan-aide' }, [
        h('summary', null, e.aide.titre),
        h('ul', { role: 'list' }, e.aide.points.map(function (p) { return h('li', null, p); }))
      ]));
    }
    var corps = h('div', { 'class': 'plan-etape__corps' });
    els.vivants = { tuiles: null, alertes: null, manques: null, lignes: {} };

    if (e.id === 'ventes' || e.id === 'charges' || e.id === 'financement') {
      els.vivants.tuiles = h('div', { 'class': 'plan-tuiles-zone' });
      corps.appendChild(els.vivants.tuiles);
    }
    if (e.id === 'resultats') {
      rendreResultats(e, corps);
    } else if (e.id === 'export') {
      rendreExport(e, corps);
    } else {
      rendreChamps(e, corps);
    }
    if (e.id === 'ventes' || e.id === 'charges' || e.id === 'financement') {
      els.vivants.alertes = h('div', { 'class': 'plan-alertes-zone' });
      corps.appendChild(els.vivants.alertes);
    }

    var manques = h('div', { 'class': 'plan-manques', 'aria-live': 'polite' });
    els.vivants.manques = manques;

    var prec = idx > 0 ? M.ETAPES[idx - 1] : null, suiv = idx < M.ETAPES.length - 1 ? M.ETAPES[idx + 1] : null;
    var navigation = h('nav', { 'class': 'plan-etape__nav', 'aria-label': 'Passer à une autre étape' }, [
      prec ? h('a', { href: '#/' + prec.id, 'class': 'btn btn--contour', rel: 'prev' }, [icone('gauche'), 'Précédent' + NBSP + ': ' + prec.court]) : h('span'),
      suiv ? h('a', { href: '#/' + suiv.id, 'class': 'btn btn--plein', rel: 'next' }, ['Suivant' + NBSP + ': ' + suiv.court, icone('droite')]) : null
    ]);

    els.principal.textContent = '';
    els.principal.appendChild(h('article', { 'class': 'feuille plan-feuille plan-feuille--' + e.id, 'aria-labelledby': 'plan-titre-etape' }, [
      h('header', { 'class': 'plan-etape__tete' }, tete), corps, manques, navigation
    ]));
    majVivant();
    UI.ajusterTextareas(els.principal);
  }

  function rendreChamps(e, corps) {
    var titres = TITRES_SECTION[e.id] || {};
    e.champs.forEach(function (c) {
      if (titres[c.cle]) corps.appendChild(h('h3', { 'class': 'plan-sous-titre' }, titres[c.cle]));
      var noeud = null;
      if (c.type === 'carte') noeud = rendreCarteVentes(e, c);
      else if (c.type === 'serie12') noeud = rendreSaison(e, c);
      else if (c.type === 'liste') {
        var acces = accesChamp(e, c);
        var rep = UI.champ(c, acces, { changer: changer, apres: function (effet) { apresListe(e, c, effet); } });
        noeud = rep && rep.noeud;
      } else if (c.type === 'demarches') {
        var rep2 = UI.champ(c, accesChamp(e, c), { changer: changer });
        noeud = rep2 && rep2.noeud;
      } else {
        var rep3 = UI.champ(c, accesChamp(e, c), {});
        noeud = rep3 && rep3.noeud;
      }
      if (noeud) corps.appendChild(noeud);
    });
  }

  /* Listes : ajout, suppression (avec annulation), déplacement. */
  function apresListe(e, c, effet) {
    if (e.id === 'offre' && c.cle === 'lignes') {
      var avant = null;
      if (effet.type === 'suppression') avant = etat.r.ventes.lignes[effet.ligne.id];
      M.accorderVentes(etat.r);
      if (effet.type === 'suppression') suppression = { etape: e.id, cle: c.cle, index: effet.index, ligne: effet.ligne, ventes: avant };
    } else if (effet.type === 'suppression') {
      suppression = { etape: e.id, cle: c.cle, index: effet.index, ligne: effet.ligne, ventes: null };
    }
    changer();
    if (effet.type === 'ajout') focusApres = '[data-ligne="' + effet.id + '"] input, [data-ligne="' + effet.id + '"] textarea, [data-ligne="' + effet.id + '"] select';
    else if (effet.type === 'suggestions' && effet.ids.length) focusApres = '[data-ligne="' + effet.ids[0] + '"] input, [data-ligne="' + effet.ids[0] + '"] textarea';
    else if (effet.type === 'deplacement') focusApres = '[data-focus="' + (effet.sens < 0 ? 'monter-' : 'descendre-') + effet.id + '"]:not([disabled]), [data-focus="' + (effet.sens < 0 ? 'descendre-' : 'monter-') + effet.id + '"]:not([disabled])';
    else if (effet.type === 'suppression') focusApres = '[data-focus="ajouter-' + c.cle + '"]';
    rerendre();
    if (effet.type === 'suppression') {
      notifier('Ligne supprimée.', { libelle: 'Annuler', fn: annulerSuppression });
    } else if (effet.type === 'suggestions') {
      notifier(effet.ids.length ? effet.ids.length + (effet.ids.length > 1 ? ' suggestions ajoutées.' : ' suggestion ajoutée.') : 'Toutes les suggestions figurent déjà dans votre liste.');
    }
  }
  function annulerSuppression() {
    var s = suppression;
    if (!s) return;
    suppression = null;
    var e = M.etapeParId(s.etape);
    var c = M.champListe(s.etape, s.cle);
    var arr = etat.r[M.sectionDe(e)][s.cle];
    if (arr.length >= (c.max || 30)) { notifier('La liste est pleine : la ligne ne peut pas être rétablie.'); return; }
    arr.splice(Math.min(s.index, arr.length), 0, s.ligne);
    if (s.etape === 'offre') { M.accorderVentes(etat.r); if (s.ventes) etat.r.ventes.lignes[s.ligne.id] = s.ventes; }
    changer();
    if (etapeAffichee === s.etape) { focusApres = '[data-ligne="' + s.ligne.id + '"] input, [data-ligne="' + s.ligne.id + '"] textarea'; rerendre(); }
    else notifier('La ligne est rétablie à l’étape « ' + e.titre + ' ».');
  }

  /* ---------- Étape Ventes : une carte par offre ---------- */
  function libelleMois(n) {
    var d = Calc.lireMois(etat.r.projet.debut);
    if (!d) return 'mois ' + n;
    var k = d.mois - 1 + (n - 1);
    return 'mois ' + n + ' (' + M.MOIS_NOMS[k % 12] + ' ' + (d.annee + Math.floor(k / 12)) + ')';
  }
  function rendreCarteVentes(e, c) {
    M.accorderVentes(etat.r);
    var offres = etat.r.offre.lignes;
    var zone = h('div', { 'class': 'cartes-ventes', role: 'group', 'aria-labelledby': 'plan-ventes-titre' });
    zone.appendChild(h('h3', { 'class': 'liste__titre', id: 'plan-ventes-titre' }, c.etiquette));
    var utiles = offres.filter(function (o) { return t(o.nom) || o.prix > 0; });
    if (!utiles.length) {
      zone.appendChild(h('p', { 'class': 'plan-vide' }, ['Aucune offre n’est encore décrite. ', h('a', { href: '#/offre' }, 'Ajoutez d’abord vos produits ou services à l’étape Offre'), ' : vous pourrez ensuite en prévoir les ventes ici.']));
      return zone;
    }
    offres.forEach(function (o, i) {
      if (!(t(o.nom) || o.prix > 0)) return;
      var v = etat.r.ventes.lignes[o.id];
      var nom = t(o.nom) || 'Offre ' + (i + 1) + ' (sans nom)';
      var unite = t(o.unite) || 'unité';
      var tid = 'plan-vente-' + i;
      var champDebut = h('select', { id: tid + '-debut' }, []);
      for (var n = 1; n <= 12; n++) champDebut.appendChild(h('option', { value: String(n) }, 'Au ' + libelleMois(n)));
      champDebut.value = String(v.debut);
      champDebut.addEventListener('change', function () { v.debut = parseInt(champDebut.value, 10); changer(); });
      var qte = function (cle, etiquette, aide) {
        return UI.champ({ type: 'argent', cle: cle, etiquette: etiquette, aide: aide, facultatif: false }, {
          get: function () { return v[cle]; },
          set: function (x) { v[cle] = x; changer(); }
        }, { id: tid + '-' + cle });
      };
      var vivant = h('p', { 'class': 'carte-vente__vivant', 'data-vivant-offre': o.id });
      els.vivants.lignes[o.id] = vivant;
      zone.appendChild(h('section', { 'class': 'carte-vente', 'aria-labelledby': tid + '-titre' }, [
        h('div', { 'class': 'carte-vente__tete' }, [
          h('h4', { id: tid + '-titre' }, nom),
          h('p', { 'class': 'carte-vente__prix' }, o.prix > 0 ? argent(o.prix) + ' par ' + unite : 'Prix à indiquer à l’étape Offre')
        ]),
        h('div', { 'class': 'carte-vente__champs' }, [
          h('div', { 'class': 'champ' }, [h('label', { 'for': tid + '-debut' }, 'Début des ventes'), champDebut]),
          qte('m1', 'Quantité mensuelle au départ', 'Combien vous en vendez chaque mois au début des ventes de cette offre.').noeud,
          qte('m12', 'Quantité mensuelle au mois 12', 'Le rythme que vous visez à la fin de la première année. Le rythme passe en ligne droite de l’un à l’autre.').noeud
        ]),
        vivant
      ]));
    });
    return zone;
  }

  /* ---------- Étape Ventes : variation selon les saisons ---------- */
  var MOIS_COURTS = D.MOIS_COURTS;
  function rendreSaison(e, c) {
    var serie = etat.r.ventes.saison;
    var zone = h('div', { 'class': 'saison', role: 'group', 'aria-labelledby': 'plan-saison-aide' });
    zone.appendChild(h('p', { 'class': 'champ__aide', id: 'plan-saison-aide' }, 'Si vos ventes varient selon les mois, donnez à chaque mois un indice : 100 correspond à un mois normal, 50 à deux fois moins de ventes, 200 à deux fois plus. Laissez vide si vos ventes sont régulières. Les mois sont ceux du calendrier.'));
    var grille = h('div', { 'class': 'saison__grille' });
    var barres = [];
    var moyenne = h('p', { 'class': 'saison__moyenne', 'aria-live': 'polite' });
    function indice(i) { var v = serie[i]; return v === null || v === undefined ? 100 : v; }
    function majBarres() {
      var mx = 100;
      for (var i = 0; i < 12; i++) mx = Math.max(mx, indice(i));
      var somme = 0;
      for (var j = 0; j < 12; j++) {
        somme += indice(j);
        barres[j].style.setProperty('--h', Math.max(2, Math.round(100 * indice(j) / mx)) + '%');
      }
      moyenne.textContent = 'Indice moyen : ' + UI.formaterNombre(Math.round(somme / 12 * 10) / 10, 1) + '. Plus il s’éloigne de 100, plus l’ensemble de vos ventes de l’année change : 100 les laisse telles que vous les avez entrées.';
    }
    for (var i = 0; i < 12; i++) {
      (function (k) {
        var sid = 'plan-saison-' + k;
        var inp = h('input', { type: 'text', id: sid, inputmode: 'numeric', autocomplete: 'off', 'class': 'nombre', placeholder: '100' });
        inp.value = serie[k] === null || serie[k] === undefined ? '' : UI.formaterNombre(serie[k], 0);
        var err = h('div', { 'class': 'erreur', id: sid + '-err', 'aria-live': 'polite' });
        inp.setAttribute('aria-describedby', sid + '-err');
        var def = { type: 'entier', min: 0, max: 1000 };
        inp.addEventListener('input', function () {
          var r = UI.lireSaisie(def, inp.value);
          if (r.vide) { serie[k] = null; err.textContent = ''; inp.removeAttribute('aria-invalid'); }
          else if (r.message) { err.textContent = r.message; inp.setAttribute('aria-invalid', 'true'); return; }
          else { serie[k] = r.valeur; err.textContent = ''; inp.removeAttribute('aria-invalid'); }
          majBarres(); changer();
        });
        inp.addEventListener('blur', function () { if (!inp.getAttribute('aria-invalid')) inp.value = serie[k] === null ? '' : UI.formaterNombre(serie[k], 0); });
        var barre = h('span', { 'class': 'saison__barre', 'aria-hidden': 'true' }, [h('span', { 'class': 'saison__remplissage' })]);
        barres.push(barre);
        grille.appendChild(h('div', { 'class': 'saison__mois' }, [
          barre,
          h('label', { 'for': sid }, [h('span', { 'aria-hidden': 'true' }, MOIS_COURTS[k]), h('span', { 'class': 'sr-only' }, 'Indice ' + M.deMois(M.MOIS_NOMS[k]))]),
          inp, err
        ]));
      })(i);
    }
    zone.appendChild(grille);
    zone.appendChild(moyenne);
    zone.appendChild(h('button', { type: 'button', 'class': 'btn btn--contour btn--petit', onclick: function () {
      for (var i = 0; i < 12; i++) serie[i] = null;
      changer(); focusApres = '#plan-saison-0'; rerendre();
    } }, 'Ventes régulières (effacer les indices)'));
    majBarres();
    return zone;
  }

  /* ---------- Éléments « vivants » : chiffres, alertes, éléments à compléter ---------- */
  function tuile(libelle, valeur, note) {
    return h('div', { 'class': 'tuile' }, [h('dt', null, libelle), h('dd', null, [valeur, note ? h('span', { 'class': 'tuile__note' }, note) : null])]);
  }
  function tuilesPour(id, res) {
    var an = res.base.annuel, b = res.besoin;
    if (id === 'ventes') {
      return [
        tuile('Ventes, année 1', argent(an.rev[0])), tuile('Ventes, année 2', argent(an.rev[1])), tuile('Ventes, année 3', argent(an.rev[2])),
        tuile('Marge brute, année 1', argent(an.margeBrute[0]), an.tauxMarge[0] === null ? '' : ' (' + Calc.pourcent(an.tauxMarge[0], true) + ')')
      ];
    }
    if (id === 'charges') {
      return [
        tuile('Charges fixes, année 1', argent(an.charges[0])),
        tuile('Salaires et rémunération, année 1', argent(an.salaires[0] + an.remuneration[0])),
        tuile('Ventes nécessaires pour atteindre l’équilibre, année 1', argent(an.seuil[0]))
      ];
    }
    if (id === 'financement') {
      var out = [
        tuile('Dépenses de démarrage', argent(b.utilisations)),
        tuile('Sources de financement prévues', argent(b.sources)),
        tuile(b.ecart >= 0 ? 'Marge par rapport au démarrage' : 'Il manque pour le démarrage', argent(Math.abs(b.ecart)))
      ];
      if (b.nonConfirme > 0) out.push(tuile('Financement non confirmé', argent(b.nonConfirme)));
      if (b.supplementaire > 0) out.push(tuile('Financement supplémentaire à prévoir', argent(b.supplementaire)));
      return out;
    }
    return [];
  }
  function alertesDOM(alertes, titre, tous) {
    if (!alertes.length) return null;
    var liste = alertes.map(function (a) {
      var etape = M.etapeParId(a.etape);
      return h('li', { 'class': 'plan-alerte plan-alerte--' + a.niveau }, [
        h('span', { 'class': 'plan-alerte__marque', 'aria-hidden': 'true' }, a.niveau === 'avert' ? '!' : 'i'),
        h('div', null, [
          h('p', null, [h('span', { 'class': 'sr-only' }, a.niveau === 'avert' ? 'Attention : ' : 'À noter : '), M.messageAlerte(a)]),
          (tous && etape) ? h('p', { 'class': 'plan-alerte__lien' }, h('a', { href: '#/' + etape.id }, 'Aller à l’étape « ' + etape.court + ' »')) : null
        ])
      ]);
    });
    return h('section', { 'class': 'plan-alertes', 'aria-label': titre }, [h('h3', null, titre), h('ul', { role: 'list' }, liste)]);
  }
  function ordreAlertes(alertes) {
    return alertes.slice().sort(function (a, b) { return (a.niveau === 'avert' ? 0 : 1) - (b.niveau === 'avert' ? 0 : 1); });
  }

  function majVivant() {
    minuteurVivant = null;
    if (!etat || !els.vivants || etapeAffichee === 'accueil') return;
    var id = etapeAffichee;
    var prog = majNavigation();
    majBandeau(prog);
    // Chiffres en direct
    if (els.vivants.tuiles || els.vivants.alertes || Object.keys(els.vivants.lignes).length) {
      var res = calculs();
      if (els.vivants.tuiles) {
        els.vivants.tuiles.textContent = '';
        els.vivants.tuiles.appendChild(h('section', { 'class': 'plan-tuiles', 'aria-label': 'Chiffres en direct' }, [
          h('h3', { 'class': 'sr-only' }, 'Chiffres en direct'),
          h('dl', null, tuilesPour(id, res))
        ]));
      }
      if (els.vivants.alertes) {
        els.vivants.alertes.textContent = '';
        var propres = ordreAlertes(res.alertes.filter(function (a) { return a.etape === id; }));
        var d = alertesDOM(propres, 'Points d’attention', false);
        if (d) els.vivants.alertes.appendChild(d);
      }
      res.base.lignes.forEach(function (l) {
        var z = els.vivants.lignes[l.id];
        if (!z) return;
        z.textContent = l.volAn[0] > 0 || l.revAn[0] > 0
          ? 'Prévu la première année : ' + UI.formaterNombre(Math.round(l.volAn[0]), 0) + ' ' + (t(l.unite) || 'unité') + (Math.round(l.volAn[0]) > 1 && !/[sx]$/.test(t(l.unite) || 'unité') ? 's' : '') + ', soit ' + argent(l.revAn[0]) + ' de ventes.'
          : 'Entrez une quantité pour voir les ventes prévues.';
      });
    }
    // Éléments à compléter
    if (els.vivants.manques) {
      var zm = els.vivants.manques;
      var s = M.etatEtape(id, etat.r);
      // La zone est une région vivante : on ne la réécrit que lorsque son contenu change, pour ne pas la faire relire à chaque frappe.
      var signature = id === 'resultats' || id === 'export' ? '' : s.etat + '|' + s.manques.join('|');
      if (zm.getAttribute('data-signature') !== signature) {
        zm.setAttribute('data-signature', signature);
        zm.textContent = '';
        if (id !== 'resultats' && id !== 'export') {
          if (s.etat === 'complet') zm.appendChild(h('p', { 'class': 'plan-manques__ok' }, [icone('coche'), 'Cette étape est complète.']));
          else if (s.manques.length) zm.appendChild(h('div', null, [h('p', { 'class': 'plan-manques__titre' }, 'Pour terminer cette étape, il reste :'), h('ul', { role: 'list' }, s.manques.map(function (m) { return h('li', null, m.charAt(0).toUpperCase() + m.slice(1)); }))]));
        }
      }
    }
    if (els.apercu) rafraichirApercuOuvert();
  }

  /* ---------- Étape Résultats ---------- */
  function sectionH2(blocs, regle) {
    var debut = -1;
    for (var i = 0; i < blocs.length; i++) if (blocs[i].t === 'h2' && regle.test(blocs[i].texte)) { debut = i; break; }
    if (debut < 0) return [];
    var fin = blocs.length;
    for (var j = debut + 1; j < blocs.length; j++) if (blocs[j].t === 'h2' || blocs[j].t === 'h1') { fin = j; break; }
    return blocs.slice(debut, fin);
  }
  function largeurGraphique(zone) {
    var w = zone && zone.clientWidth ? zone.clientWidth : 640;
    return Math.max(300, Math.min(720, Math.floor(w) - 4));
  }
  function arbreBlocs(blocs, meta, niveau, prefixe, largeur) {
    var hauteur = Math.max(230, Math.min(320, Math.round(largeur * 0.5)));
    return D.enDom(D.arbre({ blocs: blocs, meta: meta }, {
      niveau: niveau,
      graphiques: function (b) { return D.graphiqueDuBloc(meta.resultats, b, { prefixe: prefixe, largeur: largeur, hauteur: hauteur }); }
    }), doc);
  }
  function rendreResultats(e, corps) {
    var zoneDoc = h('div', { 'class': 'plan-resultats-doc' });
    var zoneScenario = h('div', { 'class': 'plan-scenario-zone' });
    var tuilesZone = h('div', { 'class': 'plan-tuiles-zone' });
    var alertesZone = h('div', { 'class': 'plan-alertes-zone' });
    corps.appendChild(tuilesZone);
    corps.appendChild(zoneDoc);
    corps.appendChild(zoneScenario);
    corps.appendChild(alertesZone);
    corps.appendChild(h('p', { 'class': 'petit' }, ['Les tableaux mensuels (résultats et trésorerie des 12 premiers mois) figurent dans l’', h('button', { type: 'button', 'class': 'plan-lien-bouton', onclick: ouvrirApercu }, 'aperçu du plan'), ' et dans le document exporté.']));

    function dessiner() {
      var d = composerDoc();
      var res = d.meta.resultats;
      var an = res.base.annuel, b = res.besoin;
      tuilesZone.textContent = '';
      tuilesZone.appendChild(h('section', { 'class': 'plan-tuiles', 'aria-label': 'Chiffres clés' }, [h('h3', { 'class': 'sr-only' }, 'Chiffres clés'), h('dl', null, [
        tuile('Ventes, année 1', argent(an.rev[0])),
        tuile('Résultat avant impôts, année 1', argent(an.resultat[0])),
        tuile('Trésorerie la plus basse', argent(res.base.tres.min), ' (' + (res.base.tres.moisMin === 0 ? 'avant l’ouverture' : 'mois ' + res.base.tres.moisMin) + ')'),
        tuile('Ventes nécessaires pour atteindre l’équilibre, année 1', argent(an.seuil[0])),
        tuile('Financement supplémentaire à prévoir', argent(b.supplementaire))
      ])]));
      var largeur = largeurGraphique(zoneDoc);
      var financier = d.blocs;
      var blocs = [];
      var resAn = sectionH2(financier, /^Résultats prévisionnels$/);
      var tres = sectionH2(financier, /^Budget de trésorerie$/).filter(function (x) { return x.t === 'h2' || (x.t === 'tableau' && /^Trésorerie, par année/.test(x.titre)) || x.t === 'graphique'; });
      var indic = sectionH2(financier, /^Seuil de rentabilité/);
      var besoin = sectionH2(financier, /^Besoin de financement$/).filter(function (x) { return x.t === 'h2' || x.t === 'kv'; });
      blocs = [].concat(resAn, tres, indic, besoin);
      zoneDoc.textContent = '';
      zoneDoc.appendChild(arbreBlocs(blocs, d.meta, 2, 'res', largeur));
      indiquerDefilement(zoneDoc);

      // Scénario : curseur + tableau
      zoneScenario.textContent = '';
      var sid = 'plan-baisse';
      var sortie = h('output', { 'for': sid, 'class': 'scenario__valeur' }, etat.ui.baisse + NBSP + '%');
      var curseur = h('input', { type: 'range', id: sid, min: '0', max: '50', step: '5', value: String(etat.ui.baisse), 'aria-valuetext': etat.ui.baisse + ' %' });
      curseur.addEventListener('input', function () {
        etat.ui.baisse = parseInt(curseur.value, 10);
        sortie.textContent = etat.ui.baisse + NBSP + '%';
        curseur.setAttribute('aria-valuetext', etat.ui.baisse + ' %');
        changer();
        dessinerScenario();
      });
      var zoneTableau = h('div', { 'class': 'scenario__tableau' });
      zoneScenario.appendChild(h('section', { 'class': 'scenario', 'aria-labelledby': 'plan-scenario-titre' }, [
        h('h3', { id: 'plan-scenario-titre' }, 'Et si vos ventes étaient plus faibles?'),
        h('p', null, 'Testez la solidité de votre plan : l’outil recalcule votre trésorerie avec des ventes réduites. Si le scénario est activé (plus de 0' + NBSP + '%), il figure aussi dans le plan exporté.'),
        h('div', { 'class': 'scenario__controle' }, [h('label', { 'for': sid }, 'Baisse des ventes'), curseur, sortie]),
        zoneTableau
      ]));
      function dessinerScenario() {
        var d2 = composerDoc();
        var sc = sectionH2(d2.blocs, /^Scénario prudent/);
        zoneTableau.textContent = '';
        if (!sc.length) { zoneTableau.appendChild(h('p', { 'class': 'petit' }, 'Déplacez le curseur pour voir l’effet d’une baisse des ventes sur vos résultats et votre trésorerie.')); return; }
        zoneTableau.appendChild(arbreBlocs(sc, d2.meta, 2, 'sc', largeur));
        indiquerDefilement(zoneTableau);
        var tb = zoneTableau.getElementsByTagName('h3')[0];
        if (tb) tb.classList.add('sr-only');
      }
      dessinerScenario();

      alertesZone.textContent = '';
      var al = alertesDOM(ordreAlertes(res.alertes), 'Points d’attention', true);
      alertesZone.appendChild(al || h('p', { 'class': 'plan-manques__ok' }, [icone('coche'), 'Aucun point d’attention : vos chiffres sont cohérents entre eux. Faites-les tout de même relire par un comptable.']));
    }
    els.vivants.redessiner = dessiner;
    dessiner();
    observerLargeur(zoneDoc, dessiner);
  }

  /* Un tableau plus large que l'écran se fait défiler : une ombre sur le bord indique de quel côté il reste du contenu. */
  function indiquerDefilement(conteneur) {
    $$('.doc-defile', conteneur).forEach(function (d) {
      var zone = d.parentNode;
      var maj = function () {
        var reste = d.scrollWidth - d.clientWidth;
        zone.classList.toggle('defile-gauche', d.scrollLeft > 2);
        zone.classList.toggle('defile-droite', reste > 2 && d.scrollLeft < reste - 2);
      };
      d.addEventListener('scroll', maj, { passive: true });
      maj();
      if (g.requestAnimationFrame) g.requestAnimationFrame(maj);   // la zone n'est parfois attachée à la page qu'après coup
    });
  }

  var observateur = null;
  function observerLargeur(zone, fn) {
    if (observateur) { observateur.disconnect(); observateur = null; }
    if (!g.ResizeObserver) return;
    var derniere = zone.clientWidth, attente = null;
    observateur = new g.ResizeObserver(function () {
      if (Math.abs(zone.clientWidth - derniere) < 24) return;
      derniere = zone.clientWidth;
      if (attente) g.clearTimeout(attente);
      attente = g.setTimeout(fn, 160);
    });
    observateur.observe(zone);
  }

  /* ---------- Étape Exportation ---------- */
  function rendreExport(e, corps) {
    var d = composerDoc();
    var zoneApercu = h('div', { 'class': 'plan-feuille-doc' });
    var prog = M.progression(etat.r);

    // 1. État du plan
    var etatPlan;
    if (d.meta.manques.length) {
      etatPlan = h('div', null, [
        h('p', null, 'Plan complété à ' + prog.pourcent + NBSP + '%. Il reste ' + d.meta.manques.length + (d.meta.manques.length > 1 ? ' éléments' : ' élément') + ' à compléter. Vous pouvez exporter dès maintenant : les passages manquants porteront la mention « À compléter ».'),
        h('ul', { 'class': 'plan-liste-manques', role: 'list' }, d.meta.manques.map(function (m) {
          var etape = M.etapeParId(m.etape);
          return h('li', null, [m.texte.charAt(0).toUpperCase() + m.texte.slice(1), etape ? [' ', h('a', { href: '#/' + etape.id }, 'Compléter')] : null]);
        }))
      ]);
    } else {
      etatPlan = h('p', { 'class': 'plan-manques__ok' }, [icone('coche'), 'Toutes les sections sont renseignées. Relisez votre plan avant de l’exporter.']);
    }
    corps.appendChild(h('section', { 'class': 'plan-bloc', 'aria-labelledby': 'plan-export-etat' }, [h('h3', { id: 'plan-export-etat' }, 'Où en est votre plan'), etatPlan]));

    // 2. Option de mention
    var caseMention = h('input', { type: 'checkbox', id: 'plan-mention' });
    caseMention.checked = etat.ui.mention !== false;
    caseMention.addEventListener('change', function () { etat.ui.mention = caseMention.checked; changer(); dessinerApercu(); });
    corps.appendChild(h('div', { 'class': 'champ champ--case plan-option' }, [caseMention, h('label', { 'for': 'plan-mention' }, 'Ajouter la mention « Préparé avec le créateur de plan d’affaires d’InnovAffaires » sur la couverture')]));

    // 3. Exportations
    var action = function (icon, titre, texte, bouton, fn, classe) {
      return h('li', { 'class': 'plan-export__action' }, [
        h('div', null, [h('h4', null, titre), h('p', null, texte)]),
        h('button', { type: 'button', 'class': 'btn ' + (classe || 'btn--contour'), onclick: fn }, [icone(icon), bouton])
      ]);
    };
    corps.appendChild(h('section', { 'class': 'plan-bloc', 'aria-labelledby': 'plan-export-titre' }, [
      h('h3', { id: 'plan-export-titre' }, 'Enregistrer votre plan'),
      h('ul', { 'class': 'plan-export', role: 'list' }, [
        action('imprimer', 'PDF ou papier', 'Ouvre la fenêtre d’impression de votre navigateur. Pour obtenir un PDF, choisissez « Enregistrer en PDF » comme imprimante.', 'Imprimer ou enregistrer en PDF', imprimer, 'btn--plein'),
        action('fichier', 'Word (.docx)', 'Un document que vous pouvez retoucher dans Word, LibreOffice ou Google Docs. Les graphiques ne sont pas inclus : les tableaux portent les mêmes chiffres.', 'Télécharger en Word', telechargerWord),
        action('telecharger', 'Copie de sauvegarde (.json)', 'Pour reprendre votre plan plus tard ou sur un autre appareil. Elle contient tout ce que vous avez saisi : gardez-la en lieu sûr.', 'Télécharger la copie de sauvegarde', telechargerSauvegarde),
        action('televerser', 'Reprendre une copie de sauvegarde', 'Remplace le plan de cet appareil par le contenu d’une copie téléchargée plus tôt.', 'Importer une copie', choisirFichier)
      ])
    ]));

    // 4. Aperçu
    corps.appendChild(h('section', { 'class': 'plan-bloc', 'aria-labelledby': 'plan-apercu-titre' }, [
      h('h3', { id: 'plan-apercu-titre' }, 'Aperçu de votre plan'),
      h('p', { 'class': 'petit' }, 'Voici le document tel qu’il sera exporté. Les sections « À compléter » se remplissent dans les étapes précédentes.'),
      zoneApercu
    ]));

    // 5. Relecture professionnelle
    var cta = [h('h3', { id: 'plan-aide-titre' }, 'Un regard professionnel?'), h('p', null, 'Dans le forfait Lancement, InnovAffaires prépare avec vous un plan d’affaires personnalisé, bâti à partir de son modèle. Vous pouvez aussi nous écrire pour en discuter, sans engagement de votre part.')];
    var actions = [];
    if (liens.forfait) actions.push(h('a', { href: liens.forfait, 'class': 'btn btn--contour' }, 'Découvrir le forfait'));
    if (liens.contact) actions.push(h('a', { href: liens.contact, 'class': 'btn btn--contour' }, 'Nous joindre'));
    if (actions.length) cta.push(h('div', { 'class': 'actions' }, actions));
    corps.appendChild(h('section', { 'class': 'plan-bloc plan-bloc--aide', 'aria-labelledby': 'plan-aide-titre' }, cta));

    // 6. Données
    corps.appendChild(h('section', { 'class': 'plan-bloc', 'aria-labelledby': 'plan-donnees-titre' }, [
      h('h3', { id: 'plan-donnees-titre' }, 'Vos données'),
      h('p', null, 'Votre plan est enregistré dans ce navigateur seulement. Vous pouvez l’effacer en tout temps.'),
      h('button', { type: 'button', 'class': 'btn btn--contour', onclick: demanderEffacement }, [icone('corbeille'), 'Effacer mes données'])
    ]));

    function dessinerApercu() {
      var d2 = composerDoc();
      zoneApercu.textContent = '';
      zoneApercu.appendChild(D.enDom(D.arbre(d2, {
        niveau: 4,
        liens: function (etape) { return M.etapeParId(etape) ? '#/' + etape : null; },
        graphiques: function (b) { var w = largeurGraphique(zoneApercu); return D.graphiqueDuBloc(d2.meta.resultats, b, { prefixe: 'ap', largeur: w, hauteur: Math.max(230, Math.min(320, Math.round(w * 0.5))) }); }
      }), doc));
      indiquerDefilement(zoneApercu);
    }
    els.vivants.redessiner = dessinerApercu;
    dessinerApercu();
    observerLargeur(zoneApercu, dessinerApercu);
  }

  /* ---------- Fenêtre d'aperçu (disponible à toutes les étapes) ---------- */
  function ouvrirApercu() {
    if (els.apercuFenetre) return;
    var zone = h('div', { 'class': 'plan-feuille-doc' });
    var pied = h('div', { 'class': 'plan-dialogue__pied' }, [
      h('button', { type: 'button', 'class': 'btn btn--contour', onclick: function () { fenetre.fermer(); aller('export'); } }, [icone('telecharger'), 'Exporter']),
      h('button', { type: 'button', 'class': 'btn btn--plein', autofocus: true, onclick: function () { fenetre.fermer(); } }, 'Fermer')
    ]);
    var fenetre = dialogue('Aperçu de votre plan', [h('p', { 'class': 'petit' }, 'Ce document se met à jour à mesure que vous écrivez.'), zone], {
      classe: 'plan-dialogue--grand',
      pied: pied,
      apres: function () { els.apercu = null; els.apercuFenetre = null; }
    });
    els.apercuFenetre = fenetre;
    els.apercu = { zone: zone };
    rafraichirApercuOuvert();
    var af = $('[autofocus]', fenetre.noeud);
    if (af) af.focus();
  }
  function rafraichirApercuOuvert() {
    if (!els.apercu || !els.apercu.zone.isConnected) { els.apercu = null; return; }
    var zone = els.apercu.zone;
    var d = composerDoc();
    var w = largeurGraphique(zone);
    zone.textContent = '';
    zone.appendChild(D.enDom(D.arbre(d, {
      niveau: 3,
      liens: function (etape) { return M.etapeParId(etape) ? '#/' + etape : null; },
      graphiques: function (b) { return D.graphiqueDuBloc(d.meta.resultats, b, { prefixe: 'dlg', largeur: w, hauteur: Math.max(230, Math.min(320, Math.round(w * 0.5))) }); }
    }), doc));
    indiquerDefilement(zone);
    $$('a.doc-lien-completer', zone).forEach(function (a) {
      a.addEventListener('click', function () { var f = $('dialog.plan-dialogue', doc); if (f && f.close) f.close(); });
    });
  }

  /* ---------- Démarrage ---------- */
  function demarrer() {
    racine = doc.getElementById('plan-app');
    if (!racine || racine.getAttribute('data-pret') === '1') return;
    racine.setAttribute('data-pret', '1');
    liens = { forfait: racine.getAttribute('data-lien-forfait'), contact: racine.getAttribute('data-lien-contact'), confidentialite: racine.getAttribute('data-lien-confidentialite') };
    var copie = copieEnregistree();
    etat = copie.statut === 'ok' ? copie.etat : null;
    vuMaj = etat ? copie.maj : null;
    if (!etat) etat = M.nouvelEtat();
    M.accorderVentes(etat.r);
    monterCoque();
    g.addEventListener('hashchange', route);
    g.addEventListener('storage', surStockage);
    g.addEventListener('afterprint', nettoyerImpression);
    g.addEventListener('pagehide', function () { if (minuteurSauve) sauvegarderMaintenant(); });
    // Une page ouverte directement sur une étape (adresse avec #/…) reprend le plan enregistré.
    route(true);
    // Teste le stockage une fois, pour avertir tout de suite si l'enregistrement est impossible.
    try { g.localStorage.setItem(CLE + '.essai', '1'); g.localStorage.removeItem(CLE + '.essai'); } catch (err) { stockage.ok = false; majStatut(); }
  }

  NS.App = { demarrer: demarrer, CLE: CLE };
  if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', demarrer); else demarrer();
})(typeof window !== 'undefined' ? window : globalThis);
