// =============================================================================
// Demandes de forfait (page « Lancement InnovAffaires » du site) : logique pure partagée
// par le serveur et l'interface. Aucun accès au stockage ni au DOM.
//
// Le formulaire de la page d'un forfait ouvre le texte du projet par la mention
//   « Forfait demandé : Lancement InnovAffaires »
//   « Niveau : Clé en main »              (deuxième ligne : le niveau choisi, ou « à déterminer »)
// suivie d'une ligne vide (voir site/src/assets/js/main.js). Le CRM reconnaît ces lignes pour que l'affaire
// ouverte à la conversion porte le nom du forfait et du niveau plutôt que celui d'un diagnostic de financement.
// Un forfait n'a pas de tarif fixe : la page du site donne une fourchette indicative par niveau, et le montant
// exact se fixe dans la soumission écrite. L'affaire est donc créée avec le service « Autre mandat » et, comme
// honoraires estimés, le BAS de la fourchette du niveau choisi (0 $ si le niveau n'est pas choisi) : la
// consultante les ajuste sur la fiche de l'affaire.
//
// Les niveaux ci-dessous sont les mêmes que sur la page du site (site/data.mjs, FORFAIT.niveaux) : un essai
// du CRM le vérifie. L'ancienne mention « Forfait demandé : Business in a Box » (sans ligne « Niveau ») reste lue.
// =============================================================================

/**
 * La mention, au tout début du texte. Le nom du forfait : 60 caractères au plus, lettres, chiffres, espaces
 * (y compris insécables) et & ’ ' . - ; rien d'autre. Un visiteur peut écrire cette ligne lui-même : ce qu'il
 * peut en tirer se limite à un titre d'affaire sobre, créé seulement si une personne du CRM convertit la demande.
 */
const MENTION = /^Forfait demandé : ([\p{L}\p{N}][\p{L}\p{N}   '’&.-]{0,59})[   ]*(?:\r?\n|$)/u;
/** La ligne du niveau, juste sous la mention : 40 caractères au plus, mêmes signes permis. */
const LIGNE_NIVEAU = /^Forfait demandé : [^\r\n]*\r?\nNiveau : ([\p{L}\p{N}][\p{L}\p{N}   '’&.-]{0,39})[   ]*(?:\r?\n|$)/u;

/** Service de l'affaire ouverte pour un forfait (liste « Service » des affaires). */
export const SERVICE_FORFAIT = "autre";
/** Honoraires estimés à l'ouverture quand le niveau n'est pas choisi : aucun tarif connu, on n'attribue pas ceux d'un diagnostic. */
export const HONORAIRES_FORFAIT = 0;
/** Longueur maximale d'un titre d'affaire (même valeur que le schéma : un essai le vérifie). */
export const TITRE_AFFAIRE_MAX = 160;

/**
 * Les niveaux du forfait, avec leur fourchette indicative (avant taxes). « min » sert d'honoraires de départ.
 * « plus » : le haut de la fourchette est ouvert (« 10 000 $ et plus »).
 */
export const NIVEAUX_FORFAIT = Object.freeze([
  Object.freeze({ id: "essentiel", nom: "Essentiel", min: 1000, max: 1800, plus: false }),
  Object.freeze({ id: "cle-en-main", nom: "Clé en main", min: 2500, max: 5000, plus: false }),
  Object.freeze({ id: "premium", nom: "Premium", min: 5500, max: 10000, plus: true }),
]);

/** Comparaison tolérante : sans casse, sans accents, espaces (même insécables) ramenés à un seul. */
const cle = (s) =>
  String(s ?? "")
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[  \s]+/g, " ")
    .trim()
    .toLowerCase();

/** Nom du forfait demandé (« Lancement InnovAffaires »), ou « » si le texte n'ouvre pas par la mention du site. */
export function forfaitDeDemande(projet) {
  const m = MENTION.exec(String(projet ?? ""));
  return m ? m[1].replace(/[  ]/g, " ").replace(/ {2,}/g, " ").trim() : "";
}

/**
 * Niveau demandé : l'entrée de NIVEAUX_FORFAIT dont le nom suit « Niveau : » sous la mention du forfait, ou null
 * (pas de ligne « Niveau », niveau « à déterminer » ou inconnu, texte qui n'ouvre pas par la mention du site).
 */
export function niveauDeDemande(projet) {
  const texte = String(projet ?? "");
  if (!MENTION.test(texte)) return null;
  const m = LIGNE_NIVEAU.exec(texte);
  if (!m) return null;
  const voulu = cle(m[1]);
  return NIVEAUX_FORFAIT.find((n) => cle(n.nom) === voulu) || null;
}

/** Honoraires estimés à l'ouverture de l'affaire : le bas de la fourchette du niveau, ou 0 sans niveau. */
export function honorairesDeDepart(niveau) {
  return niveau && Number.isFinite(niveau.min) ? niveau.min : HONORAIRES_FORFAIT;
}

/**
 * Titre de l'affaire ouverte pour un forfait : « Lancement InnovAffaires (Clé en main) — Ferme Tremblay inc. »
 * (entreprise indiquée à la conversion) ou « Lancement InnovAffaires — Marie Tremblay » (sans niveau).
 * Le nom (entreprise ou personne) est abrégé pour que le titre ne dépasse jamais TITRE_AFFAIRE_MAX caractères.
 */
export function titreAffaireForfait(forfait, { entreprise = "", nom = "", niveau = "" } = {}) {
  const propre = (v) => String(v ?? "").replace(/\s+/g, " ").trim();
  const nomNiveau = propre(niveau);
  const base = nomNiveau ? `${forfait} (${nomNiveau})` : forfait;
  const place = Math.min(90, TITRE_AFFAIRE_MAX - base.length - 3);
  const qui = place > 0 ? (propre(entreprise) || propre(nom)).slice(0, place).trim() : "";
  return qui ? `${base} — ${qui}` : base;
}
