// =============================================================================
// Poste d'appel (power dialer) : logique pure partagée par le serveur et
// l'interface — résultats d'appel, file d'attente tirée des tâches « appel »,
// personne à joindre et ses numéros, relances, script, plage horaire, statistiques.
// Aucun accès au stockage ni au DOM : tout se teste directement.
// =============================================================================
import { RESULTATS_APPEL } from "./schema.js";
import { aujourdhui, jourSemaine, partiesLocales, prochainJourOuvrable } from "./dates.js";
import { nomComplet, telephone as formaterTel } from "./format.js";

// ----- Résultats d'un appel ------------------------------------------------------------------------------------------
/**
 * abouti  : a-t-on parlé à quelqu'un ? (sert aux statistiques et à « demande répondue »)
 * suite   : "facultative" (tâche de suite au choix) | "rdv" (rendez-vous, date facultative) | "rappel" (date obligatoire)
 * relance : le CRM programme lui-même un nouvel essai (jusqu'au nombre d'essais permis)
 */
const META = {
  joint: { court: "Joint", abouti: true, ton: "ok", icone: "ok", touche: "1", suite: "facultative" },
  rdv: { court: "Rendez-vous", abouti: true, ton: "ok", icone: "rendez-vous", touche: "2", suite: "rdv" },
  rappeler: { court: "À rappeler", abouti: true, ton: "info", icone: "horloge", touche: "3", suite: "rappel" },
  pas_de_reponse: { court: "Sans réponse", abouti: false, ton: "neutre", icone: "appel-manque", touche: "4", relance: true },
  message: { court: "Message laissé", abouti: false, ton: "neutre", icone: "messagerie", touche: "5", relance: true },
  pas_interesse: { court: "Pas intéressé", abouti: true, ton: "attention", icone: "pouce-bas", touche: "6" },
  mauvais_numero: { court: "Mauvais numéro", abouti: false, ton: "attention", icone: "raccrocher", touche: "7" },
  ne_pas_appeler: { court: "Ne plus appeler", abouti: true, ton: "erreur", icone: "bloquer", touche: "8" },
};

/** [{ id, libelle, court, abouti, ton, icone, touche, suite?, relance? }] dans l'ordre d'affichage (touches 1 à 8). */
export const RESULTATS = RESULTATS_APPEL.map((r) => ({ ...r, ...META[r.id] }));
export const resultatDe = (id) => RESULTATS.find((r) => r.id === id) || null;
export const estAbouti = (id) => META[id]?.abouti === true;
export const TYPES_SUITE = [["appel", "Appel"], ["courriel", "Courriel"], ["tache", "Tâche"]].map(([id, libelle]) => ({ id, libelle }));

// ----- Numéros de téléphone ---------------------------------------------------------------------------------------
// Le poste, à la fin du numéro : « poste 22 », « poste : 22 », « p. 22 », « ext. 22 », « ext: 22 », « local 22 », « x22 », « #22 »,
// « , 22 » ou « - 22 », seul ou entre parenthèses (« (poste 22) »). Un trait d'union collé aux chiffres fait partie du numéro.
const RE_POSTE = /^(.*?)(?:\s*[([]?\s*(?:poste|post|ext|extension|local|loc|p|x|#)\.?\s*:?\s*#?\s*(\d{1,6})\s*[)\]]?|\s*,\s*(\d{1,6})|\s+[-–—]\s+(\d{1,6}))\s*$/i;
const nbChiffres = (s) => (String(s).match(/\d/g) || []).length;

/**
 * Sépare un numéro de son poste : « 514 555-1234 p. 22 » → { base: "514 555-1234", poste: "22" }. Plusieurs postes (« poste 22 poste 23 »)
 * donnent le premier. Sans poste reconnu (ou si ce qui précède n'a pas au moins 7 chiffres), le numéro est rendu tel quel.
 */
export function separerPoste(brut) {
  let base = String(brut ?? "").trim();
  let poste = "";
  for (let tour = 0; tour < 3; tour += 1) {
    const m = RE_POSTE.exec(base);
    if (!m || nbChiffres(m[1]) < 7) break;
    base = m[1].trim();
    poste = m[2] || m[3] || m[4];
  }
  return { base, poste };
}

/**
 * Analyse un numéro saisi à la main. Retourne null s'il n'a pas assez de chiffres, sinon
 * { brut, chiffres, composable, poste, affiche } :
 *   composable : forme à placer dans tel: (« +15793731237 ») ; 10 chiffres → indicatif +1 ; poste exclu
 *   poste      : « 123 » ou « » (à composer à la main après la connexion)
 */
export function analyserTelephone(brut) {
  const s = String(brut ?? "").trim();
  if (!s || s.length > 100) return null; // aucun numéro valide n'est aussi long (les fiches en acceptent 40)
  const { base, poste } = separerPoste(s);
  const chiffres = base.replace(/\D/g, "");
  if (chiffres.length < 7) return null;
  let composable;
  if (base.startsWith("+")) composable = `+${chiffres}`;
  else if (chiffres.length === 10) composable = `+1${chiffres}`;
  else if (chiffres.length === 11 && chiffres[0] === "1") composable = `+${chiffres}`;
  else composable = chiffres;
  return { brut: s, chiffres, composable, poste, affiche: formaterTel(base) };
}

/**
 * Numéro à enregistrer sur une fiche : « 514 555-1234 » (ou le numéro tel que saisi, sans lettres, s'il n'a pas 10 chiffres),
 * suivi de « poste 123 » au besoin. Chaîne vide si le numéro est inutilisable (moins de 7 ou plus de 15 chiffres).
 */
export function numeroNormalise(brut) {
  const a = analyserTelephone(brut);
  if (!a || a.chiffres.length > 15) return "";
  const dix = a.chiffres.length === 10 ? a.chiffres : a.chiffres.length === 11 && a.chiffres[0] === "1" ? a.chiffres.slice(1) : "";
  const base = dix ? formaterTel(dix) : separerPoste(a.brut).base.replace(/[^\d\s().+-]/g, " ").replace(/\s+/g, " ").trim();
  return a.poste ? `${base} poste ${a.poste}` : base;
}

/** Adresse tel: d'un numéro (null si le numéro est inutilisable). */
export const adresseTel = (brut) => {
  const a = analyserTelephone(brut);
  return a ? `tel:${a.composable}` : null;
};

// ----- Personne à joindre -----------------------------------------------------------------------------------------------
/** « Marie Tremblay » → { prenom, nom } ; « Tremblay, Marie » est aussi compris. */
export function separerNom(complet) {
  const s = String(complet || "").replace(/\s+/g, " ").trim();
  if (!s) return {};
  if (s.includes(",")) {
    const [nom, ...reste] = s.split(",");
    return { prenom: reste.join(" ").trim() || undefined, nom: nom.trim() || undefined };
  }
  const mots = s.split(" ");
  if (mots.length === 1) return { nom: mots[0] };
  return { prenom: mots[0], nom: mots.slice(1).join(" ") };
}

const TYPES_PERSONNE = new Set(["contacts", "entreprises", "demandes"]);
export const peutEtreAppele = (entite) => TYPES_PERSONNE.has(entite);

/**
 * La personne (ou l'entreprise) que vise une tâche d'appel, avec ses numéros.
 *   acces : { fiche(entite, id) → fiche | null, contactsDe(entrepriseId) → [contacts] }  (les fiches à la corbeille sont ignorées)
 *   (lieType, lieId) : la fiche à laquelle la tâche (ou le bouton « Appeler ») est liée
 * Retourne { cible, contexte, demande, entreprise, nom, prenom, nomFamille, fonction, courriel, numeros, nePasAppeler }
 *   cible    : { entite, id, fiche } — la fiche appelée et qui reçoit l'historique ; null si la tâche n'a pas de fiche liée
 *   contexte : { entite, id, fiche } — la fiche de la tâche quand elle diffère de la cible (affaire, dossier, facture, demande)
 *   numeros  : [{ cle, etiquette, de, brut, composable, poste, affiche }] sans doublon
 */
export function resoudrePersonne(lieType, lieId, acces) {
  const prendre = (entite, id) => {
    const f = id ? acces.fiche(entite, id) : null;
    return f && !f.supprime ? f : null;
  };
  const vide = { cible: null, contexte: null, demande: null, entreprise: null, nom: "", prenom: "", nomFamille: "", fonction: "", courriel: "", numeros: [], nePasAppeler: false };
  const source = lieType && lieId ? prendre(lieType, lieId) : null;
  if (!source) return vide;

  let cible = null;
  let contexte = null;
  let demande = null;
  if (lieType === "contacts") {
    cible = { entite: "contacts", fiche: source };
  } else if (lieType === "entreprises") {
    cible = { entite: "entreprises", fiche: source };
  } else if (lieType === "demandes") {
    demande = source;
    const c = prendre("contacts", source.contact_id);
    if (c && !c.anonymise) {
      cible = { entite: "contacts", fiche: c };
      contexte = { entite: "demandes", fiche: source };
    } else cible = { entite: "demandes", fiche: source };
  } else if (lieType === "opportunites" || lieType === "dossiers" || lieType === "factures") {
    contexte = { entite: lieType, fiche: source };
    const c = prendre("contacts", source.contact_id);
    const e = prendre("entreprises", source.entreprise_id);
    if (c && !c.anonymise) cible = { entite: "contacts", fiche: c };
    else if (e) cible = { entite: "entreprises", fiche: e };
    if (lieType === "opportunites") demande = prendre("demandes", source.demande_id);
  }
  if (!cible) return { ...vide, contexte };
  cible.id = cible.fiche.id;
  if (contexte) contexte.id = contexte.fiche.id;

  const f = cible.fiche;
  let entreprise = null;
  if (cible.entite === "contacts") entreprise = prendre("entreprises", f.entreprise_id);
  else if (cible.entite === "entreprises") entreprise = f;

  // Noms
  let nom = "";
  let prenom = "";
  let nomFamille = "";
  let fonction = "";
  let courriel = "";
  if (cible.entite === "contacts") {
    nom = nomComplet(f) || f.courriel || "Contact sans nom";
    prenom = f.prenom || "";
    nomFamille = f.nom || "";
    fonction = f.titre || "";
    courriel = f.courriel || "";
  } else if (cible.entite === "demandes") {
    const sep = separerNom(f.nom);
    nom = f.nom || f.courriel || "Demande";
    prenom = sep.prenom || "";
    nomFamille = sep.nom || "";
    courriel = f.courriel || "";
  } else {
    nom = f.nom || "Entreprise";
  }

  // Numéros (sans doublon, dans l'ordre : le plus direct d'abord)
  const numeros = [];
  const vus = new Set();
  const ajouter = (brut, etiquette, de = "") => {
    const a = analyserTelephone(brut);
    if (!a) return;
    const k = `${a.chiffres}|${a.poste}`;
    if (vus.has(k)) return;
    vus.add(k);
    numeros.push({ cle: `${numeros.length}`, etiquette, de, ...a });
  };
  if (cible.entite === "contacts") {
    ajouter(f.mobile, "Cellulaire");
    ajouter(f.telephone, "Téléphone");
    if (entreprise) ajouter(entreprise.telephone, "Entreprise", entreprise.nom);
    if (demande) ajouter(demande.telephone, "Demande du site");
  } else if (cible.entite === "demandes") {
    ajouter(f.telephone, "Téléphone");
  } else {
    ajouter(f.telephone, "Entreprise");
    // Les numéros des personnes de l'entreprise, sauf de celles qui ont demandé de ne plus être appelées.
    for (const c of (acces.contactsDe?.(f.id) || []).filter((x) => !x.supprime && !x.anonymise && !x.archive && x.ne_pas_appeler !== true).slice(0, 4)) {
      ajouter(c.mobile, "Cellulaire", nomComplet(c) || c.courriel || "");
      ajouter(c.telephone, "Téléphone", nomComplet(c) || c.courriel || "");
    }
  }

  const nePasAppeler = f.ne_pas_appeler === true || entreprise?.ne_pas_appeler === true || demande?.ne_pas_appeler === true;
  return { cible, contexte, demande, entreprise, nom, prenom, nomFamille, fonction, courriel, numeros, nePasAppeler };
}

// ----- File d'attente ----------------------------------------------------------------------------------------------------------
const POIDS_PRIORITE = { haute: 0, normale: 1, basse: 2 };
const poids = (t) => POIDS_PRIORITE[t.priorite || "normale"] ?? 1;
const minutesDe = (hhmm) => (/^\d{2}:\d{2}$/.test(hhmm || "") ? +hhmm.slice(0, 2) * 60 + +hhmm.slice(3) : null);

/** Ordre des tâches d'une même personne : échéance, priorité, heure, titre. */
function comparerTaches(a, b) {
  const ea = a.echeance || "9999-12-31";
  const eb = b.echeance || "9999-12-31";
  if (ea !== eb) return ea < eb ? -1 : 1;
  if (poids(a) !== poids(b)) return poids(a) - poids(b);
  const ha = a.heure || "99:99";
  const hb = b.heure || "99:99";
  if (ha !== hb) return ha < hb ? -1 : 1;
  return String(a.titre || "").localeCompare(String(b.titre || ""), "fr-CA");
}

/**
 * Place une tâche dans un groupe : 0 = à faire d'abord (en retard, ou rappel dont l'heure est arrivée),
 * 1 = aujourd'hui sans heure, 2 = aujourd'hui plus tard (heure fixée), 3 = à venir, 4 = sans échéance.
 */
function groupeDe(t, auj, minutesMaintenant, avance) {
  if (!t.echeance) return 4;
  if (t.echeance < auj) return 0;
  if (t.echeance > auj) return 3;
  const m = minutesDe(t.heure);
  if (m === null) return 1;
  return m <= minutesMaintenant + avance ? 0 : 2;
}

function comparerItems(a, b) {
  if (a.groupe !== b.groupe) return a.groupe - b.groupe;
  const ta = a.tache;
  const tb = b.tache;
  if (a.groupe === 0 || a.groupe === 3) {
    const ea = ta.echeance || "9999-12-31";
    const eb = tb.echeance || "9999-12-31";
    if (ea !== eb) return ea < eb ? -1 : 1;
    const ha = ta.heure || "00:00";
    const hb = tb.heure || "00:00";
    if (ha !== hb) return ha < hb ? -1 : 1;
  } else if (a.groupe === 2) {
    if ((ta.heure || "") !== (tb.heure || "")) return (ta.heure || "") < (tb.heure || "") ? -1 : 1;
  }
  if (poids(ta) !== poids(tb)) return poids(ta) - poids(tb);
  // Les appels voulus un par un (sans liste ni rang) viennent d'abord, par ordre alphabétique. Ceux des listes de prospection suivent :
  // une liste à la fois (celle dont l'appel en attente a été ajouté le plus tôt), chacune dans l'ordre de son fichier.
  const oa = a.ordreListe || "";
  const ob = b.ordreListe || "";
  if (oa !== ob) return oa < ob ? -1 : 1;
  const la = ta.liste_id || "";
  const lb = tb.liste_id || "";
  if (la !== lb) return la < lb ? -1 : 1;
  const ra = Number.isInteger(ta.rang) ? ta.rang : -1;
  const rb = Number.isInteger(tb.rang) ? tb.rang : -1;
  if (ra !== rb) return ra < rb ? -1 : 1;
  return String(a.personne.nom).localeCompare(String(b.personne.nom), "fr-CA");
}

/**
 * La file d'attente d'appels, tirée des tâches de type « appel » encore à faire.
 *   taches       : toutes les tâches non supprimées
 *   acces        : voir resoudrePersonne
 *   moiId        : l'utilisateur courant (ses tâches et celles sans responsable)
 *   portee       : "jour" (en retard + aujourd'hui, par défaut) | "tout" (à venir et sans échéance en plus)
 *   avanceMin    : un rappel fixé à telle heure entre dans la file dès `avanceMin` minutes avant (15)
 * Retourne { items, exclus, resume }
 *   items  : une entrée par personne { cle, personne, taches, tache (la première), essai, groupe }
 *   exclus : [{ raison: "ne_pas_appeler" | "archive" | "anonymise" | "sans_numero" | "sans_fiche", personne, taches }]
 */
export function construireFile({ taches, acces, auj, maintenantMs, moiId, portee = "jour", avanceMin = 15 }) {
  const minutesMaintenant = (() => {
    const p = partiesLocales(maintenantMs);
    return +p.heure.slice(0, 2) * 60 + +p.heure.slice(3, 5);
  })();
  const groupes = new Map();
  const resume = { total: 0, enRetard: 0, aujourdhui: 0, aVenir: 0, sansEcheance: 0, rappelsMaintenant: 0 };
  for (const t of taches) {
    if (t.supprime || t.type !== "appel" || t.statut === "fait") continue;
    if (t.responsable_id && t.responsable_id !== moiId) continue;
    const dansPortee = portee === "tout" || (t.echeance && t.echeance <= auj);
    if (!dansPortee) {
      if (!t.echeance) resume.sansEcheance += 1;
      else resume.aVenir += 1;
      continue;
    }
    const personne = resoudrePersonne(t.lie_type, t.lie_id, acces);
    const cle = personne.cible ? `${personne.cible.entite}:${personne.cible.id}` : `tache:${t.id}`;
    if (!groupes.has(cle)) groupes.set(cle, { cle, personne, taches: [] });
    groupes.get(cle).taches.push(t);
  }
  const items = [];
  const exclus = [];
  for (const g of groupes.values()) {
    g.taches.sort(comparerTaches);
    const tache = g.taches[0];
    if (!g.personne.cible) exclus.push({ raison: "sans_fiche", personne: g.personne, taches: g.taches, cle: g.cle });
    else if (g.personne.nePasAppeler) exclus.push({ raison: "ne_pas_appeler", personne: g.personne, taches: g.taches, cle: g.cle });
    else if (g.personne.cible.fiche.anonymise === true) exclus.push({ raison: "anonymise", personne: g.personne, taches: g.taches, cle: g.cle });
    else if (g.personne.cible.fiche.archive === true) exclus.push({ raison: "archive", personne: g.personne, taches: g.taches, cle: g.cle });
    else if (!g.personne.numeros.length) exclus.push({ raison: "sans_numero", personne: g.personne, taches: g.taches, cle: g.cle });
    else {
      const groupe = groupeDe(tache, auj, minutesMaintenant, avanceMin);
      items.push({ cle: g.cle, personne: g.personne, taches: g.taches, tache, essai: tache.essai || 1, groupe });
    }
  }
  // Pour chaque liste, le moment où son plus ancien appel en attente a été ajouté à la file.
  const debutDeListe = new Map();
  for (const t of taches) {
    if (t.supprime || t.type !== "appel" || t.statut === "fait" || !t.liste_id) continue;
    const cree = String(t.cree || "");
    if (!debutDeListe.has(t.liste_id) || cree < debutDeListe.get(t.liste_id)) debutDeListe.set(t.liste_id, cree);
  }
  for (const it of items) if (it.tache.liste_id) it.ordreListe = debutDeListe.get(it.tache.liste_id) || "";
  items.sort(comparerItems);
  for (const it of items) {
    resume.total += 1;
    if (it.groupe === 0 && it.tache.echeance < auj) resume.enRetard += 1;
    else if (it.groupe === 0 || it.groupe === 1 || it.groupe === 2) {
      resume.aujourdhui += 1;
      if (it.groupe === 0) resume.rappelsMaintenant += 1;
    } else if (it.groupe === 3) resume.aVenir += 1;
    else resume.sansEcheance += 1;
  }
  exclus.sort((a, b) => String(a.personne.nom).localeCompare(String(b.personne.nom), "fr-CA"));
  return { items, exclus, resume };
}

/**
 * Un appel direct (bouton « Appeler » d'une fiche) : même forme qu'un élément de la file. `taches` : toutes les tâches ;
 * celles d'appel encore à faire pour cette personne sont reprises (la plus urgente d'abord) pour que le résultat les termine.
 */
export function itemDirect(lieType, lieId, acces, taches = []) {
  const personne = resoudrePersonne(lieType, lieId, acces);
  const cle = personne.cible ? `${personne.cible.entite}:${personne.cible.id}` : `direct:${lieType}:${lieId}`;
  const ouvertes = personne.cible
    ? taches
        .filter((t) => {
          if (t.supprime || t.type !== "appel" || t.statut === "fait" || !t.lie_type || !t.lie_id) return false;
          const p = resoudrePersonne(t.lie_type, t.lie_id, acces);
          return p.cible && `${p.cible.entite}:${p.cible.id}` === cle;
        })
        .sort(comparerTaches)
    : [];
  return { cle, personne, taches: ouvertes, tache: ouvertes[0] || null, essai: ouvertes[0]?.essai || 1, groupe: 0, direct: true };
}

// ----- Relances et rappels ----------------------------------------------------------------------------------------------
const feriesDe = (config) => config?.jours_feries_supplementaires || [];

/**
 * Prochain essai après un appel sans réponse (ou un message laissé) :
 * { date, essai, max } — ou null quand le nombre d'essais permis est atteint.
 */
export function calculerRelance({ essai = 1, config, auj }) {
  const max = config.appels.essais_max;
  if (essai >= max) return null;
  return { date: prochainJourOuvrable(auj, config.appels.delai_relance_jours, feriesDe(config)), essai: essai + 1, max };
}

/** Date et heure proposées pour « À rappeler » et pour la prise de rendez-vous. */
export function rappelParDefaut({ config, auj }) {
  return { date: prochainJourOuvrable(auj, config.appels.delai_rappel_jours, feriesDe(config)), heure: config.appels.heure_rappel };
}

export const libelleEssai = (essai, max) => `Essai ${essai} sur ${max}`;

// ----- Plage horaire ---------------------------------------------------------------------------------------------------------
/**
 * Plage dans laquelle les appels de télémarketing sont permis (réglable : par défaut 9 h à 21 h 30 en semaine,
 * 10 h à 18 h la fin de semaine). Retourne { dansPlage, debut, fin, finDeSemaine } à l'instant donné.
 */
export function plageHoraire(config, maintenantMs) {
  const p = partiesLocales(maintenantMs);
  const j = jourSemaine(p.date);
  const finDeSemaine = j === 0 || j === 6;
  const plage = finDeSemaine ? config.appels.heures_fin_semaine : config.appels.heures_semaine;
  const hhmm = p.heure.slice(0, 5);
  return { dansPlage: hhmm >= plage.debut && hhmm < plage.fin, debut: plage.debut, fin: plage.fin, finDeSemaine, heure: hhmm };
}

/** « 21:30 » → « 21 h 30 » ; « 09:00 » → « 9 h ». */
export function heureCourte(hhmm) {
  if (!/^\d{2}:\d{2}$/.test(hhmm || "")) return "";
  const h = +hhmm.slice(0, 2);
  const m = hhmm.slice(3);
  return m === "00" ? `${h} h` : `${h} h ${m}`;
}

// ----- Script ------------------------------------------------------------------------------------------------------------------------
/**
 * Découpe un script en sections : « ## Titre » ouvre une section ; « - » ouvre une puce ; sinon, un paragraphe par ligne.
 * Retourne [{ titre, blocs: [{ type: "p", texte } | { type: "puces", lignes: [texte] }] }]
 */
export function analyserScript(texte) {
  const sections = [];
  let courante = null;
  let puces = null;
  const section = (titre) => {
    courante = { titre, blocs: [] };
    sections.push(courante);
    puces = null;
  };
  for (const ligne of String(texte ?? "").replace(/\r\n?/g, "\n").split("\n")) {
    const brut = ligne.trimEnd();
    const m = /^##\s+(.*\S)\s*$/.exec(brut);
    if (m) {
      section(m[1]);
      continue;
    }
    if (!brut.trim()) {
      puces = null;
      continue;
    }
    if (!courante) section("");
    const p = /^\s*[-•]\s+(.*\S)\s*$/.exec(brut);
    if (p) {
      if (!puces) {
        puces = { type: "puces", lignes: [] };
        courante.blocs.push(puces);
      }
      puces.lignes.push(p[1]);
    } else {
      puces = null;
      courante.blocs.push({ type: "p", texte: brut.trim() });
    }
  }
  return sections;
}

const RE_CHAMP = /\{\{\s*([a-z_]+)\s*\}\}/gi;

/** Découpe une ligne en morceaux : "texte" ou { champ: "prenom" }. */
export function segmenterChamps(ligne) {
  const out = [];
  let dernier = 0;
  const s = String(ligne ?? "");
  for (const m of s.matchAll(RE_CHAMP)) {
    if (m.index > dernier) out.push(s.slice(dernier, m.index));
    out.push({ champ: m[1].toLowerCase() });
    dernier = m.index + m[0].length;
  }
  if (dernier < s.length) out.push(s.slice(dernier));
  return out;
}

export const CHAMPS_SCRIPT = [
  ["prenom", "Prénom"], ["nom", "Nom"], ["entreprise", "Entreprise"], ["projet", "Projet décrit dans la demande"],
  ["mon_nom", "Votre nom"], ["mon_entreprise", "Nom de votre entreprise"], ["mon_telephone", "Votre numéro"],
].map(([id, libelle]) => ({ id, libelle }));

/** Valeurs de fusion d'un script pour une personne ; une valeur absente reste "" (l'écran affiche alors un repère). */
export function valeursScript({ personne, utilisateur, config }) {
  const projet = String(personne.demande?.projet || "").replace(/\s+/g, " ").trim();
  return {
    prenom: personne.prenom || "",
    nom: personne.nomFamille || "",
    entreprise: personne.entreprise?.nom || (personne.cible?.entite === "entreprises" ? personne.nom : ""),
    projet: projet.length > 280 ? `${projet.slice(0, 279).trimEnd()}…` : projet,
    mon_nom: utilisateur?.nom || "",
    mon_entreprise: config.entreprise?.nom || "",
    mon_telephone: formaterTel(config.entreprise?.telephone || ""),
  };
}

/**
 * Le script proposé pour cette personne : celui de sa liste d'appels s'il y en a un (`prefereId`), sinon celui des demandes
 * du site, ou celui de la prospection.
 */
export function scriptPourPersonne(personne, config, { prefereId = "" } = {}) {
  const a = config.appels;
  const prefere = prefereId ? a.scripts.find((s) => s.id === prefereId) : null;
  if (prefere) return prefere;
  const id = personne.demande ? a.script_demande : a.script_prospection;
  return a.scripts.find((s) => s.id === id) || a.scripts[0] || null;
}

// ----- Statistiques ---------------------------------------------------------------------------------------------------------
const JOUR_MS = 86_400_000;

/**
 * Statistiques d'appels à partir des activités de type « appel » qui portent un résultat.
 *   du, au : dates (AAAA-MM-JJ, incluses) ; activites : n'importe quelles activités (le filtre est fait ici)
 * Retourne { du, au, total, joints, rdv, secondes, secondesJoints, parResultat, parJour, parHeure, parUtilisateur }
 */
export function calculerStats(activites, { du, au }) {
  const parResultat = Object.fromEntries(RESULTATS_APPEL.map((r) => [r.id, 0]));
  const jours = new Map();
  const heures = Array.from({ length: 24 }, (_, h) => ({ heure: h, total: 0, joints: 0 }));
  const parUtilisateur = new Map();
  const out = { du, au, total: 0, joints: 0, rdv: 0, secondes: 0, secondesJoints: 0, parResultat, parJour: [], parHeure: heures, parUtilisateur: [] };
  for (let d = du, n = 0; d <= au && n < 400; d = new Date(Date.parse(`${d}T00:00:00Z`) + JOUR_MS).toISOString().slice(0, 10), n++) {
    jours.set(d, { date: d, total: 0, joints: 0, rdv: 0 });
  }
  for (const a of activites) {
    if (a.type !== "appel" || !a.resultat || !(a.resultat in parResultat)) continue;
    const ms = Date.parse(a.date);
    if (!Number.isFinite(ms)) continue;
    const p = partiesLocales(ms);
    if (p.date < du || p.date > au) continue;
    const abouti = estAbouti(a.resultat);
    const secondes = Number.isInteger(a.duree_s) ? a.duree_s : Number.isInteger(a.duree_min) ? a.duree_min * 60 : 0;
    out.total += 1;
    parResultat[a.resultat] += 1;
    out.secondes += secondes;
    if (abouti) {
      out.joints += 1;
      out.secondesJoints += secondes;
    }
    if (a.resultat === "rdv") out.rdv += 1;
    const jour = jours.get(p.date);
    if (jour) {
      jour.total += 1;
      if (abouti) jour.joints += 1;
      if (a.resultat === "rdv") jour.rdv += 1;
    }
    const hh = heures[+p.heure.slice(0, 2)];
    if (hh) {
      hh.total += 1;
      if (abouti) hh.joints += 1;
    }
    const uid = a.par || "inconnu";
    if (!parUtilisateur.has(uid)) parUtilisateur.set(uid, { uid, total: 0, joints: 0, rdv: 0, secondes: 0 });
    const u = parUtilisateur.get(uid);
    u.total += 1;
    u.secondes += secondes;
    if (abouti) u.joints += 1;
    if (a.resultat === "rdv") u.rdv += 1;
  }
  out.parJour = [...jours.values()];
  out.parUtilisateur = [...parUtilisateur.values()].sort((a, b) => b.total - a.total);
  return out;
}

/** Date locale d'aujourd'hui (pour les écrans et le serveur). */
export const jourDe = (ms) => aujourdhui(ms);

/** « 2 min 15 s », « 45 s », « 1 h 05 » à partir d'un nombre de secondes. */
export function dureeTexte(secondes) {
  const s = Math.max(0, Math.round(+secondes || 0));
  if (s < 60) return `${s} s`;
  const m = Math.floor(s / 60);
  if (m < 60) return s % 60 ? `${m} min ${s % 60} s` : `${m} min`;
  const h = Math.floor(m / 60);
  return `${h} h ${String(m % 60).padStart(2, "0")}`;
}

/** Chronomètre « 03:25 » (ou « 1:03:25 »). */
export function chronoTexte(secondes) {
  const s = Math.max(0, Math.floor(+secondes || 0));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const r = s % 60;
  const mm = String(m).padStart(2, "0");
  const ss = String(r).padStart(2, "0");
  return h ? `${h}:${mm}:${ss}` : `${mm}:${ss}`;
}
