// Réglages de départ du CRM : étapes, statuts, provenances, gabarits de tâches
// (repris de l'ancien CRM) et gabarits de courriel. Tout se modifie ensuite
// dans Paramètres.

const H = "haute";
const N = "normale";

export const ETAPES_DEFAUT = [
  { id: "nouveau", nom: "Nouveau lead", probabilite: 10, type: "ouverte" },
  { id: "decouverte", nom: "Appel découverte", probabilite: 25, type: "ouverte" },
  { id: "proposition", nom: "Proposition envoyée", probabilite: 50, type: "ouverte" },
  { id: "negociation", nom: "Négociation", probabilite: 70, type: "ouverte" },
  { id: "mandat", nom: "Mandat en cours", probabilite: 100, type: "gagnee" },
  { id: "livre", nom: "Mandat livré", probabilite: 100, type: "gagnee" },
  { id: "perdu", nom: "Perdu", probabilite: 0, type: "perdue" },
];

// type : en-cours | accepte | refuse | termine
export const STATUTS_DOSSIER_DEFAUT = [
  { id: "collecte", nom: "Collecte des documents", type: "en-cours" },
  { id: "redaction", nom: "Rédaction", type: "en-cours" },
  { id: "revision", nom: "Révision par le client", type: "en-cours" },
  { id: "prete", nom: "Prête à déposer", type: "en-cours" },
  { id: "deposee", nom: "Déposée", type: "en-cours" },
  { id: "analyse", nom: "En analyse", type: "en-cours" },
  { id: "acceptee", nom: "Acceptée", type: "accepte" },
  { id: "suivi", nom: "Suivi et reddition de comptes", type: "accepte" },
  { id: "terminee", nom: "Terminée", type: "termine" },
  { id: "refusee", nom: "Refusée", type: "refuse" },
];

export const SOURCES_DEFAUT = [
  { id: "site", libelle: "Site Web" },
  { id: "recommandation", libelle: "Recommandation" },
  { id: "reseau", libelle: "Réseau (SADC, CAE, chambre de commerce…)" },
  { id: "evenement", libelle: "Événement ou webinaire" },
  { id: "appel", libelle: "Appel entrant" },
  { id: "prospection", libelle: "Liste de prospection" },
  { id: "linkedin", libelle: "LinkedIn" },
  { id: "client", libelle: "Client existant" },
  { id: "autre", libelle: "Autre" },
];

// Gabarits de tâches par statut de dossier. `delai` : jours après le changement
// de statut (null : sans date, à fixer plus tard). Types : tache, courriel, appel.
const T = (titre, priorite, delai, type = "tache", description = "") => ({ titre, priorite, delai, type, ...(description ? { description } : {}) });

export const GABARITS_TACHES_DEFAUT = {
  collecte: [
    T("Envoyer au client la liste des pièces à fournir", H, 1, "courriel"),
    T("Valider l’admissibilité : critères du programme, dépenses admissibles, taux d’aide", H, 3),
    T("Obtenir les documents légaux : statuts, NEQ, règlements généraux ou preuve de constitution", N, 7),
    T("Obtenir les états financiers les plus récents (et ceux de l’exercice précédent)", N, 7),
    T("Obtenir la description du projet, le calendrier et les résultats attendus", N, 7),
    T("Obtenir les soumissions ou devis des fournisseurs pour les dépenses importantes", N, 10),
    T("Obtenir le montage financier : mise de fonds, autres sources de financement, prévisions", N, 10),
    T("Faire déclarer les autres aides reçues ou demandées (cumul de l’aide publique)", N, 7),
    T("Faire signer l’autorisation de représentation, si l’organisme l’exige", N, 7),
    T("Faire le point avec le client sur les pièces manquantes", N, 10, "appel"),
  ],
  redaction: [
    T("Relire le guide du programme et vérifier la version du formulaire en vigueur", H, 1),
    T("Rédiger la description du projet et les objectifs", N, 5),
    T("Rédiger la justification du besoin, les retombées et les indicateurs de résultat", N, 7),
    T("Bâtir le budget détaillé et le plan de financement", H, 7),
    T("Préparer le calendrier de réalisation et les jalons", N, 7),
    T("Préparer et nommer les pièces jointes selon les exigences de l’organisme", N, 10),
    T("Faire une relecture complète : cohérence des chiffres, orthographe, limites de longueur", N, 12),
    T("Envoyer la version préliminaire au client, puis passer la demande à « Révision par le client »", H, 14, "courriel"),
  ],
  revision: [
    T("Envoyer le dossier au client avec la date limite pour ses commentaires", H, 1, "courriel"),
    T("Réviser le dossier avec le client", N, 3, "appel"),
    T("Intégrer les corrections et les commentaires du client", N, 5),
    T("Obtenir l’approbation écrite du client", H, 7),
    T("Obtenir la signature de la personne autorisée à engager l’organisation", H, 7),
  ],
  prete: [
    T("Faire le contrôle final : sections complètes, chiffres cohérents, pièces lisibles", H, 1),
    T("Confirmer la méthode de dépôt (portail, courriel ou poste) et les accès nécessaires", N, 1),
    T("Déposer la demande avant la date limite", H, 2),
    T("Conserver l’accusé de réception et noter le numéro de dossier", N, 2),
    T("Facturer le solde des honoraires, selon l’entente de service", N, 2),
  ],
  deposee: [
    T("Inscrire la date de dépôt et le numéro de dossier dans la fiche", H, 0),
    T("Confirmer le dépôt au client et lui expliquer les prochaines étapes", N, 1, "courriel"),
    T("Classer une copie complète du dossier déposé", N, 1),
    T("Noter le délai de réponse annoncé et inscrire la date de décision prévue", N, 3),
  ],
  analyse: [
    T("Surveiller les messages de l’organisme et répondre vite aux demandes de précisions", N, 7),
    T("Donner au client un point d’étape sur l’état de la demande", N, 14, "courriel"),
    T("Faire un suivi auprès de l’organisme si aucune nouvelle à la date prévue", N, 21, "appel"),
  ],
  acceptee: [
    T("Annoncer la décision au client et lui transmettre la lettre d’octroi", H, 0, "courriel"),
    T("Inscrire le montant accordé et le numéro de dossier dans la fiche", N, 1),
    T("Lire la lettre d’octroi ou la convention : conditions, dépenses admissibles, dates clés, rapports exigés", H, 2),
    T("Bâtir le calendrier des obligations : rapports d’étape, preuves de dépenses, versements", H, 5),
    T("Faire signer la convention ou l’entente d’aide et la retourner à l’organisme", H, 7),
    T("Expliquer au client ses obligations et la suite du processus", N, 7, "appel"),
  ],
  suivi: [
    T("Inscrire au calendrier les dates des rapports d’étape et du rapport final", H, 3),
    T("Rappeler au client de conserver ses factures et ses preuves de paiement", N, 7, "courriel"),
    T("Demander au client les preuves de dépenses pour la prochaine réclamation", N, 30, "courriel"),
    T("Préparer la demande de versement ou le rapport d’étape", N, null, "tache", "Selon l’échéancier de la convention : fixer la date de cette tâche une fois le calendrier des obligations établi."),
    T("Déposer le rapport d’étape et suivre l’arrivée du versement", N, null, "tache", "Selon l’échéancier de la convention."),
    T("Préparer et déposer le rapport final", H, null, "tache", "Selon l’échéancier de la convention."),
  ],
  terminee: [
    T("Faire le bilan final avec le client : montant reçu, résultats, points à retenir", N, 3),
    T("Remercier le client et lui demander s’il accepte de donner un témoignage", N, 7, "courriel"),
    T("Archiver le dossier complet et la correspondance", N, 7),
    T("Noter les programmes et les dates à surveiller pour une prochaine demande", N, 10),
  ],
  refusee: [
    T("Informer le client du refus et lui présenter les options : recours, nouvelle demande ou autre programme", H, 1, "courriel"),
    T("Obtenir la lettre de refus et demander les motifs à l’organisme", H, 2),
    T("Évaluer les autres programmes possibles et la prochaine date de dépôt", N, 7),
    T("Consigner les motifs du refus pour améliorer les prochaines demandes", N, 7),
  ],
};

/** Statuts après lesquels le dépôt n'a pas encore eu lieu : l'échéance d'une tâche ne dépasse pas la date limite. */
export const STATUTS_AVANT_DEPOT = ["collecte", "redaction", "revision", "prete"];

// ----- Gabarits de courriel --------------------------------------------------
// Champs de fusion : {{prenom}} {{nom}} {{entreprise}} {{programme}} {{date_limite}}
// {{delai}} {{montant}} {{numero}} {{echeance}} {{signature}}
export const GABARITS_COURRIEL_DEFAUT = [
  {
    id: "accuse",
    nom: "Accusé de réception d’une demande",
    objet: "Votre demande de financement",
    corps:
      "Bonjour {{prenom}},\n\nMerci de m’avoir écrit. J’ai bien reçu votre demande et je l’examine. Je vous reviens {{delai}} pour vous proposer un échange de 30 minutes, sans frais ni engagement, afin de comprendre votre projet et de cerner les pistes de financement les plus prometteuses.\n\nSi vous avez déjà une description de votre projet ou vos derniers états financiers, vous pouvez me les envoyer en réponse à ce courriel.\n\nCordialement,\n{{signature}}",
  },
  {
    id: "rendez-vous",
    nom: "Proposition d’un appel de découverte",
    objet: "Un appel pour parler de votre projet",
    corps:
      "Bonjour {{prenom}},\n\nJ’ai lu votre demande avec intérêt. Je vous propose un appel de 30 minutes, sans frais, pour valider l’admissibilité de votre projet et préciser vos besoins.\n\nVoici quelques moments possibles : [date et heure], [date et heure] ou [date et heure]. Dites-moi lequel vous convient, ou proposez-moi un autre moment.\n\nCordialement,\n{{signature}}",
  },
  {
    id: "pieces",
    nom: "Liste des pièces à fournir",
    objet: "Documents à nous transmettre pour {{programme}}",
    corps:
      "Bonjour {{prenom}},\n\nPour préparer votre demande au programme {{programme}}, voici les documents dont j’ai besoin :\n\n- Documents légaux : statuts, NEQ, règlements généraux ou preuve de constitution\n- États financiers les plus récents et ceux de l’exercice précédent\n- Description du projet, calendrier et résultats attendus\n- Soumissions des fournisseurs pour les dépenses importantes\n- Montage financier : mise de fonds et autres sources de financement\n- Liste des autres aides reçues ou demandées\n\nLa date limite de dépôt est le {{date_limite}}. Pour respecter ce délai, j’aimerais recevoir les documents d’ici une semaine. N’hésitez pas à m’appeler si une pièce est difficile à obtenir.\n\nCordialement,\n{{signature}}",
  },
  {
    id: "depot",
    nom: "Confirmation de dépôt",
    objet: "Votre demande {{programme}} a été déposée",
    corps:
      "Bonjour {{prenom}},\n\nBonne nouvelle : votre demande au programme {{programme}} a été déposée. Je conserve l’accusé de réception et une copie complète du dossier.\n\nL’organisme analysera la demande et pourrait nous demander des précisions. Je surveille ses messages et je vous tiens au courant dès qu’il y a du nouveau.\n\nCordialement,\n{{signature}}",
  },
  {
    id: "point",
    nom: "Point d’étape pendant l’analyse",
    objet: "Où en est votre demande {{programme}}",
    corps:
      "Bonjour {{prenom}},\n\nUn petit point d’étape sur votre demande au programme {{programme}} : elle est toujours en analyse auprès de l’organisme. Je n’ai pas de nouvelle décision à vous communiquer pour l’instant, mais je fais un suivi régulier et je vous écris dès que la situation change.\n\nCordialement,\n{{signature}}",
  },
  {
    id: "rappel-facture",
    nom: "Rappel de paiement d’une facture",
    objet: "Rappel : facture {{numero}}",
    corps:
      "Bonjour {{prenom}},\n\nUn petit rappel au sujet de la facture {{numero}} d’un montant de {{montant}}, échue le {{echeance}}. Si le paiement est déjà en route, vous pouvez ignorer ce message.\n\nMerci de votre confiance.\n\nCordialement,\n{{signature}}",
  },
  {
    id: "envoi-facture",
    nom: "Envoi d’une facture",
    objet: "Facture {{numero}}",
    corps:
      "Bonjour {{prenom}},\n\nVous trouverez ci-joint la facture {{numero}} d’un montant de {{montant}}, payable au plus tard le {{echeance}}.\n\nMerci de votre confiance.\n\nCordialement,\n{{signature}}",
  },
  {
    id: "envoi-devis",
    nom: "Envoi d’un devis",
    objet: "Devis {{numero}}",
    corps:
      "Bonjour {{prenom}},\n\nVoici, comme convenu, le devis {{numero}} d’un montant de {{montant}}, valide jusqu’au {{echeance}}.\n\nSi vous souhaitez aller de l’avant ou si vous avez des questions, répondez simplement à ce courriel : je suis disponible pour en discuter.\n\nCordialement,\n{{signature}}",
  },
];

// ----- Scripts d'appel ---------------------------------------------------------
// Texte simple : « ## Titre » ouvre une section repliable, « - » une puce. Champs de fusion :
// {{prenom}} {{nom}} {{entreprise}} {{projet}} {{mon_nom}} {{mon_entreprise}} {{mon_telephone}}
export const SCRIPTS_APPEL_DEFAUT = [
  {
    id: "suivi-demande",
    nom: "Suivi d’une demande du site",
    texte: [
      "## Ouverture",
      "Bonjour, {{prenom}} ? Ici {{mon_nom}}, d’{{mon_entreprise}}. Vous nous avez écrit par notre site au sujet de votre projet : j’ai préféré vous appeler directement. Avez-vous deux ou trois minutes ?",
      "",
      "## Comprendre le projet",
      "Votre message : « {{projet}} »",
      "- Pouvez-vous me décrire le projet en quelques mots ?",
      "- Où en êtes-vous : idée, plan d’affaires, dépenses déjà engagées ?",
      "- Quel est le budget total, et quelle part cherchez-vous à financer ?",
      "- Quand voulez-vous démarrer ? Y a-t-il une date limite à respecter ?",
      "- Avez-vous déjà fait des demandes de financement ? Auprès de qui ?",
      "",
      "## Proposer la suite",
      "Je vous propose un appel découverte de 30 minutes, sans frais ni engagement, pour valider l’admissibilité de votre projet et cerner les programmes les plus prometteurs. Quel moment vous conviendrait cette semaine ?",
      "",
      "## Si c’est la boîte vocale",
      "Bonjour {{prenom}}, ici {{mon_nom}}, d’{{mon_entreprise}}. Je vous appelle au sujet de la demande que vous nous avez envoyée par notre site. Je vous écris aussi un courriel. Vous pouvez me joindre au {{mon_telephone}}. Bonne journée !",
      "",
      "## Si la personne hésite",
      "- « Je n’ai pas le temps » : Je comprends. Serait-ce plus facile demain matin ou en fin de journée ?",
      "- « Combien ça coûte ? » : Le premier échange de 30 minutes est sans frais. Si on poursuit, je vous présente une offre claire avant tout engagement.",
      "- « Je vais regarder ça moi-même » : Très bien. Je peux vous envoyer la liste des programmes qui semblent vous convenir ; vous me direz si vous voulez de l’aide pour le dossier.",
    ].join("\n"),
  },
  {
    id: "premier-contact",
    nom: "Premier contact (prospection)",
    texte: [
      "## Ouverture",
      "Bonjour, {{prenom}} ? Je suis {{mon_nom}}, d’{{mon_entreprise}}. Nous aidons les entreprises du Québec à trouver et à obtenir des subventions, des prêts et des crédits d’impôt pour leurs projets. Est-ce que je vous appelle à un bon moment ? Ce sera très court.",
      "",
      "## Accroche",
      "- Avez-vous un projet d’investissement, d’embauche ou d’innovation dans les 12 prochains mois ?",
      "- Savez-vous quels programmes d’aide pourraient en financer une partie ?",
      "",
      "## Qualifier",
      "- Secteur d’activité et nombre d’employés ?",
      "- Type de projet : équipement, numérique, exportation, embauche, formation, innovation ?",
      "- Montant approximatif et échéancier ?",
      "- Avez-vous déjà reçu de l’aide publique pour ce projet ?",
      "",
      "## Proposer la suite",
      "Je vous propose un appel de 30 minutes, sans frais ni engagement, pour vérifier ce à quoi votre projet pourrait avoir droit. Quel moment vous conviendrait ?",
      "",
      "## Si c’est la boîte vocale",
      "Bonjour {{prenom}}, ici {{mon_nom}}, d’{{mon_entreprise}}. Nous aidons les entreprises à obtenir du financement pour leurs projets. Si le sujet vous intéresse, vous pouvez me joindre au {{mon_telephone}}. Bonne journée !",
      "",
      "## Si la personne refuse",
      "- Je comprends, merci de votre temps. Souhaitez-vous que je vous retire de notre liste d’appels ? (si oui : résultat « Ne plus appeler »)",
    ].join("\n"),
  },
];

// ----- Configuration complète ------------------------------------------------
export function configParDefaut() {
  return {
    v: 1,
    entreprise: {
      nom: "InnovAffaires",
      nom_legal: "",
      neq: "",
      no_tps: "",
      no_tvq: "",
      adresse: "461, rue des Merisiers",
      ville: "Saint-Colomban",
      province: "QC",
      code_postal: "J5K 1S6",
      telephone: "579 373-1237",
      courriel: "info@innovaffaires.com",
      site_web: "https://www.innovaffaires.com",
      responsable_vie_privee: "Sarah Leduc",
      signature: "Sarah Leduc, consultante\nInnovAffaires\n579 373-1237\ninfo@innovaffaires.com\nwww.innovaffaires.com",
    },
    taxes: { tps: 5, tvq: 9.975 },
    facturation: {
      prefixe_facture: "F-",
      prefixe_devis: "D-",
      sequences: {},
      conditions: "Payable dans les 30 jours",
      delai_echeance_jours: 30,
      validite_devis_jours: 30,
      note_facture: "Merci de votre confiance.",
    },
    honoraires: { taux_horaire: 125, diagnostic: 750, dossier: 2500 },
    delai_reponse_heures: 48,
    jours_feries_supplementaires: [],
    etapes: structuredClone(ETAPES_DEFAUT),
    statuts_dossier: structuredClone(STATUTS_DOSSIER_DEFAUT),
    sources: structuredClone(SOURCES_DEFAUT),
    etiquettes: [],
    gabarits_taches: structuredClone(GABARITS_TACHES_DEFAUT),
    gabarits_courriel: structuredClone(GABARITS_COURRIEL_DEFAUT),
    conservation: { demandes_archivees_mois: 24, pourriels_jours: 30 },
    securite: { double_facteur_obligatoire: false, duree_session_heures: 12 },
    calendrier: { jeton: "", actif: false, rendez_vous: true },
    appels: {
      essais_max: 3,
      delai_relance_jours: 2,
      delai_rappel_jours: 1,
      heure_rappel: "10:00",
      objectif_jour: 20,
      avertir_heures: true,
      heures_semaine: { debut: "09:00", fin: "21:30" },
      heures_fin_semaine: { debut: "10:00", fin: "18:00" },
      script_demande: "suivi-demande",
      script_prospection: "premier-contact",
      scripts: structuredClone(SCRIPTS_APPEL_DEFAUT),
    },
  };
}
