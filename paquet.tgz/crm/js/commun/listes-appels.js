// =============================================================================
// Listes d'appels de prospection : logique pure partagée par le serveur et
// l'interface — champs importables, devinette des colonnes d'un fichier,
// découpage des numéros de téléphone, nettoyage d'une ligne, clés de comparaison
// (doublons), libellés des états. Aucun accès au stockage ni au DOM.
// =============================================================================
import { analyserTelephone, numeroNormalise, separerNom, separerPoste } from "./appels.js";
import { validerValeur } from "./valider.js";

export const MAX_LIGNES_LISTE = 2000;
export const MAX_NOM_LISTE = 40;
export const MAX_DESCRIPTION_LISTE = 300;
export const MAX_COLONNES_EXTRA = 12;

// ----- Libellés ---------------------------------------------------------------------------------------------------------
export const STATUTS_LISTE = [
  { id: "active", libelle: "Active" },
  { id: "pausee", libelle: "En pause" },
  { id: "archivee", libelle: "Archivée" },
];
export const statutListe = (id) => STATUTS_LISTE.find((s) => s.id === id) || STATUTS_LISTE[0];

/** États d'une ligne d'une liste (calculés par le serveur). */
export const ETATS_LIGNE = [
  { id: "a_appeler", libelle: "À appeler" },
  { id: "file", libelle: "Dans la file" },
  { id: "appele", libelle: "Appelé" },
  { id: "exclu", libelle: "Exclu" },
];

export const RAISONS_EXCLU = {
  supprime: "Fiche supprimée",
  anonymise: "Fiche anonymisée",
  archive: "Fiche archivée",
  ne_pas_appeler: "Sur la liste « ne pas appeler »",
  sans_numero: "Aucun numéro de téléphone",
  introuvable: "Fiche introuvable",
};

/** Raisons pour lesquelles une ligne du fichier n'entre pas dans la liste (rapport d'importation). */
export const RAISONS_IGNOREES = {
  sans_nom: "Ni nom de personne ni nom d’entreprise",
  sans_numero: "Aucun numéro de téléphone utilisable",
  doublon_fichier: "Déjà plus haut dans le fichier",
  deja_dans_le_crm: "Déjà dans votre CRM",
  fiche_sans_numero: "Fiche existante sans numéro de téléphone",
  ne_pas_appeler: "Sur la liste « ne pas appeler »",
  fiche_inutilisable: "Fiche existante archivée",
  invalide: "Ligne que le CRM n’a pas pu enregistrer",
};

// ----- Champs importables ------------------------------------------------------------------------------------------------------
export const CHAMPS_LISTE = [
  { id: "entreprise", libelle: "Entreprise" },
  { id: "nom_complet", libelle: "Nom complet (prénom puis nom)" },
  { id: "nom_prenom", libelle: "Nom complet (nom puis prénom)" },
  { id: "prenom", libelle: "Prénom" },
  { id: "nom", libelle: "Nom de famille" },
  { id: "titre", libelle: "Fonction" },
  { id: "telephone", libelle: "Téléphone" },
  { id: "mobile", libelle: "Cellulaire" },
  { id: "telephone_entreprise", libelle: "Téléphone de l’entreprise" },
  { id: "poste", libelle: "Poste téléphonique" },
  { id: "courriel", libelle: "Courriel" },
  { id: "ville", libelle: "Ville" },
  { id: "adresse", libelle: "Adresse" },
  { id: "code_postal", libelle: "Code postal" },
  { id: "site_web", libelle: "Site Web" },
  { id: "employes", libelle: "Nombre d’employés" },
  { id: "neq", libelle: "NEQ" },
  { id: "notes", libelle: "Notes" },
];
const IDS_CHAMPS = new Set(CHAMPS_LISTE.map((c) => c.id));
export const estChampListe = (id) => IDS_CHAMPS.has(id);

// ----- Texte -------------------------------------------------------------------------------------------------------------------
const CTRL = new RegExp("[\\u0000-\\u0008\\u000b\\u000c\\u000e-\\u001f\\u007f\\u2028\\u2029]", "g");

/** Valeur d'une cellule en texte d'une ligne, sans caractères de contrôle ni espaces en double. Un nombre Excel est écrit sans « .0 ». */
export function texteCellule(v, max = 200) {
  if (v === undefined || v === null) return "";
  let s;
  if (typeof v === "number") s = Number.isFinite(v) ? String(v) : "";
  else if (typeof v === "string") s = v;
  else return "";
  s = s.replace(CTRL, "").replace(/\s+/g, " ").trim();
  if (/^\d{7,15}\.0+$/.test(s)) s = s.replace(/\.0+$/, "");
  if (/^\d(\.\d+)?e\+?\d{1,2}$/i.test(s)) {
    const n = Number(s);
    if (Number.isFinite(n) && n >= 1e6 && n < 1e15) s = String(Math.round(n));
  }
  return s.length > max ? s.slice(0, max).trim() : s;
}

/** Comme casseNom, mais deux majuscules (« JF », « MA ») sont les initiales d'un prénom composé : elles restent telles quelles. */
export const casePrenom = (s) => (/^\p{Lu}{2}$/u.test(String(s ?? "")) ? String(s) : casseNom(s));

/** « TREMBLAY » → « Tremblay », « SAINT-JÉRÔME » → « Saint-Jérôme ». Un texte déjà en casse mixte reste tel quel. */
export function casseNom(s) {
  const t = String(s ?? "");
  if (!t || t !== t.toUpperCase() || t === t.toLowerCase()) return t;
  return t.toLowerCase().replace(/(^|[\s\-'’.(])(\p{L})/gu, (_, a, b) => a + b.toUpperCase());
}

// Les accents des lettres latines (é, ç, ñ…) : seules ces marques sont retirées. Celles des autres écritures (japonais, hindi, arabe…)
// font partie des mots : les enlever ferait confondre « ガス » et « カス », ou « कमल » et « कोमल ».
const MARQUES_LATINES = /[\u0300-\u036f\u1ab0-\u1aff\u1dc0-\u1dff\u20d0-\u20ff\ufe20-\ufe2f]+/g;
// Les lettres latines que l'Unicode ne décompose pas : « Bœuf » et « Boeuf » sont le même nom.
const LIGATURES = { œ: "oe", æ: "ae", ß: "ss", ø: "o", đ: "d", ł: "l" };

/**
 * Texte comparable : sans accents, en minuscules, ponctuation réduite à un espace. Toutes les écritures comptent (grec, cyrillique,
 * chinois…) : deux noms non latins différents ne se ramènent jamais au même texte vide.
 */
export const cleTexte = (s) =>
  String(s ?? "")
    .toLowerCase()
    .replace(/[œæßøđł]/g, (c) => LIGATURES[c])
    .normalize("NFKD")
    .replace(MARQUES_LATINES, "")
    .normalize("NFC")
    .replace(/[^\p{L}\p{N}\p{M}]+/gu, " ")
    .trim();

/** Clé d'une personne : les mots de son nom et de son prénom, sans accents ni ordre (« Tremblay Jean » = « Jean Tremblay »). */
export const cleNomPersonne = (prenom, nom) => cleTexte(`${prenom || ""} ${nom || ""}`).split(" ").filter(Boolean).sort().join(" ");

/** Clé de comparaison d'un nom de liste (le texte brut en minuscules si le nom ne contient aucun caractère comparable). */
export const cleNomListe = (s) => cleTexte(s) || String(s ?? "").trim().toLowerCase();

const SUFFIXES = new Set(["inc", "incorporee", "ltee", "ltd", "limitee", "limited", "enr", "enregistree", "senc", "sencrl", "srl", "cie", "co", "corp", "corporation", "llc", "lp"]);
/** Nom d'entreprise comparable : « Gestion ABC Inc. » et « GESTION A.B.C. ltée » se rapprochent (points retirés, forme juridique ignorée). */
export function cleEntreprise(nom) {
  let mots = cleTexte(String(nom ?? "").replace(/\./g, "")).split(" ").filter(Boolean);
  while (mots.length > 1 && SUFFIXES.has(mots[mots.length - 1])) mots = mots.slice(0, -1);
  return mots.join(" ") || String(nom ?? "").trim().toLowerCase();
}

/** Les 10 derniers chiffres d'un numéro (comparaison de numéros écrits de façons différentes). */
export const cleTelephone = (chiffres) => String(chiffres || "").slice(-10);

// ----- Téléphones --------------------------------------------------------------------------------------------------------------
/**
 * Découpe une cellule qui contient un ou plusieurs numéros (« 514 555-1234 / 450 555-9876 », « 514-555-1234, poste 22 »…).
 * Retourne { numeros: ["514 555-1234", …] (sans doublon), incomplets } — incomplets : numéros sans indicatif régional (moins de 10 chiffres).
 */
export function decouperTelephones(valeur) {
  const s = texteCellule(valeur, 400);
  const sortie = { numeros: [], incomplets: 0 };
  if (!s) return sortie;
  // Un petit nombre seul est un poste : « 514 555-1234, 22 » le recolle au numéro précédent, et « poste 22 ou 23 » donne un second poste
  // du même numéro.
  const morceaux = [];
  for (const m of s.split(/\s*(?:[/;|&]|\bou\b|\bet\b|\bor\b)\s*/i)) {
    for (const p of m.split(/\s*,\s*/)) {
      if (!p) continue;
      if (/^\d{1,6}$/.test(p) && morceaux.length) {
        const precedent = morceaux[morceaux.length - 1];
        const { base, poste } = separerPoste(precedent);
        if (poste) morceaux.push(`${base} poste ${p}`);
        else morceaux[morceaux.length - 1] = `${precedent} poste ${p}`;
      } else morceaux.push(p);
    }
  }
  const vus = new Set();
  for (const m of morceaux) {
    const a = analyserTelephone(m);
    if (!a) continue;
    if (a.chiffres.length < 10 && !m.trim().startsWith("+")) {
      sortie.incomplets += 1;
      continue;
    }
    const n = numeroNormalise(m);
    if (!n) continue;
    const cle = `${cleTelephone(a.chiffres)}|${a.poste}`;
    if (vus.has(cle)) continue;
    vus.add(cle);
    sortie.numeros.push(n);
  }
  return sortie;
}

/** Les chiffres d'un numéro enregistré (« 514 555-1234 poste 22 » → « 5145551234 »). Le poste est exclu. */
export function chiffresDe(numero) {
  const a = analyserTelephone(numero);
  return a ? a.chiffres : "";
}

/** Un numéro pour le comparer à ceux de la liste « ne pas appeler » : { cle: ses 10 derniers chiffres, poste } ; null si ce n'est pas un numéro. */
export function empreinteNumero(numero) {
  const a = analyserTelephone(numero);
  return a ? { cle: cleTelephone(a.chiffres), poste: a.poste } : null;
}

// ----- Devinette des colonnes ----------------------------------------------------------------------------------------------
// Un titre de colonne démesuré est coupé : aucun vrai titre ne dépasse 200 caractères, et le calcul reste instantané.
const normEntete = (s) => cleTexte(String(s ?? "").slice(0, 200));

// L'ordre compte : la première règle qui reconnaît le titre l'emporte.
const REGLES_ENTETES = [
  ["ignorer", /\b(fax|telecopieur|telecopie)\b/],
  ["courriel", /\b(e ?mail|courriel|courrier electronique|mail)\b/],
  ["site_web", /\b(site|website|web|url|www|internet)\b/],
  ["code_postal", /\b(code postal|postal|zip|cp)\b/],
  ["employes", /\b(employes?|employees?|effectifs?|nb emp|nombre d employes)\b/],
  ["neq", /\bneq\b|numero d entreprise du quebec/],
  // « Poste » seul peut aussi être la fonction occupée : deviner() regarde alors les valeurs de la colonne.
  ["poste", /^(?:(?:n|no|num|numero) )?(?:de )?(?:poste|extension|ext|local)(?: tel| telephonique| telephone)?$|^(?:tel|telephone) (?:poste|extension|ext)$/],
  ["mobile", /\b(cell|cellulaire|mobile|portable|gsm)\b/],
  [
    "telephone_entreprise",
    /\b(tel|telephone|phone)\b.*\b(entreprise|bureau|compagnie|societe|company|office|principal|standard|general)\b|\b(entreprise|bureau|compagnie|societe|company|office|standard)\b.*\b(tel|telephone|phone)\b/,
  ],
  ["telephone", /\b(tel|telephone|phone|tel\d*)\b/],
  ["ville", /\b(ville|city|municipalite|localite)\b/],
  ["adresse", /\b(adresse|address|rue|street)\b/],
  ["titre", /\b(fonction|titre|job title|jobtitle|position|poste occupe|role|title)\b/],
  // « Nom et prénom », « Nom, Prénom », « Last name, first name » : le nom vient en premier. « Prénom et nom », « Prénom Nom »,
  // « First name last name » : le prénom en premier.
  ["nom_prenom", /\bnoms? (et |& )?prenoms?\b|\b(last name|lastname|surname|family name|nom de famille) (et |and |& )?(first name|firstname|given name|prenoms?)\b/],
  ["nom_complet", /\bprenoms? (et |& )?noms?\b|\b(first name|firstname|given name) (and |& )?(last name|lastname|surname|family name)\b/],
  ["prenom", /\b(prenom|first name|firstname|given name)\b/],
  ["nom_complet", /\b(nom complet|full name|fullname|nom du contact|nom de la personne|contact|personne contact|personne ressource|representant|responsable|interlocuteur|dirigeant|proprietaire)\b/],
  ["nom", /^(nom|nom de famille|nom famille|last name|lastname|surname|family name)$/],
  ["entreprise", /\b(entreprise|societe|compagnie|organisation|organisme|raison sociale|company|business|etablissement|employeur|firme|nom commercial|commerce)\b/],
  ["notes", /\b(notes?|commentaires?|remarques?|observations?|comments?|description)\b/],
];

const RE_COURRIEL_SIMPLE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const RE_POSTAL = /^[a-z]\d[a-z] ?\d[a-z]\d$/i;
const RE_TEL_SIMPLE = /^\+?[\d\s().-]{10,20}$/;
const RE_URL_SIMPLE = /^(https?:\/\/|www\.)\S+$|^[\w-]+(\.[\w-]+)+\/?$/i;
const RE_ENTREPRISE = /\b(inc|ltee|ltée|enr|senc|cie|corp|ltd|llc|gestion|groupe|construction|services?|solutions?|restaurant|boutique)\b|\d/i;

function parForme(valeurs) {
  const v = valeurs.map((x) => texteCellule(x, 120)).filter(Boolean);
  if (v.length < 2) return "";
  const part = (f) => v.filter((x) => (typeof f === "function" ? f(x) : f.test(x))).length / v.length;
  if (part(RE_COURRIEL_SIMPLE) >= 0.7) return "courriel";
  if (part(RE_POSTAL) >= 0.7) return "code_postal";
  if (part(RE_TEL_SIMPLE) >= 0.7) return "telephone";
  if (part((x) => RE_URL_SIMPLE.test(x) && !x.includes("@")) >= 0.7) return "site_web";
  return "";
}

/**
 * Propose un champ pour chaque colonne d'un fichier.
 *   entetes  : titres des colonnes (ou « Colonne 1 »… quand le fichier n'en a pas)
 *   lignes   : cellules (tableau de tableaux) dont les 30 premières servent d'échantillon
 * Retourne un tableau de la même longueur : l'identifiant d'un champ de CHAMPS_LISTE, « extra » (à ajouter aux notes) ou « ignorer ».
 * Un champ n'est proposé que pour une colonne; les quatre premières colonnes non reconnues vont dans les notes, les autres sont ignorées.
 */
export function deviner(entetes, lignes = []) {
  const echantillon = lignes.slice(0, 30);
  const colonne = (i) => echantillon.map((l) => l?.[i]);
  const brut = entetes.map((e) => {
    const n = normEntete(e);
    for (const [champ, re] of REGLES_ENTETES) if (re.test(n)) return champ;
    return "";
  });
  const a = (champ) => brut.includes(champ);
  // « Poste » seul : le poste téléphonique si la colonne contient de petits nombres, sinon la fonction occupée.
  entetes.forEach((e, i) => {
    if (brut[i] !== "poste" || normEntete(e) !== "poste") return;
    const v = colonne(i).map((x) => texteCellule(x, 40)).filter(Boolean);
    if (v.length && v.filter((x) => /^(?:(?:poste|p|ext|x|#)\.?\s*:?\s*)?\d{1,6}$/i.test(x)).length / v.length < 0.6) brut[i] = "titre";
  });
  // Un prénom et un « nom complet » sans colonne « Nom » (« Contact - Prénom », « Contact - Nom ») : la seconde colonne n'a que le nom de famille.
  if (a("prenom") && !a("nom") && !a("nom_prenom") && a("nom_complet")) brut[brut.indexOf("nom_complet")] = "nom";
  // « Nom » seul : le nom de famille si un prénom existe; sinon un nom complet — ou une entreprise si les valeurs y ressemblent.
  entetes.forEach((e, i) => {
    if (normEntete(e) !== "nom" || brut[i] !== "nom") return;
    if (a("prenom")) return;
    if (a("entreprise")) {
      brut[i] = "nom_complet";
      return;
    }
    const v = colonne(i).map((x) => texteCellule(x, 120)).filter(Boolean);
    const part = v.length ? v.filter((x) => RE_ENTREPRISE.test(x)).length / v.length : 0;
    brut[i] = part >= 0.4 ? "entreprise" : "nom_complet";
  });
  // Titres non reconnus : la forme des valeurs (courriels, numéros, codes postaux, adresses Web) peut les révéler.
  brut.forEach((champ, i) => {
    if (champ) return;
    const f = parForme(colonne(i));
    if (f) brut[i] = f;
  });
  const pris = new Set();
  let extras = 0;
  const suivant = { telephone: ["mobile", "telephone_entreprise"], mobile: ["telephone_entreprise"], telephone_entreprise: ["mobile"] };
  const versLesNotes = () => (++extras <= 4 ? "extra" : "ignorer");
  return brut.map((champ) => {
    if (champ === "ignorer") return "ignorer";
    if (!champ) return versLesNotes();
    if (!pris.has(champ)) {
      pris.add(champ);
      return champ;
    }
    for (const alt of suivant[champ] || []) {
      if (!pris.has(alt)) {
        pris.add(alt);
        return alt;
      }
    }
    return versLesNotes();
  });
}

// ----- Nom complet ---------------------------------------------------------------------------------------------------------------
const PARTICULES = new Set(["de", "du", "des", "d", "le", "la", "les", "van", "von", "di", "da", "del", "della", "st", "ste", "saint", "sainte", "mc", "mac"]);
/** Un mot en majuscules d'au moins 3 lettres (« TREMBLAY ») : « JF » ou « MA » sont des initiales de prénom, pas un nom de famille. */
const enMajuscules = (mot) => mot === mot.toUpperCase() && (mot.match(/\p{Lu}/gu) || []).length >= 3;
const particuleMajuscule = (mot) => mot === mot.toUpperCase() && PARTICULES.has(cleTexte(mot));
const initiale = (mot) => /^\p{L}\.?$/u.test(mot);
/** Le mot réduit à ses lettres et chiffres : « M.Sc. » → « msc ». */
const jeton = (mot) => cleTexte(mot).replace(/ /g, "");

const TITRES = new Set(["mr", "mrs", "ms", "mme", "mlle", "mmes", "monsieur", "madame", "mademoiselle", "dr", "dre", "docteur", "docteure", "pr", "prof", "professeur", "professeure", "me", "maitre"]);
const DIPLOMES = new Set([
  "cpa", "ca", "cma", "cga", "cfa", "cfp", "cim", "mba", "msc", "ma", "phd", "md", "dmd", "dds", "rn", "np", "pmp", "crha", "adma", "arch", "ing", "eng",
  "avocat", "avocate", "notaire", "esq", "ll", "llb", "lld", "bsc", "jr", "sr",
]);
// Ceux qu'on retire même sans virgule (« Jean Tremblay CPA ») : aucun n'est un nom ou un prénom.
const DIPLOMES_SURS = new Set(["cpa", "cma", "cga", "cfa", "cfp", "mba", "phd", "pmp", "crha", "adma", "avocat", "avocate", "notaire", "esq"]);

/** Retire les titres (« Dr », « Mme », « Me ») devant un nom et les diplômes ou ordres professionnels (« , CPA », « , ing. ») qui le suivent. */
function enleverTitres(texte) {
  let s = texte;
  if (s.includes(",")) {
    // « Jean Tremblay, CPA » : le nom d'abord, puis ses titres. « Tremblay, Jean » (nom, prénom) n'est pas touché.
    const parties = s.split(",").map((x) => x.trim());
    const seulementDesDiplomes = (x) => x.split(" ").every((m) => !jeton(m) || DIPLOMES.has(jeton(m)));
    while (parties.length > 2 || (parties.length === 2 && parties[0].includes(" "))) {
      if (!seulementDesDiplomes(parties[parties.length - 1])) break;
      parties.pop();
    }
    s = parties.join(", ");
  }
  const mots = s.split(" ").filter(Boolean);
  while (mots.length > 1 && TITRES.has(jeton(mots[0]))) mots.shift();
  if (mots.length > 2 && jeton(mots[0]) === "m") mots.shift(); // « M. Jean Tremblay » (mais « M. Tremblay » : l'initiale d'un prénom)
  while (mots.length > 2 && DIPLOMES_SURS.has(jeton(mots[mots.length - 1]))) mots.pop();
  while (mots.length > 2 && mots[mots.length - 1].endsWith(".") && DIPLOMES.has(jeton(mots[mots.length - 1]))) mots.pop();
  return mots.join(" ");
}

/**
 * Sépare un nom complet écrit dans une seule cellule.
 *   « Marie Tremblay » → prénom Marie, nom Tremblay (par défaut, le prénom vient en premier; « Jean M. Tremblay » garde l'initiale au prénom)
 *   « Tremblay, Marie », « TREMBLAY Marie » et « Marie TREMBLAY » → prénom Marie, nom Tremblay (la virgule, ou un nom en majuscules)
 *   « Dr Jean Tremblay, CPA » → les titres sont retirés; « JF Tremblay » : JF est un prénom (deux lettres majuscules = des initiales)
 *   nomDabord : « Tremblay Marie » (colonne « Nom et prénom ») → prénom Marie, nom Tremblay; les particules (de, du, la…) restent avec le nom
 * Retourne { prenom?, nom? }.
 */
export function separerNomListe(complet, { nomDabord = false } = {}) {
  const s = enleverTitres(String(complet ?? "").replace(/\s+/g, " ").trim());
  if (!s) return {};
  if (s.includes(",")) return separerNom(s);
  const mots = s.split(" ");
  if (mots.length === 1) return { nom: mots[0] };
  // Un nom de famille en majuscules en tête de cellule (« TREMBLAY Jean », « DE GRANDPRÉ Jean »).
  let i = 0;
  while (i < mots.length && (enMajuscules(mots[i]) || particuleMajuscule(mots[i]))) i += 1;
  while (i > 0 && !enMajuscules(mots[i - 1])) i -= 1;
  if (i > 0 && i < mots.length) return { prenom: mots.slice(i).join(" "), nom: mots.slice(0, i).join(" ") };
  // … ou en fin de cellule (« Marie Anne TREMBLAY », « Jean DE LA FONTAINE ») : la casse en dit plus que l'ordre attendu des colonnes.
  let k = mots.length;
  while (k > 0 && enMajuscules(mots[k - 1])) k -= 1;
  if (k > 0 && k < mots.length) {
    while (k > 1 && particuleMajuscule(mots[k - 1])) k -= 1;
    return { prenom: mots.slice(0, k).join(" "), nom: mots.slice(k).join(" ") };
  }
  if (!nomDabord) {
    // Les initiales qui suivent le prénom (« Jean M. Tremblay ») ne font pas partie du nom de famille.
    let j = 1;
    while (j < mots.length - 1 && initiale(mots[j])) j += 1;
    return { prenom: mots.slice(0, j).join(" "), nom: mots.slice(j).join(" ") };
  }
  let j = 0;
  while (j < mots.length - 1 && PARTICULES.has(cleTexte(mots[j]))) j += 1;
  j += 1; // le premier mot qui n'est pas une particule appartient au nom de famille
  return { prenom: mots.slice(j).join(" ") || undefined, nom: mots.slice(0, j).join(" ") };
}

// ----- Nettoyage d'une ligne --------------------------------------------------------------------------------------------------
export const MAX_NOTES = 5000;

function courrielDe(v) {
  const s = texteCellule(v, 300);
  if (!s) return { valeur: "", retire: false };
  for (const morceau of s.split(/[\s;,]+/)) {
    if (!morceau) continue;
    const r = validerValeur({ type: "courriel" }, morceau.replace(/^mailto:/i, ""));
    if (!r.erreur) return { valeur: r.valeur, retire: false };
  }
  return { valeur: "", retire: true };
}

function siteDe(v) {
  const s = texteCellule(v, 300);
  if (!s) return { valeur: "", retire: false };
  const r = validerValeur({ type: "url", max: 300 }, s);
  return r.erreur ? { valeur: "", retire: true } : { valeur: r.valeur, retire: false };
}

function neqDe(v) {
  const s = texteCellule(v, 40).replace(/[\s-]/g, "");
  if (!s) return { valeur: "", retire: false };
  return /^\d{10}$/.test(s) ? { valeur: s, retire: false } : { valeur: "", retire: true };
}

function employesDe(v) {
  const s = texteCellule(v, 60);
  if (!s) return { valeur: undefined, texte: "" };
  const m = /^(\d{1,6})(?:[.,]0+)?\s*(?:employ[ée]?e?s?)?$/i.exec(s);
  if (m && +m[1] <= 100000) return { valeur: +m[1], texte: "" };
  return { valeur: undefined, texte: s };
}

/**
 * Nettoie une ligne du fichier (déjà associée à des champs : voir CHAMPS_LISTE; `extras` : [{ etiquette, valeur }]).
 * Retourne { ok: true, ligne, type: "personne" | "entreprise", contact, entreprise, numeros, retires } ou
 * { ok: false, ligne, raison: "sans_nom" | "sans_numero", detail? }.
 *   contact    : { prenom, nom, titre, courriel, telephone, mobile, ville, notes } (type « personne »)
 *   entreprise : { nom, telephone, adresse, ville, code_postal, site_web, employes, neq, notes } ou null
 *   numeros    : chiffres (10 derniers) des numéros propres à la ligne, pour repérer les doublons
 *   retires    : { courriel, site_web, neq } — valeurs invalides retirées de la ligne (compte pour le rapport)
 */
export function nettoyerLigne(brut, { ligne = 0 } = {}) {
  const b = brut && typeof brut === "object" ? brut : {};
  const t = (k, max = 200) => texteCellule(b[k], max);
  let prenom = casePrenom(t("prenom", 80));
  let nom = casseNom(t("nom", 80));
  const complet = t("nom_complet", 160);
  const inverse = t("nom_prenom", 160);
  if ((complet || inverse) && !prenom && !nom) {
    const s = complet ? separerNomListe(complet) : separerNomListe(inverse, { nomDabord: true });
    prenom = casePrenom(s.prenom || "");
    nom = casseNom(s.nom || "");
  }
  const nomEntreprise = t("entreprise", 160);
  const courriel = courrielDe(b.courriel);
  const retires = { courriel: courriel.retire, site_web: false, neq: false };

  const tel = decouperTelephones(b.telephone);
  const mob = decouperTelephones(b.mobile);
  const telEnt = decouperTelephones(b.telephone_entreprise);
  const incomplets = tel.incomplets + mob.incomplets + telEnt.incomplets;
  // Colonne « Poste » : le poste se rattache au numéro de bureau de la ligne (jamais à un cellulaire).
  const textePoste = texteCellule(b.poste, 40);
  const poste = (/^\D*(\d{1,6})(?!\d)/.exec(textePoste) || [])[1] || "";
  const avecPoste = (n) => (poste && n && !analyserTelephone(n)?.poste ? `${n} poste ${poste}` : n);

  const personne = !!(prenom || nom || (!nomEntreprise && courriel.valeur));
  if (!personne && !nomEntreprise) return { ok: false, ligne, raison: "sans_nom" };

  const notes = [];
  const ajouterNote = (s) => {
    if (s) notes.push(s);
  };
  const site = siteDe(b.site_web);
  const neq = neqDe(b.neq);
  retires.site_web = site.retire;
  retires.neq = neq.retire;
  const emp = employesDe(b.employes);
  const ville = casseNom(t("ville", 80));
  const adresse = t("adresse", 200);
  const codePostal = t("code_postal", 10);

  let contact = null;
  let entreprise = null;
  let numeros = [];
  const autresNumeros = [];

  if (personne) {
    // Le premier numéro de la colonne « Téléphone » est la ligne directe; le second va au cellulaire s'il est libre.
    const propres = [...tel.numeros, ...mob.numeros];
    let telephone = tel.numeros[0] || "";
    let mobile = mob.numeros[0] || "";
    const reste = [...tel.numeros.slice(1), ...mob.numeros.slice(mob.numeros[0] ? 1 : 0)];
    if (!mobile && reste.length) mobile = reste.shift();
    const deLEntreprise = [...telEnt.numeros];
    // Sans entreprise ni numéro propre, le numéro « de bureau » (ou « principal ») est celui de la personne : il n'y a pas d'autre fiche où le mettre.
    if (!nomEntreprise && !propres.length && deLEntreprise.length) telephone = deLEntreprise.shift();
    for (const r of reste) autresNumeros.push(r);
    let telephoneEntreprise = deLEntreprise[0] || "";
    for (const r of deLEntreprise.slice(1)) autresNumeros.push(r);
    if (!telephone && !mobile && !telephoneEntreprise) {
      return { ok: false, ligne, raison: "sans_numero", detail: incomplets ? "Numéro sans indicatif régional" : "" };
    }
    if (telephone) telephone = avecPoste(telephone);
    else if (telephoneEntreprise) telephoneEntreprise = avecPoste(telephoneEntreprise);
    else if (textePoste) ajouterNote(`Poste : ${textePoste}`);
    numeros = [telephone, mobile].filter(Boolean).map((n) => cleTelephone(chiffresDe(n)));
    contact = { prenom, nom, titre: t("titre", 120), courriel: courriel.valeur, telephone, mobile, ville, notes: "" };
    if (nomEntreprise) {
      entreprise = { nom: nomEntreprise, telephone: telephoneEntreprise, adresse, ville, code_postal: codePostal, site_web: site.valeur, employes: emp.valeur, neq: neq.valeur, notes: "" };
      if (emp.texte) ajouterNote(`Employés : ${emp.texte}`);
    } else {
      // Sans entreprise, ces renseignements n'ont pas de fiche où aller : ils se retrouvent dans les notes de la personne.
      if (telephoneEntreprise) autresNumeros.unshift(telephoneEntreprise);
      if (adresse || codePostal) ajouterNote(`Adresse : ${[adresse, codePostal].filter(Boolean).join(", ")}`);
      if (site.valeur) ajouterNote(`Site Web : ${site.valeur}`);
      if (neq.valeur) ajouterNote(`NEQ : ${neq.valeur}`);
      if (emp.valeur !== undefined) ajouterNote(`Employés : ${emp.valeur}`);
      else if (emp.texte) ajouterNote(`Employés : ${emp.texte}`);
    }
  } else {
    // Ligne d'entreprise seule : le numéro de la colonne « Téléphone » ou « Cellulaire » est celui de l'entreprise.
    const tous = [...telEnt.numeros, ...tel.numeros, ...mob.numeros];
    const uniques = [];
    const vus = new Set();
    for (const n of tous) {
      const k = chiffresDe(n);
      if (!vus.has(k)) {
        vus.add(k);
        uniques.push(n);
      }
    }
    if (!uniques.length) return { ok: false, ligne, raison: "sans_numero", detail: incomplets ? "Numéro sans indicatif régional" : "" };
    for (const r of uniques.slice(1)) autresNumeros.push(r);
    numeros = [cleTelephone(chiffresDe(uniques[0]))];
    entreprise = { nom: nomEntreprise, telephone: avecPoste(uniques[0]), adresse, ville, code_postal: codePostal, site_web: site.valeur, employes: emp.valeur, neq: neq.valeur, notes: "" };
    if (emp.texte) ajouterNote(`Employés : ${emp.texte}`);
  }

  if (!contact && courriel.valeur) ajouterNote(`Courriel : ${courriel.valeur}`);
  ajouterNote(t("notes", 2000));
  if (autresNumeros.length) ajouterNote(`Autres numéros : ${autresNumeros.join(" ; ")}`);
  const extras = Array.isArray(b.extras) ? b.extras.slice(0, MAX_COLONNES_EXTRA) : [];
  for (const x of extras) {
    const valeur = texteCellule(x?.valeur, 300);
    if (!valeur) continue;
    const etiquette = texteCellule(x?.etiquette, 60);
    ajouterNote(etiquette ? `${etiquette} : ${valeur}` : valeur);
  }
  const texteNotes = notes.join("\n").slice(0, MAX_NOTES);
  if (contact) contact.notes = texteNotes;
  else entreprise.notes = texteNotes;

  return { ok: true, ligne, type: contact ? "personne" : "entreprise", contact, entreprise, numeros, retires, incomplets };
}

// ----- Clés de comparaison (doublons) ---------------------------------------------------------------------------------------
/**
 * Clés qui désignent « la même personne » (ou « la même entreprise ») : deux lignes qui en partagent une sont des doublons.
 * Les clés sont préfixées pour ne pas se confondre entre elles. `pourCrm` : clés servant à retrouver une fiche déjà dans le CRM
 * (une entreprise y est reconnue par son seul nom : deux établissements de même nom y sont une seule entreprise).
 */
export function clesDe(l, { pourCrm = false } = {}) {
  const cles = [];
  if (l.type === "personne") {
    const c = l.contact;
    if (c.courriel) cles.push(`m:${c.courriel}`);
    const nomPersonne = cleNomPersonne(c.prenom, c.nom);
    if (nomPersonne) {
      cles.push(`p:${nomPersonne}|${l.entreprise ? cleEntreprise(l.entreprise.nom) : `#${l.numeros[0] || ""}`}`);
      // Une fiche du CRM sans entreprise se reconnaît à son nom et à l'un de ses numéros.
      if (pourCrm) for (const n of l.numeros) cles.push(`p:${nomPersonne}|#${n}`);
    }
  } else {
    const e = l.entreprise;
    if (e.neq) cles.push(`q:${e.neq}`);
    cles.push(pourCrm ? `n:${cleEntreprise(e.nom)}` : `e:${cleEntreprise(e.nom)}|${l.numeros[0] || ""}`);
  }
  return cles;
}
