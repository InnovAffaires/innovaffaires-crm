// Dates du Québec : fuseau America/Toronto, jours fériés, jours ouvrables.
// Les dates sans heure sont des chaînes « AAAA-MM-JJ ». Les instants sont des
// millisecondes (nombre) ou des chaînes ISO UTC.

export const FUSEAU = "America/Toronto";

const RE_DATE = /^(\d{4})-(\d{2})-(\d{2})$/;

export function estDateValide(s) {
  if (typeof s !== "string") return false;
  const m = RE_DATE.exec(s);
  if (!m) return false;
  const [a, mo, j] = [+m[1], +m[2], +m[3]];
  if (mo < 1 || mo > 12 || j < 1) return false;
  const d = new Date(Date.UTC(a, mo - 1, j));
  return d.getUTCFullYear() === a && d.getUTCMonth() === mo - 1 && d.getUTCDate() === j;
}

const utc = (s) => {
  const m = RE_DATE.exec(s);
  return Date.UTC(+m[1], +m[2] - 1, +m[3]);
};
const enChaine = (ms) => new Date(ms).toISOString().slice(0, 10);

/** Date du jour (ou de l'instant `ms`) à Toronto. */
export function aujourdhui(ms = Date.now()) {
  return new Intl.DateTimeFormat("en-CA", { timeZone: FUSEAU, year: "numeric", month: "2-digit", day: "2-digit" }).format(ms);
}

export const ajouterJours = (s, n) => enChaine(utc(s) + n * 86400000);
export const differenceJours = (a, b) => Math.round((utc(b) - utc(a)) / 86400000);
/** 0 = dimanche … 6 = samedi */
export const jourSemaine = (s) => new Date(utc(s)).getUTCDay();
/** Lundi de la semaine qui contient la date. */
export const debutSemaine = (s) => ajouterJours(s, -((jourSemaine(s) + 6) % 7));
export const debutMois = (s) => `${s.slice(0, 7)}-01`;
export function ajouterMois(s, n) {
  const a = +s.slice(0, 4);
  const m = +s.slice(5, 7) - 1 + n;
  const d = new Date(Date.UTC(a, m, 1));
  return enChaine(d.getTime());
}
export function finMois(s) {
  return ajouterJours(ajouterMois(debutMois(s), 1), -1);
}

// ----- Jours fériés du Québec ------------------------------------------------
/** Dimanche de Pâques (algorithme de Meeus/Jones/Butcher). Retourne « AAAA-MM-JJ ». */
export function paques(annee) {
  const a = annee % 19;
  const b = Math.floor(annee / 100);
  const c = annee % 100;
  const d = Math.floor(b / 4);
  const e = b % 4;
  const f = Math.floor((b + 8) / 25);
  const g = Math.floor((b - f + 1) / 3);
  const h = (19 * a + b - d - g + 15) % 30;
  const i = Math.floor(c / 4);
  const k = c % 4;
  const l = (32 + 2 * e + 2 * i - h - k) % 7;
  const m = Math.floor((a + 11 * h + 22 * l) / 451);
  const mois = Math.floor((h + l - 7 * m + 114) / 31);
  const jour = ((h + l - 7 * m + 114) % 31) + 1;
  return `${annee}-${String(mois).padStart(2, "0")}-${String(jour).padStart(2, "0")}`;
}

/** n-ième (1, 2…) lundi du mois, ou lundi qui précède une date. */
function lundiAvant(s) {
  // dernier lundi strictement avant s
  let d = ajouterJours(s, -1);
  while (jourSemaine(d) !== 1) d = ajouterJours(d, -1);
  return d;
}
function nieLundi(annee, mois, n) {
  let d = `${annee}-${String(mois).padStart(2, "0")}-01`;
  while (jourSemaine(d) !== 1) d = ajouterJours(d, 1);
  return ajouterJours(d, 7 * (n - 1));
}

/**
 * Jours fériés au Québec pour une année : jour de l'An, Vendredi saint,
 * Journée nationale des patriotes, Fête nationale, Fête du Canada, Fête du
 * Travail, Action de grâce, Noël. Retourne un tableau de « AAAA-MM-JJ ».
 */
export function joursFeriesQc(annee) {
  const canada = `${annee}-07-01`;
  return [
    `${annee}-01-01`,
    ajouterJours(paques(annee), -2),
    lundiAvant(`${annee}-05-25`),
    `${annee}-06-24`,
    jourSemaine(canada) === 0 ? `${annee}-07-02` : canada,
    nieLundi(annee, 9, 1),
    nieLundi(annee, 10, 2),
    `${annee}-12-25`,
  ];
}

/** Ensemble des jours fériés pour les années de `debut` à `fin` (incluses). */
export function ensembleFeries(anneeDebut, anneeFin, supplementaires = []) {
  const ens = new Set(supplementaires);
  for (let a = anneeDebut; a <= anneeFin; a++) for (const j of joursFeriesQc(a)) ens.add(j);
  return ens;
}

export const estOuvrable = (s, feries = new Set()) => {
  const j = jourSemaine(s);
  return j !== 0 && j !== 6 && !feries.has(s);
};

// ----- Heure locale (Toronto) ------------------------------------------------
function decalageMinutes(ms) {
  const p = new Intl.DateTimeFormat("en-US", {
    timeZone: FUSEAU, hourCycle: "h23", year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit",
  }).formatToParts(new Date(ms));
  const o = {};
  for (const x of p) o[x.type] = x.value;
  const commeUtc = Date.UTC(+o.year, +o.month - 1, +o.day, +o.hour, +o.minute, +o.second);
  return (commeUtc - Math.floor(ms / 1000) * 1000) / 60000;
}

/** Instant (ms) correspondant à `heure` (« HH:MM », 00:00 par défaut) à Toronto le `date`. */
export function instantLocal(date, heure = "00:00") {
  const [h, mi] = heure.split(":").map(Number);
  const ref = utc(date) + (h * 60 + mi) * 60000;
  let ms = ref - decalageMinutes(ref) * 60000;
  const off2 = decalageMinutes(ms);
  const off1 = decalageMinutes(ref);
  if (off1 !== off2) ms = ref - off2 * 60000;
  return ms;
}

/** { date: 'AAAA-MM-JJ', heure: 'HH:MM' } à Toronto pour un instant. */
export function partiesLocales(ms) {
  const date = aujourdhui(ms);
  const p = new Intl.DateTimeFormat("en-GB", { timeZone: FUSEAU, hourCycle: "h23", hour: "2-digit", minute: "2-digit" }).format(ms);
  return { date, heure: p };
}

// ----- Délai en heures ouvrables --------------------------------------------
// « 48 heures ouvrables » : on ne compte que les heures des jours ouvrables
// (lundi au vendredi, hors jours fériés). Une demande reçue le vendredi à 16 h
// est donc due le mardi à 16 h.
function feriesPourPlage(debutMs, finMs, sup) {
  const a0 = +aujourdhui(debutMs).slice(0, 4);
  const a1 = +aujourdhui(finMs).slice(0, 4) + 1;
  return ensembleFeries(a0, a1, sup);
}

/** Heures ouvrables écoulées entre deux instants (peut être décimal). */
export function heuresOuvrablesEcoulees(debutMs, finMs, supplementaires = []) {
  if (finMs <= debutMs) return 0;
  const feries = feriesPourPlage(debutMs, finMs, supplementaires);
  let jour = aujourdhui(debutMs);
  const dernier = aujourdhui(finMs);
  let total = 0;
  for (let garde = 0; garde < 4000 && jour <= dernier; garde++) {
    if (estOuvrable(jour, feries)) {
      const a = Math.max(debutMs, instantLocal(jour));
      const b = Math.min(finMs, instantLocal(ajouterJours(jour, 1)));
      if (b > a) total += (b - a) / 3600000;
    }
    jour = ajouterJours(jour, 1);
  }
  return total;
}

/** Instant où `heures` heures ouvrables se seront écoulées depuis `debutMs`. */
export function echeanceOuvrable(debutMs, heures, supplementaires = []) {
  const feries = feriesPourPlage(debutMs, debutMs + (heures / 24 + 30) * 86400000, supplementaires);
  let restant = heures * 3600000;
  let jour = aujourdhui(debutMs);
  for (let garde = 0; garde < 4000; garde++) {
    if (estOuvrable(jour, feries)) {
      const a = Math.max(debutMs, instantLocal(jour));
      const b = instantLocal(ajouterJours(jour, 1));
      if (b > a) {
        if (b - a >= restant) return a + restant;
        restant -= b - a;
      }
    }
    jour = ajouterJours(jour, 1);
  }
  return debutMs + heures * 3600000;
}
