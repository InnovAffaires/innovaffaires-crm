// Identifiants et jetons. Utilise seulement WebCrypto : fonctionne dans le
// navigateur et dans les fonctions Netlify.

// Alphabet de Crockford en minuscules (sans i, l, o, u) : 32 caractères.
const ALPHABET = "0123456789abcdefghjkmnpqrstvwxyz";

/** Identifiant de fiche : 12 caractères (60 bits aléatoires). */
export function nouvelId() {
  const o = new Uint8Array(12);
  crypto.getRandomValues(o);
  let s = "";
  for (const b of o) s += ALPHABET[b & 31];
  return s;
}

export const ID_VALIDE = /^[0-9a-hjkmnp-tv-z]{12}$/;
export const estId = (s) => typeof s === "string" && ID_VALIDE.test(s);

/** Jeton aléatoire en base64url (32 octets par défaut = 256 bits). */
export function jetonAleatoire(octets = 32) {
  const o = new Uint8Array(octets);
  crypto.getRandomValues(o);
  let bin = "";
  for (const b of o) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

/** Code lisible à saisir à la main, par groupes : xxxx-xxxx-xxxx-xxxx. */
export function codeLisible(groupes = 4, taille = 4) {
  // Sans les caractères ambigus (0/o, 1/l/i/u) : 30 symboles, ~4,9 bits chacun.
  // Tirage par rejet : aucun symbole n'est favorisé.
  const sym = "23456789abcdefghjkmnpqrstvwxyz";
  const limite = 256 - (256 % sym.length); // 240
  const car = [];
  while (car.length < groupes * taille) {
    const o = new Uint8Array(64);
    crypto.getRandomValues(o);
    for (const b of o) if (b < limite && car.length < groupes * taille) car.push(sym[b % sym.length]);
  }
  const out = [];
  for (let g = 0; g < groupes; g++) out.push(car.slice(g * taille, (g + 1) * taille).join(""));
  return out.join("-");
}
