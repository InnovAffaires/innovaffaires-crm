// =============================================================================
// Calculs des rapports. Tout part des fiches déjà chargées (demandes, affaires,
// dossiers, factures) et d'une période ; aucun accès au DOM : l'écran des rapports
// dessine, ce module compte. Les définitions ci-dessous sont celles que l'écran
// annonce en toutes lettres, pour que chaque chiffre puisse être vérifié à la main.
//
//   demande reçue   demande du site datée de la période, pourriels exclus
//   convertie       demande dont le statut est « Convertie »
//   affaire gagnée  affaire à une étape de type « gagnée », fermée pendant la période
//   affaire perdue  affaire à une étape de type « perdue », fermée pendant la période
//   dossier accepté dossier « accepté », ou « terminé » avec un montant accordé,
//                   dont la décision est datée de la période
//   facturé         factures émises (ni brouillon ni annulées), à leur date d'émission
//   encaissé        paiements reçus pendant la période sur toute facture émise
//   Les montants facturés et encaissés incluent les taxes (même base, donc comparables).
// =============================================================================
import { aujourdhui, ajouterJours, ajouterMois, debutMois, differenceJours, estDateValide } from "./dates.js";
import { calculerTotaux, enCents, enDollars, etatFacture } from "./calculs.js";
import { RAISONS_PERTE } from "./schema.js";

export const PERIODES = [
  { id: "6m", libelle: "6 derniers mois" },
  { id: "12m", libelle: "12 derniers mois" },
  { id: "annee", libelle: "Depuis janvier" },
  { id: "derniere", libelle: "Année dernière" },
];
export const PERIODE_DEFAUT = "12m";

/** Nombre maximal de provenances affichées ; le reste est regroupé. */
export const MAX_PROVENANCES = 6;

// ----- Période ---------------------------------------------------------------------------------------------------
/**
 * La période demandée, à partir de la date du jour (« AAAA-MM-JJ »).
 * `mois` : les mois couverts (« AAAA-MM »), du premier au dernier, un par colonne des graphiques.
 * `precedente` : de quoi comparer. Pour une fenêtre mobile (6 ou 12 mois), la période de même durée en jours
 * qui la précède ; pour « Depuis janvier », la même portion de l'année précédente ; pour « Année dernière »,
 * l'année d'avant.
 */
export function definirPeriode(id, ref = aujourdhui()) {
  const choix = PERIODES.find((p) => p.id === id) || PERIODES.find((p) => p.id === PERIODE_DEFAUT);
  const an = +ref.slice(0, 4);
  let debut;
  let fin;
  let precedente;
  switch (choix.id) {
    case "6m":
    case "12m": {
      debut = ajouterMois(debutMois(ref), choix.id === "6m" ? -5 : -11);
      fin = ref;
      const jours = differenceJours(debut, fin) + 1;
      precedente = { debut: ajouterJours(debut, -jours), fin: ajouterJours(debut, -1) };
      break;
    }
    case "annee": {
      debut = `${an}-01-01`;
      fin = ref;
      const memeJour = `${an - 1}-${ref.slice(5)}`;
      precedente = { debut: `${an - 1}-01-01`, fin: estDateValide(memeJour) ? memeJour : `${an - 1}-02-28` };
      break;
    }
    default:
      debut = `${an - 1}-01-01`;
      fin = `${an - 1}-12-31`;
      precedente = { debut: `${an - 2}-01-01`, fin: `${an - 2}-12-31` };
  }
  const mois = [];
  for (let m = debutMois(debut); m <= fin; m = ajouterMois(m, 1)) mois.push(m.slice(0, 7));
  return { id: choix.id, libelle: choix.libelle, debut, fin, mois, precedente };
}

const dansPeriode = (date, p) => !!date && date >= p.debut && date <= p.fin;

/** Date locale (Toronto) d'un horodatage ISO, ou null s'il est absent ou illisible. */
function dateLocale(iso) {
  const ms = Date.parse(iso);
  return Number.isFinite(ms) ? aujourdhui(ms) : null;
}

const somme = (liste, f) => enDollars(liste.reduce((n, x) => n + enCents(f(x)), 0));
const part = (n, total) => (total > 0 ? n / total : null);

// ----- Calcul ----------------------------------------------------------------------------------------------------
/**
 * donnees : { demandes, affaires, dossiers, factures } (tableaux de fiches)
 * config  : { etapes, statuts_dossier, sources }
 */
export function calculerRapports(donnees, config, periodeId = PERIODE_DEFAUT, ref = aujourdhui()) {
  const p = definirPeriode(periodeId, ref);
  const vivantes = (liste) => (liste || []).filter((f) => !f.supprime);
  const demandes = vivantes(donnees.demandes).filter((d) => d.statut !== "pourriel");
  const affaires = vivantes(donnees.affaires);
  const dossiers = vivantes(donnees.dossiers);
  const factures = vivantes(donnees.factures).filter((f) => f.type !== "devis" && f.statut !== "brouillon" && f.statut !== "annulee");
  const etapes = new Map((config.etapes || []).map((e) => [e.id, e]));
  const statuts = new Map((config.statuts_dossier || []).map((s) => [s.id, s]));
  const sources = new Map((config.sources || []).map((s) => [s.id, s.libelle]));

  // --- Demandes
  const dateDemande = (d) => dateLocale(d.recu || d.cree);
  const demandesDe = (per) => demandes.filter((d) => dansPeriode(dateDemande(d), per));
  const demandesMois = new Map(p.mois.map((m) => [m, { cle: m, total: 0, converties: 0 }]));
  for (const d of demandesDe(p)) {
    const ligne = demandesMois.get(dateDemande(d).slice(0, 7));
    ligne.total++;
    if (d.statut === "converti") ligne.converties++;
  }
  const dem = demandesDe(p);
  const demandesTuile = { valeur: dem.length, converties: dem.filter((d) => d.statut === "converti").length, precedente: demandesDe(p.precedente).length };

  // --- Affaires fermées pendant la période
  // Une étape qui n'existe plus dans les réglages ne compte ni comme ouverte, ni comme gagnée, ni comme perdue.
  const typeEtape = (a) => etapes.get(a.etape)?.type || null;
  const fermeeLe = (a) => a.fermee_le || a.etape_depuis || null;
  const fermees = (per, type) => affaires.filter((a) => typeEtape(a) === type && dansPeriode(fermeeLe(a), per));
  const gagnees = fermees(p, "gagnee");
  const perdues = fermees(p, "perdue");
  const gagneesAvant = fermees(p.precedente, "gagnee");
  const affairesTuile = {
    gagnees: gagnees.length,
    valeur: somme(gagnees, (a) => a.valeur),
    perdues: perdues.length,
    tauxReussite: part(gagnees.length, gagnees.length + perdues.length),
    precedente: { gagnees: gagneesAvant.length, valeur: somme(gagneesAvant, (a) => a.valeur) },
  };

  // --- Provenance : affaires ouvertes pendant la période, selon l'origine du client
  const parSource = new Map();
  for (const a of affaires) {
    if (!dansPeriode(dateLocale(a.cree), p)) continue;
    const id = a.source && sources.has(a.source) ? a.source : "";
    const ligne = parSource.get(id) || { id, libelle: id ? sources.get(id) : "Non précisée", total: 0, gagnees: 0 };
    ligne.total++;
    if (typeEtape(a) === "gagnee") ligne.gagnees++;
    parSource.set(id, ligne);
  }
  let provenance = [...parSource.values()].sort((a, b) => b.total - a.total || a.libelle.localeCompare(b.libelle, "fr-CA"));
  if (provenance.length > MAX_PROVENANCES) {
    const reste = provenance.slice(MAX_PROVENANCES - 1);
    provenance = provenance.slice(0, MAX_PROVENANCES - 1);
    provenance.push({ id: "_autres", libelle: "Autres provenances", total: reste.reduce((n, x) => n + x.total, 0), gagnees: reste.reduce((n, x) => n + x.gagnees, 0), regroupe: reste.length });
  }

  // --- Raisons de perte
  const libellesPerte = new Map(RAISONS_PERTE.map((r) => [r.id, r.libelle]));
  const parRaison = new Map();
  for (const a of perdues) {
    const id = libellesPerte.has(a.raison_perte) ? a.raison_perte : "";
    const ligne = parRaison.get(id) || { id, libelle: id ? libellesPerte.get(id) : "Non précisée", total: 0 };
    ligne.total++;
    parRaison.set(id, ligne);
  }
  const raisonsPerte = [...parRaison.values()].sort((a, b) => b.total - a.total || a.libelle.localeCompare(b.libelle, "fr-CA"));

  // --- Dossiers de financement décidés pendant la période
  const typeStatut = (d) => statuts.get(d.statut)?.type || "en-cours";
  const accepte = (d) => typeStatut(d) === "accepte" || (typeStatut(d) === "termine" && (+d.montant_obtenu || 0) > 0);
  const refuse = (d) => typeStatut(d) === "refuse";
  const dateDecision = (d) => d.date_decision || d.statut_depuis || null;
  const decides = (per) => dossiers.filter((d) => (accepte(d) || refuse(d)) && dansPeriode(dateDecision(d), per));
  const decidesP = decides(p);
  const acceptes = decidesP.filter(accepte);
  const refuses = decidesP.filter(refuse);
  const acceptesAvant = decides(p.precedente).filter(accepte);
  const financementTuile = {
    obtenu: somme(acceptes, (d) => d.montant_obtenu),
    acceptes: acceptes.length,
    refuses: refuses.length,
    tauxAcceptation: part(acceptes.length, acceptes.length + refuses.length),
    precedent: { obtenu: somme(acceptesAvant, (d) => d.montant_obtenu), acceptes: acceptesAvant.length },
  };

  // --- Facturation (taxes incluses)
  const totalDe = (f) => f.totaux?.total ?? calculerTotaux(f.lignes, f.taux, f.paiements).total;
  const soldeDe = (f) => f.totaux?.solde ?? calculerTotaux(f.lignes, f.taux, f.paiements).solde;
  const dateEmission = (f) => f.date_emission || dateLocale(f.cree);
  const facturesDe = (per) => factures.filter((f) => dansPeriode(dateEmission(f), per));
  const paiementsDe = (per) => factures.flatMap((f) => (f.paiements || []).filter((x) => dansPeriode(x.date, per)));
  const facturationMois = new Map(p.mois.map((m) => [m, { cle: m, facture: 0, encaisse: 0 }]));
  for (const f of facturesDe(p)) facturationMois.get(dateEmission(f).slice(0, 7)).facture += enCents(totalDe(f));
  for (const x of paiementsDe(p)) facturationMois.get(x.date.slice(0, 7)).encaisse += enCents(x.montant);
  const facturationParMois = [...facturationMois.values()].map((l) => ({ cle: l.cle, facture: enDollars(l.facture), encaisse: enDollars(l.encaisse) }));
  const facturationTuile = {
    facture: somme(facturesDe(p), totalDe),
    encaisse: somme(paiementsDe(p), (x) => x.montant),
    precedente: { facture: somme(facturesDe(p.precedente), totalDe), encaisse: somme(paiementsDe(p.precedente), (x) => x.montant) },
  };

  // --- Situation actuelle (indépendante de la période)
  const probabiliteDe = (a) => (a.probabilite !== undefined && a.probabilite !== null ? +a.probabilite : +(etapes.get(a.etape)?.probabilite ?? 0));
  const ouvertes = affaires.filter((a) => typeEtape(a) === "ouverte");
  const pipelineEtapes = (config.etapes || [])
    .filter((e) => e.type === "ouverte")
    .map((e) => {
      const liste = ouvertes.filter((a) => a.etape === e.id);
      return {
        id: e.id,
        nom: e.nom,
        nombre: liste.length,
        valeur: somme(liste, (a) => a.valeur),
        ponderee: enDollars(Math.round(liste.reduce((n, a) => n + enCents(a.valeur) * (probabiliteDe(a) / 100), 0))),
      };
    });
  const pipeline = {
    etapes: pipelineEtapes,
    nombre: ouvertes.length,
    valeur: somme(ouvertes, (a) => a.valeur),
    ponderee: enDollars(pipelineEtapes.reduce((n, e) => n + enCents(e.ponderee), 0)),
  };

  const enCours = dossiers.filter((d) => ["en-cours", "accepte"].includes(typeStatut(d)));
  const dossiersActuels = {
    statuts: (config.statuts_dossier || [])
      .filter((s) => ["en-cours", "accepte"].includes(s.type))
      .map((s) => {
        const liste = enCours.filter((d) => d.statut === s.id);
        return { id: s.id, nom: s.nom, nombre: liste.length, montant: somme(liste, (d) => d.montant_demande) };
      }),
    nombre: enCours.length,
    montantDemande: somme(enCours, (d) => d.montant_demande),
  };

  const aRecevoir = factures.map((f) => ({ f, etat: etatFacture(f, ref), solde: soldeDe(f) })).filter((x) => ["envoyee", "partielle", "en_retard"].includes(x.etat) && x.solde > 0);
  const recevoir = {
    total: somme(aRecevoir, (x) => x.solde),
    nombre: aRecevoir.length,
    enRetard: somme(aRecevoir.filter((x) => x.etat === "en_retard"), (x) => x.solde),
    nombreEnRetard: aRecevoir.filter((x) => x.etat === "en_retard").length,
  };

  return {
    periode: p,
    tuiles: { demandes: demandesTuile, affaires: affairesTuile, financement: financementTuile, facturation: facturationTuile },
    mois: {
      demandes: [...demandesMois.values()],
      facturation: facturationParMois,
    },
    provenance,
    raisonsPerte,
    actuel: { pipeline, dossiers: dossiersActuels, recevoir },
  };
}
