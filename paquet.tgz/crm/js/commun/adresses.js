// =============================================================================
// Adresses courriel pour l'envoi avec Gmail. Une seule règle, partagée entre l'écran et le serveur :
// on n'accepte que les adresses usuelles (lettres sans accent, chiffres et quelques signes), jamais
// de quoi fabriquer un en-tête de courriel mal formé.
// =============================================================================

/** Partie locale « atext » de la RFC 5322, domaine à étiquettes ASCII. */
export const RE_ADRESSE_ENVOI = /^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]{1,64}@[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)+$/;

/** Destinataires (À + Cc) permis dans un seul courriel. */
export const MAX_DESTINATAIRES = 10;

/** Adresse en minuscules si elle est acceptable, sinon chaîne vide. */
export function adresseValide(s) {
  const v = typeof s === "string" ? s.trim().toLowerCase() : "";
  return v.length <= 254 && v && RE_ADRESSE_ENVOI.test(v) ? v : "";
}

/**
 * Découpe une saisie (« a@x.com, b@y.com ; c@z.com ») en adresses.
 * Accepte aussi la forme copiée d'un logiciel de courriel : « Nom Prénom <a@x.com> ».
 * Retourne { adresses, invalides } : adresses sans doublon, en minuscules ; invalides telles que saisies.
 */
export function separerAdresses(texte) {
  const adresses = [];
  const invalides = [];
  for (const segment of String(texte ?? "").split(/[,;\n]+/)) {
    const s = segment.trim();
    if (!s) continue;
    const entre = /<([^<>]*)>\s*$/.exec(s);
    const morceaux = entre ? [entre[1]] : s.split(/\s+/);
    for (const m of morceaux) {
      const a = adresseValide(m);
      if (!a) invalides.push(m.trim());
      else if (!adresses.includes(a)) adresses.push(a);
    }
  }
  return { adresses, invalides };
}

/** « "Pierre Tremblay" <pierre@x.com> » → { nom: "Pierre Tremblay", adresse: "pierre@x.com" } (nom vide s'il n'y en a pas). */
export function nomEtAdresse(entete) {
  const s = String(entete ?? "").trim();
  const m = /^(.*?)<([^<>]+)>\s*$/.exec(s);
  if (m) return { nom: m[1].trim().replace(/^"+|"+$/g, "").trim(), adresse: m[2].trim().toLowerCase() };
  return { nom: "", adresse: s.toLowerCase() };
}

/** Objet d'une réponse : « Re: » une seule fois, quelle que soit la façon dont l'objet commence (Gmail regroupe ainsi la conversation). */
export function objetReponse(objet) {
  const s = String(objet ?? "").trim();
  if (!s) return "";
  return /^(?:re|réf|ref)\s*:/i.test(s) ? s : `Re: ${s}`.slice(0, 200);
}
