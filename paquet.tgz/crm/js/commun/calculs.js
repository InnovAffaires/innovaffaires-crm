// Calculs financiers : tout se fait en cents entiers, pour éviter les erreurs
// d'arrondi. Utilisé par le serveur (qui a le dernier mot) et par l'interface
// (aperçu en direct).

import { aujourdhui } from "./dates.js";

// toPrecision(15) retire le bruit des nombres à virgule flottante (1,005 × 100 = 100,49999…).
const arrondi = (x) => Math.round(parseFloat((+x || 0).toPrecision(15)));
export const enCents = (dollars) => arrondi((+dollars || 0) * 100);
export const enDollars = (cents) => cents / 100;

/** Taux en pourcentage (5, 9.975) -> centièmes de millième (5000, 9975) pour un calcul entier. */
const tauxEntier = (pct) => Math.round((+pct || 0) * 1000);

/** Taxe arrondie au cent le plus proche (0,5 cent arrondi vers le haut). */
export function taxeEnCents(baseCents, tauxPct) {
  const t = tauxEntier(tauxPct); // 5 % -> 5000 ; 9,975 % -> 9975 (sur 100 000)
  const brut = baseCents * t; // cents × (taux × 1000)
  const signe = brut < 0 ? -1 : 1;
  return signe * Math.floor((Math.abs(brut) + 50000) / 100000);
}

/**
 * Totaux d'une facture ou d'un devis.
 * lignes   : [{ quantite, prix, taxable }]
 * taux     : { tps: 5, tvq: 9.975 }
 * paiements: [{ montant }]
 * Les montants sont retournés en dollars (2 décimales).
 */
export function calculerTotaux(lignes = [], taux = { tps: 5, tvq: 9.975 }, paiements = []) {
  let sousTotal = 0;
  let baseTaxable = 0;
  for (const l of lignes) {
    const c = arrondi((+l.quantite || 0) * enCents(l.prix));
    sousTotal += c;
    if (l.taxable !== false) baseTaxable += c;
  }
  const tps = taxeEnCents(baseTaxable, taux.tps);
  const tvq = taxeEnCents(baseTaxable, taux.tvq);
  const total = sousTotal + tps + tvq;
  const paye = paiements.reduce((n, p) => n + enCents(p.montant), 0);
  return {
    sous_total: enDollars(sousTotal),
    base_taxable: enDollars(baseTaxable),
    tps: enDollars(tps),
    tvq: enDollars(tvq),
    total: enDollars(total),
    paye: enDollars(paye),
    solde: enDollars(total - paye),
  };
}

export const montantLigne = (l) => enDollars(arrondi((+l.quantite || 0) * enCents(l.prix)));

/**
 * État d'affichage d'une facture : tient compte des paiements et de l'échéance.
 * Retourne l'un de : brouillon, envoyee, partielle, payee, en_retard, annulee
 * (factures) ou brouillon, envoyee, acceptee, refusee, expiree (devis).
 */
export function etatFacture(f, ref = aujourdhui()) {
  if (!f) return "brouillon";
  if (f.type === "devis") {
    if (f.statut === "envoyee" && f.date_echeance && f.date_echeance < ref) return "expiree";
    return f.statut || "brouillon";
  }
  if (f.statut === "annulee" || f.statut === "brouillon") return f.statut;
  const t = f.totaux || calculerTotaux(f.lignes, undefined, f.paiements);
  if (t.total > 0 && t.solde <= 0) return "payee";
  if (f.statut === "payee") return "payee";
  if (f.date_echeance && f.date_echeance < ref) return "en_retard";
  if (t.paye > 0) return "partielle";
  return "envoyee";
}

/** Valeur pondérée d'une affaire : valeur × probabilité. */
export const valeurPonderee = (a) => (+a.valeur || 0) * ((+a.probabilite || 0) / 100);

/** Numéro de facture : préfixe + année + séquence sur 4 chiffres (F-2026-0007). */
export const formaterNumero = (prefixe, annee, seq) => `${prefixe}${annee}-${String(seq).padStart(4, "0")}`;
