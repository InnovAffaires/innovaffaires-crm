// Mise en forme en français du Québec (fr-CA). Utilisé par l'interface et par
// le serveur (courriels, exports).

import { aujourdhui, differenceJours } from "./dates.js";

const LANG = "fr-CA";
const fmtArgent = new Intl.NumberFormat(LANG, { style: "currency", currency: "CAD" });
const fmtArgentEntier = new Intl.NumberFormat(LANG, { style: "currency", currency: "CAD", maximumFractionDigits: 0 });
const fmtNombre = new Intl.NumberFormat(LANG);
const fmtDecimal1 = new Intl.NumberFormat(LANG, { minimumFractionDigits: 0, maximumFractionDigits: 1 });
const fmtTaux = new Intl.NumberFormat(LANG, { minimumFractionDigits: 0, maximumFractionDigits: 3 });
const fmtDateCourte = new Intl.DateTimeFormat(LANG, { timeZone: "UTC", day: "numeric", month: "short", year: "numeric" });
const fmtDateLongue = new Intl.DateTimeFormat(LANG, { timeZone: "UTC", weekday: "long", day: "numeric", month: "long", year: "numeric" });
const fmtDateComplete = new Intl.DateTimeFormat(LANG, { timeZone: "UTC", day: "numeric", month: "long", year: "numeric" });
const fmtJourMois = new Intl.DateTimeFormat(LANG, { timeZone: "UTC", day: "numeric", month: "short" });
const fmtMoisAnnee = new Intl.DateTimeFormat(LANG, { timeZone: "UTC", month: "long", year: "numeric" });
const fmtMoisCourt = new Intl.DateTimeFormat(LANG, { timeZone: "UTC", month: "short" });
const fmtJourSemaineCourt = new Intl.DateTimeFormat(LANG, { timeZone: "UTC", weekday: "short" });
const fmtHeure = new Intl.DateTimeFormat(LANG, { timeZone: "America/Toronto", hour: "numeric", minute: "2-digit", hourCycle: "h23" });
const fmtRelatif = new Intl.RelativeTimeFormat(LANG, { numeric: "auto" });

const dateUtc = (s) => new Date(`${s}T00:00:00Z`);

export const argent = (n) => (n === null || n === undefined || n === "" || Number.isNaN(+n) ? "" : fmtArgent.format(+n));
export const argentEntier = (n) => (n === null || n === undefined || n === "" || Number.isNaN(+n) ? "" : fmtArgentEntier.format(+n));
/** 12 500 → « 12,5 k$ » ; 1 200 000 → « 1,2 M$ » (tableaux de bord). */
export function argentCompact(n) {
  const v = +n || 0;
  const a = Math.abs(v);
  if (a >= 1e6) return `${fmtDecimal1.format(v / 1e6)} M$`;
  if (a >= 1e4) return `${fmtDecimal1.format(v / 1e3)} k$`;
  return fmtArgentEntier.format(v);
}
export const nombre = (n) => (n === null || n === undefined || n === "" ? "" : fmtNombre.format(+n));
export const pourcent = (n) => `${fmtDecimal1.format(+n || 0)} %`;
/** Taux de taxe : « 5 % », « 9,975 % » (les décimales comptent). */
export const tauxTaxe = (n) => `${fmtTaux.format(+n || 0)} %`;

export const dateCourte = (s) => (s ? fmtDateCourte.format(dateUtc(s)) : "");
export const dateLongue = (s) => (s ? fmtDateLongue.format(dateUtc(s)) : "");
/** « 15 novembre 2026 » (sans le jour de la semaine : courriels, documents). */
export const dateComplete = (s) => (s ? fmtDateComplete.format(dateUtc(s)) : "");
export const jourMois = (s) => (s ? fmtJourMois.format(dateUtc(s)) : "");
export const moisAnnee = (s) => (s ? fmtMoisAnnee.format(dateUtc(s.length === 7 ? `${s}-01` : s)) : "");
export const moisCourt = (s) => (s ? fmtMoisCourt.format(dateUtc(s.length === 7 ? `${s}-01` : s)) : "");
export const jourSemaineCourt = (s) => (s ? fmtJourSemaineCourt.format(dateUtc(s)) : "");
export const heure = (ms) => (ms ? fmtHeure.format(ms).replace(/\s*[:h]\s*/, "\u00A0h\u00A0") : "");

/** « il y a 3 h », « hier », « dans 2 jours » à partir d'un instant (ms). */
export function ilYa(ms, maintenant = Date.now()) {
  const d = (ms - maintenant) / 1000;
  const a = Math.abs(d);
  if (a < 60) return "à l’instant";
  if (a < 3600) return fmtRelatif.format(Math.round(d / 60), "minute");
  if (a < 86400) return fmtRelatif.format(Math.round(d / 3600), "hour");
  if (a < 86400 * 45) return fmtRelatif.format(differenceJours(aujourdhui(maintenant), aujourdhui(ms)), "day");
  return fmtRelatif.format(Math.round(d / (86400 * 30)), "month");
}

/** Écart d'une date par rapport à aujourd'hui : « aujourd'hui », « demain », « dans 5 jours », « il y a 2 jours ». */
export function echeanceRelative(s, ref = aujourdhui()) {
  if (!s) return "";
  const n = differenceJours(ref, s);
  if (n === 0) return "aujourd’hui";
  return fmtRelatif.format(n, "day");
}

export const pluriel = (n, singulier, plur) => `${fmtNombre.format(n)} ${Math.abs(n) < 2 ? singulier : plur ?? `${singulier}s`}`;

export function telephone(s) {
  if (!s) return "";
  const c = String(s).replace(/\D/g, "");
  const n = c.length === 11 && c[0] === "1" ? c.slice(1) : c;
  return n.length === 10 ? `${n.slice(0, 3)} ${n.slice(3, 6)}-${n.slice(6)}` : String(s);
}

export const nomComplet = (c) => [c?.prenom, c?.nom].filter(Boolean).join(" ").trim();
const SUFFIXES_LEGAUX = new Set(["inc", "inc.", "ltée", "ltee", "ltée.", "ltd", "ltd.", "enr", "enr.", "cie", "co", "co.", "corp", "corp.", "llc", "senc", "sencrl", "s.e.n.c.", "s.e.n.c.r.l."]);
/** Initiales d'un nom de personne (« Isabelle Fournier » → IF) ou d'entreprise (« Atelier Boréal inc. (exemple) » → AB). */
export function initiales(texte) {
  const mots = String(texte || "")
    .replace(/\([^)]*\)/g, " ")
    .trim()
    .split(/\s+/)
    .map((m) => m.replace(/^[^\p{L}\p{N}]+/u, ""))
    .filter((m, i) => m && (i === 0 || !SUFFIXES_LEGAUX.has(m.toLowerCase())));
  if (!mots.length) return "?";
  return ((mots[0][0] || "") + (mots.length > 1 ? mots[mots.length - 1][0] : "")).toUpperCase();
}

/** Texte comparable pour la recherche : sans accents, en minuscules. */
export const normaliser = (s) =>
  String(s ?? "")
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .trim();

export const tronquer = (s, n = 80) => {
  const t = String(s ?? "").replace(/\s+/g, " ").trim();
  return t.length > n ? `${t.slice(0, n - 1).trimEnd()}…` : t;
};
