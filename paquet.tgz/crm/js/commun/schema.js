// =============================================================================
// Schéma des données du CRM : source unique pour le serveur (validation) et
// l'interface (formulaires, tableaux, libellés).
//
// Types de champ : texte, texte_long, courriel, tel, url, nombre, montant,
// pourcent, date, heure, datetime, choix, multi, booleen, ref, liste.
// Un champ « serveur: true » est géré par le serveur et ignoré à l'écriture.
// =============================================================================

// ----- Listes de valeurs fixes -----------------------------------------------
export const REGIONS = [
  ["bas-saint-laurent", "Bas-Saint-Laurent"], ["saguenay-lac-saint-jean", "Saguenay–Lac-Saint-Jean"],
  ["capitale-nationale", "Capitale-Nationale"], ["mauricie", "Mauricie"], ["estrie", "Estrie"], ["montreal", "Montréal"],
  ["outaouais", "Outaouais"], ["abitibi-temiscamingue", "Abitibi-Témiscamingue"], ["cote-nord", "Côte-Nord"],
  ["nord-du-quebec", "Nord-du-Québec"], ["gaspesie-iles-de-la-madeleine", "Gaspésie–Îles-de-la-Madeleine"],
  ["chaudiere-appalaches", "Chaudière-Appalaches"], ["laval", "Laval"], ["lanaudiere", "Lanaudière"],
  ["laurentides", "Laurentides"], ["monteregie", "Montérégie"], ["centre-du-quebec", "Centre-du-Québec"],
  ["hors-quebec", "Hors Québec"],
].map(([id, libelle]) => ({ id, libelle }));

// Mêmes identifiants que le site (data.mjs, SECTEURS).
export const SECTEURS = [
  ["agriculture", "Agriculture et agroalimentaire"], ["arts-culture", "Arts, culture et médias"],
  ["tourisme", "Tourisme et loisirs"], ["environnement-energie", "Environnement et énergie"],
  ["fabrication-technologies", "Fabrication et technologies"], ["commerce-services", "Commerce et services"],
  ["economie-sociale", "Économie sociale et OBNL"], ["municipalites", "Municipalités et organismes publics"],
  ["autre", "Autre secteur"],
].map(([id, libelle]) => ({ id, libelle }));

export const FORMES_JURIDIQUES = [
  ["societe-actions", "Société par actions"], ["entreprise-individuelle", "Entreprise individuelle"],
  ["societe-personnes", "Société en nom collectif ou en commandite"], ["cooperative", "Coopérative"],
  ["obnl", "Organisme à but non lucratif"], ["municipalite", "Municipalité ou organisme public"], ["autre", "Autre"],
].map(([id, libelle]) => ({ id, libelle }));

export const SERVICES = [
  ["consultation", "Consultation initiale"], ["diagnostic", "Diagnostic de financement"],
  ["dossier", "Préparation d’un dossier"], ["suivi", "Suivi et reddition de comptes"], ["autre", "Autre mandat"],
].map(([id, libelle]) => ({ id, libelle }));

export const TYPES_AIDE = [
  ["subvention", "Subvention ou contribution"], ["pret", "Prêt ou garantie"], ["credit", "Crédit d’impôt"],
  ["capital", "Capital ou investissement"], ["accompagnement", "Accompagnement"], ["autre", "Autre"],
].map(([id, libelle]) => ({ id, libelle }));

export const PALIERS = [
  ["federal", "Fédéral"], ["provincial", "Provincial"], ["municipal", "Municipal ou régional"], ["prive", "Privé"],
].map(([id, libelle]) => ({ id, libelle }));

export const RAISONS_PERTE = [
  ["prix", "Honoraires trop élevés"], ["concurrent", "A choisi un autre cabinet"], ["non-admissible", "Projet non admissible"],
  ["sans-reponse", "Plus de nouvelles"], ["reporte", "Projet reporté ou abandonné"], ["autre", "Autre raison"],
].map(([id, libelle]) => ({ id, libelle }));

export const TYPES_TACHE = [
  ["tache", "Tâche"], ["appel", "Appel"], ["courriel", "Courriel"], ["rendezvous", "Rendez-vous"], ["texto", "Texto"],
].map(([id, libelle]) => ({ id, libelle }));

export const PRIORITES = [["haute", "Haute"], ["normale", "Normale"], ["basse", "Basse"]].map(([id, libelle]) => ({ id, libelle }));

export const TYPES_EVENEMENT = [
  ["appel-decouverte", "Appel découverte"], ["rencontre", "Rencontre"], ["visio", "Rencontre virtuelle"],
  ["echeance", "Échéance"], ["autre", "Autre"],
].map(([id, libelle]) => ({ id, libelle }));

export const TYPES_ACTIVITE = [
  ["note", "Note"], ["appel", "Appel"], ["courriel", "Courriel"], ["rencontre", "Rencontre"], ["document", "Document"],
  ["systeme", "Historique"],
].map(([id, libelle]) => ({ id, libelle }));

/** Résultats possibles d'un appel (poste d'appel). Le détail du comportement de chacun est dans appels.js. */
export const RESULTATS_APPEL = [
  ["joint", "Joint — conversation tenue"], ["rdv", "Rendez-vous pris"], ["rappeler", "À rappeler"], ["pas_de_reponse", "Sans réponse"],
  ["message", "Message laissé"], ["pas_interesse", "Pas intéressé"], ["mauvais_numero", "Mauvais numéro"], ["ne_pas_appeler", "Ne plus appeler"],
].map(([id, libelle]) => ({ id, libelle }));

export const MODES_PAIEMENT = [
  ["virement", "Virement bancaire ou Interac"], ["cheque", "Chèque"], ["carte", "Carte de crédit"], ["comptant", "Comptant"],
  ["autre", "Autre"],
].map(([id, libelle]) => ({ id, libelle }));

export const CONSENTEMENTS = [
  ["aucun", "Aucun consentement"], ["demande", "Demande de renseignements (implicite, 6 mois)"],
  ["client", "Relation d’affaires (implicite, 2 ans)"], ["expres", "Consentement exprès"],
].map(([id, libelle]) => ({ id, libelle }));

export const STATUTS_DEMANDE = [
  ["nouveau", "Nouvelle"], ["en-cours", "En traitement"], ["converti", "Convertie"], ["archive", "Archivée"], ["pourriel", "Pourriel"],
].map(([id, libelle]) => ({ id, libelle }));

export const STATUTS_FACTURE = [
  ["brouillon", "Brouillon"], ["envoyee", "Émise"], ["partielle", "Partiellement payée"], ["payee", "Payée"],
  ["en_retard", "En retard"], ["annulee", "Annulée"],
].map(([id, libelle]) => ({ id, libelle }));

export const STATUTS_ENREGISTRES_FACTURE = [
  ["brouillon", "Brouillon"], ["envoyee", "Émise"], ["payee", "Payée"], ["annulee", "Annulée"],
  ["acceptee", "Accepté"], ["refusee", "Refusé"],
].map(([id, libelle]) => ({ id, libelle }));

export const STATUTS_DEVIS = [
  ["brouillon", "Brouillon"], ["envoyee", "Émis"], ["acceptee", "Accepté"], ["refusee", "Refusé"], ["expiree", "Expiré"],
].map(([id, libelle]) => ({ id, libelle }));

export const ROLES = [
  ["admin", "Administrateur"], ["standard", "Utilisateur"], ["lecture", "Lecture seule"],
].map(([id, libelle]) => ({ id, libelle }));

export const LANGUES = [["fr", "Français"], ["en", "Anglais"]].map(([id, libelle]) => ({ id, libelle }));

export const TYPES_LIEN = ["contacts", "entreprises", "opportunites", "dossiers", "factures", "demandes"];

// ----- Constructeurs de champs -----------------------------------------------
const t = (libelle, o = {}) => ({ type: "texte", libelle, max: 200, ...o });
const tl = (libelle, o = {}) => ({ type: "texte_long", libelle, max: 8000, ...o });
const ch = (libelle, options, o = {}) => ({ type: "choix", libelle, options, ...o });
const ref = (libelle, cible, o = {}) => ({ type: "ref", libelle, cible, ...o });
const dt = (libelle, o = {}) => ({ type: "date", libelle, ...o });
const mt = (libelle, o = {}) => ({ type: "montant", libelle, ...o });
const SRV = { serveur: true };

// Champs communs à toutes les fiches (gérés par le serveur).
export const CHAMPS_COMMUNS = {
  id: { type: "texte", libelle: "Identifiant", ...SRV },
  cree: { type: "datetime", libelle: "Créée le", ...SRV },
  maj: { type: "datetime", libelle: "Modifiée le", ...SRV },
  v: { type: "nombre", libelle: "Version", ...SRV },
  par: { type: "texte", libelle: "Créée par", ...SRV },
  maj_par: { type: "texte", libelle: "Modifiée par", ...SRV },
  supprime: { type: "datetime", libelle: "Supprimée le", ...SRV },
  exemple: { type: "booleen", libelle: "Donnée d’exemple", ...SRV },
};

// ----- Entités ---------------------------------------------------------------
// options : tableau [{id, libelle}] ou "config:<liste>" (liste modifiable dans les paramètres)
export const ENTITES = {
  contacts: {
    cle: "contacts", singulier: "contact", pluriel: "contacts", libelle: "Contact", libellePluriel: "Contacts", genre: "m",
    icone: "user",
    champs: {
      prenom: t("Prénom", { max: 80 }),
      nom: t("Nom", { max: 80 }),
      courriel: { type: "courriel", libelle: "Courriel", max: 254 },
      telephone: { type: "tel", libelle: "Téléphone", max: 40 },
      mobile: { type: "tel", libelle: "Cellulaire", max: 40 },
      titre: t("Fonction", { max: 120 }),
      entreprise_id: ref("Entreprise", "entreprises"),
      ville: t("Ville", { max: 80 }),
      langue: ch("Langue", LANGUES, { defaut: "fr" }),
      source: ch("Provenance", "config:sources"),
      consentement: ch("Consentement aux communications", CONSENTEMENTS, { defaut: "aucun" }),
      consentement_date: dt("Date du consentement"),
      etiquettes: { type: "multi", libelle: "Étiquettes" },
      responsable_id: ref("Responsable", "utilisateurs"),
      notes: tl("Notes", { max: 5000 }),
      ne_pas_appeler: { type: "booleen", libelle: "Ne pas appeler", defaut: false },
      ne_pas_appeler_le: { type: "date", libelle: "Inscrit à la liste interne le", ...SRV },
      archive: { type: "booleen", libelle: "Archivé", defaut: false },
      anonymise: { type: "booleen", libelle: "Anonymisé", ...SRV },
    },
    exigeUnDe: ["prenom", "nom", "courriel"],
    messageExigeUnDe: "Indiquez au moins un nom ou un courriel.",
    recherche: ["prenom", "nom", "courriel", "telephone", "mobile", "titre", "ville", "etiquettes", "notes"],
  },

  entreprises: {
    cle: "entreprises", singulier: "entreprise", pluriel: "entreprises", libelle: "Entreprise", libellePluriel: "Entreprises", genre: "f",
    icone: "building",
    champs: {
      nom: t("Nom", { requis: true, max: 160 }),
      neq: { type: "texte", libelle: "NEQ", max: 10, motif: /^\d{10}$/, messageMotif: "Le NEQ compte 10 chiffres." },
      secteur: ch("Secteur", SECTEURS),
      forme: ch("Forme juridique", FORMES_JURIDIQUES),
      employes: { type: "nombre", libelle: "Employés", entier: true, min: 0, max: 100000 },
      annee_fondation: { type: "nombre", libelle: "Année de fondation", entier: true, min: 1800, max: 2100 },
      chiffre_affaires: mt("Chiffre d’affaires annuel", { min: 0 }),
      site_web: { type: "url", libelle: "Site Web", max: 300 },
      telephone: { type: "tel", libelle: "Téléphone", max: 40 },
      adresse: t("Adresse", { max: 200 }),
      ville: t("Ville", { max: 80 }),
      code_postal: t("Code postal", { max: 10 }),
      region: ch("Région administrative", REGIONS),
      source: ch("Provenance", "config:sources"),
      etiquettes: { type: "multi", libelle: "Étiquettes" },
      responsable_id: ref("Responsable", "utilisateurs"),
      notes: tl("Notes", { max: 5000 }),
      ne_pas_appeler: { type: "booleen", libelle: "Ne pas appeler", defaut: false },
      ne_pas_appeler_le: { type: "date", libelle: "Inscrite à la liste interne le", ...SRV },
      archive: { type: "booleen", libelle: "Archivée", defaut: false },
    },
    recherche: ["nom", "neq", "ville", "etiquettes", "notes", "site_web"],
  },

  opportunites: {
    cle: "opportunites", singulier: "affaire", pluriel: "affaires", libelle: "Affaire", libellePluriel: "Affaires", genre: "f",
    icone: "kanban",
    champs: {
      titre: t("Titre", { requis: true, max: 160 }),
      entreprise_id: ref("Entreprise", "entreprises"),
      contact_id: ref("Contact", "contacts"),
      etape: ch("Étape", "config:etapes", { requis: true }),
      service: ch("Service", SERVICES, { defaut: "dossier" }),
      valeur: mt("Honoraires estimés", { min: 0, defaut: 0 }),
      probabilite: { type: "pourcent", libelle: "Probabilité", min: 0, max: 100 },
      date_fermeture_prevue: dt("Fermeture prévue"),
      source: ch("Provenance", "config:sources"),
      raison_perte: ch("Raison de la perte", RAISONS_PERTE),
      responsable_id: ref("Responsable", "utilisateurs"),
      etape_depuis: { type: "date", libelle: "À cette étape depuis", ...SRV },
      fermee_le: { type: "date", libelle: "Fermée le", ...SRV },
      demande_id: { type: "texte", libelle: "Demande d’origine", ...SRV },
      notes: tl("Notes", { max: 5000 }),
    },
    exigeUnDe: ["entreprise_id", "contact_id"],
    messageExigeUnDe: "Associez l’affaire à une entreprise ou à un contact.",
    recherche: ["titre", "notes"],
  },

  dossiers: {
    cle: "dossiers", singulier: "dossier", pluriel: "dossiers", libelle: "Dossier de financement", libellePluriel: "Dossiers de financement", genre: "m",
    icone: "folder",
    champs: {
      titre: t("Titre du dossier", { requis: true, max: 200 }),
      entreprise_id: ref("Entreprise", "entreprises", { requis: true }),
      contact_id: ref("Contact", "contacts"),
      opportunite_id: ref("Affaire liée", "opportunites"),
      programme: t("Programme", { requis: true, max: 200 }),
      organisme: t("Organisme", { max: 200 }),
      palier: ch("Palier", PALIERS),
      type_aide: ch("Type d’aide", TYPES_AIDE),
      statut: ch("Statut", "config:statuts_dossier", { requis: true }),
      montant_demande: mt("Montant demandé", { min: 0 }),
      cout_projet: mt("Coût total du projet", { min: 0 }),
      montant_obtenu: mt("Montant accordé", { min: 0 }),
      date_limite: dt("Date limite de dépôt"),
      date_depot: dt("Déposé le"),
      date_decision_prevue: dt("Décision prévue"),
      date_decision: dt("Décision reçue le"),
      numero_dossier: t("Numéro de dossier (organisme)", { max: 80 }),
      lien_portail: { type: "url", libelle: "Lien du portail de l’organisme", max: 300 },
      raison_refus: tl("Motifs du refus", { max: 3000 }),
      documents: {
        type: "liste", libelle: "Documents à obtenir", maxItems: 80,
        item: {
          id: { type: "texte", libelle: "Identifiant", max: 24 },
          nom: t("Document", { requis: true, max: 200 }),
          recu: { type: "booleen", libelle: "Reçu", defaut: false },
          date_recu: dt("Reçu le"),
          note: t("Note", { max: 300 }),
        },
      },
      responsable_id: ref("Responsable", "utilisateurs"),
      statut_depuis: { type: "date", libelle: "À ce statut depuis", ...SRV },
      notes: tl("Notes", { max: 8000 }),
    },
    recherche: ["titre", "programme", "organisme", "numero_dossier", "notes"],
  },

  taches: {
    cle: "taches", singulier: "tâche", pluriel: "tâches", libelle: "Tâche", libellePluriel: "Tâches", genre: "f",
    icone: "check-square",
    champs: {
      titre: t("Tâche", { requis: true, max: 300 }),
      description: tl("Détails", { max: 3000 }),
      type: ch("Type", TYPES_TACHE, { defaut: "tache" }),
      priorite: ch("Priorité", PRIORITES, { defaut: "normale" }),
      echeance: dt("Échéance"),
      heure: { type: "heure", libelle: "Heure" },
      statut: ch("Statut", [{ id: "a-faire", libelle: "À faire" }, { id: "fait", libelle: "Fait" }], { defaut: "a-faire" }),
      terminee_le: { type: "datetime", libelle: "Terminée le", ...SRV },
      lie_type: ch("Liée à (type)", TYPES_LIEN.map((id) => ({ id, libelle: id }))),
      lie_id: { type: "ref", libelle: "Liée à", cible: "*" },
      responsable_id: ref("Responsable", "utilisateurs"),
      origine: { type: "texte", libelle: "Origine", max: 20, ...SRV },
      gabarit_cle: { type: "texte", libelle: "Gabarit", max: 80, ...SRV },
      gabarit_contact: { type: "texte", libelle: "Gabarit (personne visée)", max: 40, ...SRV },
      essai: { type: "nombre", libelle: "Essai d’appel", entier: true, min: 1, max: 50, ...SRV },
    },
    recherche: ["titre", "description"],
  },

  evenements: {
    cle: "evenements", singulier: "rendez-vous", pluriel: "rendez-vous", libelle: "Rendez-vous", libellePluriel: "Rendez-vous", genre: "m",
    icone: "calendar",
    champs: {
      titre: t("Titre", { requis: true, max: 200 }),
      type: ch("Type", TYPES_EVENEMENT, { defaut: "rencontre" }),
      debut: { type: "datetime", libelle: "Début", requis: true },
      fin: { type: "datetime", libelle: "Fin" },
      journee_entiere: { type: "booleen", libelle: "Toute la journée", defaut: false },
      lieu: t("Lieu ou lien de la rencontre", { max: 300 }),
      lie_type: ch("Liée à (type)", TYPES_LIEN.map((id) => ({ id, libelle: id }))),
      lie_id: { type: "ref", libelle: "Liée à", cible: "*" },
      responsable_id: ref("Responsable", "utilisateurs"),
      notes: tl("Notes", { max: 3000 }),
      // Google Agenda (si la personne responsable a connecté son compte) : options choisies par la personne, lien écrit par le serveur.
      google_meet: { type: "booleen", libelle: "Ajouter un lien de visioconférence Google Meet", defaut: false },
      google_inviter: { type: "booleen", libelle: "Envoyer une invitation Google au contact", defaut: false },
      google_lien: { type: "texte", libelle: "Lien Google Meet", max: 300, ...SRV },
    },
    recherche: ["titre", "lieu", "notes"],
  },

  factures: {
    cle: "factures", singulier: "facture", pluriel: "factures", libelle: "Facture", libellePluriel: "Factures et devis", genre: "f",
    icone: "receipt",
    champs: {
      type: ch("Type", [{ id: "facture", libelle: "Facture" }, { id: "devis", libelle: "Devis" }], { requis: true, defaut: "facture" }),
      numero: { type: "texte", libelle: "Numéro", max: 30, ...SRV },
      // Statuts enregistrés. « Partiellement payée » et « En retard » se déduisent des paiements et de l'échéance.
      statut: ch("Statut", STATUTS_ENREGISTRES_FACTURE, { defaut: "brouillon" }),
      entreprise_id: ref("Client", "entreprises", { requis: true }),
      contact_id: ref("Contact", "contacts"),
      dossier_id: ref("Dossier lié", "dossiers"),
      opportunite_id: ref("Affaire liée", "opportunites"),
      devis_id: { type: "texte", libelle: "Devis d’origine", max: 24, ...SRV },
      objet: t("Objet", { max: 200 }),
      date_emission: dt("Date d’émission"),
      date_echeance: dt("Date d’échéance"),
      conditions: t("Conditions de paiement", { max: 120 }),
      notes: tl("Notes affichées sur le document", { max: 2000 }),
      lignes: {
        type: "liste", libelle: "Lignes", maxItems: 100,
        item: {
          description: t("Description", { requis: true, max: 300 }),
          quantite: { type: "nombre", libelle: "Quantité", min: -100000, max: 100000, defaut: 1 },
          unite: t("Unité", { max: 20 }),
          prix: mt("Prix unitaire", { defaut: 0 }),
          taxable: { type: "booleen", libelle: "Taxable", defaut: true },
        },
      },
      paiements: {
        type: "liste", libelle: "Paiements", maxItems: 100, serveur: true,
        item: {
          id: { type: "texte", libelle: "Identifiant", max: 24 },
          date: dt("Date", { requis: true }),
          montant: mt("Montant", { requis: true }),
          mode: ch("Mode", MODES_PAIEMENT),
          reference: t("Référence", { max: 80 }),
        },
      },
      totaux: { type: "objet", libelle: "Totaux", ...SRV },
      taux: { type: "objet", libelle: "Taux de taxes appliqués", ...SRV },
    },
    recherche: ["numero", "objet", "notes"],
  },

  demandes: {
    cle: "demandes", singulier: "demande", pluriel: "demandes", libelle: "Demande du site", libellePluriel: "Demandes du site", genre: "f",
    icone: "inbox",
    champs: {
      recu: { type: "datetime", libelle: "Reçue le", ...SRV },
      nom: t("Nom", { requis: true, max: 120 }),
      courriel: { type: "courriel", libelle: "Courriel", requis: true, max: 254 },
      telephone: { type: "tel", libelle: "Téléphone", max: 40 },
      organisation: t("Type d’organisation", { max: 120 }),
      projet: tl("Projet", { requis: true, max: 4000 }),
      consentement: { type: "booleen", libelle: "Consentement donné", ...SRV },
      source_page: { type: "texte", libelle: "Page d’origine", max: 200, ...SRV },
      statut: ch("Statut", STATUTS_DEMANDE, { defaut: "nouveau" }),
      traitee_le: { type: "datetime", libelle: "Traitée le", ...SRV },
      reponse_le: { type: "datetime", libelle: "Réponse envoyée le" },
      ne_pas_appeler: { type: "booleen", libelle: "Ne pas appeler", defaut: false },
      ne_pas_appeler_le: { type: "date", libelle: "Inscrite à la liste interne le", ...SRV },
      contact_id: { type: "texte", libelle: "Contact créé", ...SRV },
      entreprise_id: { type: "texte", libelle: "Entreprise créée", ...SRV },
      opportunite_id: { type: "texte", libelle: "Affaire créée", ...SRV },
      notes: tl("Notes", { max: 3000 }),
    },
    recherche: ["nom", "courriel", "organisation", "projet", "notes"],
  },
};

export const NOMS_ENTITES = Object.keys(ENTITES);

/** Activités (journal) : stockées par année, hors des collections ci-dessus. */
export const ACTIVITE = {
  type: ch("Type", TYPES_ACTIVITE, { requis: true }),
  date: { type: "datetime", libelle: "Date", requis: true },
  titre: t("Titre", { max: 200 }),
  texte: tl("Texte", { max: 8000 }),
  direction: ch("Sens", [{ id: "entrant", libelle: "Reçu" }, { id: "sortant", libelle: "Envoyé" }]),
  duree_min: { type: "nombre", libelle: "Durée (minutes)", entier: true, min: 0, max: 1440 },
  resultat: ch("Résultat de l’appel", RESULTATS_APPEL),
  duree_s: { type: "nombre", libelle: "Durée (secondes)", entier: true, min: 0, max: 86400 },
  lie_type: ch("Liée à (type)", TYPES_LIEN.map((id) => ({ id, libelle: id })), { requis: true }),
  lie_id: { type: "ref", libelle: "Liée à", cible: "*", requis: true },
  lie2_type: ch("Aussi liée à (type)", TYPES_LIEN.map((id) => ({ id, libelle: id }))),
  lie2_id: { type: "ref", libelle: "Aussi liée à", cible: "*" },
};

/** Champs que l'API n'accepte jamais en écriture, quelle que soit l'entité. */
export const CHAMPS_SERVEUR = new Set(Object.keys(CHAMPS_COMMUNS));
