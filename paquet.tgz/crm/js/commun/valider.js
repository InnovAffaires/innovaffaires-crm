// Validation et nettoyage des données reçues, d'après le schéma. Fonctionne
// dans le navigateur (messages avant l'envoi) et sur le serveur (qui a le
// dernier mot). Les champs inconnus sont ignorés ; les champs « serveur » aussi.

import { ENTITES, ACTIVITE, CHAMPS_SERVEUR } from "./schema.js";
import { estDateValide } from "./dates.js";
import { estId, nouvelId } from "./ids.js";

const RE_COURRIEL = /^[^\s@<>()[\]\\,;:"]+@[^\s@<>()[\]\\,;:"]+\.[^\s@<>()[\]\\,;:"]{2,}$/;
// Un poste s'écrit « x22 », « #22 », « ,22 », « poste 22 » ou « ext. 22 » (le poste d'appel les comprend tous).
const RE_TEL = /^(?:[\d\s().+\-xX#,]|poste|ext\.?)+$/i;
const RE_HEURE = /^([01]\d|2[0-3]):[0-5]\d$/;
const CTRL = new RegExp("[\\u0000-\\u0008\\u000b\\u000c\\u000e-\\u001f\\u007f\\u2028\\u2029]", "g");

const vide = (v) => v === undefined || v === null || (typeof v === "string" && v.trim() === "");

/** Liste d'options {id, libelle} d'un champ « choix », en tenant compte des listes modifiables. */
export function listeOptions(champ, config) {
  const o = champ.options;
  if (typeof o === "string" && o.startsWith("config:")) {
    const liste = config?.[o.slice(7)];
    return Array.isArray(liste) ? liste.map((x) => ({ id: x.id, libelle: x.libelle ?? x.nom ?? x.id })) : [];
  }
  return o || [];
}

const ok = (valeur) => ({ valeur });
const non = (erreur) => ({ erreur });

/** Valide une valeur selon la spécification d'un champ. Retourne { valeur } ou { erreur }. */
export function validerValeur(spec, brut, ctx = {}) {
  switch (spec.type) {
    case "texte": {
      if (typeof brut !== "string" && typeof brut !== "number") return non("Texte attendu.");
      const s = String(brut).replace(CTRL, "").replace(/\s*[\r\n]+\s*/g, " ").trim();
      if (s.length > (spec.max ?? 200)) return non(`Maximum ${spec.max ?? 200} caractères.`);
      if (spec.motif && s && !spec.motif.test(s)) return non(spec.messageMotif || "Format invalide.");
      return ok(s);
    }
    case "texte_long": {
      if (typeof brut !== "string") return non("Texte attendu.");
      const s = brut.replace(/\r\n?/g, "\n").replace(CTRL, "").replace(/[ \t]+\n/g, "\n").trim();
      if (s.length > (spec.max ?? 8000)) return non(`Maximum ${spec.max ?? 8000} caractères.`);
      return ok(s);
    }
    case "courriel": {
      if (typeof brut !== "string") return non("Courriel invalide.");
      const s = brut.trim().toLowerCase();
      if (s.length > 254 || !RE_COURRIEL.test(s)) return non("Entrez un courriel valide, par exemple nom@exemple.com.");
      return ok(s);
    }
    case "tel": {
      if (typeof brut !== "string" && typeof brut !== "number") return non("Numéro invalide.");
      const s = String(brut).trim();
      if (s.length < 3 || s.length > 40 || !RE_TEL.test(s) || (s.match(/\d/g) || []).length < 7) return non("Entrez un numéro de téléphone valide.");
      return ok(s);
    }
    case "url": {
      if (typeof brut !== "string") return non("Adresse invalide.");
      let s = brut.trim();
      if (s.length > (spec.max ?? 300)) return non(`Maximum ${spec.max ?? 300} caractères.`);
      if (!/^[a-z][a-z0-9+.-]*:/i.test(s) && /^[\w-]+(\.[\w-]+)+(\/.*)?$/.test(s)) s = `https://${s}`;
      try {
        const u = new URL(s);
        if (u.protocol !== "https:" && u.protocol !== "http:") return non("L’adresse doit commencer par https://");
        if (!u.hostname.includes(".") && u.hostname !== "localhost") return non("Adresse invalide.");
        // Une adresse « racine » s'écrit sans barre finale : https://www.exemple.com
        return ok(u.pathname === "/" && !u.search && !u.hash ? u.origin : u.href);
      } catch {
        return non("Adresse invalide, par exemple https://www.exemple.com");
      }
    }
    case "nombre":
    case "montant":
    case "pourcent": {
      if (typeof brut === "string" && !/^-?\d+([.,]\d+)?$/.test(brut.trim())) return non("Entrez un nombre.");
      let n = typeof brut === "string" ? parseFloat(brut.trim().replace(",", ".")) : brut;
      if (typeof n !== "number" || !Number.isFinite(n)) return non("Entrez un nombre.");
      if (spec.type === "montant") n = Math.round(n * 100) / 100;
      if (spec.type === "pourcent") {
        n = Math.round(n * 10) / 10;
        if (n < 0 || n > 100) return non("Entrez un pourcentage entre 0 et 100.");
      }
      if (spec.entier && !Number.isInteger(n)) return non("Entrez un nombre entier.");
      const min = spec.min ?? (spec.type === "montant" ? -1e9 : -1e12);
      const max = spec.max ?? (spec.type === "montant" ? 1e9 : 1e12);
      if (n < min) return non(`La valeur minimale est ${min}.`);
      if (n > max) return non(`La valeur maximale est ${max}.`);
      return ok(n);
    }
    case "date":
      return typeof brut === "string" && estDateValide(brut.trim()) ? ok(brut.trim()) : non("Date invalide (format AAAA-MM-JJ).");
    case "heure":
      return typeof brut === "string" && RE_HEURE.test(brut.trim()) ? ok(brut.trim()) : non("Heure invalide (format HH:MM).");
    case "datetime": {
      const ms = typeof brut === "number" ? brut : typeof brut === "string" ? Date.parse(brut) : NaN;
      if (!Number.isFinite(ms) || ms < Date.UTC(1990, 0, 1) || ms > Date.UTC(2200, 0, 1)) return non("Date et heure invalides.");
      return ok(new Date(ms).toISOString());
    }
    case "choix": {
      const opts = listeOptions(spec, ctx.config);
      if (typeof brut !== "string" || !opts.some((o) => o.id === brut)) return non("Choix invalide.");
      return ok(brut);
    }
    case "multi": {
      const tab = Array.isArray(brut) ? brut : typeof brut === "string" ? brut.split(",") : null;
      if (!tab) return non("Liste attendue.");
      const vus = new Set();
      const sortie = [];
      for (const x of tab) {
        if (typeof x !== "string") return non("Étiquette invalide.");
        const e = x.replace(CTRL, "").replace(/\s+/g, " ").trim();
        if (!e) continue;
        if (e.length > 40) return non("Une étiquette compte au plus 40 caractères.");
        if (!vus.has(e.toLowerCase())) {
          vus.add(e.toLowerCase());
          sortie.push(e);
        }
      }
      if (sortie.length > 30) return non("Au plus 30 étiquettes.");
      return ok(sortie);
    }
    case "booleen": {
      if (brut === true || brut === "true" || brut === 1) return ok(true);
      if (brut === false || brut === "false" || brut === 0) return ok(false);
      return non("Oui ou non attendu.");
    }
    case "ref":
      return estId(brut) ? ok(brut) : non("Référence invalide.");
    case "liste": {
      if (!Array.isArray(brut)) return non("Liste attendue.");
      if (brut.length > (spec.maxItems ?? 100)) return non(`Au plus ${spec.maxItems ?? 100} éléments.`);
      const sortie = [];
      const erreurs = {};
      brut.forEach((el, i) => {
        if (!el || typeof el !== "object" || Array.isArray(el)) {
          erreurs[`${i}`] = "Élément invalide.";
          return;
        }
        const r = validerObjet(spec.item, el, { ...ctx, creation: true });
        for (const [k, m] of Object.entries(r.erreurs)) erreurs[`${i}.${k}`] = m;
        if (spec.item.id && !r.valeur.id) r.valeur.id = nouvelId().slice(0, 12);
        sortie.push(r.valeur);
      });
      return Object.keys(erreurs).length ? { erreur: "Des éléments de la liste sont invalides.", detail: erreurs } : ok(sortie);
    }
    default:
      return non(`Type de champ inconnu : ${spec.type}`);
  }
}

/**
 * Valide un objet selon un ensemble de champs.
 * ctx.creation : applique les valeurs par défaut et exige les champs obligatoires.
 * Sans création (modification partielle), seuls les champs présents sont validés ;
 * une valeur vide (« ») ou null efface le champ (retourné dans `efface`).
 */
export function validerObjet(champs, donnees, ctx = {}) {
  const valeur = {};
  const erreurs = {};
  const efface = [];
  const src = donnees && typeof donnees === "object" && !Array.isArray(donnees) ? donnees : {};
  for (const [nom, spec] of Object.entries(champs)) {
    if (spec.serveur || CHAMPS_SERVEUR.has(nom)) continue;
    const present = Object.hasOwn(src, nom);
    const brut = present ? src[nom] : undefined;
    if (!present || vide(brut) || (spec.type === "multi" && Array.isArray(brut) && brut.length === 0 && !spec.requis)) {
      if (present && !ctx.creation) {
        if (spec.requis) erreurs[nom] = "Ce champ est obligatoire.";
        else efface.push(nom);
        continue;
      }
      if (ctx.creation) {
        if (spec.requis && spec.defaut === undefined) {
          erreurs[nom] = "Ce champ est obligatoire.";
        } else if (spec.defaut !== undefined) {
          valeur[nom] = Array.isArray(spec.defaut) ? [...spec.defaut] : spec.defaut;
        }
      }
      continue;
    }
    const r = validerValeur(spec, brut, ctx);
    if (r.erreur) {
      erreurs[nom] = r.erreur;
      if (r.detail) for (const [k, m] of Object.entries(r.detail)) erreurs[`${nom}.${k}`] = m;
    } else {
      valeur[nom] = r.valeur;
    }
  }
  return { valeur, erreurs, efface };
}

/**
 * Valide une fiche d'une entité. `existant` (modification) sert aux règles qui
 * portent sur plusieurs champs (par exemple « un nom ou un courriel »).
 */
export function validerFiche(nomEntite, donnees, { creation = false, config, existant } = {}) {
  const ent = ENTITES[nomEntite];
  if (!ent) throw new Error(`Entité inconnue : ${nomEntite}`);
  const r = validerObjet(ent.champs, donnees, { creation, config });
  if (ent.exigeUnDe && !Object.keys(r.erreurs).length) {
    const final = { ...(existant || {}), ...r.valeur };
    for (const f of r.efface) delete final[f];
    if (!ent.exigeUnDe.some((f) => !vide(final[f]))) r.erreurs._global = ent.messageExigeUnDe || "Remplissez au moins un des champs requis.";
  }
  return r;
}

export function validerActivite(donnees) {
  const r = validerObjet(ACTIVITE, donnees, { creation: true });
  // Le résultat et la durée précise (poste d'appel) ne concernent que les appels.
  if (r.valeur.type !== "appel") {
    delete r.valeur.resultat;
    delete r.valeur.duree_s;
  }
  return r;
}

/** Valeurs par défaut d'une nouvelle fiche (pour préremplir un formulaire). */
export function valeursParDefaut(nomEntite) {
  const out = {};
  for (const [nom, spec] of Object.entries(ENTITES[nomEntite].champs)) {
    if (spec.defaut !== undefined && !spec.serveur) out[nom] = Array.isArray(spec.defaut) ? [...spec.defaut] : spec.defaut;
  }
  return out;
}
