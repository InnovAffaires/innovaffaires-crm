// =============================================================================
// Point d'entrée de l'API du CRM sur Netlify : toutes les adresses /api/* y
// arrivent (Functions « v2 »). Aucune dépendance à installer.
//
// Les données vivent dans Netlify Blobs (deux coffres du site : « crm-donnees »
// et « crm-auth »). Le contexte du stockage est fourni par Netlify à chaque
// appel : on ouvre donc les coffres à chaque requête (opération sans coût).
// =============================================================================
import { ouvrirMagasinNetlify, lireContexteBlobs } from "./lib/blobs-netlify.mjs";
import { traiter } from "./lib/routes.mjs";
import { reponseJSON } from "./lib/http.mjs";

export default async (req, context) => {
  let donnees;
  let auth;
  try {
    const contexte = lireContexteBlobs();
    donnees = ouvrirMagasinNetlify("crm-donnees", { contexte });
    auth = ouvrirMagasinNetlify("crm-auth", { contexte });
  } catch (e) {
    console.error("[api] stockage indisponible :", e?.message);
    return reponseJSON(
      {
        ok: false,
        code: "stockage",
        erreur: "Le CRM est installé, mais le stockage de Netlify n’est pas accessible depuis cette fonction. Consultez la section « Dépannage » du guide.",
      },
      { statut: 503 }
    );
  }
  return traiter(req, { donnees, auth, env: process.env, contexte: context, nomStockage: "netlify-blobs" });
};

export const config = { path: "/api/*" };
