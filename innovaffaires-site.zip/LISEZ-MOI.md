# Site InnovAffaires — mise en ligne

Déposer le contenu de ce dossier à la racine du site (Netlify : glisser-déposer le dossier ou le pousser dans le dépôt).

## Pages incluses (nouvelle identité visuelle)
index, entreprises, particuliers, a-propos, methodologie, solutions, services, forfait-lancement,
repertoire-subventions (48 programmes), blogue, faq, contact (entreprises), contact-particuliers, merci
+ assets/site.css, assets/favicon.svg

## Deux formulaires de contact
- /contact : portail Entreprises (nom, courriel, téléphone, type d'organisation, forfait Lancement, projet)
- /contact-particuliers : portail Particuliers (type de démarche, organisme concerné, date limite, situation)
Ils utilisent Netlify Forms (attributs data-netlify). Activer les notifications par courriel dans
Netlify > Forms. Si les demandes doivent aller dans le CRM, brancher le formulaire sur le CRM à la place.
Attention : /contact remplace l'ancienne page de contact.

## Pages NON touchées (à conserver telles quelles sur le site actuel)
- /plan-affaires (outil), /confidentialite (texte légal), les 16 articles du blogue (/blogue-...)

## Avant de publier
1. Remplacer le logo approximatif (SVG intégré) par le fichier officiel.
2. Valider les fiches du répertoire (montants, volets ouverts, dates) : elles changent souvent.
